package utility;
public class BPCLogCategory {
	public static void bPCLogCategory(java.lang.String LogCategory, com.ibm.bpe.api.ProcessInstanceData ProcessInstanceData, com.ibm.bpe.api.ActivityInstanceData ActivityInstance, java.lang.String InMessage, commonj.sdo.DataObject aDataObject) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__4 = ActivityInstance.getApplicationName();
		java.lang.String __result__5 = ActivityInstance.getProcessTemplateName();
		java.lang.String __result__6 = ActivityInstance.getProcessInstanceName();
		java.util.logging.Level __result__9 = java.util.logging.Level.INFO;
		__result__1.logCategory(LogCategory, __result__4, __result__5, __result__6, InMessage, aDataObject, __result__9);
	}
}