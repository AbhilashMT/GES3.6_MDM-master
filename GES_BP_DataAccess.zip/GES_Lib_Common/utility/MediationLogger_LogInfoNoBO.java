package utility;
public class MediationLogger_LogInfoNoBO {
	public static void mediationLogger_LogInfoNoBO(com.ibm.wsspi.sibx.mediation.esb.SCAServices SCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MediationServices, java.lang.String LogMsg) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = SCAServices.getModuleName();
		java.lang.String __result__5 = MediationServices.getMediationName();
		java.lang.String __result__6 = MediationServices.getMediationDisplayName();
		__result__1.logInfo(__result__3, __result__5, __result__6, LogMsg);
	}
}