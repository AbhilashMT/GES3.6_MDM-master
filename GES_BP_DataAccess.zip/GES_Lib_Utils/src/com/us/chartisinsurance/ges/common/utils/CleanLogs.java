package com.us.chartisinsurance.ges.common.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.FileFileFilter;
import org.apache.commons.lang3.StringUtils;

import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.GESServicesFormatter;
import com.us.chartisinsurance.ges.logger.SetUpNonRootLogger;
import com.us.chartisinsurance.ges.logger.SetupUtilLogger;

import commonj.sdo.DataObject;

public class CleanLogs {

	public static boolean cleanLogs(DataObject input) {

		String category = input.getString("Category");

		String env = System.getProperty("env");

		String gesRuntime = System.getProperty("ges.runtime");
		String logLocation = "";

		if (null == env || null == gesRuntime || "local".equalsIgnoreCase(env)) {
			logLocation = SetUpNonRootLogger.initProps.getProperty("loc");
		} else {
			logLocation = SetUpNonRootLogger.initProps.getProperty(gesRuntime
					+ ".loc." + env);
		}

		try {

			if (category != null) {

				if (category.equalsIgnoreCase(GESLoggerV4.subSystemName)) {

					String filePattern = SetUpNonRootLogger.initProps
							.getProperty("java.util.logging.FileHandler.pattern."
									+ gesRuntime + "." + env);
					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = SetUpNonRootLogger.initProps
							.getProperty("java.util.logging.FileHandler.pattern."
									+ gesRuntime + "." + env);
					settingNewHandler(category, filePattern, handlerPattern);

				}
				// For PBBI Log category
				if (category.equalsIgnoreCase("PBBI")) {

					String filePattern = logLocation
							+ SetUpNonRootLogger.PBBI_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.PBBI_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);

				}
				// MDM Category
				if (category.equalsIgnoreCase("MDM")) {

					String filePattern = logLocation
							+ SetUpNonRootLogger.MDM_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.MDM_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);
				}
				// EPR Category
				if (category.equalsIgnoreCase("EPR")) {
					String filePattern = logLocation
							+ SetUpNonRootLogger.ENDPOINT_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.ENDPOINT_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);
				}

				// Config Category
				if (category.equalsIgnoreCase("CONFIG")) {

					String filePattern = logLocation
							+ SetUpNonRootLogger.GESSERVLET_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.GESSERVLET_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);
				}
				// Email Roll up
				if (category.equalsIgnoreCase("EMAIL")) {
					String filePattern = logLocation
							+ SetUpNonRootLogger.EMAIL_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.EMAIL_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);
				}
				// Cleansing File

				if (category.equalsIgnoreCase("CLEANSING")) {
					String filePattern = logLocation
							+ SetUpNonRootLogger.GESSCRUBBING_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.GESSCRUBBING_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);
				}
				// MONITOR Logs roll up
				if (category.equalsIgnoreCase("MONITOR")) {
					String filePattern = logLocation
							+ SetUpNonRootLogger.GESMONITOR_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.GESMONITOR_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);
				}

				// DBUPDATE
				if (category.equalsIgnoreCase("DBUPDATE")) {
					String filePattern = logLocation
							+ SetUpNonRootLogger.DBUPDATE_LOG_FILE_NAME;

					filePattern = filePattern.substring(0, filePattern
							.indexOf("%"));

					String handlerPattern = logLocation
							+ SetUpNonRootLogger.DBUPDATE_LOG_FILE_NAME;
					settingNewHandler(category, filePattern, handlerPattern);

				}

				return true;

			}
		} catch (Exception e) {

		}
		return false;
	}

	// Removing the handler and setting up new handler
	public static void settingNewHandler(String category, String filePattern,
			String handlerPattern) throws FileNotFoundException, IOException {

		LogManager logManager = LogManager.getLogManager();
		Logger rootLogger = logManager.getLogger(category);
		// Ret rieveing the handler
		Handler handlers[] = rootLogger.getHandlers();

		for (Handler handler : handlers) {
			if (handler.getClass().getSimpleName().equalsIgnoreCase(
					"FileHandler")) {
				// Detaching the handler

				rootLogger.removeHandler(handler);
				handler.close();
			}
		}

		// Creating a new file
		boolean append = Boolean.valueOf(SetUpNonRootLogger.initProps
				.getProperty("java.util.logging.FileHandler.append").trim());
		int limit = Integer.parseInt(SetUpNonRootLogger.initProps.getProperty(
				"java.util.logging.FileHandler.limit").trim());
		int numLogFiles = Integer.parseInt(SetUpNonRootLogger.initProps
				.getProperty("java.util.logging.FileHandler.count").trim());
		initOutputFiles(filePattern);
		FileHandler handler = new FileHandler(handlerPattern, limit,
				numLogFiles, append);

		handler.setFormatter(new GESServicesFormatter());
		// attaching the handler with main logger file
		rootLogger.addHandler(handler);

	}

	public static void initOutputFiles(String pattern)
			throws FileNotFoundException, IOException {

		// try to find a unique file which is not locked by other process

		int count = 5;

		String fileName = null;
		File[] files = new File[count];
		for (int generation = 0; generation < count; generation++) {
			// cache all file names for rotation use
			files[generation] = new File(pattern + generation + ".log");

		}
		fileName = files[0].getAbsolutePath();

		try {

			for (int i = count - 1; i > 0; i--) {
				{

					System.out.println("File Deleted" + files[i].delete());
				}

				files[i - 1].renameTo(files[i]);

			}
		} catch (Exception e) {

			e.printStackTrace();

		}
		// files[0].createNewFile();

	}

	public static boolean deleteFiles(String aMode) {
		boolean result = false;

		String env = System.getProperty("env");

		String gesRuntime = System.getProperty("ges.runtime");
		String directoryName = "";

		if (null == env || null == gesRuntime || "local".equalsIgnoreCase(env)) {
			directoryName = SetUpNonRootLogger.initProps.getProperty("loc");
		} else {
			directoryName = SetUpNonRootLogger.initProps.getProperty(gesRuntime
					+ ".loc." + env);
		}

		// destroying all loggers before deleting
		SetupUtilLogger.destroyAllLoggers();

		File directory = new File(directoryName);
		Collection<File> fileList = FileUtils.listFiles(directory,
				FileFileFilter.FILE, FileFileFilter.FILE);

		if (fileList != null && fileList.size() > 0) {

			for (File file : fileList) {
				System.out
						.println("file names in directory\n" + file.getName());
				try {

					if (StringUtils.isEmpty(aMode)
							&& StringUtils.isBlank(aMode)) {

						if (StringUtils.indexOf(file.getName(), "_V36") != -1) {

							FileUtils.forceDelete(file);

						}
					} else {

						FileUtils.forceDelete(file);

					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			}

			result = true;
		}
		// Setting up all loggers after deleting
		new SetUpNonRootLogger();

		return result;

	}

}
