/**
 * 
 */
package com.us.chartisinsurance.ges.gateway.utils;

import com.ibm.websphere.http.data.streams.HTTPInputStream;
import com.ibm.websphere.http.headers.HTTPControl;
import com.ibm.websphere.http.headers.HTTPHeaders;
import com.ibm.websphere.http.selectors.HTTPFunctionSelector;
import commonj.connector.runtime.SelectorException;

/**
 * @author ASurendr
 * 
 */
public class AIGFunctionSelectorForHTTP extends HTTPFunctionSelector {

	/**
	 * 
	 */
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public AIGFunctionSelectorForHTTP() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ibm.websphere.http.selectors.HTTPFunctionSelector#generateEISFunctionName
	 * (com.ibm.websphere.http.headers.HTTPControl,
	 * com.ibm.websphere.http.headers.HTTPHeaders,
	 * com.ibm.websphere.http.data.streams.HTTPInputStream)
	 */
	@Override
	public String generateEISFunctionName(HTTPControl arg0, HTTPHeaders arg1,
			HTTPInputStream arg2) throws SelectorException {
		// TODO Auto-generated method stub
		

		String methodName = "requestResponse";
		return methodName;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
