package com.us.chartisinsurance.ges.logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;

public class SuspectsLogFormatter {

	/**
	 * @param args
	 */

	private static final String RecordHeader = "Date|SovLocationId|MDMContractId|MDMContractComponentId|MDMHoldingId|MDMAddressId|MDMSource|MatchResult";
	private static final String DateFormatPattern = "yyyy-MM-dd'T'HH:mm:ss.SSSz";

	private static final SimpleDateFormat DateFormat = new SimpleDateFormat(
			DateFormatPattern);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static String getHeaderEntry() {

		StringBuffer sBuffer = new StringBuffer();

		sBuffer.append(RecordHeader + "\n");

		return sBuffer.toString();

	}

	public static String getFormattedMessage(String sovLocId,
			String MDMContractId, String MDMContractComponentId,
			String MDMHoldingId, String MDMAddressId, String MDMSource,String aMatchResult) {

		StringBuffer sBuffer = new StringBuffer();
		String[] searchList = StringUtils.split(RecordHeader, "|");

		String[] inputReplacementList = {
				DateFormat.format(Calendar.getInstance().getTime()), sovLocId,
				MDMContractId, MDMContractComponentId, MDMHoldingId,
				MDMAddressId, MDMSource,aMatchResult };

		sBuffer.append(StringUtils.replaceEach(RecordHeader, searchList,
				inputReplacementList)
				+ "\n");

		return sBuffer.toString();
	}
	
	

}
