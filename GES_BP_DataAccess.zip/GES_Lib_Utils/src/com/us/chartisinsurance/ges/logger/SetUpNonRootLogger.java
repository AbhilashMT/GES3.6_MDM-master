/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

/**
 * @author M1019070
 * 
 */

public class SetUpNonRootLogger {

	/**
	 * 
	 */

	public static final String PBBI_LOG_FILE_NAME = "PBBIXtremeLogger_V36_%g.log";
	public static final String MDM_LOG_FILE_NAME = "MDMXtremeLogger_V36_%g.log";
	public static final String DBUPDATE_LOG_FILE_NAME = "DBUPDXtremeLogger_V36_%g.log";
	public static final String EMAIL_LOG_FILE_NAME = "EMAILXtremeLogger_V36_%g.log";
	public static final String ENDPOINT_LOG_FILE_NAME = "ChartisEPR_V36_%g.log";
	public static final String MATCH_LOG_FILE_NAME = "MatchConfig_V36.log";
	public static final String GESSERVLET_LOG_FILE_NAME = "GESConfigXtremeLogger_V36_%g.log";
	public static final String GESSCRUBBING_LOG_FILE_NAME = "GESCleansing_V36_%g.log";
	public static final String GESMONITOR_LOG_FILE_NAME = "GESMonitor_V36_%g.log";
	public static final String GESSUSPECTLOGGER_LOG_FILE_NAME = "GESSuspectLogger_V36_%g.log";
	public static final String OTHER_LOG_FILE_NAME = "XtremeLogger_V36_%g.log";
	private static final int limit = 20000000;
	private static final int count = 5;
	public static Properties initProps = new Properties();
	private static final String env = System.getProperty("env");
	private static final String gesRuntime = System.getProperty("ges.runtime");
	private static final LogManager logManager = LogManager.getLogManager();
	static {
		try {
			initProps
					.load(SetupUtilLogger.class
							.getResourceAsStream("/com/us/chartisinsurance/ges/logger/logger.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getLogLocation() {
		String logLocation = "";

		if (null == env || null == gesRuntime) {
			logLocation = initProps.getProperty("loc");
		} else {
			logLocation = initProps.getProperty(gesRuntime + ".loc." + env);
		}

		return logLocation;
	}

	public SetUpNonRootLogger() {

		// This place will be used to set up all Loggers

		String customLoggerNames = initProps.getProperty("custom.loggers.init");
		String logLocation = "";

		if (null == env || null == gesRuntime) {
			logLocation = initProps.getProperty("loc");
		} else {
			logLocation = initProps.getProperty(gesRuntime + ".loc." + env);
		}

		System.out.println(" Log Location  = " + logLocation
				+ " Custom Logger Names : " + customLoggerNames);

		String[] customLoggerList = StringUtils.split(customLoggerNames, ",");
		Level logLevel = Level.parse(initProps.getProperty(".level"));

		if (null == env || "local".equalsIgnoreCase(env)
				|| "dev".equalsIgnoreCase(env)) {
			logLevel = Level.INFO;

		}
		System.out.println(" Log Level configured for " + env + " is "
				+ logLevel.getLocalizedName());
		for (int i = 0; i < customLoggerList.length; ++i) {
			Logger cLogger = logManager.getLogger(customLoggerList[i]);
			if (null == cLogger) {
				cLogger = Logger.getLogger(customLoggerList[i]);
				System.out.println(" Logger " + customLoggerList[i]
						+ " is not registered hence created via Logger");
			}
			String loggerName = customLoggerList[i].trim();

			if ("PBBI".equalsIgnoreCase(loggerName)) {

				try {

					FileHandler fileHandler = new FileHandler(logLocation
							+ PBBI_LOG_FILE_NAME, limit, count, true);
					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("MDM".equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ MDM_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("EPR".equalsIgnoreCase(loggerName)) {

				try {

					FileHandler fileHandler = new FileHandler(logLocation
							+ ENDPOINT_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("CONFIG".equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ GESSERVLET_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("EMAIL".equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ EMAIL_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("CLEANSING".equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ GESSCRUBBING_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);

					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("MONITOR".equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ GESMONITOR_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("DBUPDATE".equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ DBUPDATE_LOG_FILE_NAME, limit, count, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("MATCHCONFIG".equalsIgnoreCase(loggerName)) {
				setUpMatchLogger();
			} else if (GESLoggerV4.subSystemName.equalsIgnoreCase(loggerName)) {

				try {
					FileHandler fileHandler = new FileHandler(
							initProps
									.getProperty("java.util.logging.FileHandler.pattern."
											+ gesRuntime + "." + env),
							20000000, 5, true);

					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());
					fileHandler.setLevel(logLevel);
					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else if ("SUSPECTS".equalsIgnoreCase(loggerName))

			{
				setUpSuspectLogger();
			} else {

				try {
					FileHandler fileHandler = new FileHandler(logLocation
							+ loggerName + OTHER_LOG_FILE_NAME, true);
					cLogger.setLevel(logLevel);
					fileHandler.setFormatter(new GESServicesFormatter());

					cLogger.setUseParentHandlers(false);
					cLogger.addHandler(fileHandler);

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			System.out.println(" Custom Logger Name : " + loggerName
					+ " Created");
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void setUpMatchLogger() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		Logger cLogger = Logger.getLogger(LogCategory.MATCH);
		String dateRepresentation = dateFormat.format(Calendar.getInstance(
				TimeZone.getTimeZone("UTC")).getTime());
		String fileName = getLogLocation() + dateRepresentation + "_"
				+ MATCH_LOG_FILE_NAME;
		FileHandler fileHandler;
		try {
			fileHandler = new FileHandler(fileName, true);
			cLogger.setLevel(Level.INFO);
			fileHandler.setFormatter(new GESMatchLoggerFormatter());
			fileHandler.setLevel(Level.INFO);
			cLogger.setUseParentHandlers(false);
			cLogger.addHandler(fileHandler);

			System.out
					.println("Match Logger Cofigured with : Params , Level  "
							+ cLogger.getLevel().getName() + " logLocation "
							+ fileName);
			cLogger.log(Level.INFO, MatchLogFormatter.getHeaderEntry() + "\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void setUpSuspectLogger() {
		// SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		Logger cLogger = Logger.getLogger(LogCategory.SUSPECTS);

		String fileName = getLogLocation() + GESSUSPECTLOGGER_LOG_FILE_NAME;
		FileHandler fileHandler;
		try {
			fileHandler = new FileHandler(fileName, true);
			cLogger.setLevel(Level.INFO);
			fileHandler.setFormatter(new GESMatchLoggerFormatter()); // Both
																		// Suspects
																		// and
																		// Match
																		// Logger
																		// Formats
																		// are
																		// same
																		// .
																		// hence
																		// using
																		// the
																		// same
																		// formatter
																		// class
			fileHandler.setLevel(Level.INFO);
			cLogger.setUseParentHandlers(false);
			cLogger.addHandler(fileHandler);

			System.out
					.println("Suspect Logger Cofigured with : Params , Level  "
							+ cLogger.getLevel().getName() + " logLocation "
							+ fileName);
			cLogger.log(Level.INFO, SuspectsLogFormatter.getHeaderEntry()
					+ "\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
