package com.us.chartisinsurance.ges.db.utils;

public interface QueryAccessBundle {

	public static final String SovLocationFetchbyVersion = "SovLocationFetchbyVersion";
	public static final String EsbCrossReferenceFetchbyVersion = "EsbCrossReferenceFetchbyVersion";
	public static final String SovLocationIdByDuration = "SovLocationIdByDuration";
	public static final String PBBIConfigQuery = "PBBIConfigQuery";
	public static final String UpdateStatusBySovVersionId = "UpdateStatusBySovVersionId";
	public static final String UpdateStatusBySovLocationId = "UpdateStatusBySovLocationId";
	public static final String GetScrubbingDurationInSeconds = "getScrubbingDuration";
	public static final String GetMatchConfig = "getLocationDeDupeConfig";
	public static final String GetCopeConfig = "getLocationCopeConfig";
	public static final String GetCacheConfig = "getCacheConfig";
	public static final String GetSetUpCacheConfig = "getSetUpCacheConfig";

}
