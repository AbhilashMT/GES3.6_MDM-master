package com.us.aig.ges.dataobject.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.eclipse.emf.ecore.xmi.XMIResource;

import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.sdo.DataFactory;
import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;

/**
 * @author M1019070
 * 
 */

public class CreateAndSetTargetBO {

	// final static String boXMLString =
	// "<lexp:GetAccountsRs xmlns=\"http://aig.us.com/ges/common/v3\" xmlns:lexp=\"http://aig.us.com/ges/ext/LocationExposureServiceV3\" xmlns:ch=\"http://aig.com/CommonHeaderV12\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://aig.us.com/ges/ext/LocationExposureServiceV3 file:/D:/ResearchWork/MonitorProcess/GES_Lib_SchemaV3/schemas/LocationExposureServiceV3.xsd\"><PageIndex>-1073741773</PageIndex><TotalResultsAvailable>0</TotalResultsAvailable><BulkMode>false</BulkMode><SourceSystemCd><SourceSystemCode>GPW</SourceSystemCode><SourceSystemkey>SourceSystemkey0</SourceSystemkey></SourceSystemCd><Accounts><AccountDetails><GESAccountId>GESAccountId0</GESAccountId><AccountNumberId>AccountNumberId0</AccountNumberId><AccountNm>AccountNm0</AccountNm><AccountTypeCd>AccountTypeCd0</AccountTypeCd><AccountCd><DNBNo>DNBNo0</DNBNo><ShellAccountNo>ShellAccountNo0</ShellAccountNo></AccountCd><HQAccountId>HQAccountId0</HQAccountId><ParentAccountId>ParentAccountId0</ParentAccountId><DNBNm>DNBNm0</DNBNm><DNBNo>DNBNo1</DNBNo><HQDNbNo>HQDNbNo0</HQDNbNo><TopHQDnb>TopHQDnb0</TopHQDnb><ParentDNBNo>ParentDNBNo0</ParentDNBNo><RevisedDNBNo>RevisedDNBNo0</RevisedDNBNo><UltimateDnBNo>UltimateDnBNo0</UltimateDnBNo><NationalId>NationalId0</NationalId><NationalIdDesc>NationalIdDesc0</NationalIdDesc><NationalIdVal>NationalIdVal0</NationalIdVal><SICId>SICId0</SICId><AccountAddress>AccountAddress0</AccountAddress><AcctCity>AcctCity0</AcctCity><AcctState><Code>Code0</Code><Value>Value0</Value></AcctState><AcctZip>AcctZip0</AcctZip><AcctCountry><Code>Code1</Code><Value>Value1</Value></AcctCountry><FEINNo>FEINNo0</FEINNo><IsAccountActv>IsAccountActv0</IsAccountActv><MarketSegment><Code>Code2</Code><Value>Value2</Value></MarketSegment><LOB><Code>Code3</Code><Value>Value3</Value></LOB><CreatedBy>CreatedBy0</CreatedBy><WorkingBranch><Code>Code4</Code><Value>Value4</Value></WorkingBranch><PolicyPackID>PolicyPackID0</PolicyPackID><InsuredAddress>InsuredAddress0</InsuredAddress><GraspReviewed>GraspReviewed0</GraspReviewed><NoOfLocations>-1073741773</NoOfLocations><CurrencyCode>USD</CurrencyCode><GESChangeRequestId>GESChangeRequestId0</GESChangeRequestId><AccountRiskRtngFire>0</AccountRiskRtngFire><AccountRiskRtngCat>0</AccountRiskRtngCat><AccountRiskRtngCompSt>0</AccountRiskRtngCompSt><AccountPD>0</AccountPD><AccountBI>0</AccountBI><AccountTIV>0</AccountTIV><UnderWriters><UnderWriter><UWNm>UWNm0</UWNm><UWId>UWId0</UWId><UWEmpId>UWEmpId0</UWEmpId><UWCountry/><UWRegion/><UWBranch/><UWMaxLayerPercent>0</UWMaxLayerPercent><UWCapacity/><UWCountryCodeIso3/><UWBranchCode>UWBranchCode0</UWBranchCode></UnderWriter><UnderWriter><UWNm>UWNm1</UWNm><UWId>UWId1</UWId><UWEmpId>UWEmpId1</UWEmpId><UWCountry/><UWRegion/><UWBranch/><UWMaxLayerPercent>0</UWMaxLayerPercent><UWCapacity/><UWCountryCodeIso3/><UWBranchCode>UWBranchCode1</UWBranchCode></UnderWriter></UnderWriters><Policies><PolicyDetail><PolicyNo>PolicyNo0</PolicyNo><GesPolicyId>GesPolicyId0</GesPolicyId><PolicyInceptionDate>2006-05-04</PolicyInceptionDate><PolicyExpiryDate>2006-05-04</PolicyExpiryDate><PolicyStatus/><TxType/><PolicyTyp/><ProductCd/><LegalEntityCd/><ProductLine/><SubmissionNo>SubmissionNo0</SubmissionNo><MajorLine/><CreditedBranchOffice/><MinorLine/><WorkingBranch/><ProducerInfo><ProducerNm>ProducerNm0</ProducerNm></ProducerInfo><UWRiskGrpId>0</UWRiskGrpId><UWRiskGrpNm>UWRiskGrpNm0</UWRiskGrpNm><InsuredNm>InsuredNm0</InsuredNm><AssociateEngNm>AssociateEngNm0</AssociateEngNm><PerilClass/><ProfitUnitCode/><TxEffectiveDt>2006-05-04</TxEffectiveDt><CurrencyCode>USD</CurrencyCode><CurrencyDesc>CurrencyDesc0</CurrencyDesc><PrimarySICCd/><LastUpdatedTs>2006-05-04T18:13:51.0</LastUpdatedTs><UnderWriter/><CreatedBy>CreatedBy1</CreatedBy><PolicyTIV/><SectionCd/><PolicyPD/><PolicyBI/><PolicyLimit/><ChartisLimit/><PolicyOption><PolicyOptionId>PolicyOptionId0</PolicyOptionId></PolicyOption><PolicyOption><PolicyOptionId>PolicyOptionId1</PolicyOptionId></PolicyOption></PolicyDetail><PolicyDetail><PolicyNo>PolicyNo1</PolicyNo><GesPolicyId>GesPolicyId1</GesPolicyId><PolicyInceptionDate>2006-05-04</PolicyInceptionDate><PolicyExpiryDate>2006-05-04</PolicyExpiryDate><PolicyStatus/><TxType/><PolicyTyp/><ProductCd/><LegalEntityCd/><ProductLine/><SubmissionNo>SubmissionNo1</SubmissionNo><MajorLine/><CreditedBranchOffice/><MinorLine/><WorkingBranch/><ProducerInfo><ProducerNm>ProducerNm1</ProducerNm></ProducerInfo><UWRiskGrpId>0</UWRiskGrpId><UWRiskGrpNm>UWRiskGrpNm1</UWRiskGrpNm><InsuredNm>InsuredNm1</InsuredNm><AssociateEngNm>AssociateEngNm1</AssociateEngNm><PerilClass/><ProfitUnitCode/><TxEffectiveDt>2006-05-04</TxEffectiveDt><CurrencyCode>USD</CurrencyCode><CurrencyDesc>CurrencyDesc1</CurrencyDesc><PrimarySICCd/><LastUpdatedTs>2006-05-04T18:13:51.0</LastUpdatedTs><UnderWriter/><CreatedBy>CreatedBy2</CreatedBy><PolicyTIV/><SectionCd/><PolicyPD/><PolicyBI/><PolicyLimit/><ChartisLimit/><PolicyOption><PolicyOptionId>PolicyOptionId2</PolicyOptionId></PolicyOption><PolicyOption><PolicyOptionId>PolicyOptionId3</PolicyOptionId></PolicyOption></PolicyDetail></Policies></AccountDetails><AccountDetails><GESAccountId>GESAccountId1</GESAccountId><AccountNumberId>AccountNumberId1</AccountNumberId><AccountNm>AccountNm1</AccountNm><AccountTypeCd>AccountTypeCd1</AccountTypeCd><AccountCd><DNBNo>DNBNo2</DNBNo><ShellAccountNo>ShellAccountNo1</ShellAccountNo></AccountCd><HQAccountId>HQAccountId1</HQAccountId><ParentAccountId>ParentAccountId1</ParentAccountId><DNBNm>DNBNm1</DNBNm><DNBNo>DNBNo3</DNBNo><HQDNbNo>HQDNbNo1</HQDNbNo><TopHQDnb>TopHQDnb1</TopHQDnb><ParentDNBNo>ParentDNBNo1</ParentDNBNo><RevisedDNBNo>RevisedDNBNo1</RevisedDNBNo><UltimateDnBNo>UltimateDnBNo1</UltimateDnBNo><NationalId>NationalId1</NationalId><NationalIdDesc>NationalIdDesc1</NationalIdDesc><NationalIdVal>NationalIdVal1</NationalIdVal><SICId>SICId1</SICId><AccountAddress>AccountAddress1</AccountAddress><AcctCity>AcctCity1</AcctCity><AcctState><Code>Code5</Code><Value>Value5</Value></AcctState><AcctZip>AcctZip1</AcctZip><AcctCountry><Code>Code6</Code><Value>Value6</Value></AcctCountry><FEINNo>FEINNo1</FEINNo><IsAccountActv>IsAccountActv1</IsAccountActv><MarketSegment><Code>Code7</Code><Value>Value7</Value></MarketSegment><LOB><Code>Code8</Code><Value>Value8</Value></LOB><CreatedBy>CreatedBy3</CreatedBy><WorkingBranch><Code>Code9</Code><Value>Value9</Value></WorkingBranch><PolicyPackID>PolicyPackID1</PolicyPackID><InsuredAddress>InsuredAddress1</InsuredAddress><GraspReviewed>GraspReviewed1</GraspReviewed><NoOfLocations>-1073741773</NoOfLocations><CurrencyCode>USD</CurrencyCode><GESChangeRequestId>GESChangeRequestId1</GESChangeRequestId><AccountRiskRtngFire>0</AccountRiskRtngFire><AccountRiskRtngCat>0</AccountRiskRtngCat><AccountRiskRtngCompSt>0</AccountRiskRtngCompSt><AccountPD>0</AccountPD><AccountBI>0</AccountBI><AccountTIV>0</AccountTIV><UnderWriters><UnderWriter><UWNm>UWNm2</UWNm><UWId>UWId2</UWId><UWEmpId>UWEmpId2</UWEmpId><UWCountry/><UWRegion/><UWBranch/><UWMaxLayerPercent>0</UWMaxLayerPercent><UWCapacity/><UWCountryCodeIso3/><UWBranchCode>UWBranchCode2</UWBranchCode></UnderWriter><UnderWriter><UWNm>UWNm3</UWNm><UWId>UWId3</UWId><UWEmpId>UWEmpId3</UWEmpId><UWCountry/><UWRegion/><UWBranch/><UWMaxLayerPercent>0</UWMaxLayerPercent><UWCapacity/><UWCountryCodeIso3/><UWBranchCode>UWBranchCode3</UWBranchCode></UnderWriter></UnderWriters><Policies><PolicyDetail><PolicyNo>PolicyNo2</PolicyNo><GesPolicyId>GesPolicyId2</GesPolicyId><PolicyInceptionDate>2006-05-04</PolicyInceptionDate><PolicyExpiryDate>2006-05-04</PolicyExpiryDate><PolicyStatus/><TxType/><PolicyTyp/><ProductCd/><LegalEntityCd/><ProductLine/><SubmissionNo>SubmissionNo2</SubmissionNo><MajorLine/><CreditedBranchOffice/><MinorLine/><WorkingBranch/><ProducerInfo><ProducerNm>ProducerNm2</ProducerNm></ProducerInfo><UWRiskGrpId>0</UWRiskGrpId><UWRiskGrpNm>UWRiskGrpNm2</UWRiskGrpNm><InsuredNm>InsuredNm2</InsuredNm><AssociateEngNm>AssociateEngNm2</AssociateEngNm><PerilClass/><ProfitUnitCode/><TxEffectiveDt>2006-05-04</TxEffectiveDt><CurrencyCode>USD</CurrencyCode><CurrencyDesc>CurrencyDesc2</CurrencyDesc><PrimarySICCd/><LastUpdatedTs>2006-05-04T18:13:51.0</LastUpdatedTs><UnderWriter/><CreatedBy>CreatedBy4</CreatedBy><PolicyTIV/><SectionCd/><PolicyPD/><PolicyBI/><PolicyLimit/><ChartisLimit/><PolicyOption><PolicyOptionId>PolicyOptionId4</PolicyOptionId></PolicyOption><PolicyOption><PolicyOptionId>PolicyOptionId5</PolicyOptionId></PolicyOption></PolicyDetail><PolicyDetail><PolicyNo>PolicyNo3</PolicyNo><GesPolicyId>GesPolicyId3</GesPolicyId><PolicyInceptionDate>2006-05-04</PolicyInceptionDate><PolicyExpiryDate>2006-05-04</PolicyExpiryDate><PolicyStatus/><TxType/><PolicyTyp/><ProductCd/><LegalEntityCd/><ProductLine/><SubmissionNo>SubmissionNo3</SubmissionNo><MajorLine/><CreditedBranchOffice/><MinorLine/><WorkingBranch/><ProducerInfo><ProducerNm>ProducerNm3</ProducerNm></ProducerInfo><UWRiskGrpId>0</UWRiskGrpId><UWRiskGrpNm>UWRiskGrpNm3</UWRiskGrpNm><InsuredNm>InsuredNm3</InsuredNm><AssociateEngNm>AssociateEngNm3</AssociateEngNm><PerilClass/><ProfitUnitCode/><TxEffectiveDt>2006-05-04</TxEffectiveDt><CurrencyCode>USD</CurrencyCode><CurrencyDesc>CurrencyDesc3</CurrencyDesc><PrimarySICCd/><LastUpdatedTs>2006-05-04T18:13:51.0</LastUpdatedTs><UnderWriter/><CreatedBy>CreatedBy5</CreatedBy><PolicyTIV/><SectionCd/><PolicyPD/><PolicyBI/><PolicyLimit/><ChartisLimit/><PolicyOption><PolicyOptionId>PolicyOptionId6</PolicyOptionId></PolicyOption><PolicyOption><PolicyOptionId>PolicyOptionId7</PolicyOptionId></PolicyOption></PolicyDetail></Policies></AccountDetails></Accounts><Errors><Error><ErrorCd>ErrorCd0</ErrorCd><ErrorMsg>ErrorMsg0</ErrorMsg><ErrorTyp>ErrorTyp0</ErrorTyp><ErrorDesc>ErrorDesc0</ErrorDesc><ErrorDetails>ErrorDetails0</ErrorDetails></Error><Error><ErrorCd>ErrorCd1</ErrorCd><ErrorMsg>ErrorMsg1</ErrorMsg><ErrorTyp>ErrorTyp1</ErrorTyp><ErrorDesc>ErrorDesc1</ErrorDesc><ErrorDetails>ErrorDetails1</ErrorDetails></Error></Errors></lexp:GetAccountsRs>";
	final static GESLoggerV4 CreateAndSetTargetBOLogger = GESLoggerFactory
			.getLogger();
	final static String CreateAndSetTargetBO_CLASS = CreateAndSetTargetBO.class
			.getName();
	final static String CreateAndSetTargetBO_CLASSSHORT = CreateAndSetTargetBO.class
			.getSimpleName();

	/**
	 * 
	 */
	public CreateAndSetTargetBO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	// 0,2
	public static ServiceMessageObject constructAndPopulateSMO(
			String aSMOQName, String aSMOMessageName, String aIndexes,
			String aBOXMLString) throws Exception

	{

		StopWatch sw = new StopWatch();
		sw.start();
		CreateAndSetTargetBOLogger.entering(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
				"constructAndPopulateSMO", "Supplied params : QName : "
						+ aSMOQName + " Message : " + aSMOMessageName
						+ " supplied Indexes : " + aIndexes);
		ServiceMessageObject targetDO = null;
		ServiceMessageObjectFactory smoFactory = ServiceMessageObjectFactory.INSTANCE;

		targetDO = smoFactory.createServiceMessageObject(aSMOQName,
				aSMOMessageName);

		if (null != targetDO) {
			DataObject body = targetDO.getDataObject("body");

			scanBO(body, aIndexes, aBOXMLString);

		}

		CreateAndSetTargetBOLogger.logInfo(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
				"constructAndPopulateSMO", "Supplied params : QName : "
						+ aSMOQName + " Message : " + aSMOMessageName
						+ " supplied Indexes : " + aIndexes, targetDO);
		sw.stop();
		CreateAndSetTargetBOLogger.exiting(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
				"constructAndPopulateSMO", "Supplied params : QName : "
						+ aSMOQName + " Message : " + aSMOMessageName
						+ " supplied Indexes : " + aIndexes + " Time Taken : "
						+ sw.getTime());

		return targetDO;
	}

	public static DataObject constructAndPopulateDO(String boTypeURI,
			String boType, boolean isCopy, DataObject inBO, String aIndexes,
			String aBOXMLString) throws Exception {
		CreateAndSetTargetBOLogger.entering(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
				"constructAndPopulateDO", "Supplied params : boTypeURI : "
						+ boTypeURI + " boType : " + boType + " IsCopy ? "
						+ isCopy + "supplied Indexes : " + aIndexes, inBO);

		DataObject outBO = null;

		if (isCopy) {
			outBO = inBO;
		} else {
			outBO = DataFactory.INSTANCE.create(boTypeURI, boType);
			if (null == outBO) {

				String errMsg = " Please check the BO Namespace & Name : Supplied BO Name : "
						+ boType + " URI for the BO is : " + boTypeURI;

				CreateAndSetTargetBOLogger.logSevere(
						CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
						CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
						"constructAndPopulateDO",
						"Supplied params : boTypeURI : " + boTypeURI
								+ " boType : " + boType + " IsCopy ? " + isCopy
								+ "supplied Indexes : " + aIndexes
								+ " Error : " + errMsg);
				throw new ServiceBusinessException(errMsg);
			}
		}

		scanBO(outBO, aIndexes, aBOXMLString);

		CreateAndSetTargetBOLogger.exiting(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
				"constructAndPopulateDO", "Supplied params : boTypeURI : "
						+ boTypeURI + " boType : " + boType + " IsCopy ? "
						+ isCopy + "supplied Indexes : " + aIndexes, outBO);

		return outBO;
	}

	public static void scanBO(DataObject aDataObject, String aIndexes,
			String aBOXMLString) throws Exception {

		CreateAndSetTargetBOLogger.entering(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT, "scanBO",
				"Supplied Indexes : " + aIndexes + " DataObject Provided ",
				aDataObject);

		String preString = StringUtils.substringBefore(aIndexes, ",");
		CreateAndSetTargetBOLogger.logInfo(
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
				CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT, "scanBO",
				"Before Index : " + preString + " Supplied DataObject : ",
				aDataObject);

		try {

			List<Property> boProperties = aDataObject.getInstanceProperties();
			int totalProperties = boProperties.size();
			int preIndex = Integer.parseInt(preString);
			if (preIndex > (totalProperties - 1)) {

				String errMsg = " The supplied index  : " + preIndex
						+ " Does not exist in the BO : "
						+ aDataObject.getType().getName();
				CreateAndSetTargetBOLogger.logSevere(
						CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
						CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
						"scanBO", "Before Index : " + preString + " Error : "
								+ errMsg);

				throw new ServiceBusinessException(errMsg);
			}
			Property boProperty = (Property) aDataObject
					.getInstanceProperties().get(preIndex);

			CreateAndSetTargetBOLogger.logInfo(
					CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
					CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
					"scanBO", "Before Index : " + preString
							+ " Property Name : " + boProperty.getName());
			if (boProperty.isContainment()) {
				String subStrings = StringUtils.substringAfter(aIndexes, ",");

				String propertyTypeName = boProperty.getType().getName();

				DataObject bObj = null;
				Type boType = null;
				if (!"Object".equalsIgnoreCase(propertyTypeName)) {
					bObj = aDataObject.createDataObject(Integer
							.parseInt(preString));

					boType = bObj.getType();

					CreateAndSetTargetBOLogger
							.logInfo(
									CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
									CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
									"scanBO", "Before Index : " + preString
											+ " BOType Created : "
											+ boType.getName() + " QName : "
											+ boType.getURI()
											+ " Next SubString : " + subStrings);
				}

				if (StringUtils.isBlank(subStrings)
						|| StringUtils.isEmpty(subStrings)) {

					DataObject convertedBO = convertBOXMLStringToBO(aBOXMLString);
					int index = Integer.parseInt(preString);

					String originalType = ((Property) aDataObject
							.getInstanceProperties().get(index)).getType()
							.getName();

					String inType = convertedBO.getType().getName();
                   
					if (originalType.equalsIgnoreCase(inType)
							|| originalType.equalsIgnoreCase("Object")) {

						aDataObject.setDataObject(index, convertedBO);
					} else {

						String errMsg = " Please check the indexes . Supplied index : "
								+ index
								+ " is of type : "
								+ originalType
								+ " The transformed dataobject is of type : "
								+ inType;

						CreateAndSetTargetBOLogger
								.logSevere(
										CreateAndSetTargetBO.CreateAndSetTargetBO_CLASS,
										CreateAndSetTargetBO.CreateAndSetTargetBO_CLASSSHORT,
										"scanBO", "Error : " + errMsg);
						throw new ServiceBusinessException(errMsg);
					}

					return;
				}

				scanBO(bObj, subStrings, aBOXMLString);
			}
		} catch (Exception e) {

			throw e;
		}

	}

	public static DataObject convertBOXMLStringToBO(String aBOXMLString) {

		DataObject outBO = null;
		try {
			outBO = DataObjectUtils.stringToDataObject(aBOXMLString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return outBO;
	}

	@Deprecated
	// @ GES ; -- >WPS doesn't support Helper context methods , hence we cannot
	// use it , need
	// to find some other alternative to disable pretty print
	public static void printDataObjectLinearize(DataObject aDataObject) {
		if (null != aDataObject) {

			BOXMLSerializer boXMLSer = (BOXMLSerializer) ServiceManager.INSTANCE
					.locateService("com/ibm/websphere/bo/BOXMLSerializer");
			

			Map<Object, Object> saveOptions = new HashMap<Object, Object>();
			saveOptions.put(XMIResource.OPTION_FORMATTED, Boolean.FALSE);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				boXMLSer.writeDataObjectWithOptions(aDataObject, aDataObject
						.getType().getURI(), aDataObject.getType().getName(),
						baos, saveOptions);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static String dataObjectLinearize(DataObject aDataObject) {
		String s = "Empty DataObject Or Invalid XML , Unable to Deserialize";
		if (null != aDataObject) {

			BOXMLSerializer boXMLSer = (BOXMLSerializer) ServiceManager.INSTANCE
					.locateService("com/ibm/websphere/bo/BOXMLSerializer");
			Map<Object, Object> saveOptions = new HashMap<Object, Object>();
			saveOptions.put(XMIResource.OPTION_FORMATTED, Boolean.FALSE);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				boXMLSer.writeDataObjectWithOptions(aDataObject, aDataObject
						.getType().getURI(), aDataObject.getType().getName(),
						baos, saveOptions);
				s = baos.toString("UTF-8");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return s;
	}
}
