package com.aig.us.ges.cache.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import javax.crypto.spec.SecretKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;


import commonj.sdo.DataObject;

public class AuthCredentials {


	public AuthCredentials()
	{

	}


	//setting up auth Credentials from file
	public  void setUpAuthCache()
	{



		@SuppressWarnings("unused")
		HashMap<String, HashMap> credentials=new HashMap<String,HashMap>();

		@SuppressWarnings("unused")
		boolean result=false;

		//Reading from property file
		try {
			String filePath=null;

			if(System.getProperty("env").equalsIgnoreCase("local"))
			{
				filePath="C:\\logs\\";
			}
			else
			{
				filePath="/opt/logs/wps70/ges/";

			}
			String fileName=filePath+"AuthCrential.properties";

			File file=new File(fileName);

			FileInputStream fileInput =new FileInputStream(file);
			Properties properties = new Properties();
			properties.load(fileInput);
			fileInput.close();


			Enumeration enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);

				String userCre[]=value.split(",");


				HashMap<String,String>  upCredentials=new HashMap<String, String>();
				String encyptValue=encryptStr(userCre[1]);

				upCredentials.put(userCre[0],encyptValue);
				//		credentials.put(key, upCredentials);


				if(GESCacheLoader.gesdbCache!=null)
				{

					GESCacheLoader.gesdbCache.put(key, upCredentials);


				}
			}
			result=true;



		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		//return result;
	}


	//	Retrieving from Cache and Setting Header
	public void setAuth(String key,DataObject httpHeader)
	{

		HashMap authValues=(HashMap)GESCacheLoader.getValueFromCache(key);

		String username=null;
		String password=null;
		Set<String> keysets=authValues.keySet();
		for(String keyset:keysets)
		{
			username=keyset;
			password=authValues.get(keyset).toString();
		}

		

		DataObject control=httpHeader.getDataObject("control");
		DataObject authentication=control.createDataObject("Authentication");
		DataObject credentials=authentication.createDataObject("credentials");
		credentials.setString("userId", username);
		credentials.setString("password", password);




	}

	//Encryption of a String 

	public String encryptStr(String str)
	{
		String encryptedString=null;	

		String mykey ="1234567891234567";

		SecretKey key = new SecretKeySpec(mykey.getBytes(), "AES");

		try {
			Cipher ecipher = Cipher.getInstance("AES");

			ecipher.init(Cipher.ENCRYPT_MODE, key);

			byte[] utf8 = str.getBytes("UTF-8");
			byte[] enc = ecipher.doFinal(utf8);

			encryptedString= new sun.misc.BASE64Encoder().encode(enc);


		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




		return encryptedString;
	}



	//Decryption of String

	public String decryptStr(String str)
	{
		String decryptedString=null;	


		String mykey ="1234567891234567";

		SecretKey key = new SecretKeySpec(mykey.getBytes(), "AES");

		try {
			Cipher dcipher = Cipher.getInstance("AES");

			dcipher.init(Cipher.DECRYPT_MODE, key);

			byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);

			byte[] utf8 = dcipher.doFinal(dec);

			decryptedString= new String(utf8, "UTF-8");

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return decryptedString;		

	}

	//writing to property file
	public void writeFile(String valueToWrite)
	{
		

		if(valueToWrite!=null)
		{
			//Do nothing
		}
		else{
			valueToWrite="PEGACREDENTIALS=serviceuser,rules";
		}
		String keyValue[]=valueToWrite.split("=");
		String filePath=null;

		if(System.getProperty("env").equalsIgnoreCase("local"))
		{
			filePath="C:\\logs\\";
		}
		else
		{
			filePath="/opt/logs/wps70/ges/";

		}

		String fileName=filePath+"AuthCrential.properties";
		Properties fileProperties=new Properties();
		fileProperties.put(keyValue[0],keyValue[1]);
		try {

			File file =new File(fileName);
			if(!file.exists())
			{
				file.createNewFile();

			}



			FileOutputStream fileStream=new FileOutputStream(file,true);
			fileProperties.store(fileStream,"AuthCredentials");
			fileStream.close();





		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}

	public String  decideInteraction(DataObject Request)
	{
	
		 String interactionStyle=null;
		 
		 
		 
		 
		 return interactionStyle;
		
		
		
	}
	
	 

	public static void main(String args[])
	{


		AuthCredentials test=new AuthCredentials();
		test.writeFile(null);
		test.setUpAuthCache();
	}
}
