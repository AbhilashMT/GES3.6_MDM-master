package com.aig.us.custom.dataccess.impl;

import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.Ticket;
import commonj.sdo.DataObject;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.service.invocation.GESSIF;
import com.us.chartisinsurance.ges.service.invocation.GESSIFImpl;

public class InvokeEISImpl {
	/**
	 * Default constructor.
	 */
	public InvokeEISImpl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this implementation
	 * class.  This method should be used when passing this service to a partner reference
	 * or if you want to invoke this component service asynchronously.    
	 *
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * This method is used to locate the service for the reference
	 * named "GESExposureDataPartner".  This will return an instance of 
	 * {@link com.ibm.websphere.sca.Service}.  This is the dynamic
	 * interface which is used to invoke operations on the reference service
	 * either synchronously or asynchronously.  You will need to pass the operation
	 * name in order to invoke an operation on the service.
	 *
	 * @generated (com.ibm.wbit.java)
	 *
	 * @return Service
	 */
	private Service _GESExposureDataPartner = null;
	public static final GESLoggerV4 gesLogger = GESLoggerFactory.getLogger();
	public static final String CLASSNAME = InvokeEISImpl.class.getName();
	public static final String CLASSNAMESHORT = InvokeEISImpl.class
			.getSimpleName();

	public Service locateService_GESExposureDataPartner() {
		if (_GESExposureDataPartner == null) {
			_GESExposureDataPartner = (Service) ServiceManager.INSTANCE
					.locateService("GESExposureDataPartner");
		}
		return _GESExposureDataPartner;
	}

	/**
	 * This method is used to locate the service for the reference
	 * named "GESScrubbingDataPartner".  This will return an instance of 
	 * {@link com.ibm.websphere.sca.Service}.  This is the dynamic
	 * interface which is used to invoke operations on the reference service
	 * either synchronously or asynchronously.  You will need to pass the operation
	 * name in order to invoke an operation on the service.
	 *
	 * @generated (com.ibm.wbit.java)
	 *
	 * @return Service
	 */
	private Service _GESScrubbingDataPartner = null;

	public Service locateService_GESScrubbingDataPartner() {
		if (_GESScrubbingDataPartner == null) {
			_GESScrubbingDataPartner = (Service) ServiceManager.INSTANCE
					.locateService("GESScrubbingDataPartner");
		}
		return _GESScrubbingDataPartner;
	}

	/**
	 * Method generated to support implementation of operation "getDataFromSP"
	 * defined for WSDL port type named "DataAccess".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject getDataFromSP(DataObject getDataFromSPRequest)
			throws ServiceBusinessException {
		// To get or set attributes for DataObject getDataFromSPRequest, use the
		// APIs as shown below:
		// To set a string attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.setString(stringAttributeName, stringValue)
		// To get a string attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.getString(stringAttributeName)
		// To set a dataObject attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.setDataObject(stringAttributeName,
		// dataObjectValue)
		// To get a dataObject attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.getDataObject(stringAttributeName)

		// Get Component
		// Get Refernces apply filter for "self" partner
		// Once partnet is determined ,, do getOprtaionType( paasing
		// getDataFromSP as Input)
		// Based on the OPerationTYpe , get InputType ,
		// If its Wrapper , get the first property Name which will be the Root
		// element for this WSDL

		gesLogger.entering(CLASSNAME, "getDataFromSP", CLASSNAMESHORT,
				"About to Invoke EIS Service ", getDataFromSPRequest);
		DataObject responseBO = null;

		GESSIF invocationINt = GESSIFImpl.INSTANCE;

		try {
			responseBO = invocationINt.invokeEISServiceSP(getDataFromSPRequest,
					"getDataFromSP");
		} catch (ServiceBusinessException sbe) {
			gesLogger.logSevere(CLASSNAME, "invokeEISService", CLASSNAMESHORT,
					" Fault returned by downstream ", (DataObject) sbe
							.getData());
			throw sbe;
		}
		gesLogger.exiting(CLASSNAME, "getDataFromSP", CLASSNAMESHORT,
				"Response from getDataFromSP ", responseBO);
		return responseBO;
	}

	/**
	 * Method generated to support implementation of operation "getData" defined
	 * for WSDL port type named "DataAccess".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject getData(DataObject aGetDataType)
			throws ServiceBusinessException {
		// To get or set attributes for DataObject aGetDataType, use the APIs as
		// shown below:
		// To set a string attribute in aGetDataType, use
		// aGetDataType.setString(stringAttributeName, stringValue)
		// To get a string attribute in aGetDataType, use
		// aGetDataType.getString(stringAttributeName)
		// To set a dataObject attribute in aGetDataType, use
		// aGetDataType.setDataObject(stringAttributeName, dataObjectValue)
		// To get a dataObject attribute in aGetDataType, use
		// aGetDataType.getDataObject(stringAttributeName)

		return null;
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation
	 * "GESExposureData_EISImp#getAccountsSP(DataObject getAccountsSPInput)" of
	 * wsdl interface "GESExposureData_EISImp"
	 */
	public void onGetAccountsSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation
	 * "GESExposureData_EISImp#getPolicyDetailsSP(DataObject getPolicyDetailsSPInput)"
	 * of wsdl interface "GESExposureData_EISImp"
	 */
	public void onGetPolicyDetailsSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation"GESExposureData_EISImp#getPolicyOptionDetailsSP(DataObject getPolicyOptionDetailsSPInput)"
	 * of wsdl interface "GESExposureData_EISImp"
	 */
	public void onGetPolicyOptionDetailsSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback
	 * for the operation "GESExposureData_EISImp#getLocationDetailsSP(DataObject getLocationDetailsSPInput)"
	 * of wsdl interface "GESExposureData_EISImp"	
	 */
	public void onGetLocationDetailsSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		//TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback
	 * for the operation "GESExposureData_EISImp#notifyPolicyOptionSP(DataObject notifyPolicyOptionSPInput)"
	 * of wsdl interface "GESExposureData_EISImp"	
	 */
	public void onNotifyPolicyOptionSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		//TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback
	 * for the operation "GESExposureData_EISImp#getLocationsSP(DataObject getLocationsSPInput)"
	 * of wsdl interface "GESExposureData_EISImp"	
	 */
	public void onGetLocationsSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		//TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback
	 * for the operation "GESExposureData_EISImp#getBoundPoliciesSP(DataObject getBoundPoliciesSPInput)"
	 * of wsdl interface "GESExposureData_EISImp"	
	 */
	public void onGetBoundPoliciesSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		//TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation "DataAccess#getDataFromSP(DataObject getDataFromSPRequest)"
	 * of wsdl interface "DataAccess"
	 */
	public void onGetDataFromSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation "DataAccess#getData(DataObject aGetDataType)" of wsdl
	 * interface "DataAccess"
	 */
	public void onGetDataResponse(Ticket __ticket, DataObject returnValue,
			Exception exception) {
		// TODO Needs to be implemented.
	}

}