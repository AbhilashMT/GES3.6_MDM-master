package com.aig.us.custom.dataccess.impl;

import org.apache.commons.lang3.StringUtils;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.Ticket;
import com.ibm.websphere.sca.addressing.BindingType;
import com.ibm.websphere.sca.addressing.EndpointReference;
import com.ibm.websphere.sca.addressing.EndpointReferenceFactory;
import com.ibm.wsspi.sca.container.Container;
import com.us.aig.ges.dataobject.utils.CreateAndSetTargetBO;
import com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints;
import com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo;
import com.us.chartisinsurance.ges.service.invocation.GESSIFImpl;

import commonj.sdo.DataObject;
import commonj.sdo.Type;

public class POJO_DataAccess {
	/**
	 * Default constructor.
	 */

	private static GESLoggerV4 gesLogger = GESLoggerFactory.getLogger();
	// private String ISpec = "lp";// System.getProperty("ispec");
	private static BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	public static final String customDataType = "GetCustomDataType";

	public POJO_DataAccess() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this
	 * implementation class. This method should be used when passing this
	 * service to a partner reference or if you want to invoke this component
	 * service asynchronously.
	 * 
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * This method is used to locate the service for the reference named
	 * "DataAccessWSPartner". This will return an instance of
	 * {@link com.ibm.websphere.sca.Service}. This is the dynamic interface
	 * which is used to invoke operations on the reference service either
	 * synchronously or asynchronously. You will need to pass the operation name
	 * in order to invoke an operation on the service.
	 * 
	 * @generated (com.ibm.wbit.java)
	 * 
	 * @return Service
	 */
	private Service _DataAccessWSPartner = null;

	public Service locateService_DataAccessWSPartner() {
		if (_DataAccessWSPartner == null) {
			_DataAccessWSPartner = (Service) ServiceManager.INSTANCE
					.locateService("DataAccessWSPartner");
		}
		return _DataAccessWSPartner;
	}

	/**
	 * This method is used to locate the service for the reference named
	 * "DataAccessEISPartner". This will return an instance of
	 * {@link com.ibm.websphere.sca.Service}. This is the dynamic interface
	 * which is used to invoke operations on the reference service either
	 * synchronously or asynchronously. You will need to pass the operation name
	 * in order to invoke an operation on the service.
	 * 
	 * @generated (com.ibm.wbit.java)
	 * 
	 * @return Service
	 */
	private Service _DataAccessEISPartner = null;

	public Service locateService_DataAccessEISPartner() {
		if (_DataAccessEISPartner == null) {
			_DataAccessEISPartner = (Service) ServiceManager.INSTANCE
					.locateService("DataAccessEISPartner");
		}
		return _DataAccessEISPartner;
	}

	/**
	 * This method is used to locate the service for the reference named
	 * "DataAccess_CEISImpPartner". This will return an instance of
	 * {@link com.ibm.websphere.sca.Service}. This is the dynamic interface
	 * which is used to invoke operations on the reference service either
	 * synchronously or asynchronously. You will need to pass the operation name
	 * in order to invoke an operation on the service.
	 * 
	 * @generated (com.ibm.wbit.java)
	 * 
	 * @return Service
	 */
	private Service _DataAccess_CEISImpPartner = null;

	public Service locateService_DataAccess_CEISImpPartner() {
		if (_DataAccess_CEISImpPartner == null) {
			_DataAccess_CEISImpPartner = (Service) ServiceManager.INSTANCE
					.locateService("DataAccess_CEISImpPartner");
		}
		return _DataAccess_CEISImpPartner;
	}

	/**
	 * Method generated to support implementation of operation "getDataFromSP"
	 * defined for WSDL port type named "DataAccess".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject getDataFromSP(DataObject getDataFromSPRequest) {
		// To get or set attributes for DataObject getDataFromSPRequest, use the
		// APIs as shown below:
		// To set a string attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.setString(stringAttributeName, stringValue)
		// To get a string attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.getString(stringAttributeName)
		// To set a dataObject attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.setDataObject(stringAttributeName,
		// dataObjectValue)
		// To get a dataObject attribute in getDataFromSPRequest, use
		// getDataFromSPRequest.getDataObject(stringAttributeName)

		return null;
	}

	/**
	 * Method generated to support implementation of operation "getData" defined
	 * for WSDL port type named "DataAccess".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject getData(DataObject aGetDataType) {
		// To get or set attributes for DataObject aGetDataType, use the APIs as
		// shown below:
		// To set a string attribute in aGetDataType, use
		// aGetDataType.setString(stringAttributeName, stringValue)
		// To get a string attribute in aGetDataType, use
		// aGetDataType.getString(stringAttributeName)
		// To set a dataObject attribute in aGetDataType, use
		// aGetDataType.setDataObject(stringAttributeName, dataObjectValue)
		// To get a dataObject attribute in aGetDataType, use
		// aGetDataType.getDataObject(stringAttributeName)

		gesLogger.entering(POJO_DataAccess.class.getName(), "getData",
				POJO_DataAccess.class.getSimpleName(), "Log Entry getData ",
				aGetDataType);
		DataObject ResponseBO = null;
		DataObject payLoad = aGetDataType.getDataObject("Payload");

		if (customDataType.equalsIgnoreCase(payLoad.getType().getName())) {

			gesLogger.logInfo(POJO_DataAccess.class.getName(), "getData",
					POJO_DataAccess.class.getSimpleName(),
					"Request is for Custom Query Execution ", aGetDataType);
			gesLogger.logInfo(POJO_DataAccess.class.getName(), "getData",
					POJO_DataAccess.class.getSimpleName(),
					"Above to Invoke Target Service : "
							+ "DataAccess_CEISImpPartner", aGetDataType);
			ResponseBO = (DataObject) locateService_DataAccess_CEISImpPartner()
					.invoke("getData", aGetDataType);
			gesLogger.logInfo(POJO_DataAccess.class.getName(), "getData",
					POJO_DataAccess.class.getSimpleName(),
					"Response from  Target Service : "
							+ "DataAccess_CEISImpPartner", ResponseBO);

			return ResponseBO;
		}

		Service DataAccessService = null;

		// Check Type
		Type dataType = payLoad.getType();

		gesLogger.logInfo(POJO_DataAccess.class.getName(), "getData",
				POJO_DataAccess.class.getSimpleName(),
				"Interaction Specification Set : ISPEC :  "
						+ aGetDataType.getString("ISpec"), payLoad);

		DataAccessService = locateService_DataAccessEISPartner();

		gesLogger.logInfo(POJO_DataAccess.class.getName(), "getData",
				POJO_DataAccess.class.getSimpleName(), "About to Invoke  :  "
						+ DataAccessService.getReference().getName(), payLoad);

		try {
			ResponseBO = (DataObject) DataAccessService.invoke("getDataFromSP",
					payLoad);

			DataObject UnwrappedResponse = ResponseBO.getDataObject(0);
			gesLogger.logInfo(POJO_DataAccess.class.getName(), "getData",
					POJO_DataAccess.class.getSimpleName(),
					"Response DataObject :  ", UnwrappedResponse);

			Object ResponsePayLoad = UnwrappedResponse.get("Data");
			String outXML = handleResponse(ResponsePayLoad);

			if (null == outXML) {
				String errorCode = "GES-ODS-NORESULTS";
				String moduleName = Container.INSTANCE.getModule().getName();
				DataObject GESServicesFaultBO = new GESSIFImpl().constructSBE(
						errorCode, moduleName, "getData");

				gesLogger.logSevere(POJO_DataAccess.class.getName(), "getData",
						POJO_DataAccess.class.getSimpleName(),
						" No Results found for the requested criteria  : "
								+ "\n", GESServicesFaultBO);
				throw new ServiceBusinessException(GESServicesFaultBO);

			}
			DataObject responseDO = null;
			// bof.create(
			// "http://GES_Lib_DataAccess/it/DataAccess", "GetDataType");

			try {
				responseDO = CreateAndSetTargetBO.constructAndPopulateDO(
						"http://GES_Lib_DataAccess/it/DataAccess",
						"GetDataType", false, null, "1", outXML);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// responseDO.setString("Payload", outXML);
			gesLogger.exiting(POJO_DataAccess.class.getName(), "getData",
					POJO_DataAccess.class.getSimpleName(), "Log Exit getData ",
					responseDO);
			return responseDO;
		} catch (ServiceBusinessException sbe) {
			// sbe.printStackTrace();
			throw sbe;
		}

	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation"SP_GPS_EISImp#executeSp_GpsGexpusrtUsp_Gps01_Get_Accounts_Xml(DataObject executeSpGpsGexpusrtUspGps01GetAccountsXmlInput)"
	 * of wsdl interface "SP_GPS_EISImp"
	 */
	public void onExecuteSp_GpsGexpusrtUsp_Gps01_Get_Accounts_XmlResponse(
			Ticket __ticket, DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation "DataAccess#getDataFromSP(DataObject getDataFromSPRequest)"
	 * of wsdl interface "DataAccess"
	 */
	public void onGetDataFromSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation "DataAccess#getData(DataObject aGetDataType)" of wsdl
	 * interface "DataAccess"
	 */
	public void onGetDataResponse(Ticket __ticket, DataObject returnValue,
			Exception exception) {
		// TODO Needs to be implemented.
	}

	private String handleResponse(Object aObject) {
		gesLogger.entering(POJO_DataAccess.class.getName(), "handleResponse",
				POJO_DataAccess.class.getSimpleName(),
				"Log Entry handleResponse for " + aObject.toString());
		String outXML = null;
		String value = "";
		// String typeName = inBO.getType().getName();
		gesLogger.logInfo(POJO_DataAccess.class.getName(), "handleResponse",
				POJO_DataAccess.class.getSimpleName(), "Object Type "
						+ aObject.getClass().getName());
		if (aObject instanceof commonj.sdo.DataObject) {

			DataObject datObject = (DataObject) aObject;

			// List<Property> props = datObject.getInstanceProperties();

			String aTypeName = datObject.getType().getName();
			if ("TextBody".equalsIgnoreCase(aTypeName)) {
				value = datObject.getString("value");

				// Transform into Actual DataObject
			} else if (1 == 0) {
				// Handle Other Types here
			}

			else {

				value = datObject.getString("value");
			}

		}
		outXML = value;

		// gesLogger.stringToDataObject(value);
		gesLogger.exiting(POJO_DataAccess.class.getName(), "handleResponse",
				POJO_DataAccess.class.getSimpleName(),
				"Log Exit handleResponse for " + outXML);
		return outXML;
	}

	private Service getService(String aPartnerName) {

		gesLogger.entering(POJO_DataAccess.class.getName(), "getService",
				POJO_DataAccess.class.getSimpleName(),
				"Log Entry getService for " + "PartnerName : " + aPartnerName);
		String ModuleName = "GES_BP_DataAccess_v3_3_0";
		String version = MediationModuleMetaInfo
				.extractVersionFromModuleName(ModuleName);
		String endPointAddress = "";
		Service service = null;
		if (StringUtils.isNotBlank(endPointAddress)
				|| StringUtils.isNotEmpty(endPointAddress)) {
			endPointAddress = ReferenceEndPoints.getEndPoint(aPartnerName,
					version);
		} else {

			endPointAddress = XMLConfig.getURI(aPartnerName, ModuleName,
					version);
			ReferenceEndPoints.setEndPoint(aPartnerName, version,
					endPointAddress);
			gesLogger.logInfo(POJO_DataAccess.class.getName(), "getService",
					POJO_DataAccess.class.getCanonicalName(),
					"Endpoint Address : " + endPointAddress);
		}

		EndpointReference epr = EndpointReferenceFactory.INSTANCE
				.createEndpointReference();
		epr.setBindingType(BindingType.BINDING_TYPE_WEB_SERVICE_SOAP_1_1);
		epr.setAddress(endPointAddress);

		service = (Service) ServiceManager.INSTANCE.getService(aPartnerName,
				epr);
		gesLogger.exiting(POJO_DataAccess.class.getName(), "getService",
				POJO_DataAccess.class.getSimpleName(),
				"Log Exit getService for " + "PartnerName : " + aPartnerName
						+ " Version : " + version);
		return service;
	}
}