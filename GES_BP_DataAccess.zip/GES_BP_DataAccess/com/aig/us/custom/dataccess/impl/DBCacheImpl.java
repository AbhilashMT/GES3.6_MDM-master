package com.aig.us.custom.dataccess.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import org.apache.commons.lang3.StringUtils;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.aig.us.ges.workmanager.utils.GESLookupThread;
import com.aig.us.ges.workmanager.utils.GESWorkManagerService;
import com.ibm.websphere.asynchbeans.WorkException;
import com.ibm.websphere.asynchbeans.WorkItem;
import com.ibm.websphere.asynchbeans.WorkManager;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.Ticket;
import com.us.aig.ges.dataobject.utils.DataObjectUtils;
import com.us.chartisinsurance.ges.exceptionutils.GESCacheException;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import com.us.chartisinsurance.ges.service.invocation.GESSIF;
import com.us.chartisinsurance.ges.service.invocation.GESSIFImpl;
import commonj.sdo.DataObject;

public class DBCacheImpl {
	/**
	 * Default constructor.
	 */

	private static final BOFactory bofService = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	private static final GESLoggerV4 GESDBCacheLogger = GESLoggerFactory
			.getLogger();
	private static final String CLSNM = DBCacheImpl.class.getName();
	private static final String CLSNMSHORT = DBCacheImpl.class.getSimpleName();
	private static final String loadCache = "loadCache";

	public DBCacheImpl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this
	 * implementation class. This method should be used when passing this
	 * service to a partner reference or if you want to invoke this component
	 * service asynchronously.
	 * 
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * This method is used to locate the service for the reference named
	 * "DataAccessPartner". This will return an instance of
	 * {@link com.ibm.websphere.sca.Service}. This is the dynamic interface
	 * which is used to invoke operations on the reference service either
	 * synchronously or asynchronously. You will need to pass the operation name
	 * in order to invoke an operation on the service.
	 * 
	 * @generated (com.ibm.wbit.java)
	 * 
	 * @return Service
	 */
	private Service _DataAccessPartner = null;

	public Service locateService_DataAccessPartner() {
		if (_DataAccessPartner == null) {
			_DataAccessPartner = (Service) ServiceManager.INSTANCE
					.locateService("DataAccessPartner");
		}
		return _DataAccessPartner;
	}

	/**
	 * Method generated to support implementation of operation "loadCache"
	 * defined for WSDL port type named "LoadCache".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject loadCache(DataObject aLoadCacheRequestType)
			throws GESCacheException {

		GESDBCacheLogger.logCategory(LogCategory.CONFIG, CLSNM, loadCache,
				CLSNMSHORT, "Entry - loadCache", aLoadCacheRequestType,
				Level.INFO);

		DataObject responseDO = bofService.createByElement(
				"http://aig.us.com/ges/LoadCache", "LoadCacheResponse");
		responseDO.setBoolean("cacheLoaded", false);
		GESSIF gesSIF = GESSIFImpl.INSTANCE;

		String key = aLoadCacheRequestType.getString("Key");
		String query = aLoadCacheRequestType.getString("Query");
		List<String> queryParams = aLoadCacheRequestType.getList("Params");

		Map<String, String> paramMap = new HashMap<String, String>();
		for (int i = 0; i < queryParams.size(); ++i) {
			paramMap.put("K" + i + 1, queryParams.get(i));
		}

		DataObject response = gesSIF.invokeCustomQuery(query, paramMap);

		boolean isSerialized = aLoadCacheRequestType.getBoolean("IsSerialized");

		if (null != response) {

			if (isSerialized) {

				DataObject MatchConfigurations = bofService.createByElement(
						"http://aig.us.com/ges/lookup/gbo/GBOTypes",
						"Configurations");

				String XMLRootElementName = "Configurations";

				if (!response.getList("SPResults").isEmpty()) {
					DataObject SPResultsType = (DataObject) response.getList(
							"SPResults").get(0);

					if (!SPResultsType.getList("SPResult").isEmpty()) {
						DataObject ResultSetType = (DataObject) SPResultsType
								.getList("SPResult").get(0);
						List<DataObject> MatchConfigurationList = new ArrayList<DataObject>();
						if (ResultSetType.isSet("ResultRows")) {
							List<DataObject> ResultRows = ResultSetType
									.getDataObject("ResultRows").getList(
											"ResultRow");

							for (DataObject ResultRow : ResultRows) {
								DataObject MatchConfiguration = bofService
										.createByElement(
												"http://aig.us.com/ges/lookup/gbo/GBOTypes",
												"Configuration");

								if (ResultRow.isSet("ColumnRecords"))

								{
									DataObject ColumnRecords = ResultRow
											.getDataObject("ColumnRecords");

									List<DataObject> propertyList = new ArrayList<DataObject>();

									if (!ColumnRecords.getList("ColumnRecord")
											.isEmpty()) {
										List<DataObject> ColumnRecordsLst = ColumnRecords
												.getList("ColumnRecord");

										for (DataObject ColumnRecord : ColumnRecordsLst) {
											DataObject ConfigType = bofService
													.create(
															"http://aig.us.com/ges/lookup/gbo/GBOTypes",
															"ConfigType");

											ConfigType.set("@ConfigNm",
													ColumnRecord

													.getString("@Name"));// $http://aig.us.com/ges/schema/da/DataAccessV1_0$ColumnRecordType

											ConfigType
													.set(
															"ConfigValue",
															ColumnRecord
																	.getString("ColumnValue"));
											propertyList.add(ConfigType);
										}

										MatchConfiguration.setList("Property",
												propertyList);
									}
								}
								MatchConfigurationList.add(MatchConfiguration);
							}

						}
						MatchConfigurations.setList("Configuration",
								MatchConfigurationList);
						String serializedXML = DataObjectUtils
								.dataObjectToString(MatchConfigurations,
										XMLRootElementName);

						GESCacheLoader.setValueToCache(key, serializedXML);
						responseDO.setBoolean("cacheLoaded", true);
						GESDBCacheLogger
								.logCategory(
										LogCategory.CONFIG,
										CLSNM,
										loadCache,
										CLSNMSHORT,
										"Exit - loadCache Serialized Form stored in Cache ",
										Level.INFO);
					}
				}
			} else {

				if (!response.getList("SPResults").isEmpty()) {
					DataObject SPResultsType = (DataObject) response.getList(
							"SPResults").get(0);

					if (!SPResultsType.getList("SPResult").isEmpty()) {
						DataObject ResultSetType = (DataObject) SPResultsType
								.getList("SPResult").get(0);

						if (ResultSetType.isSet("ResultRows")) {
							List<DataObject> ResultRows = ResultSetType
									.getDataObject("ResultRows").getList(
											"ResultRow");

							for (DataObject ResultRow : ResultRows) {

								if (ResultRow.isSet("ColumnRecords"))

								{
									DataObject ColumnRecords = ResultRow
											.getDataObject("ColumnRecords");

									if (!ColumnRecords.getList("ColumnRecord")
											.isEmpty()) {
										List<DataObject> ColumnRecordsLst = ColumnRecords
												.getList("ColumnRecord");
										String cacheKey = "";
										String cacheValue = "";
										for (DataObject ColumnRecord : ColumnRecordsLst) {

											String columnName = ColumnRecord
													.getString("@Name");

											if ("PARM_NM"
													.equalsIgnoreCase(columnName)) {

												String columnValue = ColumnRecord
														.getString("ColumnValue");
												cacheKey = columnValue;

											}
											if ("PARM_VAL"
													.equalsIgnoreCase(columnName)) {
												cacheValue = ColumnRecord
														.getString("ColumnValue");

											}

										}

										GESCacheLoader.setValueToCache(
												cacheKey, cacheValue);

										GESDBCacheLogger.logCategory(
												LogCategory.CONFIG, CLSNM,
												loadCache, CLSNMSHORT,
												"Cache Set up With Key : "
														+ cacheKey + " Value "
														+ cacheValue,
												Level.INFO);

									}
								}

							}

						}

						responseDO.setBoolean("cacheLoaded", true);

					}
				}

			}

		}

		GESDBCacheLogger.logCategory(LogCategory.CONFIG, CLSNM, loadCache,
				CLSNMSHORT, "Exit - loadCache", responseDO, Level.INFO);

		return responseDO;
	}

	/**
	 * Method generated to support implementation of operation "setUpCache"
	 * defined for WSDL port type named "LoadCache".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject setUpCache(DataObject aSetUpCacheRequestType) {

		GESDBCacheLogger.logCategory(LogCategory.CONFIG, CLSNM, loadCache,
				CLSNMSHORT, "Entry - setUpCache", aSetUpCacheRequestType,
				Level.INFO);

		DataObject responseDO = bofService.createByElement(
				"http://aig.us.com/ges/LoadCache", "SetUpCacheResponse");
		responseDO.setBoolean("cacheLoaded", false);
		GESSIF gesSIF = GESSIFImpl.INSTANCE;

		String query = aSetUpCacheRequestType.getString("Query");
		List<String> queryParams = aSetUpCacheRequestType.getList("Params");

		Map<String, String> paramMap = new HashMap<String, String>();
		for (int i = 0; i < queryParams.size(); ++i) {
			paramMap.put("K" + i + 1, queryParams.get(i));
		}

		DataObject response = gesSIF.invokeCustomQuery(query, paramMap);

		if (null != response) {

			WorkManager gesWM = GESWorkManagerService.locateWMService();
			ArrayList workItemList = new ArrayList();

			if (!response.getList("SPResults").isEmpty()) {
				DataObject SPResultsType = (DataObject) response.getList(
						"SPResults").get(0);

				if (!SPResultsType.getList("SPResult").isEmpty()) {
					DataObject ResultSetType = (DataObject) SPResultsType
							.getList("SPResult").get(0);
					List<DataObject> MatchConfigurationList = new ArrayList<DataObject>();
					if (ResultSetType.isSet("ResultRows")) {
						List<DataObject> ResultRows = ResultSetType
								.getDataObject("ResultRows").getList(
										"ResultRow");

						for (DataObject ResultRow : ResultRows) {

							if (ResultRow.isSet("ColumnRecords"))

							{
								DataObject ColumnRecords = ResultRow
										.getDataObject("ColumnRecords");

								List<DataObject> propertyList = new ArrayList<DataObject>();

								if (!ColumnRecords.getList("ColumnRecord")
										.isEmpty()) {

									List<DataObject> ColumnRecordsLst = ColumnRecords
											.getList("ColumnRecord");

									String paramName = "";
									String paramValue = "";
									DataObject ParamValBO = ColumnRecords
											.getDataObject("ColumnRecord[Name='PARM_VAL']");
									if (null != ParamValBO) {
										paramValue = ParamValBO
												.getString("ColumnValue");
									}

									DataObject ParamNameBO = ColumnRecords
											.getDataObject("ColumnRecord[Name='PARM_NM']");
									if (null != ParamNameBO) {
										paramName = ParamNameBO
												.getString("ColumnValue");
									}

									

									// Split the String on Comma
									List<String> splitList = Collections.EMPTY_LIST;
									splitList = Arrays.asList(paramValue
											.split(","));

									// Get the param value and isSer value
									Map<String, String> extractedMap = DBCacheImpl
											.splitStrPSMap(splitList);

									if (extractedMap.entrySet().iterator()
											.hasNext()) {

										try {
											WorkItem wItem = gesWM
													.startWork(new GESLookupThread(
															paramName,
															extractedMap
																	.get("Q"),
															Boolean
																	.valueOf(extractedMap
																			.get("isSerialized")),
															StringUtils
																	.splitPreserveAllTokens(extractedMap
																			.get("P"))));
											workItemList.add(wItem);
										} catch (WorkException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										} catch (IllegalArgumentException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}

									}

									// / public GESLookupThread(String
									// aCacheKey, String aQueryReference,
									// boolean aIsSerialized, String[] aParams)
									// for (DataObject ColumnRecord :
									// ColumnRecordsLst) {
									// DataObject ConfigType = bofService
									// .create(
									// "http://aig.us.com/ges/lookup/gbo/GBOTypes",
									// "ConfigType");
									//
									// ConfigType.set("@ConfigNm",
									// ColumnRecord
									//
									// .getString("@Name"));//
									// $http://aig.us.com/ges/schema/da/DataAccessV1_0$ColumnRecordType
									//
									// ConfigType
									// .set(
									// "ConfigValue",
									// ColumnRecord
									// .getString("ColumnValue"));
									// propertyList.add(ConfigType);
									// }

								}
							}

						}

					}

					responseDO.setBoolean("cacheLoaded", true);
					GESDBCacheLogger
							.logCategory(
									LogCategory.CONFIG,
									CLSNM,
									loadCache,
									CLSNMSHORT,
									"Exit - loadCache Serialized Form stored in Cache ",
									Level.INFO);
				}
			}
			gesWM.join(workItemList, WorkManager.JOIN_AND,
					(int) WorkManager.INDEFINITE);
			for (int i = 0; i < workItemList.size(); ++i) {
				GESDBCacheLogger.logCategory(LogCategory.CONFIG, CLSNM,
						loadCache, CLSNMSHORT, "Work Item Status :  "
								+ ((WorkItem) workItemList.get(i)).getStatus(),
						Level.INFO);
			}
		}
		return null;
	}

	public static HashMap<String, String> splitStrPSMap(List<String> inputList) {

		HashMap<String, String> hm = new HashMap<String, String>();
		Iterator<String> itr = inputList.iterator();
		String returnStr = null;
		while (itr.hasNext()) {
			String str = itr.next();
			int strLen = str.length();
			String param = null;
			String isSer = null;

			if (str.contains("Q:")) {
				String QueryName = StringUtils.split(str, ":")[1];
				hm.put("Q", QueryName);
			} else if (str.contains("P:")) {

				String ParamNames = StringUtils.split(str, ":")[1];
				hm.put("P", ParamNames);
			} else if (str.contains("IsSerialized:")) {
				String isSerialized = StringUtils.split(str, ":")[1];
				hm.put("isSerialized", isSerialized);
			}

		}
		return hm;

	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation "DataAccess#getDataFromSP(DataObject getDataFromSPRequest)"
	 * of wsdl interface "DataAccess"
	 */
	public void onGetDataFromSPResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation "DataAccess#getData(DataObject aGetDataType)" of wsdl
	 * interface "DataAccess"
	 */
	public void onGetDataResponse(Ticket __ticket, DataObject returnValue,
			Exception exception) {
		// TODO Needs to be implemented.
	}

	/**
	 * Method generated to support the async implementation using callback for
	 * the operation"DBLookup_EISImp#getMatchConfigurations(DataObject retrieveallDblookupMatchConfigurationsInput)"
	 * of wsdl interface "DBLookup_EISImp"
	 */
	public void onGetMatchConfigurationsResponse(Ticket __ticket,
			DataObject returnValue, Exception exception) {
		// TODO Needs to be implemented.
	}

}