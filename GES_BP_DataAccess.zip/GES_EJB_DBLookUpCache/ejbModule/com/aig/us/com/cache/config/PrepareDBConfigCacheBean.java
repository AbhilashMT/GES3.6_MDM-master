package com.aig.us.com.cache.config;

import java.util.logging.Level;

import org.apache.commons.lang3.time.StopWatch;

import com.aig.us.ges.cache.utils.LookUpKeysI;
import com.aig.us.ges.workmanager.utils.GESLookupThread;
import com.aig.us.ges.workmanager.utils.GESWorkManagerService;
import com.ibm.websphere.asynchbeans.WorkException;
import com.ibm.websphere.asynchbeans.WorkManager;
import com.us.chartisinsurance.ges.db.utils.QueryAccessBundle;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;

/**
 * Bean implementation class for Enterprise Bean: PrepareDBConfigCache
 */
public class PrepareDBConfigCacheBean implements javax.ejb.SessionBean {

	private static GESLoggerV4 PrepareDBConfigCacheBeanLogger = GESLoggerFactory
			.getLogger();
	private static final String BEANQNAME = PrepareDBConfigCacheBean.class
			.getName();
	private static final String BEANNAME = PrepareDBConfigCacheBean.class
			.getSimpleName();

	static final long serialVersionUID = 3206093459760846163L;
	private javax.ejb.SessionContext mySessionCtx;

	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}

	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}

	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}

	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}

	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}

	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}

	public boolean start() {
		PrepareDBConfigCacheBeanLogger.logCategory(LogCategory.CONFIG,
				BEANQNAME, "Home - start()", BEANNAME, "Entry in start()",
				Level.INFO);

		WorkManager gesWM = GESWorkManagerService.locateWMService();
		boolean isStartUpOk = false;
		if (null != gesWM) {

			try {

				StopWatch sw = new StopWatch();
				sw.start();

				gesWM.startWork(new GESLookupThread(
						QueryAccessBundle.GetSetUpCacheConfig,
						LookUpKeysI.LOOKUPCONFIG, true));

				sw.stop();

				PrepareDBConfigCacheBeanLogger.logCategory(LogCategory.CONFIG,
						BEANQNAME, BEANNAME, "Home - start()",
						"Total time to load Cache : " + sw.getTime()
								+ " milliseconds", Level.SEVERE);
				isStartUpOk = true;
			} catch (WorkException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return isStartUpOk;
	}

	public void stop() {
		// TODO Auto-generated method stub

	}

}
