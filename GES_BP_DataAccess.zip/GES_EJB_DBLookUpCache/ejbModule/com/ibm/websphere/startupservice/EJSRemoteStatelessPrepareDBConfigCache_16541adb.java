package com.ibm.websphere.startupservice;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessPrepareDBConfigCache_16541adb
 */
public class EJSRemoteStatelessPrepareDBConfigCache_16541adb extends EJSWrapper implements AppStartUp {
	/**
	 * EJSRemoteStatelessPrepareDBConfigCache_16541adb
	 */
	public EJSRemoteStatelessPrepareDBConfigCache_16541adb() throws java.rmi.RemoteException {
		super();	}
	/**
	 * start
	 */
	public boolean start() throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		boolean _EJS_result = false;
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[0];
			}
	com.aig.us.com.cache.config.PrepareDBConfigCacheBean beanRef = (com.aig.us.com.cache.config.PrepareDBConfigCacheBean)container.preInvoke(this, 0, _EJS_s, _jacc_parms);
			_EJS_result = beanRef.start();
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * stop
	 */
	public void stop() throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[0];
			}
	com.aig.us.com.cache.config.PrepareDBConfigCacheBean beanRef = (com.aig.us.com.cache.config.PrepareDBConfigCacheBean)container.preInvoke(this, 1, _EJS_s, _jacc_parms);
			beanRef.stop();
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 1, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
}
