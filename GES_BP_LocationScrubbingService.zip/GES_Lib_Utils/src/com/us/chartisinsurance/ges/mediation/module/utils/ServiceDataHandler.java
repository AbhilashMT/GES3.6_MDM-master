package com.us.chartisinsurance.ges.mediation.module.utils;

import java.util.ArrayList;
import java.util.logging.Level;

import org.apache.commons.lang.StringUtils;
import org.apache.openjpa.jdbc.kernel.exps.IndexOf;

import com.ibm.wsspi.sibx.mediation.esb.SCAServices;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;

public class ServiceDataHandler {
	

	private static final String DEFAULT_VERSION = "default";
	private static final String VERSIONIDENTIFIER = "_v";
	private static final String SEARCHSTRING = "_";
	private static final String REPLACEMENTSTRING = ".";
	private static final String APP = "App";
	private static final String VERSIONSEP = "_v";
	private static GESLoggerV4 ServiceDataHandler = GESLoggerFactory
			.getLogger();

	public static String[] getServiceNameAndVersion(String controlURL) throws Exception

	{
		
		String[] serviceArray = null;
		String[] nameArray = null;
		String[] versionArray = null;
		String[] resultArrray = new String[2];
		ServiceDataHandler.logCategory(LogCategory.EPR,
				ServiceDataHandler.class.getName(), "getServiceNameVersion",
				ServiceDataHandler.class.getName(), " Entry -> \n",
				Level.INFO);
		
	try{
		String version = DEFAULT_VERSION;
		if (null != controlURL) {
			
			//Sample control URL : http://10.32.11.98:43200/IntegrationServiceGateway/sca/IntegrationGateway_WSExp?ServiceName=LocationScrubbingService&Version=3.6.0
			if(controlURL.contains("?"))
			{
			String extractedServiceData = StringUtils.substringAfter(controlURL, "?");
			if(extractedServiceData.contains("&"))
			{
			serviceArray =StringUtils.split(extractedServiceData, '&');
			if(null !=serviceArray[0] && null != serviceArray[1] && serviceArray[0].contains("=") && serviceArray[1].contains("="))
			{
				String serviceName=StringUtils.substringAfter(serviceArray[0],"=");
				String versionName= StringUtils.substringAfter(serviceArray[1],"=");
			    resultArrray[0] = serviceName;
			    resultArrray[1] = versionName;
			}
			}
			}
			
		}
		ServiceDataHandler.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(), "getServiceNameVersion",
				MediationModuleMetaInfo.class.getName(),
				"Version to Consider : " + version + "\n", Level.INFO);
		ServiceDataHandler.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(), "getServiceNameVersion",
				MediationModuleMetaInfo.class.getName(), " Exit -> \n",
				Level.INFO);
	}
	catch(Exception ex)
	{
		throw ex;
		
	}
		return resultArrray;

	
	}
	

}
