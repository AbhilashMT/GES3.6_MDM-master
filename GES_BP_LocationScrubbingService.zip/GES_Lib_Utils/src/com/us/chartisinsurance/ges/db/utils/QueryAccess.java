package com.us.chartisinsurance.ges.db.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;

import com.ibm.websphere.sca.ServiceRuntimeException;
import com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig;
import com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;

public class QueryAccess {

	/**
	 * @param args
	 */

	private static boolean _localPropertiesRead = false;
	private static boolean isPropertiesDisplayed = false;
	private static final String QUERY_FILE = "QueryRepository.xml";
	static Map<String, String> queryMap = new HashMap<String, String>();
	static Map<String, List> queryParamMap = new HashMap<String, List>();

	private static XMLConfiguration xmlConfigSlave = null;
	private static final String runtimeEnv = System.getProperty("env");
	private static GESLoggerV4 XMLConfigLogger = GESLoggerFactory.getLogger();

	public static void main(String[] args) {
		try {
			readLocalProperties();
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static {
		InputStream is = null;
		if (null != runtimeEnv) {

			is = (InputStream) XMLConfig.class
					.getResourceAsStream("/com/us/chartisinsurance/ges/db/utils/"
							+ QUERY_FILE);
		}
		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfigSlave = new XMLConfiguration();
			xmlConfigSlave.setDelimiterParsingDisabled(true);
			try {
				xmlConfigSlave.load(reader);
				xmlConfigSlave.setExpressionEngine(new XPathExpressionEngine());
				readLocalProperties();
				_localPropertiesRead = true;

			} catch (ConfigurationException e1) {
				e1.printStackTrace();
			}
			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}
	}

	public static String getQuerybyName(String queryName,
			List<String> paramValue) {

		String finalQuery = null;
		if (!_localPropertiesRead) {
			try {
				readLocalProperties();
			} catch (ConfigurationException e) {
				throw new ServiceRuntimeException(GESExceptionHandler
						.formatException("GES-SYS-QUERYE01",
								"Unable to invoke readLocalProperties",
								XMLConfig.class.getSimpleName(), "getQE6"));
			}
		} else {
			if (null == queryName) {
				XMLConfigLogger.logSevere(XMLConfig.class.getName(), "getQ",
						"", "Error Occured - Queryname not Provided\n");

				throw new ServiceRuntimeException(GESExceptionHandler
						.formatException("GES-SYS-QUERYE01",
								"Query name not Available", XMLConfig.class
										.getSimpleName(), "getQE1"));
			} else {
				List<String> paramNames = queryParamMap.get(queryName);
				if (paramNames.isEmpty()) {
					XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getQ",
							"", "No Parameters Supplied\n");
					finalQuery = queryMap.get(queryName);
				} else {
					XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getQ",
							"", "ParamSize is--->" + paramNames.size());

					finalQuery = queryMap.get(queryName);
					for (int i = 0; i < paramNames.size(); i++) {
						finalQuery = setParameter(finalQuery,
								paramNames.get(i), paramValue.get(i));
					}
				}
			}
		}
		return finalQuery;
	}

	public static String setParameter(String query, String paramName,
			String paramValue) {

		final String SINGLE_QUOTE_SIGN = "'";
		String finalParamValue = "";
		if (paramValue.equalsIgnoreCase("current timestamp")
				|| paramValue.equalsIgnoreCase("timestamp")) {
			finalParamValue = paramValue;
		} else {
			finalParamValue = SINGLE_QUOTE_SIGN + paramValue
					+ SINGLE_QUOTE_SIGN;
		}
		String queryToReturn = query.replaceAll(":" + paramName,
				finalParamValue);

		return queryToReturn;
	}

	public static String getQueryValue(String QueryName) {

		String queryValue = "";
		if (null == QueryName) {
			throw new ServiceRuntimeException(
					GESExceptionHandler
							.formatException(
									"GES-SYS-QUERYE01",
									"Query Name/Value/ParamList not given or not query available in repository",
									XMLConfig.class.getSimpleName(), "getQE1"));
		} else {
			queryValue = queryMap.get(QueryName);
		}
		return queryValue;
	}

	public static List<String> getQueryParamList(String QueryName) {

		List<String> quertParamList = Collections.EMPTY_LIST;
		if (null == QueryName) {
			throw new ServiceRuntimeException(
					GESExceptionHandler
							.formatException(
									"GES-SYS-QUERYE01",
									"Query Name/Value/ParamList not given or not query available in repository",
									XMLConfig.class.getSimpleName(), "getQE1"));
		} else {

			quertParamList = queryParamMap.get(QueryName);
		}
		return quertParamList;
	}

	public static String updateQuerybyName(String queryName, String queryValue,
			List<String> paramList) {

		String initialQuery = null;

		initialQuery = queryMap.get(queryName);
		if (null == queryName || null == initialQuery || null == queryValue) {
			throw new ServiceRuntimeException(
					GESExceptionHandler
							.formatException(
									"GES-SYS-QUERYE01",
									"Query Name/Value/ParamList not given or query not available in repository",
									XMLConfig.class.getSimpleName(), "getQE1"));
		} else {
			queryMap.put(queryName, queryValue);
			queryParamMap.put(queryName, paramList);
			return "SUCCESS";
		}
	}

	public static void readLocalProperties() throws ConfigurationException {
		InputStream is = null;
		if (null != System.getProperty("ges.runtime")) {
			is = (InputStream) XMLConfig.class
					.getResourceAsStream("/com/us/chartisinsurance/ges/db/utils/"
							+ QUERY_FILE);
		}
		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfigSlave = new XMLConfiguration();
			xmlConfigSlave.setDelimiterParsingDisabled(true);
			xmlConfigSlave.load(reader);
			xmlConfigSlave.setExpressionEngine(new XPathExpressionEngine());
			_localPropertiesRead = true;

			displayConfig(xmlConfigSlave);
			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}
	}

	private static boolean displayConfig(XMLConfiguration xmlConfig) {
		xmlConfig.setDelimiterParsingDisabled(true);
		try {
			if (null != xmlConfig) {
				Object prop = xmlConfig.getProperty("Queries/Query");

				if (prop instanceof Collection) {
					
					XMLConfigLogger.logInfo(XMLConfig.class.getName(),
							"displayCOnfig()", XMLConfig.class.getName(),
							"Queries listed in Queryfile : "
									+ ((Collection) prop).size() + "\n");

					int QuerySize = ((Collection) prop).size();
					
					xmlConfig.setExpressionEngine(new XPathExpressionEngine());
					for (int i = 1; i <= QuerySize; i++) {
						String QueryName = (String) xmlConfig
								.getProperty("Queries/Query[" + i + "]/@name");
						String QueryValue = (String) xmlConfig
								.getProperty("Queries/Query[" + i + "]");
						String paramCount = (String) xmlConfig
								.getProperty("Queries/Query[" + i
										+ "]/Params/@count");
						int paramCountIntValue = new Integer(paramCount);

						List<String> paramList = new ArrayList<String>();
						for (int j = 1; j <= paramCountIntValue; j++) {
							String param = (String) xmlConfig
									.getProperty("Queries/Query[" + i
											+ "]/Params/Param[" + j + "]");
							paramList.add(param);
						}

						XMLConfigLogger.logInfo(XMLConfig.class.getName(),
								"displayCOnfig()", XMLConfig.class.getName(),
								"Queryname:  " + QueryName + "\n"
										+ "QueryValue: " + QueryValue + "\n");
						queryMap.put(QueryName, QueryValue);
						queryParamMap.put(QueryName, paramList);
					}
				
				} else {
					
				}
				isPropertiesDisplayed = true;
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return isPropertiesDisplayed;
	}

}
