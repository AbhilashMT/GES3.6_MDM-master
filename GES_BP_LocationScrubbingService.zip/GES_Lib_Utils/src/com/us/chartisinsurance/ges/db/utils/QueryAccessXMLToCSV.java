package com.us.chartisinsurance.ges.db.utils;

import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.ConfigurationException;

import commonj.sdo.DataObject;

public class QueryAccessXMLToCSV {

	public static void readProperties(DataObject responseDO)
			throws ConfigurationException {
 
		List<String> columnNames = new ArrayList<String>();
		Map<Integer, Map<String, String>> finalAllRowsMap = new HashMap<Integer, Map<String, String>>();
		int i = 0;
		Map<String, String> rowMap = null;

		DataObject payLoad = responseDO.getDataObject("Payload ");
		DataObject sPResults = (DataObject) payLoad.getList("SPResults").get(0);
		DataObject sPResult = (DataObject) sPResults.getList("SPResult").get(0);
		DataObject resultRows = (DataObject) sPResult.getDataObject(
				"ResultRows").get(0);

		List<DataObject> resultRowList = resultRows.getList("ResultRow");

		Iterator itRows = resultRowList.iterator();
		while (itRows.hasNext()) {
			i++;
			DataObject resultRow = (DataObject) itRows.next();
			DataObject columnRecords = resultRow.getDataObject("ColumnRecords");

			List<DataObject> columnRecordList = columnRecords
					.getList("ColumnRecord");
			Iterator itColumns = columnRecordList.iterator();
			rowMap = new HashMap<String, String>();
			while (itColumns.hasNext()) {
				DataObject columnRecorsDO = (DataObject) itColumns.next();
				columnNames.add(columnRecorsDO.getString("@Name"));
				rowMap.put(columnRecorsDO.getString("@Name"), columnRecorsDO
						.getString("ColumnValue"));
			}
			finalAllRowsMap.put(i, rowMap);
		}
		createCSVFile(columnNames, finalAllRowsMap);
	}

	private static void createCSVFile(List<String> columnNames,
			Map<Integer, Map<String, String>> finalAllRowsMap) {

		String FILE_HEADER = "";
		String rowValueString = "";
		final String NEW_LINE_SEPARATOR = "\n";
		Map<String, String> rowforHeader = finalAllRowsMap.get(1);
		Iterator itforHeader = rowforHeader.entrySet().iterator();
		while (itforHeader.hasNext()) {
			Map.Entry pair = (Map.Entry) itforHeader.next();
			FILE_HEADER = pair.getKey() + ",";
		}

		FileWriter fileWriter = null;

		try {
			fileWriter = new FileWriter("C:\\XMLTest.csv");
			// Write the CSV file header
			fileWriter.append(FILE_HEADER.toString());
			// Add a new line separator after the header
			fileWriter.append(NEW_LINE_SEPARATOR);

			Iterator it = finalAllRowsMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				Map<String, String> SingleRowValue = (Map<String, String>) pair
						.getValue();

				Iterator itRow = SingleRowValue.entrySet().iterator();
				while (itRow.hasNext()) {
					Map.Entry rowPair = (Map.Entry) itRow.next();
					rowValueString = rowPair.getValue() + ",";
					fileWriter.append(rowValueString);
					fileWriter.append(NEW_LINE_SEPARATOR);
				}
			}
			

		} catch (Exception e) {
			
			e.printStackTrace();
		} finally {

			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}
}
