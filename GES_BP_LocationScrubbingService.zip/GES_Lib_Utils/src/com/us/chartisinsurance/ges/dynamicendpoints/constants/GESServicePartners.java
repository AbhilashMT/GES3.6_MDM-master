/**
 * 
 */
package com.us.chartisinsurance.ges.dynamicendpoints.constants;

/**
 * @author araju
 * 
 */
public interface GESServicePartners {

	public static final String MATCHGLOBALLOCATIONSERVICE_PARTNER = "MatchGlobalLocationServicePartner";
	public static final String STANDARDIZEANDAUGMENTLOCATIONSERVICE_PARTNER = "StandardizeAndAugmentGlobalLocationServicePartner";
	public static final String PBBI_STANDARDIZEANDAUGMENTSERVICE_PARTNER = "PBBIStandardizeAndAugmentServicesPartner";
	public static final String PBBI_CANADAFLOODCODELOCATIONSERVICE_PARTNER = "PBBICanadaFloodCodeLocationServicesPartner";
	public static final String PBBI_CRESTACODELOCATIONSERVICE_PARTNER = "PBBICrestaCodeGlobalLocationServicesPartner";
	public static final String PBBI_GEOCODEGLOBALSERVICE_PARTNER = "PBBIGetGeocodeGlobalServicesPartner";
	public static final String PBBI_MATCHLOCATIONSERVICE_PARTNER = "PBBIMatchGlobalLocationServicesPartner";
	public static final String PBBI_STANDARDIZEGLOBALLOCATIONSERVICE_PARTNER = "PBBIStandardizeGlobalLocationServicesPartner";
	public static final String CANADAFLOODCODELOCATIONSERVICE_PARTNER = "CanadaFloodCodeLocationServicePartner";
	public static final String CRESTACODEGLOBALLOCATIONSERVICE_PARTNER = "CrestaCodeGlobalLocationServicePartner";
	public static final String GEOCODEGLOBALLOCATIONSERVICE_PARTNER = "GeocodeGlobalLocationServicePartner";
	public static final String STANDARDIZEGLOBALLOCATIONSERVICE_PARTNER = "StandardizeGlobalLocationServicePartner";
	public static final String AIGMDMBUSINESSPROXYSERVICE_PARTNER = "AIGMDMBusinessProxyServicePartner";
	public static final String LOCATIONSCRUBBINGSERVICE_PARTNER = "LocationScrubbingProcessPartner";
	public static final String LOCATIONCLEANSINGSERVICE_PARTNER = "LocationCleansingProcessPartner";
	public static final String COMMONSERVICE_PARTNER = "GESCommonServicePartner";
	public static final String LOCATIONSERVICE_PARTNER = "LocationServicePartner";
	public static final String DBUPDATEHANDLERSERVICE_PARTNER = "DBUpdateHandlerPartner";

	public static final String MATCHGLOBALLOCATIONSERVICE_MOD = "COM_GES_MF_LocationServiceApp";
	public static final String STANDARDIZEANDAUGMENTLOCATIONSERVICE_MOD = "COM_GES_MF_LocationServiceApp";
	public static final String PBBI_STANDARDIZEANDAUGMENTSERVICE_MOD = "PBBIStandardizeAndAugmentServicesPartner";
	public static final String PBBI_CANADAFLOODCODELOCATIONSERVICE_MOD = "PBBICanadaFloodCodeLocationServicesPartner";
	public static final String PBBI_CRESTACODELOCATIONSERVICE_MOD = "PBBICrestaCodeGlobalLocationServicesPartner";
	public static final String PBBI_GEOCODEGLOBALSERVICE_MOD = "PBBIGetGeocodeGlobalServicesPartner";
	public static final String PBBI_MATCHLOCATIONSERVICE_MOD = "PBBIMatchGlobalLocationServicesPartner";
	public static final String PBBI_STANDARDIZEGLOBALLOCATIONSERVICE_MOD = "PBBIStandardizeGlobalLocationServicesPartner";
	public static final String CANADAFLOODCODELOCATIONSERVICE_MOD = "COM_GES_MF_CanadaFloodZoneApp";
	public static final String CRESTACODEGLOBALLOCATIONSERVICE_MOD = "COM_GES_MF_CrestaCodeApp";
	public static final String GEOCODEGLOBALLOCATIONSERVICE_MOD = "COM_GES_MF_GetGeoCodeApp";
	public static final String STANDARDIZEGLOBALLOCATIONSERVICE_MOD = "COM_GES_MF_StandardizeLocationsApp";
	public static final String LOCATIONSERVICE_MOD = "GES_BP_CleansingProcessApp";
	public static final String LOCATIONSCRUBBINGSERVICE_MOD = "COM_GES_MF_ScrubbingFlowApp";
	public static final String COMMONSERVICE_MOD = "GES_BP_LocationScrubbingProcessApp";

	public static final String LOCATIONSCRUBBINSERVICE_MOD = "COM_GES_MF_CommonServiceApp";

	public static final String GESSERVICEVERSION = "GES_V2_0_1_";
	public static final String GESSERVICEDEFAULTVERSION = "GES_";

}
