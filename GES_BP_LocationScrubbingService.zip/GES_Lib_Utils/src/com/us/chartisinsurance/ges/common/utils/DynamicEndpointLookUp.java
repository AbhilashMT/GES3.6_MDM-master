package com.us.chartisinsurance.ges.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.io.BufferedReader;


import com.ibm.wsspi.sibx.mediation.esb.SCAServices;
import com.us.aig.ges.dataobject.utils.DataObjectUtils;
import com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo;
import com.us.chartisinsurance.ges.mediation.module.utils.ServiceDataHandler;

import commonj.sdo.DataObject;
import commonj.sdo.helper.SDO;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.helper.XMLHelper;

public class DynamicEndpointLookUp {
	private static XMLHelper xmlHelper = SDO.getDefaultHelperContext()
			.getXMLHelper();
	private static GESLoggerV4 DynamicEndPointLookUp = GESLoggerFactory
			.getLogger();

	public static String getEndPointReferenceForServiceAndVersion(
			String gesServiceDefinitionConfig, String serviceName,
			String serviceVersion) throws Exception{
		String endPointReference = null;
		DynamicEndPointLookUp.logCategory(LogCategory.EPR,
				ServiceDataHandler.class.getName(),
				"getEndPointReferenceForServiceAndVersion",
				ServiceDataHandler.class.getName(), " Entry -> \n", Level.INFO);
		    DataObject GESServiceDefinitions;
			try {
				GESServiceDefinitions = DataObjectUtils.stringToDataObject(gesServiceDefinitionConfig);
				
				DataObject ServiceDefs = GESServiceDefinitions
						.getDataObject("ServiceDefintions");
			
				String xPathExp = "ServiceDefinition[ServiceNm=" + "'"
				+ serviceName + "'" + " and ServiceVersion ="
				+ "'" + serviceVersion + "'" + "]";
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getEndPointReferenceForServiceAndVersion",
						ServiceDataHandler.class.getName(),"Logging the Xpath : "+xPathExp, Level.INFO);
				DataObject ServiceDefinition = ServiceDefs
						.getDataObject("ServiceDefinition[ServiceNm=" + "'"
								+ serviceName + "'" + " and ServiceVersion ="
								+ "'" + serviceVersion + "'" + "]");
				
                endPointReference = ServiceDefinition.getString("Endpoint");
				
			 			
			}
			catch (Exception e) {
				throw e;
				
			}
			
			if(null == endPointReference)
			{
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getEndPointReferenceForServiceAndVersion",
						ServiceDataHandler.class.getName(), " Could Not Retreive the Endpoint ! -> \n", Level.INFO);
				throw new Exception("Could not retreive the endpoint URL based on the service Name & version search criteria !!");
			}
		

		return endPointReference;

	}

	public static String getEndPointReferenceForTypeAndNS(
			String gesServiceDefinitionConfig, String rootType, String NS) throws Exception{
		String endPointReference = null;
		
		 DataObject GESServiceDefinitions;

			try {
				GESServiceDefinitions = DataObjectUtils.stringToDataObject(gesServiceDefinitionConfig);
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getEndPointReferenceForServiceAndVersion",
						ServiceDataHandler.class.getName(), " Entry  -> \n",
						Level.INFO);
	
					DataObject ServiceDefs = GESServiceDefinitions
					.getDataObject("ServiceDefintions");
                    String Xpath = "ServiceDefinition[RootElementTypNm=" + "'"
						+ rootType + "'" + " and RootElementQName ="
						+ "'" + NS + "'" + "]";
					DynamicEndPointLookUp.logCategory(LogCategory.EPR,
							ServiceDataHandler.class.getName(),
							"getEndPointReferenceForTypeAndNS",
							ServiceDataHandler.class.getName(),"Logging the Xpath : "+Xpath, Level.INFO);
				DataObject ServiceDefinition = ServiceDefs
				.getDataObject("ServiceDefinition[RootElementTypNm=" + "'"
						+ rootType + "'" + " and RootElementQName ="
						+ "'" + NS + "'" + "]");
				endPointReference = ServiceDefinition.getString("Endpoint");

			} catch (Exception e) {
				throw e;
			}
			if(null == endPointReference)
			{
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getEndPointReferenceForTypeAndNS",
						ServiceDataHandler.class.getName(),"EndPoint Retreived is Null!", Level.INFO);
				throw new Exception("Could not retreive the endpoint URL based on the request Type & Name space search criteria !!");
				
				
				
			}

		return endPointReference;

	}
	
	
	public static HashMap getHashMapForScaInvoke(
			String rootType, SCAServices scaService ,String NS,String gesServiceDefinitionConfig) throws Exception{
		
		String PartnerName = null;
		String MethodName = null;
		String ScaAddress = null;
		HashMap<String, String> resultSet = new HashMap<String, String>();
		DataObject ServiceDefinition = null;
		 DataObject GESServiceDefinitions;
           
			try {
				String moduleName = XMLConfig.getModuleBaseName(scaService
						.getModuleName());
				
				String version = MediationModuleMetaInfo.getModuleVersion(scaService);
				GESServiceDefinitions = DataObjectUtils.stringToDataObject(gesServiceDefinitionConfig);
				String transport ="SCA";
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getHashMapForScaInvoke",
						ServiceDataHandler.class.getName(), " Entry  -> \n",
						Level.INFO);
	
					DataObject ServiceDefs = GESServiceDefinitions
					.getDataObject("ServiceDefintions");
                if(ServiceDefs != null)
                {
				
				String xPathExp = "ServiceDefinition[RootElementTypNm="+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and Transport ="+"'"+transport+"'"+"]";
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getHashMapForScaInvoke",
						ServiceDataHandler.class.getName(), "Logging the Xpath  :"+ xPathExp,
						Level.INFO);
				ServiceDefinition = ServiceDefs
				.getDataObject("ServiceDefinition[ServiceVersion ="+"'"+version+"'"+"RootElementTypNm="+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and Transport ="+"'"+transport+"'"+"]");
				
				if(ServiceDefinition != null)
				{	
				PartnerName = ServiceDefinition.getString("PartnerName");
				MethodName = ServiceDefinition.getString("MethodName");
				ScaAddress = ServiceDefinition.getString("Endpoint");
				resultSet.put("MethodName", MethodName);
				resultSet.put("PartnerName", PartnerName);
				resultSet.put("ScaAddress", ScaAddress);
				
				}
				else
				{  
					String xPthExp = "ServiceDefinition[RootElementTypeNm=" + "'"
					+ rootType + "'" + " and rootElementQName ="
					+ "'" + NS + "'" + "and ServiceVersion ="+"'"+version+"'"+"and Transport ="+"'"+transport+"'"+"]";
					
					
					transport ="GenericSCA";
					ServiceDefinition = ServiceDefs
					.getDataObject("ServiceDefinition[RootElementTypNm="+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and Transport ="+"'"+transport+"'"+"]");
					 if(ServiceDefinition != null)
					 {
						
						 PartnerName = ServiceDefinition.getString("PartnerName");
							
							
							MethodName = ServiceDefinition.getString("MethodName");
							ScaAddress = ServiceDefinition.getString("Endpoint");
							resultSet.put("MethodName", MethodName);
							resultSet.put("PartnerName", PartnerName);
							resultSet.put("ScaAddress", ScaAddress);
						 
					 }
					 else
					 {
						 throw new Exception("Could not retreive the endpoint URL based on the request Type & Name space search criteria !!");
						 
					 }
				}
				
				
                }	
                else
                {
                	
                	DynamicEndPointLookUp.logCategory(LogCategory.EPR,
    						ServiceDataHandler.class.getName(),
    						"getHashMapForScaInvoke",
    						ServiceDataHandler.class.getName(), "Cache Data retreived is Null!!",
    						Level.INFO);
                }
			} catch (Exception e) {
				throw e;
			}
			
		return resultSet;

	}
	
	
	
	public static HashMap getHashMapForJMSInvoke(
			String rootType, SCAServices scaService ,String NS,String gesServiceDefinitionConfig) throws Exception{
		
		String PartnerName = null;
		String MethodName = null;
		String ScaAddress = null;
		HashMap<String, String> resultSet = new HashMap<String, String>();
		DataObject ServiceDefinition = null;
		 DataObject GESServiceDefinitions;

			try {
				String moduleName = XMLConfig.getModuleBaseName(scaService
						.getModuleName());
				String version = MediationModuleMetaInfo.getModuleVersion(scaService);
				GESServiceDefinitions = DataObjectUtils.stringToDataObject(gesServiceDefinitionConfig);
				String transport ="JMS";
				DynamicEndPointLookUp.logCategory(LogCategory.EPR,
						ServiceDataHandler.class.getName(),
						"getHashMapForJMSInvoke",
						ServiceDataHandler.class.getName(), " Entry  -> \n",
						Level.INFO);
					DataObject ServiceDefs = GESServiceDefinitions
					.getDataObject("ServiceDefintions");
					String Xpath = "ServiceDefinition[RootElementTypNm=+"+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and ServiceVersion ="+"'"+version+"'"+"and Transport ="+"'"+transport+"'"+"]";
					DynamicEndPointLookUp.logCategory(LogCategory.EPR,
							ServiceDataHandler.class.getName(),
							"getHashMapForJMSInvoke",
							ServiceDataHandler.class.getName(), "Logging the Xpath : "+Xpath,
							Level.INFO);
				ServiceDefinition = ServiceDefs
				.getDataObject("ServiceDefinition[RootElementTypNm=+"+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and ServiceVersion ="+"'"+version+"'"+"and Transport ="+"'"+transport+"'"+"]");
				if(ServiceDefinition != null)
				{
				PartnerName = ServiceDefinition.getString("PartnerName");
				MethodName = ServiceDefinition.getString("MethodName");
				resultSet.put("MethodName", MethodName);
				resultSet.put("PartnerName", PartnerName);}
				else
				{  
					transport ="GenericJMS";
					Xpath = "ServiceDefinition[RootElementTypNm=+"+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and Transport ="+"'"+transport+"'"+"]";
					ServiceDefinition = ServiceDefs
					.getDataObject("ServiceDefinition[RootElementTypNm=+"+"'"+rootType+"'"+"and RootElementQName ="+"'"+NS +"'"+"and Transport ="+"'"+transport+"'"+"]");
					 if(ServiceDefinition != null)
					 {
						
					        PartnerName = ServiceDefinition.getString("PartnerName");
							MethodName = ServiceDefinition.getString("MethodName");
							resultSet.put("MethodName", MethodName);
							resultSet.put("PartnerName", PartnerName);	 
					 }
					 else
					 {
						 throw new Exception("Could not retreive the endpoint URL based on the request Type & Name space search criteria !!");
						 
					 }
				}
			} catch (Exception e) {
				throw e;
			}
			

		return resultSet;

	}

}
