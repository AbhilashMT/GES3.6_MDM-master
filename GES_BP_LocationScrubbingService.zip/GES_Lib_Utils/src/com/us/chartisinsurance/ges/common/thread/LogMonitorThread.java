package com.us.chartisinsurance.ges.common.thread;

import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.us.chartisinsurance.ges.logger.LogCategory;

public class LogMonitorThread implements Runnable {

	@Override
	public void run() {

		String customLoggerNames = LogCategory.CustomLoggers;

		String[] cusLoggers = StringUtils.split(customLoggerNames, ",");

		for (String customLoggerName : cusLoggers) {

			Logger cusLogger = Logger.getLogger(customLoggerName);

			if (!LogCategory.MATCH.equalsIgnoreCase(customLoggerName)) {
				Handler[] handlers = cusLogger.getHandlers();

				for (Handler handler : handlers) {
					if (!handler.getLevel().equals(Level.SEVERE)) {
						handler.setLevel(Level.SEVERE);

					}
				}

				if (!cusLogger.getLevel().equals(Level.SEVERE)) {
					cusLogger.setLevel(Level.SEVERE);

				}

			}

		}

	}
}
