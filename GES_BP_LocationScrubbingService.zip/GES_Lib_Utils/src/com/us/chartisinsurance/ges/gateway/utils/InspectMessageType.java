/**
 * 
 */
package com.us.chartisinsurance.ges.gateway.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import com.ibm.websphere.bo.BOXMLDocument;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;

import commonj.sdo.DataObject;

/**
 * @author ASurendr
 * 
 */

public class InspectMessageType {

	/**
	 * 
	 */

	private static GESLoggerV4 InspectMessageTypeLogger =  GESLoggerFactory.getLogger();
	private static BOXMLSerializer xmlSerializer = (BOXMLSerializer) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");

	public InspectMessageType() {
		// TODO Auto-generated constructor stub
	}

	public static DataObject checkMessageForRequest(DataObject aSMO) {

		InspectMessageTypeLogger.entering(InspectMessageType.class.getName(),
				"checkMessageForRequest", InspectMessageType.class.getName(),
				"DataObject under process : ", aSMO);

		String textValue = null;
		DataObject XMLBO = null;

		if (null != aSMO) {
			textValue = aSMO.getString("body/message/value");
			if (null != textValue && textValue.length() > 0) {

				InspectMessageTypeLogger.logInfo(InspectMessageType.class
						.getName(), "checkMessageForRequest",
						InspectMessageType.class.getName(), "Text Value is  : "
								+ textValue);

				XMLBO = getBOFromXML(textValue);

			}
			{

			}
		}
		InspectMessageTypeLogger.exiting(InspectMessageType.class.getName(),
				"checkMessageForRequest", InspectMessageType.class.getName(),
				"Derived DataObject: ", XMLBO);
		return XMLBO;
	}

	public static DataObject getBOFromXML(String aXMLString) {
		DataObject dataObject = null;
		InspectMessageTypeLogger.entering(InspectMessageType.class.getName(),
				"getBOFromXML", InspectMessageType.class.getName(),
				"XML String representation  : " + aXMLString);
		if (null != aXMLString && aXMLString.length() > 0) {

			byte[] xmlBytes = aXMLString.getBytes();

			try {
				BOXMLDocument xmlDocument = xmlSerializer
						.readXMLDocument(new ByteArrayInputStream(xmlBytes));

				dataObject = xmlDocument.getDataObject();
			} catch (IOException e) {
				InspectMessageTypeLogger.logSevere(InspectMessageType.class
						.getName(), "getBOFromXML", InspectMessageType.class
						.getName(),
						"An Exception Occurred  tranforming XML to DataObject");
			}
		}
		InspectMessageTypeLogger.exiting(InspectMessageType.class.getName(),
				"getBOFromXML", InspectMessageType.class.getName(),
				" Transformed Dataobject from XML  : ", dataObject);

		return dataObject;

	}
}
