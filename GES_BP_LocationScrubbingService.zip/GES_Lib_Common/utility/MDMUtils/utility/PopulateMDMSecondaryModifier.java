package utility.MDMUtils.utility;
public class PopulateMDMSecondaryModifier {
	public static commonj.sdo.DataObject populateMDMSecondaryModifier(java.lang.String secModifierName, java.lang.String secModifierValue) {
		commonj.sdo.DataObject __result__1;
		{// create SecondaryModifier
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__1 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","SecondaryModifier");
		}
		commonj.sdo.DataObject SecondaryModif_1 = __result__1;
		commonj.sdo.DataObject __result__3;
		{// create XCdSecondaryModifierNameTP
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__3 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","XCdSecondaryModifierNameTP");
		}
		commonj.sdo.DataObject NameBO1 = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create XCdSecondaryModifierTP
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","XCdSecondaryModifierTP");
		}
		commonj.sdo.DataObject ValueBO1 = __result__5;
		NameBO1.setString("value", secModifierName);
		ValueBO1.setString("value", secModifierValue);
		SecondaryModif_1.set("SecondaryModifierName", NameBO1);
		SecondaryModif_1.set("SecondaryModifier", ValueBO1);
		return SecondaryModif_1;
	}
}