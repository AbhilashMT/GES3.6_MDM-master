package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_LocationScrubbingService Interface: LocationScrubbingServiceV3 Operation: addLocation Type: request Custom Mediation: LogEntry
 */
public class Custom1421652901543 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;
	private OutputTerminal ValidateDO;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		ValidateDO = mediationServices.getOutputTerminal("out1");
		if (ValidateDO == null) {
			throw new MediationConfigurationException(
					"No terminal named out1 defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__1 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__2 = getMediationServices();
		java.lang.String __result__3 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_LocationScrubbingService_addLocations__ENTRY;
		utility.MediationLogger_LogEntry.mediationLogger_LogEntry(__result__1,
				__result__2, __result__3, __smo);
		boolean __result__6 = false;
		boolean isValidateDO = __result__6;
		java.lang.Object __result__8 = null;
		commonj.sdo.DataObject SMOValidateDO = (commonj.sdo.DataObject) __result__8;
		try {
			com.us.aig.ges.dataobject.utils.DataObjectUtils
					.validateDataObject(__smo);
		} catch (com.ibm.websphere.sca.ServiceBusinessException ex) {
			commonj.sdo.DataObject __result__13;
			{// create SMO body with GESServicesFaultMsg
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
				com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
						.createServiceMessageObject(new javax.xml.namespace.QName(
								"http://aig.us.com/ges/services/LocationExposureServiceV3",
								"GESServicesFaultMsg"));
				__result__13 = (commonj.sdo.DataObject) _new_smo.getBody();
			}
			commonj.sdo.DataObject GESSErvicesFaultMsg = __result__13;
			byte __result__16 = 0;
			java.lang.Object __result__17 = ex.getData();
			GESSErvicesFaultMsg.set(__result__16, __result__17);
			java.lang.String __result__20 = "..";
			commonj.sdo.DataObject __result__21 = GESSErvicesFaultMsg
					.getDataObject(__result__20);
			SMOValidateDO = __result__21;
			boolean __result__23 = true;
			isValidateDO = __result__23;
		}
		if (isValidateDO) {
			ValidateDO.fire(SMOValidateDO);
		} else {
			out.fire(__smo);
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_LocationScrubbingService_addLocations__ENTRY" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_LocationScrubbingService_addLocations__ENTRY" field="true">
		//    <parameters name="COM_GES_MF_LocationScrubbingService_addLocations__ENTRY">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.4/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogEntry" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.0/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.1/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="false" assignable="false">
		//    <dataOutputs target="//@executableElements.6"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@dataOutputs.0" value="isValidateDO" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null" assignable="false">
		//    <dataOutputs target="//@executableElements.8"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@dataOutputs.0" value="SMOValidateDO" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.10/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="validateDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="validateDataObject">
		//    <parameters name="aDataObject" dataInputs="//@executableElements.9/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.11/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex" dataInputs="//@executableElements.10/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with GESServicesFaultMsg" description="Create SMO body with message {http://aig.us.com/ges/services/LocationExposureServiceV3}GESServicesFaultMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://aig.us.com/ges/services/LocationExposureServiceV3&quot;, &quot;GESServicesFaultMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//      <result name="message body" displayName="service message object body">
		//        <dataOutputs target="//@executableElements.11/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.0/@result/@dataOutputs.0" value="GESSErvicesFaultMsg" localVariable="//@executableElements.11/@localVariables.0" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESSErvicesFaultMsg" localVariable="//@executableElements.11/@localVariables.0" variable="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.5/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//      <dataOutputs target="//@executableElements.11/@executableElements.5/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex.getData()" assignable="false">
		//      <dataOutputs target="//@executableElements.11/@executableElements.5/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="set" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="set">
		//      <parameters name="DataObject" dataInputs="//@executableElements.11/@executableElements.2/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </parameters>
		//      <parameters name="arg0" dataInputs="//@executableElements.11/@executableElements.3/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//      </parameters>
		//      <parameters name="arg1" dataInputs="//@executableElements.11/@executableElements.4/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </parameters>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESSErvicesFaultMsg" localVariable="//@executableElements.11/@localVariables.0" variable="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.8/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;..&quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.11/@executableElements.8/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getDataObject">
		//      <parameters name="DataObject" dataInputs="//@executableElements.11/@executableElements.6/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </parameters>
		//      <parameters name="arg0" dataInputs="//@executableElements.11/@executableElements.7/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.11/@executableElements.9"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.8/@result/@dataOutputs.0" value="SMOValidateDO" localVariable="//@localVariables.0" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//      <dataOutputs target="//@executableElements.11/@executableElements.11"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.10/@dataOutputs.0" value="isValidateDO" localVariable="//@localVariables.1" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <localVariables name="GESSErvicesFaultMsg">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </localVariables>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.0 //@executableElements.11/@executableElements.1"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.2 //@executableElements.11/@executableElements.3 //@executableElements.11/@executableElements.4 //@executableElements.11/@executableElements.5"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.6 //@executableElements.11/@executableElements.7 //@executableElements.11/@executableElements.8 //@executableElements.11/@executableElements.9"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.10 //@executableElements.11/@executableElements.11"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="isValidateDO" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.13"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.12/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ValidateDO" variable="true">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SMOValidateDO" localVariable="//@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.13/@conditionalActivities.0/@executableElements.0 //@executableElements.13/@conditionalActivities.0/@executableElements.1 //@executableElements.13/@conditionalActivities.0/@executableElements.2"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.1/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.13/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.13/@conditionalActivities.1/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.13/@conditionalActivities.1/@executableElements.0 //@executableElements.13/@conditionalActivities.1/@executableElements.1 //@executableElements.13/@conditionalActivities.1/@executableElements.2"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <localVariables name="SMOValidateDO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="isValidateDO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2 //@executableElements.3 //@executableElements.4"/>
		//  <executableGroups executableElements="//@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10 //@executableElements.11"/>
		//  <executableGroups executableElements="//@executableElements.12 //@executableElements.13"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!3:4,1
		//!SMAP!5:5,1
		//!SMAP!6:6,1
		//!SMAP!7:7,1
		//!SMAP!8:8,1
		//!SMAP!9:9,1
		//!SMAP!11:11,1
		//!SMAP!13:14,8
		//!SMAP!14:22,1
		//!SMAP!16:23,1
		//!SMAP!17:24,1
		//!SMAP!18:25,1
		//!SMAP!20:26,1
		//!SMAP!21:27,1
		//!SMAP!22:28,1
		//!SMAP!23:29,1
		//!SMAP!24:30,1
		//!SMAP!26:32,1
		//!SMAP!30:33,1
		//!SMAP!34:36,1
		//!SMAP!1000000:281,1
	}
}
