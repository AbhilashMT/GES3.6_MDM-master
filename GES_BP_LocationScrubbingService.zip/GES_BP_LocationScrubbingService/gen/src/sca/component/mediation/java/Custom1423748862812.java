package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_LocationScrubbingService Interface: LocationScrubbingServiceV3 Operation: notifyPolicyOption Type: request Custom Mediation: Invoke and Prepare Response
 */
public class Custom1423748862812 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		boolean __result__5 = false;
		boolean isFail = __result__5;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__1 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__2 = getMediationServices();
		java.lang.String __result__3 = "Inside Dynamic Service Invoke - NotifyPolicyOption";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__1,
				__result__2, __result__3, __smo);
		com.us.chartisinsurance.ges.service.invocation.GESSIFImpl __result__8 = new com.us.chartisinsurance.ges.service.invocation.GESSIFImpl();
		java.lang.String __result__9 = "notifyPolicyOption";
		java.lang.String MethodName = __result__9;
		java.lang.String __result__11 = "LocationExposureNotificationServicePartner";
		java.lang.String PartnerName = __result__11;
		commonj.sdo.DataObject __result__13 = __smo.getDataObject("body")
				.getDataObject("NotifyPolicyOptionRq");
		try {
			__result__8.invokeServiceAsync(MethodName, PartnerName,
					__result__13);
		} catch (com.ibm.websphere.sca.ServiceBusinessException ex4) {
			boolean __result__16 = true;
			isFail = __result__16;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__18 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__19 = getMediationServices();
			java.lang.String __result__20 = ex4.getMessage();
			utility.MediationLogger_LogSevereNoBO
					.mediationLogger_LogSevereNoBO(__result__18, __result__19,
							__result__20);
		} catch (com.ibm.websphere.sca.ServiceRuntimeException ex5) {
			boolean __result__23 = true;
			isFail = __result__23;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__25 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__26 = getMediationServices();
			java.lang.String __result__27 = ex5.getMessage();
			utility.MediationLogger_LogSevereNoBO
					.mediationLogger_LogSevereNoBO(__result__25, __result__26,
							__result__27);
		} catch (java.lang.Exception ex6) {
			boolean __result__30 = true;
			isFail = __result__30;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__32 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__33 = getMediationServices();
			java.lang.String __result__34 = ex6.getMessage();
			utility.MediationLogger_LogSevereNoBO
					.mediationLogger_LogSevereNoBO(__result__32, __result__33,
							__result__34);
		}
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__37 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__38 = getMediationServices();
		java.lang.String __result__39 = "After Async Invocation of NotifyPolicyOption in LocationExpNotification Service  - NotifyPolicyOption";
		utility.MediationLogger_LogSevereNoBO.mediationLogger_LogSevereNoBO(
				__result__37, __result__38, __result__39);
		commonj.sdo.DataObject __result__36;
		{// create SMO body with NotifyPolicyOptionResponseMsg
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://aig.us.com/ges/services/v3/LocationScrubbingServiceV3",
							"NotifyPolicyOptionResponseMsg"));
			__result__36 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject NotifyPolicyOptionResponse = __result__36;
		byte __result__42 = 0;
		commonj.sdo.DataObject __result__43 = NotifyPolicyOptionResponse
				.createDataObject(__result__42);
		commonj.sdo.DataObject NotifyPolicyOption = __result__43;
		if (isFail) {
			java.lang.String __result__48 = "FAILED";
			NotifyPolicyOption.setString("ProcessingStatus", __result__48);
			commonj.sdo.DataObject __result__50 = __smo.getDataObject("body")
					.getDataObject("NotifyPolicyOptionRq").getDataObject(
							"SourceSystemCd");
			NotifyPolicyOption.set("SourceSystemCd", __result__50);
			__smo.set("body", NotifyPolicyOptionResponse);
			out.fire(__smo);
		} else {
			java.lang.String __result__58 = "SUCCESS";
			NotifyPolicyOption.setString("ProcessingStatus", __result__58);
			commonj.sdo.DataObject __result__60 = __smo.getDataObject("body")
					.getDataObject("NotifyPolicyOptionRq").getDataObject(
							"SourceSystemCd");
			NotifyPolicyOption.set("SourceSystemCd", __result__60);
			__smo.set("body", NotifyPolicyOptionResponse);
			out.fire(__smo);
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Inside Dynamic Service Invoke - NotifyPolicyOption&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="false" assignable="false">
		//    <dataOutputs target="//@executableElements.5"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@dataOutputs.0" value="isFail" localVariable="//@localVariables.4" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.0/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.1/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new GESSIFImpl" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" constructor="true" memberName="GESSIFImpl">
		//    <result>
		//      <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;notifyPolicyOption&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.9"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@dataOutputs.0" value="MethodName" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;LocationExposureNotificationServicePartner&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.11"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@dataOutputs.0" value="PartnerName" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.NotifyPolicyOptionRq" field="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="NotifyPolicyOptionRqType" namespace="http://aig.us.com/ges/ext/LocationExposureNotificationServiceV2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeServiceAsync" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeServiceAsync">
		//    <parameters name="GESSIFImpl" dataInputs="//@executableElements.7/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//    </parameters>
		//    <parameters name="methodName" dataInputs="//@executableElements.9/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="partnerName" dataInputs="//@executableElements.11/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//    </exceptions>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex4" dataInputs="//@executableElements.13/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//      <dataOutputs target="//@executableElements.14/@executableElements.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.14/@executableElements.0/@dataOutputs.0" value="isFail" localVariable="//@localVariables.4" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.14/@executableElements.5/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.14/@executableElements.5/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex4.getMessage()" assignable="false">
		//      <dataOutputs target="//@executableElements.14/@executableElements.5/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//      <parameters name="SCAServices" dataInputs="//@executableElements.14/@executableElements.2/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </parameters>
		//      <parameters name="MediationServices" dataInputs="//@executableElements.14/@executableElements.3/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </parameters>
		//      <parameters name="LogMsg" dataInputs="//@executableElements.14/@executableElements.4/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.14/@executableElements.0 //@executableElements.14/@executableElements.1"/>
		//    <executableGroups executableElements="//@executableElements.14/@executableElements.2 //@executableElements.14/@executableElements.3 //@executableElements.14/@executableElements.4 //@executableElements.14/@executableElements.5"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex5" dataInputs="//@executableElements.13/@exceptions.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//      <dataOutputs target="//@executableElements.15/@executableElements.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@executableElements.0/@dataOutputs.0" value="isFail" localVariable="//@localVariables.4" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.15/@executableElements.5/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.15/@executableElements.5/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex5.getMessage()" assignable="false">
		//      <dataOutputs target="//@executableElements.15/@executableElements.5/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//      <parameters name="SCAServices" dataInputs="//@executableElements.15/@executableElements.2/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </parameters>
		//      <parameters name="MediationServices" dataInputs="//@executableElements.15/@executableElements.3/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </parameters>
		//      <parameters name="LogMsg" dataInputs="//@executableElements.15/@executableElements.4/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.15/@executableElements.0 //@executableElements.15/@executableElements.1"/>
		//    <executableGroups executableElements="//@executableElements.15/@executableElements.2 //@executableElements.15/@executableElements.3 //@executableElements.15/@executableElements.4 //@executableElements.15/@executableElements.5"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex6" dataInputs="//@executableElements.13/@exceptions.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//      <dataOutputs target="//@executableElements.16/@executableElements.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.16/@executableElements.0/@dataOutputs.0" value="isFail" localVariable="//@localVariables.4" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.16/@executableElements.5/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.16/@executableElements.5/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex6.getMessage()" assignable="false">
		//      <dataOutputs target="//@executableElements.16/@executableElements.5/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//      <parameters name="SCAServices" dataInputs="//@executableElements.16/@executableElements.2/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </parameters>
		//      <parameters name="MediationServices" dataInputs="//@executableElements.16/@executableElements.3/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </parameters>
		//      <parameters name="LogMsg" dataInputs="//@executableElements.16/@executableElements.4/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.16/@executableElements.0 //@executableElements.16/@executableElements.1"/>
		//    <executableGroups executableElements="//@executableElements.16/@executableElements.2 //@executableElements.16/@executableElements.3 //@executableElements.16/@executableElements.4 //@executableElements.16/@executableElements.5"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with NotifyPolicyOptionResponseMsg" description="Create SMO body with message {http://aig.us.com/ges/services/v3/LocationScrubbingServiceV3}NotifyPolicyOptionResponseMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://aig.us.com/ges/services/v3/LocationScrubbingServiceV3&quot;, &quot;NotifyPolicyOptionResponseMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.22"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.21/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.21/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;After Async Invocation of NotifyPolicyOption in LocationExpNotification Service  - NotifyPolicyOption&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.21/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.18/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.19/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="LogMsg" dataInputs="//@executableElements.20/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.17/@result/@dataOutputs.0" value="NotifyPolicyOptionResponse" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.24/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.24/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="createDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="createDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.25"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.24/@result/@dataOutputs.0" value="NotifyPolicyOption" localVariable="//@localVariables.3" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="NotifyPolicyOptionRsType" namespace="http://aig.us.com/ges/ext/LocationScrubbingServiceV3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="isFail" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.27"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.26/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;FAILED&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="NotifyPolicyOption.ProcessingStatus" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.NotifyPolicyOptionRq.SourceSystemCd" field="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.0/@executableElements.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SourceSysCdType" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@conditionalActivities.0/@executableElements.2/@dataOutputs.0" value="NotifyPolicyOption.SourceSystemCd" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SourceSysCdType" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NotifyPolicyOptionResponse" localVariable="//@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.0/@executableElements.5"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@conditionalActivities.0/@executableElements.4/@dataOutputs.0" value="smo.body" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="notifyPolicyOptionRequestMsg" namespace="wsdl.http://aig.us.com/ges/services/LocationExposureNotificationServiceV2"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.0/@executableElements.8/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.0/@executableElements.8/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.27/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.27/@conditionalActivities.0/@executableElements.7/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.0/@executableElements.0 //@executableElements.27/@conditionalActivities.0/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.0/@executableElements.2 //@executableElements.27/@conditionalActivities.0/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.0/@executableElements.4 //@executableElements.27/@conditionalActivities.0/@executableElements.5"/>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.0/@executableElements.6 //@executableElements.27/@conditionalActivities.0/@executableElements.7 //@executableElements.27/@conditionalActivities.0/@executableElements.8"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;SUCCESS&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.1/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="NotifyPolicyOption.ProcessingStatus" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.NotifyPolicyOptionRq.SourceSystemCd" field="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.1/@executableElements.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SourceSysCdType" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@conditionalActivities.1/@executableElements.2/@dataOutputs.0" value="NotifyPolicyOption.SourceSystemCd" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SourceSysCdType" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NotifyPolicyOptionResponse" localVariable="//@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.1/@executableElements.5"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@conditionalActivities.1/@executableElements.4/@dataOutputs.0" value="smo.body" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="notifyPolicyOptionRequestMsg" namespace="wsdl.http://aig.us.com/ges/services/LocationExposureNotificationServiceV2"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.1/@executableElements.8/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.27/@conditionalActivities.1/@executableElements.8/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.27/@conditionalActivities.1/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.27/@conditionalActivities.1/@executableElements.7/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.1/@executableElements.0 //@executableElements.27/@conditionalActivities.1/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.1/@executableElements.2 //@executableElements.27/@conditionalActivities.1/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.1/@executableElements.4 //@executableElements.27/@conditionalActivities.1/@executableElements.5"/>
		//      <executableGroups executableElements="//@executableElements.27/@conditionalActivities.1/@executableElements.6 //@executableElements.27/@conditionalActivities.1/@executableElements.7 //@executableElements.27/@conditionalActivities.1/@executableElements.8"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <localVariables name="PartnerName">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </localVariables>
		//  <localVariables name="MethodName">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </localVariables>
		//  <localVariables name="NotifyPolicyOptionResponse">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="NotifyPolicyOption">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="NotifyPolicyOptionRsType" namespace="http://aig.us.com/ges/ext/LocationScrubbingServiceV3"/>
		//  </localVariables>
		//  <localVariables name="isFail">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.4 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2 //@executableElements.3 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.7 //@executableElements.8 //@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15 //@executableElements.16"/>
		//  <executableGroups executableElements="//@executableElements.18 //@executableElements.19 //@executableElements.20 //@executableElements.21"/>
		//  <executableGroups executableElements="//@executableElements.17 //@executableElements.22 //@executableElements.23 //@executableElements.24 //@executableElements.25"/>
		//  <executableGroups executableElements="//@executableElements.26 //@executableElements.27"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:4,1
		//!SMAP!2:5,1
		//!SMAP!3:6,1
		//!SMAP!5:2,1
		//!SMAP!6:3,1
		//!SMAP!7:7,1
		//!SMAP!8:8,1
		//!SMAP!9:9,1
		//!SMAP!10:10,1
		//!SMAP!11:11,1
		//!SMAP!12:12,1
		//!SMAP!13:13,1
		//!SMAP!14:15,1
		//!SMAP!16:18,1
		//!SMAP!17:19,1
		//!SMAP!18:20,1
		//!SMAP!19:21,1
		//!SMAP!20:22,1
		//!SMAP!21:23,1
		//!SMAP!23:26,1
		//!SMAP!24:27,1
		//!SMAP!25:28,1
		//!SMAP!26:29,1
		//!SMAP!27:30,1
		//!SMAP!28:31,1
		//!SMAP!30:34,1
		//!SMAP!31:35,1
		//!SMAP!32:36,1
		//!SMAP!33:37,1
		//!SMAP!34:38,1
		//!SMAP!35:39,1
		//!SMAP!36:45,8
		//!SMAP!37:41,1
		//!SMAP!38:42,1
		//!SMAP!39:43,1
		//!SMAP!40:44,1
		//!SMAP!41:53,1
		//!SMAP!42:54,1
		//!SMAP!43:55,1
		//!SMAP!44:56,1
		//!SMAP!46:57,1
		//!SMAP!48:58,1
		//!SMAP!49:59,1
		//!SMAP!50:60,1
		//!SMAP!51:61,1
		//!SMAP!53:62,1
		//!SMAP!56:63,1
		//!SMAP!58:66,1
		//!SMAP!59:67,1
		//!SMAP!60:68,1
		//!SMAP!61:69,1
		//!SMAP!63:70,1
		//!SMAP!66:71,1
		//!SMAP!1000000:537,1
	}
}
