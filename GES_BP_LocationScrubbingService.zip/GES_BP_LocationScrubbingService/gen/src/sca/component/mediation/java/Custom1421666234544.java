package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_LocationScrubbingService Interface: LocationScrubbingServiceV3 Operation: addLocation Type: request Custom Mediation: DBResponse_To_DataObjectconversion
 */
public class Custom1421666234544 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__1 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__2 = getMediationServices();
		java.lang.String __result__3 = "Log get Locations  \n";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__1,
				__result__2, __result__3, __smo);
		commonj.sdo.DataObject __result__7;
		{// copy BO
			com.ibm.websphere.bo.BOCopy _copyService = (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOCopy");
			__result__7 = _copyService.copy(__smo);
		}
		commonj.sdo.DataObject SMONew = __result__7;
		commonj.sdo.DataObject __result__9 = __smo.getDataObject("body")
				.getDataObject("getLocationsFromGESResponseParameter")
				.getDataObject("GESSOVLocations").getDataObject(
						"arrayOfLocations");
		commonj.sdo.DataObject LocationsArray = __result__9;
		commonj.sdo.DataObject __result__12;
		{// create addLocationsRequest
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__12 = factory.create("http://aig.us.com/ges/schema",
					"addLocationsRequest");
		}
		commonj.sdo.DataObject addLocationsRequest = __result__12;
		java.lang.String __result__14 = "locations";
		addLocationsRequest.setDataObject(__result__14, LocationsArray);
		commonj.sdo.DataObject __result__17;
		{// create addLocationsRequestType
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__17 = factory.create("http://aig.us.com/ges/schema",
					"addLocationsRequestType");
		}
		commonj.sdo.DataObject addLocationsRequestType = __result__17;
		java.lang.String __result__19 = "addLocationsRequest";
		addLocationsRequestType
				.setDataObject(__result__19, addLocationsRequest);
		java.lang.String __result__22 = "GES";
		addLocationsRequestType.setString("originator", __result__22);
		commonj.sdo.DataObject __result__11;
		{// create SMO body with addLocationsRequestMsg
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://aig.us.com/ges/services/LocationServiceV2",
							"addLocationsRequestMsg"));
			__result__11 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject outputSmoBody = __result__11;
		byte __result__25 = 0;
		outputSmoBody.setDataObject(__result__25, addLocationsRequestType);
		byte __result__31 = 1;
		commonj.sdo.DataObject __result__32 = __smo.getDataObject("context")
				.getDataObject("transient").getDataObject("RequestHeader");
		outputSmoBody.setDataObject(__result__31, __result__32);
		SMONew.set("body", outputSmoBody);
		java.lang.String __result__28 = "Log Add Location Response Message \n";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__1,
				__result__2, __result__28, SMONew);
		out.fire(SMONew);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.35/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//      <dataOutputs target="//@executableElements.35/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log get Locations  \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.4/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.0/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.1/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="copy BO" description="Copy a Business Object or Business Graph" category="SCA and BO services" template="com.ibm.websphere.bo.BOCopy _copyService = &#xA;   (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOCopy&quot;); &#xA;&lt;%return%> _copyService.copy(&lt;%bo%>);">
		//    <parameters name="bo" dataInputs="//@executableElements.5/@dataOutputs.0" displayName="BO">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result name="copy" displayName="copy">
		//      <dataOutputs target="//@executableElements.7"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.6/@result/@dataOutputs.0" value="SMONew" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.getLocationsFromGESResponseParameter.GESSOVLocations.arrayOfLocations" field="true">
		//    <dataOutputs target="//@executableElements.9"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@dataOutputs.0" value="LocationsArray" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with addLocationsRequestMsg" description="Create SMO body with message {http://aig.us.com/ges/services/LocationServiceV2}addLocationsRequestMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://aig.us.com/ges/services/LocationServiceV2&quot;, &quot;addLocationsRequestMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.23"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create addLocationsRequest" description="create a new addLocationsRequest {http://aig.us.com/ges/schema}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/schema&quot;,&quot;addLocationsRequest&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.12"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequest" namespace="http://aig.us.com/ges/schema" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@result/@dataOutputs.0" value="addLocationsRequest" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequest" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;locations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.15/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="LocationsArray" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.15/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.13/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.14/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create addLocationsRequestType" description="create a new addLocationsRequestType {http://aig.us.com/ges/schema}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/schema&quot;,&quot;addLocationsRequestType&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.17"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequestType" namespace="http://aig.us.com/ges/schema" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.16/@result/@dataOutputs.0" value="addLocationsRequestType" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequestType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;addLocationsRequest&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.20/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="addLocationsRequest" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequest" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.22"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.21/@dataOutputs.0" value="addLocationsRequestType.originator" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@result/@dataOutputs.0" value="outputSmoBody" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.26/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="addLocationsRequestType" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequestType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log Add Location Response Message \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.35/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SMONew" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.35/@parameters.3"/>
		//    <dataOutputs target="//@executableElements.37/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="outputSmoBody" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="1" assignable="false">
		//    <dataOutputs target="//@executableElements.32/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.transient.RequestHeader" field="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.29/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.30/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.31/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="outputSmoBody" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.34"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.33/@dataOutputs.0" value="SMONew.body" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESResponseMsg" namespace="wsdl.http://aig.us.com/ges/services/GESCommonServiceV2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.0/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.1/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.27/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.28/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.37/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.36/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.28/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="SMONew">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </localVariables>
		//  <localVariables name="outputSmoBody">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="LocationsArray">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="addLocationsRequest">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequest" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <localVariables name="addLocationsRequestType">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="addLocationsRequestType" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2 //@executableElements.3 //@executableElements.4"/>
		//  <executableGroups executableElements="//@executableElements.5 //@executableElements.6 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.16 //@executableElements.17 //@executableElements.18 //@executableElements.19 //@executableElements.20"/>
		//  <executableGroups executableElements="//@executableElements.21 //@executableElements.22"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.23 //@executableElements.24 //@executableElements.25 //@executableElements.26"/>
		//  <executableGroups executableElements="//@executableElements.29 //@executableElements.30 //@executableElements.31 //@executableElements.32"/>
		//  <executableGroups executableElements="//@executableElements.33 //@executableElements.34"/>
		//  <executableGroups executableElements="//@executableElements.27 //@executableElements.28 //@executableElements.35"/>
		//  <executableGroups executableElements="//@executableElements.36 //@executableElements.37"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!3:4,1
		//!SMAP!5:5,1
		//!SMAP!7:6,6
		//!SMAP!8:12,1
		//!SMAP!9:13,1
		//!SMAP!10:14,1
		//!SMAP!11:35,8
		//!SMAP!12:15,6
		//!SMAP!13:21,1
		//!SMAP!14:22,1
		//!SMAP!16:23,1
		//!SMAP!17:24,6
		//!SMAP!18:30,1
		//!SMAP!19:31,1
		//!SMAP!21:32,1
		//!SMAP!22:33,1
		//!SMAP!23:34,1
		//!SMAP!24:43,1
		//!SMAP!25:44,1
		//!SMAP!27:45,1
		//!SMAP!28:50,1
		//!SMAP!31:46,1
		//!SMAP!32:47,1
		//!SMAP!33:48,1
		//!SMAP!35:49,1
		//!SMAP!36:51,1
		//!SMAP!38:52,1
		//!SMAP!1000000:353,1
	}
}
