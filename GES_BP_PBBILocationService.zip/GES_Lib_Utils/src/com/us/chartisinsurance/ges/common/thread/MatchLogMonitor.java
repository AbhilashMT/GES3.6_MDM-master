/**
 * 
 */
package com.us.chartisinsurance.ges.common.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.FileFileFilter;

import com.us.chartisinsurance.ges.logger.LogCategory;
import com.us.chartisinsurance.ges.logger.SetUpNonRootLogger;
import com.us.chartisinsurance.ges.logger.SetupUtilLogger;

/**
 * @author Asurendr
 * 
 */
public class MatchLogMonitor implements Runnable {

	/**
	 * 
	 * 
	 */
	static String env = System.getProperty("env");

	static String gesRuntime = System.getProperty("ges.runtime");

	public MatchLogMonitor() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {

		archiveLogs();
		// All Handlers removed , Now archive all Old Match Config Logs

	}

	public static void main(String[] args) {

		String directoryName = "C:\\logs\\";
		File directory = new File(directoryName);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		String dateRepresentation = dateFormat.format(Calendar.getInstance(
				TimeZone.getTimeZone("UTC")).getTime());
		String zipFileName = directoryName + "MatchConfigBCKUP" + "_"
				+ dateRepresentation + ".zip";
		Collection<File> fileList = FileUtils.listFiles(directory,
				FileFileFilter.FILE, FileFileFilter.FILE);
		try {
			FileOutputStream fos = new FileOutputStream(zipFileName);
			ZipOutputStream zipOS = new ZipOutputStream(fos);
			// System.out.println(" Zip Name : " + zipFileName);
			if (fileList != null && fileList.size() > 0) {

				for (File file : fileList) {
					String fileName = file.getName();

					// System.out.println(" File Name : " + fileName);

					if (fileName.indexOf("MatchConfig") != -1
							&& (fileName.indexOf("zip") == -1)) {

						System.out.println(" Filed to be added to Zip : "
								+ fileName);

						ZipEntry ze = new ZipEntry(file.getName());
						zipOS.putNextEntry(ze);
						FileInputStream fis = new FileInputStream(file);

						byte[] readBytes = new byte[(int) file.length()];

						int len = 0;

						while ((len = fis.read(readBytes)) > 0) {
							zipOS.write(readBytes, 0, len);
						}

						zipOS.closeEntry();
						fis.close();
					}

				}

				zipOS.close();
				fos.close();

			}

			zipOS.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String archiveLogs() {
		String loggerName = LogCategory.MATCH;

		SetupUtilLogger.destroyLogger(loggerName);
		String directoryName = "";

		if (null == env || null == gesRuntime || "local".equalsIgnoreCase(env)) {
			directoryName = SetUpNonRootLogger.initProps.getProperty("loc");
		} else {
			directoryName = SetUpNonRootLogger.initProps.getProperty(gesRuntime
					+ ".loc." + env);
		}

		File directory = new File(directoryName);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		String dateRepresentation = dateFormat.format(Calendar.getInstance(
				TimeZone.getTimeZone("UTC")).getTime());
		new File(directoryName + "BackUp").mkdir();
		String zipFileName = directoryName +"BackUp"+ "/MatchConfigBCKUP" + "_V36_"
				+ dateRepresentation + ".zip";
		Collection<File> fileList = FileUtils.listFiles(directory,
				FileFileFilter.FILE, FileFileFilter.FILE);
		try {
			FileOutputStream fos = new FileOutputStream(zipFileName);
			ZipOutputStream zipOS = new ZipOutputStream(fos);
			if (fileList != null && fileList.size() > 0) {

				for (File file : fileList) {
					String fileName = file.getName();

					if (fileName.indexOf("MatchConfig") != -1
							&& (fileName.indexOf("zip") == -1)) {

						System.out.println(" Filed to be added to Zip : "
								+ fileName);

						ZipEntry ze = new ZipEntry(file.getName());
						zipOS.putNextEntry(ze);
						FileInputStream fis = new FileInputStream(file);

						byte[] readBytes = new byte[(int) file.length()];

						int len = 0;

						while ((len = fis.read(readBytes)) > 0) {
							zipOS.write(readBytes, 0, len);
						}

						zipOS.closeEntry();
						fis.close();
					}

				}

				zipOS.close();
				fos.close();

			}

			zipOS.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SetUpNonRootLogger.setUpMatchLogger();
		return zipFileName;
	}

}
