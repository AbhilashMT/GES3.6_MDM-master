/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * @author M1019070
 * 
 */
public class SetupUtilLogger {

	/**
	 * 
	 */

	private static final String env = System.getProperty("env");
	private static final String gesRuntime = System.getProperty("ges.runtime");
	private static final LogManager logManager = LogManager.getLogManager();

	private static Properties initProps = new Properties();
	static {

		try {

			destroyAllLoggers();
			initProps
					.load(SetupUtilLogger.class
							.getResourceAsStream("/com/us/chartisinsurance/ges/logger/logger.properties"));

			// Now Prepare Actual Logger configuration based on initial
			// configuration
			ByteArrayOutputStream intibaos = new ByteArrayOutputStream();
			initProps.store(intibaos, "INIT PROPERTIES");

			System.out.println(intibaos.toString());

			Properties newProperties = new Properties();

			// Set Handler
			newProperties.setProperty("handlers", initProps
					.getProperty("handlers"));

			newProperties.setProperty(".useParentHandlers", initProps
					.getProperty(".useParentHandlers"));

			// Set the pattern file Name
			String patternFormat = "java.util.logging.FileHandler.pattern";
			if (null == gesRuntime || "local".equalsIgnoreCase(gesRuntime)) {
				patternFormat = patternFormat + ".local";
			} else {
				patternFormat = patternFormat + "." + gesRuntime;
			}

			// Set Handler Levels according to Environment
			if ("local".equalsIgnoreCase(env)) {
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.level",
								initProps
										.getProperty("java.util.logging.FileHandler.level.local"));
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.pattern",
								initProps
										.getProperty("java.util.logging.FileHandler.pattern.local"));
			} else if ("dev".equalsIgnoreCase(env)) {
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.level",
								initProps
										.getProperty("java.util.logging.FileHandler.level.dev"));
				newProperties.setProperty(
						"java.util.logging.FileHandler.pattern", initProps
								.getProperty(patternFormat + ".dev"));
			} else if ("qa".equalsIgnoreCase(env)) {
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.level",
								initProps
										.getProperty("java.util.logging.FileHandler.level.qa"));
				newProperties.setProperty(
						"java.util.logging.FileHandler.pattern", initProps
								.getProperty(patternFormat + ".qa"));
			} else if ("model".equalsIgnoreCase(env)) {
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.level",
								initProps
										.getProperty("java.util.logging.FileHandler.level.model"));
				newProperties.setProperty(
						"java.util.logging.FileHandler.pattern", initProps
								.getProperty(patternFormat + ".model"));
			} else if ("prod".equalsIgnoreCase(env)) {
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.level",
								initProps
										.getProperty("java.util.logging.FileHandler.level.prod"));
				newProperties.setProperty(
						"java.util.logging.FileHandler.pattern", initProps
								.getProperty(patternFormat + ".prod"));
			} else {
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.level",
								initProps
										.getProperty("java.util.logging.FileHandler.level.local"));
				newProperties
						.setProperty(
								"java.util.logging.FileHandler.pattern",
								initProps
										.getProperty("java.util.logging.FileHandler.pattern.local"));

			}

			// Set Properties for all Handlers

			// Set Append Property
			newProperties
					.setProperty(
							"java.util.logging.FileHandler.append",
							initProps
									.getProperty("java.util.logging.FileHandler.append"));
			// Set Formatter Property

			newProperties
					.setProperty(
							"java.util.logging.FileHandler.formatter",
							initProps
									.getProperty("java.util.logging.FileHandler.formatter"));

			// Set File Limit

			newProperties
					.setProperty(
							"java.util.logging.FileHandler.limit",
							initProps
									.getProperty("java.util.logging.FileHandler.limit"));

			// Set Backup Size

			newProperties
					.setProperty(
							"java.util.logging.FileHandler.count",
							initProps
									.getProperty("java.util.logging.FileHandler.count"));

			Set propSet = newProperties.entrySet();

			Iterator propIterator = propSet.iterator();
			while (propIterator.hasNext()) {
				System.out.println(propIterator.next().toString());
			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			newProperties.store(baos, "New Properties");

			new SetUpNonRootLogger();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public SetupUtilLogger() {
	}

	public static void setupUtilLogger() {

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Logger logger = logManager.getLogger("");
		Logger loggerPBBI = logManager.getLogger("PBBI");
		Logger loggerMDM = logManager.getLogger("MDM");
		Logger loggerEMAIL = logManager.getLogger("EMAIL");
		Logger loggerMONITOR = logManager.getLogger("MONITOR");
		logger.log(Level.INFO, "TEST !");
		loggerPBBI.log(Level.SEVERE, "TEST  PBBI !");

		loggerMDM.log(Level.INFO, "TEST MDM !");
		loggerMONITOR.log(Level.INFO, "MOITOR LOG");

		loggerEMAIL.log(Level.INFO, "TEST EMAIl!");

		destroyAllLoggers();

		Logger loggerEMAILN = logManager.getLogger("EMAIL");
		loggerEMAILN.log(Level.INFO, "WILL I LOG ? ");

	}

	public static void destroyAllLoggers() {

		Enumeration loggers = logManager.getLoggerNames();

		while (loggers.hasMoreElements()) {
			String loggerName = (String) loggers.nextElement();

			Logger logger = logManager.getLogger(loggerName);
			Handler[] handlers = logger.getHandlers();
			for (Handler handler : handlers) {

				if (handler instanceof FileHandler) {
					logger.removeHandler(handler);

					System.out.println("Handler Name : " + handler.toString()
							+ " Logger Name : " + logger.getName()
							+ " Removed from Repository");
					handler.close();
				}
			}
		}
	}

	public static void destroyLogger(String aLoggerName) {

		Logger logger = logManager.getLogger(aLoggerName);
		Handler[] handlers = logger.getHandlers();
		for (Handler handler : handlers) {

			if (handler instanceof FileHandler) {
				logger.removeHandler(handler);

				System.out.println("Handler Name : " + handler.toString()
						+ " Logger Name : " + logger.getName()
						+ " Removed from Repository");
				handler.close();
			}
		}

	}
}
