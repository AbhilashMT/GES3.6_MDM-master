/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Asurendr
 * 
 */
public class MatchLogFormatter {

	/**
	 * @param args
	 */

	private static final String RecordHeader = "Date|LocationType|Source|Precision|TPrecision|YearBuilt|NoOfStories|AddressLine1|City|PostalCode|Country|Latitude|Longitude|DQI|TIV In USD|ConstructionClass|ConstructionScheme|ConstructionWeigh|BuiltYearWeigh|NoOfFloorsWeigh|CopeWeigh|AddrConfidence|DistanceFromSource|MatchResult";

	private static final String DateFormatPattern = "yyyy-MM-dd'T'HH:mm:ss.SSSz";

	private static final SimpleDateFormat DateFormat = new SimpleDateFormat(
			DateFormatPattern);

	// private static final Calendar calender = Calendar.getInstance();

	public static void main(String[] args) {
	}

	public static String getFormattedMessage(String aMessage) {

		StringBuffer sBuffer = new StringBuffer();

		// TODO Auto-generated method stub

		/**
		 * LocationType|Source|Precision|TPrecision|YearBuilt|NoOfStories|
		 * AddressLine1|City|PostalCode|Country|Latitude|Longitude|DQI|TIV In
		 * USD|ConstructionClass|ConstructionScheme|ConstructionWeigh|
		 * BuiltYearWeigh
		 * |NoOfFloorsWeigh|CopeWeigh|AddrConfidence|DistanceFromSource
		 * |MatchResult
		 **/

		String InputRecordSep = "Suspect:";
		String InputRecordSStart = "Input:";

		String InputRecord = StringUtils.substringBetween(aMessage,
				InputRecordSStart, InputRecordSep);

		String SuspectRecord = StringUtils.substringAfter(aMessage,
				InputRecordSep);

		String Source = StringUtils.substringBetween(InputRecord, "Source:",
				"}");
		String Precision = StringUtils.substringBetween(InputRecord,
				"Precision:", "}");
		String TPrecision = StringUtils.substringBetween(InputRecord,
				"Transalated Precision:", "}");
		String YearBuilt = StringUtils.substringBetween(InputRecord,
				"Year Built:", "}");
		String NoOfStories = StringUtils.substringBetween(InputRecord,
				"No Of Stories:", "}");
		String AddressLine1 = StringUtils.substringBetween(InputRecord,
				"Address Line:", "}");
		String City = StringUtils.substringBetween(InputRecord, "City:", "}");
		String PostalCode = StringUtils.substringBetween(InputRecord,
				"Postal Code:", "}");
		String Country = StringUtils.substringBetween(InputRecord, "Country:",
				"}");
		String Latitude = StringUtils.substringBetween(InputRecord,
				"Latitude:", "}");
		String Longitude = StringUtils.substringBetween(InputRecord,
				"Longitude:", "}");
		String DQI = StringUtils.substringBetween(InputRecord, "DQI:", "}");
		String TIVInUSD = StringUtils
				.substringBetween(InputRecord, "TIV:", "}");
		String ConstructionClass = StringUtils.substringBetween(InputRecord,
				"Construction Class:", "}");
		String ConstructionScheme = StringUtils.substringBetween(InputRecord,
				"Construction Scheme:", "}");
		String ConstructionWeigh = "NA";
		String YearBuiltWeigh = "NA";
		String NoOfStoriesWeigh = "NA";
		String CopeWeigh = "NA";
		String AddrConfidence = "NA";
		String DistanceFromSource = "NA";
		String MatchResult = "NA";

		/**
		 * LocationType|Source|Precision|TPrecision|YearBuilt|NoOfStories|
		 * AddressLine1|City|PostalCode|Country|Latitude|Longitude|DQI|TIV In
		 * USD|ConstructionClass|ConstructionScheme|ConstructionWeigh|
		 * BuiltYearWeigh
		 * |NoOfFloorsWeigh|CopeWeigh|AddrConfidence|DistanceFromSource
		 * |MatchResult
		 **/

		String[] searchList = StringUtils.split(RecordHeader, "|");
		String[] inputReplacementList = {
				DateFormat.format(Calendar.getInstance().getTime()), "Input",
				StringUtils.normalizeSpace(Source),
				StringUtils.normalizeSpace(Precision),
				StringUtils.normalizeSpace(TPrecision),
				StringUtils.normalizeSpace(YearBuilt),
				StringUtils.normalizeSpace(NoOfStories),
				StringUtils.normalizeSpace(AddressLine1),
				StringUtils.normalizeSpace(City),
				StringUtils.normalizeSpace(PostalCode),
				StringUtils.normalizeSpace(Country),
				StringUtils.normalizeSpace(Latitude),
				StringUtils.normalizeSpace(Longitude),
				StringUtils.normalizeSpace(DQI),
				StringUtils.normalizeSpace(TIVInUSD),
				StringUtils.normalizeSpace(ConstructionClass),
				StringUtils.normalizeSpace(ConstructionScheme),
				StringUtils.normalizeSpace(ConstructionWeigh),
				StringUtils.normalizeSpace(YearBuiltWeigh),
				StringUtils.normalizeSpace(NoOfStoriesWeigh),
				StringUtils.normalizeSpace(CopeWeigh),
				StringUtils.normalizeSpace(AddrConfidence),
				StringUtils.normalizeSpace(DistanceFromSource),
				StringUtils.normalizeSpace(MatchResult) };

		sBuffer.append(StringUtils.replaceEach(RecordHeader, searchList,
				inputReplacementList)
				+ "\n");
		String SSource = StringUtils.substringBetween(SuspectRecord, "Source:",
				"}");
		String SPrecision = StringUtils.substringBetween(SuspectRecord,
				"Precision:", "}");
		String STPrecision = StringUtils.substringBetween(SuspectRecord,
				"Transalated Precision:", "}");
		String SYearBuilt = StringUtils.substringBetween(SuspectRecord,
				"Year Built:", "}");
		String SNoOfStories = StringUtils.substringBetween(SuspectRecord,
				"No Of Stories:", "}");
		String SAddressLine1 = StringUtils.substringBetween(SuspectRecord,
				"Address Line:", "}");
		String SCity = StringUtils
				.substringBetween(SuspectRecord, "City:", "}");
		String SPostalCode = StringUtils.substringBetween(SuspectRecord,
				"Postal Code:", "}");
		String SCountry = StringUtils.substringBetween(SuspectRecord,
				"Country:", "}");
		String SLatitude = StringUtils.substringBetween(SuspectRecord,
				"Latitude:", "}");
		String SLongitude = StringUtils.substringBetween(SuspectRecord,
				"Longitude:", "}");

		String SConstructionClass = StringUtils.substringBetween(SuspectRecord,
				"Construction Class:", "}");
		String SConstructionScheme = StringUtils.substringBetween(
				SuspectRecord, "Construction Scheme:", "}");
		String SConstructionWeigh = StringUtils.substringBetween(SuspectRecord,
				"Construction Weightage:", "}");
		String SYearBuiltWeigh = StringUtils.substringBetween(SuspectRecord,
				"Year Built Weightage:", "}");
		String SNoOfStoriesWeigh = StringUtils.substringBetween(SuspectRecord,
				"No Of Stories Weightage:", "}");
		String SCopeWeigh = StringUtils.substringBetween(SuspectRecord,
				"Overall COPE Confidence:", "}");
		String SAddrConfidence = StringUtils.substringBetween(SuspectRecord,
				"Address Confidence:", "}");
		String SDistanceFromSource = StringUtils.substringBetween(
				SuspectRecord, "Distance From Source:", "}");
		String SMatchResult = StringUtils.substringAfter(SuspectRecord,
				"Match Result:");

		String[] SuspectReplacementList = {
				DateFormat.format(Calendar.getInstance().getTime()), "Suspect",
				StringUtils.normalizeSpace(SSource),
				StringUtils.normalizeSpace(SPrecision),
				StringUtils.normalizeSpace(STPrecision),
				StringUtils.normalizeSpace(SYearBuilt),
				StringUtils.normalizeSpace(SNoOfStories),
				StringUtils.normalizeSpace(SAddressLine1),
				StringUtils.normalizeSpace(SCity),
				StringUtils.normalizeSpace(SPostalCode),
				StringUtils.normalizeSpace(SCountry),
				StringUtils.normalizeSpace(SLatitude),
				StringUtils.normalizeSpace(SLongitude),
				StringUtils.normalizeSpace("NA"),
				StringUtils.normalizeSpace("NA"),
				StringUtils.normalizeSpace(SConstructionClass),
				StringUtils.normalizeSpace(SConstructionScheme),
				StringUtils.normalizeSpace(SConstructionWeigh),
				StringUtils.normalizeSpace(SYearBuiltWeigh),
				StringUtils.normalizeSpace(SNoOfStoriesWeigh),
				StringUtils.normalizeSpace(SCopeWeigh),
				StringUtils.normalizeSpace(SAddrConfidence),
				StringUtils.normalizeSpace(SDistanceFromSource),
				StringUtils.normalizeSpace(SMatchResult) };

		sBuffer.append(StringUtils.replaceEach(RecordHeader, searchList,
				SuspectReplacementList)
				+ "\n");

		return sBuffer.toString();
	}

	public static String getHeaderEntry() {

		StringBuffer sBuffer = new StringBuffer();

		sBuffer.append(RecordHeader + "\n");

		return sBuffer.toString();

	}
}
