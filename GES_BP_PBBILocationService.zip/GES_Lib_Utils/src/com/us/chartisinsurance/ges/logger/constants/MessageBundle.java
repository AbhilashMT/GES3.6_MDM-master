/**
 * 
 */
package com.us.chartisinsurance.ges.logger.constants;

/**
 * @author Abhilash
 * 
 */
public interface MessageBundle {

	// requestOnly , IntegrationGW
	public static final String COM_GES_MF_IntegrationServiceGateway_requestOnly__ENTRY = " Log Entry , requestOnly \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestOnly__Audit = " Log Audit Message , requestOnly \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestOnly__Info = " Log Informational Message , requestOnly \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestOnly__SEVERE = " An Exception Occured , requestOnly \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestOnly__EXIT = " Log Exit, requestOnly \n";

	// requestResponse , IntegrationGW
	public static final String COM_GES_MF_IntegrationServiceGateway_requestResponse__ENTRY = " Log Entry , requestResponse \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestResponse__Audit = " Log Audit Message , requestResponse \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestResponse__Info = " Log Informational Message , requestResponse \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE = " An Exception Occured , requestResponse \n";
	public static final String COM_GES_MF_IntegrationServiceGateway_requestResponse__EXIT = " Log Exit, requestResponse \n";
	// getAccounts , LocationExposureService
	public static final String COM_GES_MF_LocationExposureService_getAccounts__ENTRY = " Log Entry , getAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getAccounts__INFO = " Log Info , getAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getAccounts__WSREQ = " Log Service Request Message , getAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getAccounts__WSRES = " Log Service Response Message , getAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getAccounts__SEVERE = " An Exception Occured , getAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getAccounts__FAULT = " An Modeled Fault Received , getAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getAccounts__EXIT = " Log Exit, getAccounts \n";

	// getMoreAccounts , LocationExposureService
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__ENTRY = " Log Entry , getMoreAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__INFO = " Log Info , getMoreAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__WSREQ = " Log Service Request Message , getMoreAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__WSRES = " Log Service Response Message , getMoreAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__SEVERE = " An Exception Occured , getMoreAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__FAULT = " An Modeled Fault Received , getMoreAccounts \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__EXIT = " Log Exit, getMoreAccounts \n";

	// getLocations , LocationExposureService

	public static final String COM_GES_MF_LocationExposureService_getLocations__ENTRY = " Log Entry , getLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getLocations__INFO = " Log Info , getLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getLocations__WSREQ = " Log Service Request Message , getLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getLocations__WSRES = " Log Service Response Message , getLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getLocations__SEVERE = " An Exception Occured , getLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getLocations__FAULT = " An Modeled Fault Received , getLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getLocations__EXIT = " Log Exit , getLocations \n";

	// getLocations , LocationExposureService

	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__ENTRY = " Log Entry , getMoreLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__INFO = " Log Info , getMoreLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__WSREQ = " Log Service Request Message , getMoreLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__WSRES = " Log Service Response Message , getMoreLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__SEVERE = " An Exception Occured , getMoreLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__FAULT = " An Modeled Fault Received , getMoreLocations \n";
	public static final String COM_GES_MF_LocationExposureService_getMoreLocations__EXIT = " Log Exit , getMoreLocations \n";

	// getLocationDetails , LocationExposureService

	public static final String COM_GES_MF_LocationExposureService_getLocationDetails__ENTRY = " Log Entry , getLocationDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getLocationDetails__INFO = " Log Info , getLocationDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getLocationDetails__WSREQ = " Log Service Request Message , getLocationDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getLocationDetails__WSRES = " Log Service Response Message ,getLocationDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getLocationDetails__SEVERE = " An Exception Occured , getLocationDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getLocationDetails__FAULT = " An Modeled Fault Received , getLocationDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getLocationDetails_EXIT = " Log Exit , getLocationDetails \n";

	// getPolicyDetails , LocationExposureService

	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails__ENTRY = " Log Entry , getPolicyDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails__INFO = " Log Info , getPolicyDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails__WSREQ = " Log Service Request Message , getPolicyDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails__WSRES = " Log Service Response Message ,getPolicyDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails__SEVERE = " An Exception Occured , getPolicyDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails__FAULT = " An Modeled Fault Received , getPolicyDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyDetails_EXIT = " Log Exit , getPolicyDetails \n";

	// getPolicyOptionDetails , LocationExposureService

	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails__ENTRY = " Log Entry , getPolicyOptionDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails__INFO = " Log Info , getPolicyOptionDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails__WSREQ = " Log Service Request Message , getPolicyOptionDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails__WSRES = " Log Service Response Message ,getPolicyOptionDetails\n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails__SEVERE = " An Exception Occured , getPolicyOptionDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails__FAULT = " An Modeled Fault Received , getPolicyOptionDetails \n";
	public static final String COM_GES_MF_LocationExposureService_getPolicyOptionDetails_EXIT = " Log Exit , getPolicyOptionDetails \n";

	// createPolicyOption , LocationExposureService

	public static final String COM_GES_MF_PolicyService_createPolicyOption__ENTRY = " Log Entry , createPolicyOption\n";
	public static final String COM_GES_MF_PolicyService_createPolicyOption__INFO = " Log Info , createPolicyOption\n";
	public static final String COM_GES_MF_PolicyService_createPolicyOption__WSREQ = " Log Service Request Message , createPolicyOption \n";
	public static final String COM_GES_MF_PolicyService_createPolicyOption__WSRES = " Log Service Response Message ,createPolicyOption\n";
	public static final String COM_GES_MF_PolicyService_createPolicyOption__SEVERE = " An Exception Occured , createPolicyOption \n";
	public static final String COM_GES_MF_PolicyService_createPolicyOption__FAULT = " An Modeled Fault Received , createPolicyOption \n";
	public static final String COM_GES_MF_PolicyService_createPolicyOption_EXIT = " Log Exit , createPolicyOption \n";
	
	// getPolicyOptionDetails , LocationExposureService

	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails__ENTRY = " Log Entry , getPolicyOptionDetails\n";
	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails__INFO = " Log Info , getPolicyOptionDetails\n";
	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails__WSREQ = " Log Service Request Message , getPolicyOptionDetails \n";
	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails__WSRES = " Log Service Response Message ,getPolicyOptionDetails\n";
	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails__SEVERE = " An Exception Occured , getPolicyOptionDetails \n";
	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails__FAULT = " An Modeled Fault Received , getPolicyOptionDetails \n";
	public static final String COM_GES_MF_PolicyService_getPolicyOptionDetails_EXIT = " Log Exit , getPolicyOptionDetails \n";
	
	// receiveLocationUpdates , LocationExposureNotificationService

	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__ENTRY = " Log Entry , receiveLocationUpdates \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__INFO = " Log Info , receiveLocationUpdates \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSREQ = " Log Service Request Message , receiveLocationUpdates \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSRES = " Log Service Response Message , receiveLocationUpdates \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE = " An Exception Occured , receiveLocationUpdates \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__FAULT = " An Modeled Fault Received , receiveLocationUpdates \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__EXIT = " Log Exit , receiveLocationUpdates \n";

	// receiveLocationUpdates , LocationExposureNotificationService

	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__ENTRY = " Log Entry , updateExposureLocationInfo \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__INFO = " Log Info , updateExposureLocationInfo \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__WSREQ = " Log Service Request Message , updateExposureLocationInfo \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__WSRES = " Log Service Response Message , updateExposureLocationInfo \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__SEVERE = " An Exception Occured , updateExposureLocationInfo \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__FAULT = " An Modeled Fault Received , updateExposureLocationInfo \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_updateExposureLocationInfo__EXIT = " Log Exit , updateExposureLocationInfo \n";

	// sendLocationUpdateAck , LocationExposureNotificationService

	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__ENTRY = " Log Entry , sendLocationUpdateAck \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__INFO = " Log Info , sendLocationUpdateAck \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__WSREQ = " Log Service Request Message , sendLocationUpdateAck \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__WSRES = " Log Service Response Message , sendLocationUpdateAck \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__SEVERE = " An Exception Occured , sendLocationUpdateAck \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__FAULT = " An Modeled Fault Received , sendLocationUpdateAck \n";
	public static final String COM_GES_MF_LocationExposureNotificationService_sendLocationUpdateAck__EXIT = " Log Exit , sendLocationUpdateAck \n";

	// insertAuditMessage , DataService

	public static final String COM_GES_MF_DataService_insertAuditMessage__ENTRY = " Log Entry , insertAuditMessages\n";
	public static final String COM_GES_MF_DataService_insertAuditMessage__INFO = " Log Info , insertAuditMessages\n";
	public static final String COM_GES_MF_DataService_insertAuditMessage__WSREQ = " Log Service Request Message , insertAuditMessage \n";
	public static final String COM_GES_MF_DataService_insertAuditMessage__WSRES = " Log Service Response Message ,insertAuditMessage\n";
	public static final String COM_GES_MF_DataService_insertAuditMessages__SEVERE = " An Exception Occured , insertAuditMessage \n";
	public static final String COM_GES_MF_DataService_insertAuditMessage__FAULT = " An Modeled Fault Received , insertAuditMessage \n";
	public static final String COM_GES_MF_DataService_insertAuditMessage_EXIT = " Log Exit , insertAuditMessage \n";

	// updateEngineeringDetails , DataService

	public static final String COM_GES_MF_DataService_updateEngineeringDetails__ENTRY = " Log Entry , updateEngineeringDetails\n";
	public static final String COM_GES_MF_DataService_updateEngineeringDetails__INFO = " Log Info , updateEngineeringDetails\n";
	public static final String COM_GES_MF_DataService_updateEngineeringDetails__WSREQ = " Log Service Request Message , updateEngineeringDetails \n";
	public static final String COM_GES_MF_DataService_updateEngineeringDetails__WSRES = " Log Service Response Message ,updateEngineeringDetails\n";
	public static final String COM_GES_MF_DataService_updateEngineeringDetails__SEVERE = " An Exception Occured , updateEngineeringDetails \n";
	public static final String COM_GES_MF_DataService_updateEngineeringDetails__FAULT = " An Modeled Fault Received , updateEngineeringDetails \n";
	public static final String COM_GES_MF_DataService_updateEngineeringDetails_EXIT = " Log Exit , updateEngineeringDetails \n";

	// scrubLocations , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations__ENTRY = " Log Entry , scrubLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations__INFO = " Log Info , scrubLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations__WSREQ = " Log Service Request Message , scrubLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations__WSRES = " Log Service Response Message ,scrubLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations__SEVERE = " An Exception Occured , scrubLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations__FAULT = " An Modeled Fault Received , scrubLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_scrubLocations_EXIT = " Log Exit , scrubLocations \n";

	// notifyAddLocations , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations__ENTRY = " Log Entry , notifyAddLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations__INFO = " Log Info , notifyAddLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations__WSREQ = " Log Service Request Message , notifyAddLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations__WSRES = " Log Service Response Message ,notifyAddLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations__SEVERE = " An Exception Occured , notifyAddLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations__FAULT = " An Modeled Fault Received , notifyAddLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocations_EXIT = " Log Exit , notifyAddLocations \n";

	// notifyBoundLocations , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations__ENTRY = " Log Entry , notifyBoundLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations__INFO = " Log Info ,notifyBoundLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations__WSREQ = " Log Service Request Message ,notifyBoundLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations__WSRES = " Log Service Response Message ,notifyBoundLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations__SEVERE = " An Exception Occured , notifyBoundLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations__FAULT = " An Modeled Fault Received , notifyBoundLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocations_EXIT = " Log Exit , notifyAddLocations \n";

	// notifyAddLocationsAsync , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync__ENTRY = " Log Entry , notifyAddLocationsAsync\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync__INFO = " Log Info , notifyAddLocationsAsync\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync__WSREQ = " Log Service Request Message , notifyAddLocationsAsync \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync__WSRES = " Log Service Response Message ,notifyAddLocationsAsync\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync__SEVERE = " An Exception Occured , notifyAddLocationsAsync \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync__FAULT = " An Modeled Fault Received , notifyAddLocationsAsync \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyAddLocationsAsync_EXIT = " Log Exit , notifyAddLocationsAsync \n";

	// ADDlOCATIONS , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_addLocations__ENTRY = " Log Entry , AddLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_addLocations__INFO = " Log Info , AddLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_addLocations__WSREQ = " Log Service Request Message , AddLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_addLocations__WSRES = " Log Service Response Message ,AddLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_addLocations__SEVERE = " An Exception Occured , AddLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_addLocations__FAULT = " An Modeled Fault Received , AddLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_addLocations_EXIT = " Log Exit , AddLocations \n";
	// UPDATElOCATIONS , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_updateLocation__ENTRY = " Log Entry , UpdateLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_updateLocation__INFO = " Log Info , UpdateLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_updateLocation__WSREQ = " Log Service Request Message , UpdateLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_updateLocation__WSRES = " Log Service Response Message ,UpdateLocations\n";
	public static final String COM_GES_MF_LocationScrubbingService_updateLocation__SEVERE = " An Exception Occured , UpdateLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_updateLocation__FAULT = " An Modeled Fault Received , UpdateLocations \n";
	public static final String COM_GES_MF_LocationScrubbingService_updateLocation_EXIT = " Log Exit , UpdateLocations \n";

	// notifyBoundLocationsAsync , LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync__ENTRY = " Log Entry , notifyBoundLocationsAsync\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync__INFO = " Log Info , notifyAddLocationsAsync\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync__WSREQ = " Log Service Request Message , notifyBoundLocationsAsync \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync__WSRES = " Log Service Response Message ,notifyBoundLocationsAsync\n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync__SEVERE = " An Exception Occured , notifyBoundLocationsAsyncc \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync__FAULT = " An Modeled Fault Received , notifyBoundLocationsAsync \n";
	public static final String COM_GES_MF_LocationScrubbingService_notifyBoundLocationsAsync_EXIT = " Log Exit , notifyBoundLocationsAsync \n";

	// EnqueueMessage SubFlow, LocationScrubbingService

	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow__ENTRY = " Log Entry , EnqueueMessageSubFlow\n";
	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow__INFO = " Log Info , EnqueueMessageSubFlow\n";
	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow__WSREQ = " Log Service Request Message , EnqueueMessageSubFlow \n";
	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow__WSRES = " Log Service Response Message ,EnqueueMessageSubFlow\n";
	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow__SEVERE = " An Exception Occured , EnqueueMessageSubFlow \n";
	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow__FAULT = " An Modeled Fault Received , EnqueueMessageSubFlow \n";
	public static final String COM_GES_MF_LocationScrubbingService_EnqueueMessageSubFlow_EXIT = " Log Exit , EnqueueMessageSubFlow \n";

	// getLocationDetails , MDMLocationService

	public static final String COM_GES_MF_MDMLocationService_getLocationDetails__ENTRY = " Log Entry , getLocationDetails\n";
	public static final String COM_GES_MF_MDMLocationService_getLocationDetails__INFO = " Log Info , getLocationDetails \n";
	public static final String COM_GES_MF_MDMLocationService_getLocationDetails__WSREQ = " Log Service Request Message , getLocationDetails \n";
	public static final String COM_GES_MF_MDMLocationService_getLocationDetails__WSRES = " Log Service Response Message ,getLocationDetails \n";
	public static final String COM_GES_MF_MDMLocationService_getLocationDetails__SEVERE = " An Exception Occured , getLocationDetails \n";
	public static final String COM_GES_MF_MDMLocationService_getLocationDetails__FAULT = " An Modeled Fault Received , getLocationDetails \n";
	public static final String COM_GES_MF_MDMLocationService_getLocationDetails_EXIT = " Log Exit , getLocationDetails \n";

	// getLocationDetails , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails__ENTRY = " Log Entry , getLocationDetails\n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails__INFO = " Log Info , getLocationDetails \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails__WSREQ = " Log Service Request Message , getLocationDetails \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails__WSRES = " Log Service Response Message ,getLocationDetails \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails__SEVERE = " An Exception Occured , getLocationDetails \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails__FAULT = " An Modeled Fault Received , getLocationDetails \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocationDetails_EXIT = " Log Exit , getLocationDetails \n";

	// addLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_addLocations__ENTRY = " Log Entry , addLocations\n";
	public static final String COM_GES_MF_LocationServiceRouter_addLocations__INFO = " Log Info , addLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_addLocations__WSREQ = " Log Service Request Message , addLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_addLocations__WSRES = " Log Service Response Message ,addLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_addLocations__SEVERE = " An Exception Occured , addLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_addLocations__FAULT = " An Modeled Fault Received , addLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_addLocations_EXIT = " Log Exit , addLocations \n";

	// getLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_getLocations__ENTRY = " Log Entry , getLocations\n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocations__INFO = " Log Info , getLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocations__WSREQ = " Log Service Request Message , getLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocations__WSRES = " Log Service Response Message ,getLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocations__SEVERE = " An Exception Occured , getLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocations__FAULT = " An Modeled Fault Received , getLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_getLocations_EXIT = " Log Exit , getLocations \n";

	// matchLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_matchLocations__ENTRY = " Log Entry , matchLocations\n";
	public static final String COM_GES_MF_LocationServiceRouter_matchLocations__INFO = " Log Info , matchLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_matchLocations__WSREQ = " Log Service Request Message , matchLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_matchLocations__WSRES = " Log Service Response Message ,matchLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_matchLocations__SEVERE = " An Exception Occured , matchLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_matchLocations__FAULT = " An Modeled Fault Received , matchLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_matchLocations_EXIT = " Log Exit , matchLocations \n";

	// standardizeAndAugmentLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations__ENTRY = " Log Entry , standardizeAndAugmentLocations\n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations__INFO = " Log Info , standardizeAndAugmentLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations__WSREQ = " Log Service Request Message , standardizeAndAugmentLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations__WSRES = " Log Service Response Message ,standardizeAndAugmentLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations__SEVERE = " An Exception Occured , standardizeAndAugmentLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations__FAULT = " An Modeled Fault Received , standardizeAndAugmentLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeAndAugmentLocations_EXIT = " Log Exit , standardizeAndAugmentLocations \n";

	// updateContract , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_updateContract__ENTRY = " Log Entry , updateContract\n";
	public static final String COM_GES_MF_LocationServiceRouter_updateContract__INFO = " Log Info , updateContract \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateContract__WSREQ = " Log Service Request Message , updateContract \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateContract__WSRES = " Log Service Response Message ,updateContract \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateContract__SEVERE = " An Exception Occured , updateContract \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateContract__FAULT = " An Modeled Fault Received , updateContract \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateContract_EXIT = " Log Exit , updateContract \n";

	// standardizeLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations__ENTRY = " Log Entry , standardizeLocations\n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations__INFO = " Log Info , standardizeLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations__WSREQ = " Log Service Request Message , standardizeLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations__WSRES = " Log Service Response Message ,standardizeLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations__SEVERE = " An Exception Occured , standardizeLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations__FAULT = " An Modeled Fault Received , standardizetLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_standardizeLocations_EXIT = " Log Exit , standardizeLocations \n";

	// getGeoCode , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode__ENTRY = " Log Entry , getGeoCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode__INFO = " Log Info , getGeoCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode__WSREQ = " Log Service Request Message , getGeoCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode__WSRES = " Log Service Response Message ,getGeoCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode__SEVERE = " An Exception Occured , getGeoCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode__FAULT = " An Modeled Fault Received , getGeoCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getGeoCode_EXIT = " Log Exit , getGeoCode \n";

	// getCrestaCode , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode__ENTRY = " Log Entry , getCrestaCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode__INFO = " Log Info , getCrestaCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode__WSREQ = " Log Service Request Message , getCrestaCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode__WSRES = " Log Service Response Message ,getCrestaCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode__SEVERE = " An Exception Occured , getCrestaCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode__FAULT = " An Modeled Fault Received , getCrestaCode \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCrestaCode_EXIT = " Log Exit , getCrestaCode \n";

	// getCanadaFloodZone , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone__ENTRY = " Log Entry , getCanadaFloodZone \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone__INFO = " Log Info , getCanadaFloodZone \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone__WSREQ = " Log Service Request Message , getCanadaFloodZone \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone__WSRES = " Log Service Response Message ,getCanadaFloodZone \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone__SEVERE = " An Exception Occured , getCanadaFloodZone \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone__FAULT = " An Modeled Fault Received , getCanadaFloodZone \n";
	public static final String COM_GES_MF_LocationServiceRouter_getCanadaFloodZone_EXIT = " Log Exit , getCanadaFloodZone \n";

	// updateLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_updateLocations__ENTRY = " Log Entry , updateLocations\n";
	public static final String COM_GES_MF_LocationServiceRouter_updateLocations__INFO = " Log Info , updateLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateLocations__WSREQ = " Log Service Request Message , updateLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateLocations__WSRES = " Log Service Response Message ,updateLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateLocations__SEVERE = " An Exception Occured , updateLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateLocations__FAULT = " An Modeled Fault Received , updateLocations \n";
	public static final String COM_GES_MF_LocationServiceRouter_updateLocations_EXIT = " Log Exit , updateLocations \n";

	// updateLocations , LocationServiceRouter

	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding__ENTRY = " Log Entry , reverseGeoCoding\n";
	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding__INFO = " Log Info , reverseGeoCoding \n";
	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding__WSREQ = " Log Service Request Message , reverseGeoCoding \n";
	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding__WSRES = " Log Service Response Message ,reverseGeoCoding \n";
	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding__SEVERE = " An Exception Occured , reverseGeoCoding \n";
	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding__FAULT = " An Modeled Fault Received , reverseGeoCoding \n";
	public static final String COM_GES_MF_LocationServiceRouter_reverseGeoCoding_EXIT = " Log Exit , reverseGeoCoding \n";

	// getShapeFileInfo , ShapeFileService

	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo__ENTRY = " Log Entry , getShapeFileInfo\n";
	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo__INFO = " Log Info , getShapeFileInfo \n";
	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo__WSREQ = " Log Service Request Message , getShapeFileInfo \n";
	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo__WSRES = " Log Service Response Message ,getShapeFileInfo \n";
	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo_SEVERE = " An Exception Occured , getShapeFileInfo \n";
	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo_FAULT = " An Modeled Fault Received , getShapeFileInfo \n";
	public static final String COM_GES_MF_ShapeFileService_getShapeFileInfo_EXIT = " Log Exit , getShapeFileInfo \n";

	// pushDataToCache ,CacheService
	public static final String COM_GES_MF_CacheService_pushDataToCache__ENTRY = " Log Entry , pushDataToCache\n";
	public static final String COM_GES_MF_CacheService_getPolicyDetails__WSREQ = " Log Service Request Message , Cache_To_getPolicyDetails \n";
	public static final String COM_GES_MF_CacheService_getAccountDetails__WSREQ = " Log Service Request Message , Cache_To_getAccountDetails \n";
	public static final String COM_GES_MF_CacheService_getPolicyOptions__WSREQ = " Log Service Request Message , Cache_To_getPolicyOptions \n";
	public static final String COM_GES_MF_CacheService_getPolicyLocations__WSREQ = " Log Service Request Message , Cache_To_getPolicyLocations \n";
	public static final String COM_GES_MF_CacheService_getPolicyDetails__WSRES = " Log Service Response Message , getPolicyDetails_To_Cache \n";
	public static final String COM_GES_MF_CacheService_getAccountDetails__WSRES = " Log Service Response Message ,getAccountDetails_To_Cache \n";
	public static final String COM_GES_MF_CacheService_getPolicyOptions__WSRES = " Log Service Response Message , getPolicyOptions_To_Cache \n";
	public static final String COM_GES_MF_CacheService_getPolicyLocations__WSRES = " Log Service Response Message ,getPolicyLocations_To_Cache \n";
	public static final String COM_GES_MF_CacheService_pushDataToCache_EXIT = " Log Exit , pushDataToCache \n";
	public static final String COM_GES_MF_CacheService_pushDataToCache_SEVERE = "Log Severe, pushDataToCache\n";
	public static final String COM_GES_MF_CacheService_pushDataToCache_FAULT = "An Modeled Fault Received , pushDataToCache\n";
	public static final String COM_GES_MF_CacheService_getAggLocations__WSREQ = " Log Service Response Message , getPolicyLocation_To_Cache \n";
	public static final String COM_GES_MF_CacheService_getAggLocations__WSRES = " Log Service Response Message ,getPolicyLocations_To_Cache \n";

	
	// requestResponse , DynamicGateway   
	   public static final String COM_GES_MF_DynamicIntegrationServiceGateway_ServiceGateway_ENTRY = " Log Entry , Log_Gateway_Entry_Req_Data \n";
	   public static final String COM_GES_MF_DynamicIntegrationServiceGateway_ServiceGateway_FAILEDDYNALOOKUP = " Log fail, Log_Gateway_LookUp_Failure \n";
//		public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__INFO = " Log Info , getMoreAccounts \n";
//		public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__WSREQ = " Log Service Request Message , getMoreAccounts \n";
//		public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__WSRES = " Log Service Response Message , getMoreAccounts \n";
//		public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__SEVERE = " An Exception Occured , getMoreAccounts \n";
//		public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__FAULT = " An Modeled Fault Received , getMoreAccounts \n";
//		public static final String COM_GES_MF_LocationExposureService_getMoreAccounts__EXIT = " Log Exit, getMoreAccounts \n";


}
