package com.us.chartisinsurance.ges.handlers.jax.ws.custom;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import com.aig.us.ges.cache.utils.AuthCredentials;
import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.us.aig.ges.constants.GESConstantBundle;

import commonj.sdo.DataObject;

public class DecryptDataHandler implements SOAPHandler<SOAPMessageContext> {

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		// TODO Auto-generated method stub

		
			String password=null;
			String username=null;

			//Setting for outbound Service

			Boolean isRequest = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

			if(isRequest)
			{
				
				HashMap authValues=(HashMap)GESCacheLoader.getValueFromCache(GESConstantBundle.PEGACREDENTIALS);

				Set<String> keysets=authValues.keySet();
				for(String keyset:keysets)
				{
					username=keyset;
					password=new AuthCredentials().decryptStr(authValues.get(keyset).toString());
				}

				

				context.put(BindingProvider.USERNAME_PROPERTY, username);	
				context.put(BindingProvider.PASSWORD_PROPERTY,password );




				return true;

			
	
			}
			
			return true;
	}

}
