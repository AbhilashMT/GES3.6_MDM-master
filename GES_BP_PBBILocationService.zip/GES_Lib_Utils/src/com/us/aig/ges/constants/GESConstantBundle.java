/**
 * 
 */
package com.us.aig.ges.constants;

/**
 * @author Asurendr
 * 
 */
public interface GESConstantBundle {

	public static final String SCRUBBING_INITIALFETCH = "sInitFetch"; // This
	// defines
	// the
	// initial
	// Fetch
	// Size
	// from
	// DB
	public static final String SCRUBBING_MAXFETCH = "sMaxFetch";// This defines
	// the Maximum
	// Fetch Size
	// from DB
	public static final String SCRUBBING_ISBURSTMODE = "sBurstMode";
	public static final String SCRUBBING_ISALGENABLED = "sRandomMode";
	public static final String SCRUBBING_BATCHSIZE = "sBatchSize";// Allows
	public static final String GRASP_BATCHSIZE = "gBatchSize";
	// Further
	// Control
	// by
	// Splitting
	// Locations
	public static final String SCRUBBING_ISSEQUENCED = "sIsSequenced";
	public static final String SCRUBBING_ISBATCHENABLED = "sIsBatchModeEnabled"; // Has
	// to
	// be
	// enabled
	// for
	// sBatchSize
	// to
	// Work
	public static final String SCRUBBING_ISMDMENABLED = "sIsMDMEnabled";
	public static final String SCRUBBING_ISASNYC = "sIsAsynEnabled"; // Decides

	// whether
	// to
	// invoke
	// MDM
	public static final String SCRUBBING_PBBI_ERROR = "sPbbiError"; // Configured
	// PBBI
	// Error
	// field in
	// Database
	public static final String SCRUBBING_SLP_MODE = "sSLPMode"; // SLP Indicates
	// Search
	// Location
	// Process
	// Invocation

	public static final String GRASP_ISMDMENABLED = "gIsMDMEnabled"; // Decides
	public static final String GRASP_ACCOUNTTHRESHOLD = "gAccountThreshold"; // Value
	public static final String GRASP_LOCATIONTHRESHOLD = "gLocationThreshold"; // Value
	// GRASP Related Constants

	public static final String SCRUBBING_CLEANSING_ASYNC = "sCleansingAsyncMode";
	public static final String GES_GATEWAY_CONFIG = "gGatewayConfig";

	public static final String GES_LOG_DIR = "/opt/logs/wps70/commsvcesb/";
	public static final String GES_LOG_SUFFIX = "/ges/";
	public static final String GES_ME_CHECK = "gEnableMeCheck";
	public static final String GES_NOFIFY_SCRUBBINGADDR = "sNotifyScrubbingAddresses";
	public static final String GES_FROM_ADDR = "GESSupport@aig.com";

	public static final String GRASP_NOTIFY_ADDR = "sGRASPAddresses";

	public static final String PEGA_UNAME = "pUserName";
	public static final String PEGA_PASSWORD = "pUserPassword";

	public static final String PEGACREDENTIALS = "PEGACREDENTIALS";

	public static final String AUTHCACHE_STATUS = "authCacheStatus";
	public static final String GES_ENABLE_GATEWAY = "sGatewayEnabled";

	public static final String PROPERTIES = "Properties";
	public static final String USESPICOMPONENT = "sPerformWithSPI";
	public static final String ACTIVATECMONITOR = "sActivateCMonitor";

	public static final String LOGONLYEVENTS = "logOnlyEvents";
	public static final String MATCHEXPR = "MatchExpression";

	public static final String LATLONGPRIORITY = "LatLongPriority";
	public static final String EnableCleansingRetry = "EnableCleansingRetry";

	public static enum AUDITSTATTYPE {
		INPROGRESS, UNKNOWN, SUCCESS, ERROR
	}

	public static final String GES_REVIVED_GATEWAY = "configGateway";
	
	public static final String PBBI_PROCESSING_MODE = "sPbbiSync";
	public static final String FILTERING_PROCESSING_MODE = "sFilteringSync";
}
