/**
 * 
 */
package com.aig.us.ges.cache.utils;

/**
 * @author Asurendr
 * 
 */
public interface LookUpKeysI {

	public final String MATCHCONFIGSRC_GES = "MATCHCONFIGSRC_GES";
	public final String MATCHCONFIGSRC_GRASP = "MATCHCONFIGSRC_GRASP";
	public final String MATCHCONFIGSRC_OTHERS = "MATCHCONFIGSRC_3rdParty";
	public final String COPECONFIG_CTC = "COPECONFIG_CTC";
	public final String COPECONFIG_OTH = "COPECONFIG_OTH";
	public final String CLEANSING = "CLEANSING";
	public final String GRASP = "GRASP";
	public final String MDMATTRIBUTE = "MDM.ATTRIBUTE";
	public final String PRECISION = "PRECISION";
	public final String COPEWEIGHT = "COPE.WEIGHT";
	public final String[] LOOKUPCONFIG = { "CACHECONFIG" };

}
