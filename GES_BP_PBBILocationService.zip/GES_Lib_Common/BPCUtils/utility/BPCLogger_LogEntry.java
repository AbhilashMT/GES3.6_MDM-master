package BPCUtils.utility;
public class BPCLogger_LogEntry {
	public static void bPCLogger_LogEntry(com.ibm.bpe.api.ActivityInstanceData ActivityInstanceData, java.lang.String inputMessage, commonj.sdo.DataObject dataObject, com.ibm.bpe.api.ProcessInstanceData ProcessInstance)throws com.ibm.websphere.sca.ServiceRuntimeException  {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = ActivityInstanceData.getApplicationName();
		java.lang.String __result__5 = ProcessInstance.getParentProcessInstanceName();
		java.lang.String __result__7 = ProcessInstance.getProcessTemplateName();
		try {
			__result__1.entering(__result__3, __result__5, __result__7, inputMessage, dataObject);
		}
		catch(com.ibm.websphere.sca.ServiceRuntimeException ex){
			throw ex;
		}
	}
}