package ExceptionHandlingUtils.utility.utility.utility;
public class TransformPBBIFaults {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject transformPBBIFaults(com.ibm.websphere.sibx.smobo.ServiceMessageObject inputSMO, java.lang.String outputMessageQName, java.lang.String OutputSMOMessageName, java.lang.String customMessage, java.lang.String moduleName, java.lang.String operationName) {
		commonj.sdo.DataObject __result__3;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(outputMessageQName, OutputSMOMessageName));
			__result__3 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject OutputSMOBody = __result__3;
		java.lang.Object __result__5 = inputSMO.getBody();
		byte __result__6 = 0;
		commonj.sdo.DataObject __result__7 = ((commonj.sdo.DataObject)__result__5).getDataObject(__result__6);
		commonj.sdo.DataObject ServiceInvocationFault = __result__7;
		commonj.sdo.DataObject __result__9;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__9 = factory.create("http://aig.us.com/ges/common/v3","GesFaultObjectType");
		}
		commonj.sdo.DataObject GESFaultObjectType = __result__9;
		GESFaultObjectType.setString("faultCode", customMessage);
		java.lang.String __result__14 = "PBBI";
		GESFaultObjectType.setString("faultOrigin", __result__14);
		byte __result__17 = 0;
		java.lang.String __result__18 = ServiceInvocationFault.getString(__result__17);
		java.lang.String message = __result__18;
		java.lang.String __result__22 = com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler.formatException(customMessage, message, moduleName, operationName);
		GESFaultObjectType.setString("faultString", __result__22);
		GESFaultObjectType.setString("faultDetail", message);
		java.util.ArrayList __result__11 = new java.util.ArrayList();
		java.util.ArrayList faultList = __result__11;
		boolean __result__28;
		{// add item to list
			__result__28 = faultList.add(GESFaultObjectType);
		}
		commonj.sdo.DataObject __result__29;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__29 = factory.create("http://aig.us.com/ges/common/v3","ArrayOfGESFault");
		}
		commonj.sdo.DataObject arrayOfGESFault = __result__29;
		arrayOfGESFault.set("gesFaults", faultList);
		byte __result__34 = 0;
		commonj.sdo.DataObject __result__35 = OutputSMOBody.createDataObject(__result__34);
		commonj.sdo.DataObject outputSMOBody_firstChild = __result__35;
		outputSMOBody_firstChild = arrayOfGESFault;
		byte __result__40 = 0;
		OutputSMOBody.setDataObject(__result__40, outputSMOBody_firstChild);
		java.lang.String __result__44 = "..";
		commonj.sdo.DataObject __result__45 = OutputSMOBody.getDataObject(__result__44);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)__result__45;
	}
}