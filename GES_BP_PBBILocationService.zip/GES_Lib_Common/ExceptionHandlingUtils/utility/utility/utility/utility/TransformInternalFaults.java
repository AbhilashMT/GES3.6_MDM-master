package ExceptionHandlingUtils.utility.utility.utility.utility;
public class TransformInternalFaults {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject transformInternalFaults(com.ibm.websphere.sibx.smobo.ServiceMessageObject inputSMO, java.lang.String outputMessageQName, java.lang.String OutputSMOMessageName, java.lang.String customMessage) {
		commonj.sdo.DataObject __result__3;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(outputMessageQName, OutputSMOMessageName));
			__result__3 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject OutputSMOBody = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://aig.us.com/ges/common/v3","ArrayOfGESFault");
		}
		commonj.sdo.DataObject arrayOfGESFault = __result__5;
		byte __result__8 = 0;
		commonj.sdo.DataObject __result__9 = OutputSMOBody.createDataObject(__result__8);
		commonj.sdo.DataObject outputSMOBody_firstChild = __result__9;
		java.lang.Object __result__11 = inputSMO.getBody();
		byte __result__12 = 0;
		commonj.sdo.DataObject __result__13 = ((commonj.sdo.DataObject)__result__11).getDataObject(__result__12);
		commonj.sdo.DataObject ArrayOfGESFault = __result__13;
		outputSMOBody_firstChild = ArrayOfGESFault;
		byte __result__17 = 0;
		OutputSMOBody.setDataObject(__result__17, outputSMOBody_firstChild);
		java.lang.String __result__21 = "..";
		commonj.sdo.DataObject __result__22 = OutputSMOBody.getDataObject(__result__21);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)__result__22;
	}
}