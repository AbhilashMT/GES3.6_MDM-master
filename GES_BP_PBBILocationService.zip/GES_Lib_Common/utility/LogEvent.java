package utility;
public class LogEvent {
	public static void logEvent(java.lang.String LogCategory, com.ibm.wsspi.sibx.mediation.esb.SCAServices aSCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MedServices, java.lang.String InMessage, commonj.sdo.DataObject InDataObject) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__4 = aSCAServices.getModuleName();
		java.lang.String __result__6 = MedServices.getMediationName();
		java.lang.String __result__7 = MedServices.getMediationDisplayName();
		java.util.logging.Level __result__10 = java.util.logging.Level.FINEST;
		__result__1.logCategory(LogCategory, __result__4, __result__6, __result__7, InMessage, InDataObject, __result__10);
	}
}