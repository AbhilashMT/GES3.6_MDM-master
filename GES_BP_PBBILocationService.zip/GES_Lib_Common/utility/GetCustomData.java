package utility;
public class GetCustomData {
	public static java.lang.String getCustomData(commonj.sdo.DataObject SPResults, java.lang.String ColumnName) {
		java.lang.String __result__1 = "XPATH : ";
		java.lang.String __result__2 = "SPResults/SPResult/ResultRows/ResultRow/ColumnRecords/ColumnRecord[@Name=";
		java.lang.String __result__3 = "'";
		java.lang.String __result__4;
		{// append text
			__result__4 = __result__3.concat(ColumnName);
		}
		java.lang.String __result__5 = "'";
		java.lang.String __result__6;
		{// append text
			__result__6 = __result__4.concat(__result__5);
		}
		java.lang.String __result__7;
		{// append text
			__result__7 = __result__2.concat(__result__6);
		}
		java.lang.String __result__8 = "]/ColumnValue";
		java.lang.String __result__10;
		{// append text
			__result__10 = __result__7.concat(__result__8);
		}
		java.lang.String __result__11;
		{// append text
			__result__11 = __result__1.concat(__result__10);
		}
		java.lang.String __result__13 = "SPResults";
		java.util.List __result__14 = SPResults.getList(__result__13);
		java.util.List SPResultsList = __result__14;
		boolean __result__16 = SPResultsList.isEmpty();
		boolean __result__17;
		{// inverse
			__result__17 = !__result__16;
		}
		if (__result__17){
			java.lang.Object __result__20 = SPResultsList.get(0);
			commonj.sdo.DataObject SPResultsType = (commonj.sdo.DataObject)__result__20;
		}
		else{
		}
		return __result__13;
	}
}