package SMO_services;
public class CreateGatewayResponseHeader {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject createGatewayResponseHeader(commonj.sdo.DataObject Input_SMO, commonj.sdo.DataObject ResponseBO) {
		java.lang.Object __result__3 = null;
		commonj.sdo.DataObject Header = (commonj.sdo.DataObject)__result__3;
		commonj.sdo.DataObject __result__5;
		{// create SMO body with gatewayMessage
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
			   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = 
			   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName("http://www.ibm.com/websphere/sibx/ServiceGateway", "gatewayMessage"));
			__result__5 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject GatewaySMOBody = __result__5;
		com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory __result__7 = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
		com.ibm.websphere.sibx.smobo.SOAPHeaderType __result__8 = __result__7.createSOAPHeaderType();
		com.ibm.websphere.sibx.smobo.SOAPHeaderType SOAPHeaderType = __result__8;
		java.lang.String __result__10 = "http://aig.com/CommonHeaderV12";
		SOAPHeaderType.setNameSpace(__result__10);
		java.lang.String __result__12 = "ResponseHeader";
		SOAPHeaderType.setName(__result__12);
		java.lang.String __result__14 = "com";
		SOAPHeaderType.setPrefix(__result__14);
		byte __result__2 = 1;
		boolean __result__16 = ResponseBO.isSet(__result__2);
		if (__result__16){
			commonj.sdo.DataObject __result__19 = ResponseBO.getDataObject(1);
			Header = __result__19;
		}
		else{
		}
		commonj.sdo.DataObject __result__23 = com.us.aig.ges.dataobject.utils.DataObjectUtils.truncateHeaderFromResponse(ResponseBO);
		commonj.sdo.DataObject PayLoad = __result__23;
		SOAPHeaderType.setValue(Header);
		java.lang.String __result__29 = "headers";
		java.lang.Object __result__30 = Input_SMO.get(__result__29);
		java.lang.String __result__31 = "SOAPHeader";
		java.util.List __result__32 = ((commonj.sdo.DataObject)__result__30).getList(__result__31);
		boolean __result__34 = __result__32.add(SOAPHeaderType);
		java.lang.String __result__36 = "..";
		commonj.sdo.DataObject __result__37 = GatewaySMOBody.getDataObject(__result__36);
		commonj.sdo.DataObject GatewayResponseSMO = __result__37;
		java.lang.String __result__40 = "headers";
		java.lang.String __result__42 = "headers";
		java.lang.Object __result__43 = Input_SMO.get(__result__42);
		GatewayResponseSMO.setDataObject(__result__40, (commonj.sdo.DataObject)__result__43);
		java.lang.String __result__46 = "body";
		GatewayResponseSMO.setDataObject(__result__46, PayLoad);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)GatewayResponseSMO;
	}
}