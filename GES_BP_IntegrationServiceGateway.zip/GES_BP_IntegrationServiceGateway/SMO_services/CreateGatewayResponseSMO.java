package SMO_services;
public class CreateGatewayResponseSMO {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject createGatewayResponseSMO(commonj.sdo.DataObject Input_SMO, commonj.sdo.DataObject ResponseBO, com.ibm.wsspi.sibx.mediation.esb.SCAServices SCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MediationServices) {
		java.lang.Object __result__1 = null;
		commonj.sdo.DataObject Header = (commonj.sdo.DataObject)__result__1;
		boolean __result__3 = null == ResponseBO;
		if (__result__3){
			return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)Input_SMO;
		}
		else{
		}
		byte __result__11 = 1;
		boolean __result__12 = ResponseBO.isSet(__result__11);
		if (__result__12){
			java.lang.String __result__17 = "Received Response Header Part ";
			commonj.sdo.DataObject __result__18 = ResponseBO.getDataObject(1);
			Header = __result__18;
			utility.MediationLogger_LogInfo.mediationLogger_LogInfo(SCAServices, MediationServices, __result__17, Header);
		}
		else{
		}
		java.util.List __result__22 = ResponseBO.getInstanceProperties();
		byte __result__23 = 0;
		java.lang.Object __result__24 = __result__22.get(__result__23);
		commonj.sdo.Property Property = (commonj.sdo.Property)__result__24;
		java.lang.String __result__26 = Property.getName();
		java.lang.String ResponseBOPayloadName = __result__26;
		java.lang.String __result__30 = "Received Response Body Part , Body Part Name is : ";
		java.lang.String __result__32;
		{// append text
			__result__32 = __result__30.concat(ResponseBOPayloadName);
		}
		utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(SCAServices, MediationServices, __result__32);
		java.lang.String __result__35 = "context/correlation/WSDLURI";
		java.lang.String __result__36 = Input_SMO.getString(__result__35);
		java.lang.String __result__38 = "context/correlation/MessageName";
		java.lang.String __result__39 = Input_SMO.getString(__result__38);
		commonj.sdo.DataObject __result__40;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(__result__36, __result__39));
			__result__40 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject SMOBODY = __result__40;
		commonj.sdo.DataObject __result__43 = SMOBODY.createDataObject(ResponseBOPayloadName);
		commonj.sdo.DataObject SMOBODY_FIRSTCHILD = __result__43;
		commonj.sdo.DataObject __result__47 = ResponseBO.getDataObject(ResponseBOPayloadName);
		SMOBODY_FIRSTCHILD = __result__47;
		SMOBODY.setDataObject(ResponseBOPayloadName, SMOBODY_FIRSTCHILD);
		// Body assignment done, Create for Headers
		com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory __result__49 = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
		com.ibm.websphere.sibx.smobo.SOAPHeaderType __result__55 = __result__49.createSOAPHeaderType();
		com.ibm.websphere.sibx.smobo.SOAPHeaderType SOAPHeaderType = __result__55;
		java.lang.String __result__57 = "http://aig.com/CommonHeaderV12";
		SOAPHeaderType.setNameSpace(__result__57);
		java.lang.String __result__59 = "ResponseHeader";
		SOAPHeaderType.setName(__result__59);
		java.lang.String __result__61 = "com";
		SOAPHeaderType.setPrefix(__result__61);
		SOAPHeaderType.setValue(Header);
		java.lang.String __result__69 = "..";
		commonj.sdo.DataObject __result__70 = SMOBODY.getDataObject(__result__69);
		commonj.sdo.DataObject GatewayResponseSMO = __result__70;
		java.lang.String __result__67 = "headers";
		java.lang.Object __result__73 = GatewayResponseSMO.get(__result__67);
		java.lang.String __result__72 = "SOAPHeader";
		java.util.List __result__74 = ((commonj.sdo.DataObject)__result__73).getList(__result__72);
		boolean __result__76 = __result__74.add(SOAPHeaderType);
		java.lang.String __result__79 = "GatewayResponse SMO Prepared : ";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(SCAServices, MediationServices, __result__79, GatewayResponseSMO);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)GatewayResponseSMO;
	}
}