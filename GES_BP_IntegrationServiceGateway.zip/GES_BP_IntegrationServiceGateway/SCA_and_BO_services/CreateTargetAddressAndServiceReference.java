package SCA_and_BO_services;
public class CreateTargetAddressAndServiceReference {
	public static com.ibm.websphere.sca.Service createTargetAddressAndServiceReference(java.lang.String TargetURI, java.lang.String PartnerName) {
		com.ibm.websphere.sca.addressing.EndpointReferenceFactory __result__1 = com.ibm.websphere.sca.addressing.EndpointReferenceFactory.INSTANCE;
		com.ibm.websphere.sca.addressing.EndpointReference __result__2 = __result__1.createEndpointReference();
		com.ibm.websphere.sca.addressing.EndpointReference epr = __result__2;
		epr.setAddress(TargetURI);
		com.ibm.websphere.sca.ServiceManager __result__7 = com.ibm.websphere.sca.ServiceManager.INSTANCE;
		java.lang.Object __result__10 = __result__7.getService(PartnerName, epr);
		com.ibm.websphere.sca.Service TargetService = (com.ibm.websphere.sca.Service)__result__10;
		return TargetService;
	}
}