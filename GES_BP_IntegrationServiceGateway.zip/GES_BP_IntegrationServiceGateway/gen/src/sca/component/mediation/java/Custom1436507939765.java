package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestResponse Type: request Custom Mediation: EnableGatewaycheck
 */
public class Custom1436507939765 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;
	private OutputTerminal GatewayNotEnabled;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		GatewayNotEnabled = mediationServices.getOutputTerminal("out1");
		if (GatewayNotEnabled == null) {
			throw new MediationConfigurationException(
					"No terminal named out1 defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		java.lang.String __result__1 = com.us.aig.ges.constants.GESConstantBundle.GES_ENABLE_GATEWAY;
		java.lang.Object __result__2 = com.aig.us.ges.cache.utils.GESCacheLoader
				.getValueFromCache(__result__1);
		java.lang.Object EnableGateway = __result__2;
		java.lang.String __result__4 = EnableGateway.toString();
		java.lang.Boolean __result__5 = java.lang.Boolean.valueOf(__result__4);
		boolean __result__6 = __result__5.booleanValue();
		boolean GatewayCheck = __result__6;
		java.lang.Object __result__15 = null;
		java.lang.String __result__13 = java.lang.Boolean
				.toString(GatewayCheck);
		java.lang.String __result__11 = "Value of Cache GatewatyCheck";
		java.lang.String __result__14;
		{// append text
			__result__14 = __result__11.concat(__result__13);
		}
		com.ibm.wsspi.sibx.mediation.MediationServices __result__10 = getMediationServices();
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__9 = getSCAServices();
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__9,
				__result__10, __result__14,
				(commonj.sdo.DataObject) __result__15);
		if (GatewayCheck) {
			out.fire(__smo);
		} else {
			GatewayNotEnabled.fire(__smo);
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESConstantBundle.GES_ENABLE_GATEWAY" category="com.us.aig.ges.constants.GESConstantBundle" className="com.us.aig.ges.constants.GESConstantBundle" static="true" memberName="GES_ENABLE_GATEWAY" field="true">
		//    <parameters name="GES_ENABLE_GATEWAY">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getValueFromCache" category="com.aig.us.ges.cache.utils.GESCacheLoader" className="com.aig.us.ges.cache.utils.GESCacheLoader" static="true" memberName="getValueFromCache">
		//    <parameters name="aKey" dataInputs="//@executableElements.0/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@result/@dataOutputs.0" value="EnableGateway" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="EnableGateway.toString()" assignable="false">
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="valueOf" category="java.lang.Boolean" className="java.lang.Boolean" static="true" memberName="valueOf">
		//    <parameters name="s" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="booleanValue" category="java.lang.Boolean" className="java.lang.Boolean" memberName="booleanValue">
		//    <parameters name="Boolean" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Boolean"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@result/@dataOutputs.0" value="GatewayCheck" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GatewayCheck" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.16"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.15/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Value of Cache GatewatyCheck&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GatewayCheck" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="toString" category="java.lang.Boolean" className="java.lang.Boolean" static="true" memberName="toString">
		//    <parameters name="arg0" dataInputs="//@executableElements.11/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.10/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.12/@result/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.15/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null" assignable="false">
		//    <dataOutputs target="//@executableElements.15/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.9/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.13/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.14/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.7/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//        <dataOutputs target="//@executableElements.16/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.16/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.16/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.16/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.16/@conditionalActivities.0/@executableElements.0 //@executableElements.16/@conditionalActivities.0/@executableElements.1 //@executableElements.16/@conditionalActivities.0/@executableElements.2"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GatewayNotEnabled" variable="true">
		//        <dataOutputs target="//@executableElements.16/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.16/@conditionalActivities.1/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.16/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.16/@conditionalActivities.1/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.16/@conditionalActivities.1/@executableElements.0 //@executableElements.16/@conditionalActivities.1/@executableElements.1 //@executableElements.16/@conditionalActivities.1/@executableElements.2"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <localVariables name="EnableGateway">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </localVariables>
		//  <localVariables name="GatewayCheck">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2"/>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.7 //@executableElements.16"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!3:4,1
		//!SMAP!4:5,1
		//!SMAP!5:6,1
		//!SMAP!6:7,1
		//!SMAP!7:8,1
		//!SMAP!9:17,1
		//!SMAP!10:16,1
		//!SMAP!11:11,1
		//!SMAP!13:10,1
		//!SMAP!14:12,4
		//!SMAP!15:9,1
		//!SMAP!16:18,1
		//!SMAP!17:19,1
		//!SMAP!21:20,1
		//!SMAP!25:23,1
		//!SMAP!1000000:227,1
	}
}
