package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestOnly Type: request Custom Mediation: DynamicAddressLookUp
 */
public class Custom1449809951156 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;
	private OutputTerminal out1;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out1 = mediationServices.getOutputTerminal("out1");
		if (out1 == null) {
			throw new MediationConfigurationException(
					"No terminal named out1 defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		java.lang.String __result__1 = __smo.getDataObject("headers")
				.getDataObject("JMSHeader").getString("JMSReplyTo");
		java.lang.String URI = __result__1;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__3 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__4 = getMediationServices();
		java.lang.String __result__5 = "Prining the URI retreived from the JMS Header : "
				+ URI;
		utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
				__result__3, __result__4, __result__5);
		java.lang.String __result__7 = com.us.aig.ges.constants.GESConstantBundle.GES_REVIVED_GATEWAY;
		java.lang.Object __result__8 = com.aig.us.ges.cache.utils.GESCacheLoader
				.getValueFromCache(__result__7);
		java.lang.Object GESCacheData = __result__8;
		boolean __result__10 = null != URI
				&& (!("" == null ? URI == null : "".equals(URI)));
		if (__result__10) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__13 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__14 = getMediationServices();
			java.lang.String __result__15 = "After Setting the end Point address :  ";
			utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
					__result__13, __result__14, __result__15);
			commonj.sdo.DataObject __result__18;
			{// get SMO body
				__result__18 = (commonj.sdo.DataObject) ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
						.getBody();
			}
			commonj.sdo.DataObject smoBody = __result__18;
			byte __result__20 = 0;
			java.lang.Object __result__21 = smoBody.get(__result__20);
			commonj.sdo.DataObject reqDataObj = (commonj.sdo.DataObject) __result__21;
			commonj.sdo.Type __result__23 = reqDataObj.getType();
			commonj.sdo.Type reqTypeObj = __result__23;
			java.lang.String __result__25 = reqTypeObj.getURI();
			java.lang.String reqURI = __result__25;
			java.lang.String __result__27 = reqTypeObj.getName();
			java.lang.String reqNme = __result__27;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__32 = getSCAServices();
			java.util.HashMap __result__35 = null;
			try {
				__result__35 = com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp
						.getHashMapForJMSInvoke(reqNme, __result__32, reqURI,
								(java.lang.String) GESCacheData);
			} catch (java.lang.Exception ex4) {
			}
			java.util.HashMap resultantMap = __result__35;
			java.lang.String __result__40 = "MethodName";
			java.lang.Object __result__41 = resultantMap.get(__result__40);
			java.lang.Object nameMethod = __result__41;
			java.lang.String __result__44 = "PartnerName";
			java.lang.Object __result__45 = resultantMap.get(__result__44);
			java.lang.Object namePartner = __result__45;
			com.us.chartisinsurance.ges.service.invocation.GESSIF __result__47 = com.us.chartisinsurance.ges.service.invocation.GESSIFImpl.INSTANCE;
			try {
				((com.us.chartisinsurance.ges.service.invocation.GESSIFImpl) __result__47)
						.invokeServiceAsync((java.lang.String) nameMethod,
								(java.lang.String) namePartner, URI, reqDataObj);
			} catch (com.ibm.websphere.sca.ServiceBusinessException ex) {
			} catch (com.ibm.websphere.sca.ServiceRuntimeException ex2) {
			} catch (java.lang.Exception ex3) {
			}
			out.fire(__smo);
		} else {
			java.lang.String __result__62 = "/body/message/value";
			java.lang.Object __result__63;
			{// get SMO part
				__result__63 = ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
						.get(__result__62);
			}
			java.lang.String valueStr = (java.lang.String) __result__63;
			commonj.sdo.DataObject __result__65 = null;
			try {
				__result__65 = com.us.aig.ges.dataobject.utils.DataObjectUtils
						.stringToDataObject(valueStr);
			} catch (java.lang.Exception ex2) {
				{// print to log
					System.out.println(ex2);
				}
			}
			commonj.sdo.DataObject RequestDO = __result__65;
			commonj.sdo.Type __result__70 = RequestDO.getType();
			commonj.sdo.Type requestDataType = __result__70;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__72 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__73 = getMediationServices();
			java.lang.String __result__74 = "Logging the requestDataType : ";
			java.lang.String __result__75 = requestDataType.getName();
			java.lang.String __result__76;
			{// append text
				__result__76 = __result__74.concat(__result__75);
			}
			java.lang.String __result__77 = "Logging the request NameSpace : ";
			java.lang.String __result__78 = requestDataType.getURI();
			java.lang.String __result__79;
			{// append text
				__result__79 = __result__77.concat(__result__78);
			}
			java.lang.String __result__80;
			{// append text
				__result__80 = __result__76.concat(__result__79);
			}
			utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
					__result__72, __result__73, __result__80, __smo);
			java.lang.String __result__92 = requestDataType.getName();
			java.lang.String requestNam = __result__92;
			java.lang.String __result__94 = requestDataType.getURI();
			java.lang.String requestNSS = __result__94;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__99 = getSCAServices();
			java.util.HashMap __result__102 = null;
			try {
				__result__102 = com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp
						.getHashMapForScaInvoke(requestNam, __result__99,
								requestNSS, (java.lang.String) GESCacheData);
			} catch (java.lang.Exception ex) {
			}
			java.util.HashMap resultHapMap = __result__102;
			java.lang.String __result__97 = "MethodName";
			java.lang.Object __result__106 = resultHapMap.get(__result__97);
			java.lang.String methodNam = (java.lang.String) __result__106;
			java.lang.String __result__109 = "PartnerName";
			java.lang.Object __result__110 = resultHapMap.get(__result__109);
			java.lang.Object partnerNam = __result__110;
			java.lang.String __result__113 = "ScaAddress";
			java.lang.Object __result__114 = resultHapMap.get(__result__113);
			java.lang.String scaAddr = (java.lang.String) __result__114;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__87 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__88 = getMediationServices();
			java.lang.Object __result__89 = "SCA Address  :" + scaAddr
					+ "Method Name : " + methodNam + "Partner Name :"
					+ partnerNam;
			java.lang.String __result__90 = "Printed the  Invocation Details : ";
			java.lang.String __result__91;
			{// append text
				__result__91 = ((java.lang.String) __result__89)
						.concat(__result__90);
			}
			utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
					__result__87, __result__88, __result__91);
			com.us.chartisinsurance.ges.service.invocation.GESSIF __result__83 = com.us.chartisinsurance.ges.service.invocation.GESSIFImpl.INSTANCE;
			try {
				__result__83.invokeServiceAsync(methodNam,
						(java.lang.String) partnerNam, scaAddr, RequestDO);
			} catch (com.ibm.websphere.sca.ServiceRuntimeException ex5) {
			} catch (java.lang.Exception ex6) {
			}
			out1.fire(__smo);
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.JMSHeader.JMSReplyTo" field="true">
		//    <dataOutputs target="//@executableElements.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="anyURI" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@dataOutputs.0" value="URI" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Prining the URI retreived from the JMS Header : &quot;+URI" assignable="false">
		//    <dataOutputs target="//@executableElements.5/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="LogMsg" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESConstantBundle.GES_REVIVED_GATEWAY" category="com.us.aig.ges.constants.GESConstantBundle" className="com.us.aig.ges.constants.GESConstantBundle" static="true" memberName="GES_REVIVED_GATEWAY" field="true">
		//    <parameters name="GES_REVIVED_GATEWAY">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getValueFromCache" category="com.aig.us.ges.cache.utils.GESCacheLoader" className="com.aig.us.ges.cache.utils.GESCacheLoader" static="true" memberName="getValueFromCache">
		//    <parameters name="aKey" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.8"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@result/@dataOutputs.0" value="GESCacheData" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null !=URI &amp;&amp; &quot;&quot; !=URI" assignable="false">
		//    <dataOutputs target="//@executableElements.10"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.9/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.3/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.3/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;After Setting the end Point address :  &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.3/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.0/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="LogMsg" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.5/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO body" description="Return the body of a Service Message Object" category="SMO services" template="&lt;%return%> (commonj.sdo.DataObject) &lt;%smo%>.getBody();">
		//        <parameters name="smo" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.4/@dataOutputs.0" displayName="service message object">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//        </parameters>
		//        <result name="smo body" displayName="service message object body">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.6"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.5/@result/@dataOutputs.0" value="smoBody" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.8/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.8/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="get">
		//        <parameters name="DataObject" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.7/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.9"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.8/@result/@dataOutputs.0" value="reqDataObj" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="reqDataObj.getType()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.11"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.10/@dataOutputs.0" value="reqTypeObj" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.2" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="reqTypeObj.getURI()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.13"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.12/@dataOutputs.0" value="reqURI" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.3" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="reqTypeObj.getName()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.15"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.14/@dataOutputs.0" value="reqNme" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.4" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.42/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.42/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="reqNme" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.22/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.22/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="reqURI" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.3" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.22/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESCacheData" localVariable="//@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.22/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getHashMapForJMSInvoke" category="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" className="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" static="true" memberName="getHashMapForJMSInvoke">
		//        <parameters name="rootType" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.18/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="scaService" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.19/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="NS" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.20/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="gesServiceDefinitionConfig" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.21/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.24"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </result>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.23/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex4" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.22/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex4" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.23/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.22/@result/@dataOutputs.0" value="resultantMap" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.5" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="resultantMap" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.27/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;MethodName&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.27/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="java.util.HashMap" className="java.util.HashMap" memberName="get">
		//        <parameters name="HashMap" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.25/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </parameters>
		//        <parameters name="key" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.26/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.28"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="V"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.27/@result/@dataOutputs.0" value="nameMethod" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.6" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="resultantMap" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.31/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PartnerName&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.31/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="java.util.HashMap" className="java.util.HashMap" memberName="get">
		//        <parameters name="HashMap" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.29/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </parameters>
		//        <parameters name="key" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.30/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.32"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="V"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.31/@result/@dataOutputs.0" value="namePartner" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.7" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESSIFImpl.INSTANCE" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" static="true" memberName="INSTANCE" field="true">
		//        <parameters name="INSTANCE">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="nameMethod" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.6" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="namePartner" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.7" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="URI" localVariable="//@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="reqDataObj" localVariable="//@executableElements.10/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@parameters.4"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeServiceAsync" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeServiceAsync">
		//        <parameters name="GESSIFImpl" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.33/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//        </parameters>
		//        <parameters name="methodName" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.34/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="aPartnerName" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.35/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="targetAddress" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.36/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="aDataObject" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.37/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.39/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//        </exceptions>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.40/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.0/@executableElements.41/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.39/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex2" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@exceptions.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex2" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.40/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex3" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.38/@exceptions.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex3" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.41/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.16/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.10/@conditionalActivities.0/@executableElements.17/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <localVariables name="smoBody">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </localVariables>
		//      <localVariables name="reqDataObj">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </localVariables>
		//      <localVariables name="reqTypeObj">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </localVariables>
		//      <localVariables name="reqURI">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="reqNme">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="resultantMap">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </localVariables>
		//      <localVariables name="nameMethod">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </localVariables>
		//      <localVariables name="namePartner">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.0 //@executableElements.10/@conditionalActivities.0/@executableElements.1 //@executableElements.10/@conditionalActivities.0/@executableElements.2 //@executableElements.10/@conditionalActivities.0/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.4 //@executableElements.10/@conditionalActivities.0/@executableElements.5 //@executableElements.10/@conditionalActivities.0/@executableElements.6 //@executableElements.10/@conditionalActivities.0/@executableElements.7 //@executableElements.10/@conditionalActivities.0/@executableElements.8 //@executableElements.10/@conditionalActivities.0/@executableElements.9"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.10 //@executableElements.10/@conditionalActivities.0/@executableElements.11"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.12 //@executableElements.10/@conditionalActivities.0/@executableElements.13"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.14 //@executableElements.10/@conditionalActivities.0/@executableElements.15"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.18 //@executableElements.10/@conditionalActivities.0/@executableElements.19 //@executableElements.10/@conditionalActivities.0/@executableElements.20 //@executableElements.10/@conditionalActivities.0/@executableElements.21 //@executableElements.10/@conditionalActivities.0/@executableElements.22 //@executableElements.10/@conditionalActivities.0/@executableElements.23 //@executableElements.10/@conditionalActivities.0/@executableElements.24"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.25 //@executableElements.10/@conditionalActivities.0/@executableElements.26 //@executableElements.10/@conditionalActivities.0/@executableElements.27 //@executableElements.10/@conditionalActivities.0/@executableElements.28"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.29 //@executableElements.10/@conditionalActivities.0/@executableElements.30 //@executableElements.10/@conditionalActivities.0/@executableElements.31 //@executableElements.10/@conditionalActivities.0/@executableElements.32"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.33 //@executableElements.10/@conditionalActivities.0/@executableElements.34 //@executableElements.10/@conditionalActivities.0/@executableElements.35 //@executableElements.10/@conditionalActivities.0/@executableElements.36 //@executableElements.10/@conditionalActivities.0/@executableElements.37 //@executableElements.10/@conditionalActivities.0/@executableElements.38 //@executableElements.10/@conditionalActivities.0/@executableElements.39 //@executableElements.10/@conditionalActivities.0/@executableElements.40 //@executableElements.10/@conditionalActivities.0/@executableElements.41"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.0/@executableElements.16 //@executableElements.10/@conditionalActivities.0/@executableElements.17 //@executableElements.10/@conditionalActivities.0/@executableElements.42"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;/body/message/value&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO part" description="Return the part of a Service Message Object specified by the given XPath" category="SMO services" template="&lt;%return%> &lt;%smo%>.get(&lt;%xpath%>);">
		//        <parameters name="smo" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" displayName="service message object">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//        </parameters>
		//        <parameters name="xpath" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.1/@dataOutputs.0" displayName="XPath">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="smo part" displayName="service message object part">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.2/@result/@dataOutputs.0" value="valueStr" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="stringToDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="stringToDataObject">
		//        <parameters name="value" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.6"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.5/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex2" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.4/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex2" variable="true">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.5/@executableElements.1/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//          <parameters name="object" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.5/@executableElements.0/@dataOutputs.0" displayName="object">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//          </parameters>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.5/@executableElements.0 //@executableElements.10/@conditionalActivities.1/@executableElements.5/@executableElements.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.4/@result/@dataOutputs.0" value="RequestDO" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RequestDO.getType()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.8"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.7/@dataOutputs.0" value="requestDataType" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.2" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.19/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.19/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Logging the requestDataType : &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.13/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="requestDataType.getName()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.13/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.11/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.12/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.17/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Logging the request NameSpace : &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.16/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="requestDataType.getURI()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.16/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.14/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.15/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.17/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.13/@result/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.16/@result/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.19/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.19/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfo" category="utility.MediationLogger_LogInfo" className="utility.MediationLogger_LogInfo" static="true" memberName="mediationLogger_LogInfo">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.9/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.10/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.17/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.18/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESSIFImpl.INSTANCE" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" static="true" memberName="INSTANCE" field="true">
		//        <parameters name="INSTANCE">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="methodNam" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.6" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="partnerNam" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.7" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="scaAddr" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.8" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.52/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.52/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;SCA Address  :&quot;+ scaAddr +&quot;Method Name : &quot;+methodNam +&quot;Partner Name :&quot;+partnerNam" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.28/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Printed the  Invocation Details : &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.28/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.26/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.27/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.52/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="requestDataType.getName()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.30"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.29/@dataOutputs.0" value="requestNam" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.3" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="requestDataType.getURI()" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.32"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.31/@dataOutputs.0" value="requestNSS" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.4" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="resultHapMap" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.42/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;MethodName&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.42/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="requestNam" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.3" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.39/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.39/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="requestNSS" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.39/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESCacheData" localVariable="//@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.39/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getHashMapForScaInvoke" category="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" className="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" static="true" memberName="getHashMapForScaInvoke">
		//        <parameters name="rootType" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.35/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="scaService" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.36/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="NS" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.37/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="gesServiceDefinitionConfig" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.38/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.40"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </result>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.41/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.39/@result/@dataOutputs.0" value="resultHapMap" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.5" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.39/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.41/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="java.util.HashMap" className="java.util.HashMap" memberName="get">
		//        <parameters name="HashMap" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.33/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </parameters>
		//        <parameters name="key" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.34/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.43"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="V"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.42/@result/@dataOutputs.0" value="methodNam" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.6" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="resultHapMap" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.46/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PartnerName&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.46/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="java.util.HashMap" className="java.util.HashMap" memberName="get">
		//        <parameters name="HashMap" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.44/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </parameters>
		//        <parameters name="key" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.45/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.47"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="V"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.46/@result/@dataOutputs.0" value="partnerNam" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.7" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="resultHapMap" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.50/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;ScaAddress&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.50/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="java.util.HashMap" className="java.util.HashMap" memberName="get">
		//        <parameters name="HashMap" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.48/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//        </parameters>
		//        <parameters name="key" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.49/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.51"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="V"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.50/@result/@dataOutputs.0" value="scaAddr" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.8" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.24/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.25/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="LogMsg" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.28/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RequestDO" localVariable="//@executableElements.10/@conditionalActivities.1/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@parameters.4"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeServiceAsync" category="com.us.chartisinsurance.ges.service.invocation.GESSIF" className="com.us.chartisinsurance.ges.service.invocation.GESSIF" memberName="invokeServiceAsync">
		//        <parameters name="GESSIF" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.20/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//        </parameters>
		//        <parameters name="methodName" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.21/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="aPartnerName" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.22/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="targetAddress" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.23/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="aDataObject" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.53/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//        </exceptions>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.55/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.56/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex5" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@exceptions.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex5" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.55/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex6" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.54/@exceptions.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex6" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.56/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out1" variable="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.59/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.10/@conditionalActivities.1/@executableElements.59/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.57/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.10/@conditionalActivities.1/@executableElements.58/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <localVariables name="valueStr">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="RequestDO">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </localVariables>
		//      <localVariables name="requestDataType">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </localVariables>
		//      <localVariables name="requestNam">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="requestNSS">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="resultHapMap">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//      </localVariables>
		//      <localVariables name="methodNam">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="partnerNam">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </localVariables>
		//      <localVariables name="scaAddr">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.0 //@executableElements.10/@conditionalActivities.1/@executableElements.1 //@executableElements.10/@conditionalActivities.1/@executableElements.2 //@executableElements.10/@conditionalActivities.1/@executableElements.3 //@executableElements.10/@conditionalActivities.1/@executableElements.4 //@executableElements.10/@conditionalActivities.1/@executableElements.5 //@executableElements.10/@conditionalActivities.1/@executableElements.6"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.7 //@executableElements.10/@conditionalActivities.1/@executableElements.8"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.9 //@executableElements.10/@conditionalActivities.1/@executableElements.10 //@executableElements.10/@conditionalActivities.1/@executableElements.11 //@executableElements.10/@conditionalActivities.1/@executableElements.12 //@executableElements.10/@conditionalActivities.1/@executableElements.13 //@executableElements.10/@conditionalActivities.1/@executableElements.14 //@executableElements.10/@conditionalActivities.1/@executableElements.15 //@executableElements.10/@conditionalActivities.1/@executableElements.16 //@executableElements.10/@conditionalActivities.1/@executableElements.17 //@executableElements.10/@conditionalActivities.1/@executableElements.18 //@executableElements.10/@conditionalActivities.1/@executableElements.19"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.29 //@executableElements.10/@conditionalActivities.1/@executableElements.30"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.31 //@executableElements.10/@conditionalActivities.1/@executableElements.32"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.35 //@executableElements.10/@conditionalActivities.1/@executableElements.36 //@executableElements.10/@conditionalActivities.1/@executableElements.37 //@executableElements.10/@conditionalActivities.1/@executableElements.38 //@executableElements.10/@conditionalActivities.1/@executableElements.39 //@executableElements.10/@conditionalActivities.1/@executableElements.40 //@executableElements.10/@conditionalActivities.1/@executableElements.41"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.33 //@executableElements.10/@conditionalActivities.1/@executableElements.34 //@executableElements.10/@conditionalActivities.1/@executableElements.42 //@executableElements.10/@conditionalActivities.1/@executableElements.43"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.44 //@executableElements.10/@conditionalActivities.1/@executableElements.45 //@executableElements.10/@conditionalActivities.1/@executableElements.46 //@executableElements.10/@conditionalActivities.1/@executableElements.47"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.48 //@executableElements.10/@conditionalActivities.1/@executableElements.49 //@executableElements.10/@conditionalActivities.1/@executableElements.50 //@executableElements.10/@conditionalActivities.1/@executableElements.51"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.24 //@executableElements.10/@conditionalActivities.1/@executableElements.25 //@executableElements.10/@conditionalActivities.1/@executableElements.26 //@executableElements.10/@conditionalActivities.1/@executableElements.27 //@executableElements.10/@conditionalActivities.1/@executableElements.28 //@executableElements.10/@conditionalActivities.1/@executableElements.52"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.20 //@executableElements.10/@conditionalActivities.1/@executableElements.21 //@executableElements.10/@conditionalActivities.1/@executableElements.22 //@executableElements.10/@conditionalActivities.1/@executableElements.23 //@executableElements.10/@conditionalActivities.1/@executableElements.53 //@executableElements.10/@conditionalActivities.1/@executableElements.54 //@executableElements.10/@conditionalActivities.1/@executableElements.55 //@executableElements.10/@conditionalActivities.1/@executableElements.56"/>
		//      <executableGroups executableElements="//@executableElements.10/@conditionalActivities.1/@executableElements.57 //@executableElements.10/@conditionalActivities.1/@executableElements.58 //@executableElements.10/@conditionalActivities.1/@executableElements.59"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <localVariables name="GESCacheData">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </localVariables>
		//  <localVariables name="URI">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!3:4,1
		//!SMAP!4:5,1
		//!SMAP!5:6,1
		//!SMAP!6:7,1
		//!SMAP!7:8,1
		//!SMAP!8:9,1
		//!SMAP!9:10,1
		//!SMAP!10:11,1
		//!SMAP!11:12,1
		//!SMAP!13:13,1
		//!SMAP!14:14,1
		//!SMAP!15:15,1
		//!SMAP!16:16,1
		//!SMAP!18:17,4
		//!SMAP!19:21,1
		//!SMAP!20:22,1
		//!SMAP!21:23,1
		//!SMAP!22:24,1
		//!SMAP!23:25,1
		//!SMAP!24:26,1
		//!SMAP!25:27,1
		//!SMAP!26:28,1
		//!SMAP!27:29,1
		//!SMAP!28:30,1
		//!SMAP!32:31,1
		//!SMAP!35:34,2
		//!SMAP!38:38,1
		//!SMAP!40:39,1
		//!SMAP!41:40,1
		//!SMAP!42:41,1
		//!SMAP!44:42,1
		//!SMAP!45:43,1
		//!SMAP!46:44,1
		//!SMAP!47:45,1
		//!SMAP!52:47,1
		//!SMAP!59:55,1
		//!SMAP!62:58,1
		//!SMAP!63:59,4
		//!SMAP!64:63,1
		//!SMAP!65:66,2
		//!SMAP!68:69,3
		//!SMAP!69:73,1
		//!SMAP!70:74,1
		//!SMAP!71:75,1
		//!SMAP!72:76,1
		//!SMAP!73:77,1
		//!SMAP!74:78,1
		//!SMAP!75:79,1
		//!SMAP!76:80,4
		//!SMAP!77:84,1
		//!SMAP!78:85,1
		//!SMAP!79:86,4
		//!SMAP!80:90,4
		//!SMAP!82:94,1
		//!SMAP!83:125,1
		//!SMAP!87:116,1
		//!SMAP!88:117,1
		//!SMAP!89:118,1
		//!SMAP!90:119,1
		//!SMAP!91:120,4
		//!SMAP!92:95,1
		//!SMAP!93:96,1
		//!SMAP!94:97,1
		//!SMAP!95:98,1
		//!SMAP!97:107,1
		//!SMAP!99:99,1
		//!SMAP!102:102,2
		//!SMAP!103:106,1
		//!SMAP!106:108,1
		//!SMAP!107:109,1
		//!SMAP!109:110,1
		//!SMAP!110:111,1
		//!SMAP!111:112,1
		//!SMAP!113:113,1
		//!SMAP!114:114,1
		//!SMAP!115:115,1
		//!SMAP!116:124,1
		//!SMAP!118:127,1
		//!SMAP!125:133,1
		//!SMAP!1000000:1078,1
	}
}
