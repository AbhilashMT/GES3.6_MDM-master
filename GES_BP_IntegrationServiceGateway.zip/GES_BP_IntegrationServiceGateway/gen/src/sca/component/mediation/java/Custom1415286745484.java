package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestOnly Type: request Custom Mediation: InvokeLocationExposureNotificationService
 */
public class Custom1415286745484 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		boolean __result__1 = __smo.getDataObject("context").getDataObject(
				"correlation").getBoolean("isInovkeService");
		if (__result__1) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__4 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__5 = getMediationServices();
			java.lang.String __result__6 = "***Before Service Invocation***";
			utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
					__result__4, __result__5, __result__6, __smo);
			boolean __result__11 = __smo.getDataObject("headers")
					.getDataObject("JMSHeader").getString("JMSReplyTo") != null;
			if (__result__11) {
				com.us.chartisinsurance.ges.service.invocation.GESSIF __result__14 = com.us.chartisinsurance.ges.service.invocation.GESSIFImpl.INSTANCE;
				java.lang.String __result__15 = __smo.getDataObject("context")
						.getDataObject("correlation").getString("MethodName");
				java.lang.String __result__16 = __smo.getDataObject("context")
						.getDataObject("correlation").getString("PartnerName");
				java.lang.String __result__17 = __smo.getDataObject("headers")
						.getDataObject("JMSHeader").getString("JMSReplyTo");
				commonj.sdo.DataObject __result__19;
				{// get SMO body
					__result__19 = (commonj.sdo.DataObject) ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
							.getBody();
				}
				try {
					((com.us.chartisinsurance.ges.service.invocation.GESSIFImpl) __result__14)
							.invokeServiceAsync(__result__15, __result__16,
									__result__17, __result__19);
				} catch (java.lang.Exception ex) {
				}
			} else {
				java.lang.String __result__30 = __smo.getDataObject("context")
						.getDataObject("correlation").getString("PartnerName");
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__31 = getSCAServices();
				java.lang.String __result__32 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
						.getEndPoint(__result__30, __result__31);
				java.lang.String TargetAddress = __result__32;
				com.us.chartisinsurance.ges.service.invocation.GESSIF __result__24 = com.us.chartisinsurance.ges.service.invocation.GESSIFImpl.INSTANCE;
				java.lang.String __result__25 = __smo.getDataObject("context")
						.getDataObject("correlation").getString("MethodName");
				java.lang.String __result__26 = __smo.getDataObject("context")
						.getDataObject("correlation").getString("PartnerName");
				commonj.sdo.DataObject __result__29;
				{// get SMO body
					__result__29 = (commonj.sdo.DataObject) ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
							.getBody();
				}
				try {
					((com.us.chartisinsurance.ges.service.invocation.GESSIFImpl) __result__24)
							.invokeServiceAsync(__result__25, __result__26,
									TargetAddress, __result__29);
				} catch (com.ibm.websphere.sca.ServiceBusinessException ex6) {
				} catch (com.ibm.websphere.sca.ServiceRuntimeException ex5) {
				} catch (java.lang.Exception ex4) {
				}
			}
			out.fire(__smo);
		} else {
			java.lang.String __result__43 = "Unable to Invoke Target URI ";
			com.ibm.wbiserver.mediation.MediationRuntimeException __result__44 = new com.ibm.wbiserver.mediation.MediationRuntimeException(
					__result__43);
			throw __result__44;
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.isInovkeService" field="true">
		//    <dataOutputs target="//@executableElements.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.0/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.4/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;***Before Service Invocation***&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.4/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.4/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.0/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.9/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.9/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.JMSHeader.JMSReplyTo!=null" assignable="false">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.7/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESSIFImpl.INSTANCE" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" static="true" memberName="INSTANCE" field="true">
		//            <parameters name="INSTANCE">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.MethodName" field="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.PartnerName" field="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6/@parameters.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.JMSHeader.JMSReplyTo" field="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6/@parameters.3"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="anyURI" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.5/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO body" description="Return the body of a Service Message Object" category="SMO services" template="&lt;%return%> (commonj.sdo.DataObject) &lt;%smo%>.getBody();">
		//            <parameters name="smo" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.4/@dataOutputs.0" displayName="service message object">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//            </parameters>
		//            <result name="smo body" displayName="service message object body">
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6/@parameters.4"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeServiceAsync" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeServiceAsync">
		//            <parameters name="GESSIFImpl" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.0/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//            </parameters>
		//            <parameters name="methodName" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="aPartnerName" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="targetAddress" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="aDataObject" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.5/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <exceptions>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//            </exceptions>
		//            <exceptions>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//            </exceptions>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.7/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//            <parameters name="ex" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6/@exceptions.2/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </executableElements>
		//            <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.7/@executableElements.0"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.0 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.1 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.2 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.3 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.4 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.5 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.6 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.0/@executableElements.7"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESSIFImpl.INSTANCE" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" static="true" memberName="INSTANCE" field="true">
		//            <parameters name="INSTANCE">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.MethodName" field="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.PartnerName" field="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@parameters.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetAddress" localVariable="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@parameters.3"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.5/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO body" description="Return the body of a Service Message Object" category="SMO services" template="&lt;%return%> (commonj.sdo.DataObject) &lt;%smo%>.getBody();">
		//            <parameters name="smo" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.4/@dataOutputs.0" displayName="service message object">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//            </parameters>
		//            <result name="smo body" displayName="service message object body">
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@parameters.4"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.PartnerName" field="true">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.8/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//            <result>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.8/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//            <parameters name="key" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.6/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="scaService" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.7/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.9"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.8/@result/@dataOutputs.0" value="TargetAddress" localVariable="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@localVariables.0" variable="true">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeServiceAsync" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeServiceAsync">
		//            <parameters name="GESSIFImpl" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.0/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//            </parameters>
		//            <parameters name="methodName" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="aPartnerName" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.2/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="targetAddress" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.3/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="aDataObject" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.5/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.11/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//            </exceptions>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.12/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//            </exceptions>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.13/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//            <parameters name="ex6" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@exceptions.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex6" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//            </executableElements>
		//            <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.11/@executableElements.0"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//            <parameters name="ex5" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@exceptions.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex5" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//            </executableElements>
		//            <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.12/@executableElements.0"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//            <parameters name="ex4" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10/@exceptions.2/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex4" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </executableElements>
		//            <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.13/@executableElements.0"/>
		//          </executableElements>
		//          <localVariables name="TargetAddress">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.6 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.7 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.8 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.9"/>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.0 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.1 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.2 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.3 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.4 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.5 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.10 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.11 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.12 //@executableElements.1/@conditionalActivities.0/@executableElements.8/@conditionalActivities.1/@executableElements.13"/>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.0 //@executableElements.1/@conditionalActivities.0/@executableElements.1 //@executableElements.1/@conditionalActivities.0/@executableElements.2 //@executableElements.1/@conditionalActivities.0/@executableElements.3 //@executableElements.1/@conditionalActivities.0/@executableElements.4"/>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.7 //@executableElements.1/@conditionalActivities.0/@executableElements.8"/>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.5 //@executableElements.1/@conditionalActivities.0/@executableElements.6 //@executableElements.1/@conditionalActivities.0/@executableElements.9"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Unable to Invoke Target URI &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.1/@executableElements.1/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new MediationRuntimeException" category="com.ibm.wbiserver.mediation.MediationRuntimeException" className="com.ibm.wbiserver.mediation.MediationRuntimeException" constructor="true" memberName="MediationRuntimeException">
		//        <parameters name="msg" dataInputs="//@executableElements.1/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.1/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wbiserver.mediation.MediationRuntimeException"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//        <parameters name="Throwable" dataInputs="//@executableElements.1/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.1/@executableElements.0 //@executableElements.1/@conditionalActivities.1/@executableElements.1 //@executableElements.1/@conditionalActivities.1/@executableElements.2"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!4:4,1
		//!SMAP!5:5,1
		//!SMAP!6:6,1
		//!SMAP!8:7,1
		//!SMAP!11:8,1
		//!SMAP!12:9,1
		//!SMAP!14:10,1
		//!SMAP!15:11,1
		//!SMAP!16:12,1
		//!SMAP!17:13,1
		//!SMAP!19:14,4
		//!SMAP!20:19,1
		//!SMAP!24:29,1
		//!SMAP!25:30,1
		//!SMAP!26:31,1
		//!SMAP!29:32,4
		//!SMAP!30:25,1
		//!SMAP!31:26,1
		//!SMAP!32:27,1
		//!SMAP!33:28,1
		//!SMAP!34:37,1
		//!SMAP!41:46,1
		//!SMAP!43:49,1
		//!SMAP!44:50,1
		//!SMAP!45:51,1
		//!SMAP!1000000:392,1
	}
}
