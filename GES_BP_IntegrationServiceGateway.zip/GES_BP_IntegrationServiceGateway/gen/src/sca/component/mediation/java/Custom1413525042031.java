package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestResponse Type: request Custom Mediation: GetRouterConfig
 */
public class Custom1413525042031 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__3 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__4 = getMediationServices();
		java.lang.String __result__5 = "About to get Config Details for dynamic dispatching \n";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__3,
				__result__4, __result__5, __smo);
		java.lang.String __result__2 = "/context/correlation";
		java.lang.Object __result__8;
		{// get SMO part
			__result__8 = ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
					.get(__result__2);
		}
		commonj.sdo.DataObject CorrelationContext = (commonj.sdo.DataObject) __result__8;
		java.lang.String __result__11 = "Key formed for Look Up : ";
		java.lang.String __result__12 = CorrelationContext
				.getString("TypeName");
		java.lang.String __result__13 = "_";
		java.lang.String __result__14;
		{// append text
			__result__14 = __result__12.concat(__result__13);
		}
		java.lang.String __result__15 = CorrelationContext.getString("URI");
		java.lang.String __result__16;
		{// append text
			__result__16 = __result__14.concat(__result__15);
		}
		java.lang.String ResultPropertiesKey = __result__16;
		java.lang.String __result__18;
		{// append text
			__result__18 = __result__11.concat(ResultPropertiesKey);
		}
		utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
				__result__3, __result__4, __result__18);
		java.lang.String __result__10 = com.us.aig.ges.constants.GESConstantBundle.GES_GATEWAY_CONFIG;
		java.lang.Object __result__20 = com.aig.us.ges.cache.utils.GESCacheLoader
				.getValueFromCache(__result__10);
		java.util.HashMap ResultProperties = (java.util.HashMap) __result__20;
		boolean __result__22 = ResultProperties.isEmpty();
		boolean __result__23;
		{// inverse
			__result__23 = !__result__22;
		}
		if (__result__23) {
			java.lang.Object __result__27 = ResultProperties
					.get(ResultPropertiesKey);
			java.lang.String __result__28 = java.lang.String
					.valueOf(__result__27);
			java.lang.String RoutingConfigStringXML = __result__28;
			commonj.sdo.DataObject __result__30 = null;
			try {
				__result__30 = com.us.aig.ges.dataobject.utils.DataObjectUtils
						.stringToDataObject(RoutingConfigStringXML);
			} catch (java.lang.Exception ex) {
			}
			commonj.sdo.DataObject RouterConfig = __result__30;
			java.lang.String __result__26 = RouterConfig
					.getString("MethodName");
			__smo.getDataObject("context").getDataObject("correlation")
					.setString("MethodName", __result__26);
			java.lang.String __result__35 = RouterConfig.getString("WSDLUri");
			__smo.getDataObject("context").getDataObject("correlation")
					.setString("WSDLURI", __result__35);
			java.lang.String __result__37 = RouterConfig
					.getString("MessageName");
			__smo.getDataObject("context").getDataObject("correlation")
					.setString("MessageName", __result__37);
			java.lang.String __result__39 = RouterConfig
					.getString("PartnerName");
			__smo.getDataObject("context").getDataObject("correlation")
					.setString("PartnerName", __result__39);
			java.lang.String __result__40 = __smo.getDataObject("context")
					.getDataObject("correlation").getString("PartnerName");
			java.lang.String PartnerName = __result__40;
			boolean __result__46 = __smo.getDataObject("context")
					.getDataObject("correlation").getBoolean("isHTTPGET");
			if (__result__46) {
				commonj.sdo.DataObject __result__49 = __smo
						.getDataObject("headers");
				java.lang.String __result__50 = __smo.getDataObject("context")
						.getDataObject("correlation").getString("TargetURI");
				java.lang.String __result__51 = com.us.aig.ges.dataobject.utils.DataObjectUtils
						.getEndpointURLWithReqParams(__result__49, __result__50);
				__smo.getDataObject("context").getDataObject("correlation")
						.setString("TargetURI", __result__51);
			} else {
			}
			boolean __result__54 = true;
			__smo.getDataObject("context").getDataObject("correlation")
					.setBoolean("isInovkeService", __result__54);
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__42 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__43 = getMediationServices();
			java.lang.String __result__44 = "Context Information Populated with required fields for Service Invocation : ";
			commonj.sdo.DataObject __result__45 = __smo
					.getDataObject("context").getDataObject("correlation");
			try {
				utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
						__result__42, __result__43, __result__44, __result__45);
			} catch (com.ibm.websphere.sca.ServiceRuntimeException ex2) {
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__58 = getSCAServices();
				com.ibm.wsspi.sibx.mediation.MediationServices __result__59 = getMediationServices();
				java.lang.String __result__60 = ex2.getMessage();
				utility.MediationLogger_LogSevereNoBO
						.mediationLogger_LogSevereNoBO(__result__58,
								__result__59, __result__60);
			}
		} else {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__63 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__64 = getMediationServices();
			java.lang.String __result__65 = "Unable to get Required properties from Configuration for service invocation ";
			java.lang.String __result__66 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE;
			java.lang.String __result__67;
			{// append text
				__result__67 = __result__65.concat(__result__66);
			}
			try {
				utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
						__result__63, __result__64, __result__67, __smo);
			} catch (com.ibm.websphere.sca.ServiceRuntimeException ex) {
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__71 = getSCAServices();
				com.ibm.wsspi.sibx.mediation.MediationServices __result__72 = getMediationServices();
				java.lang.String __result__73 = ex.getMessage();
				utility.MediationLogger_LogSevereNoBO
						.mediationLogger_LogSevereNoBO(__result__71,
								__result__72, __result__73);
			}
			boolean __result__75 = false;
			__smo.getDataObject("context").getDataObject("correlation")
					.setBoolean("isInovkeService", __result__75);
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;/context/correlation&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.7/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.18/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//      <dataOutputs target="//@executableElements.18/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;About to get Config Details for dynamic dispatching \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO part" description="Return the part of a Service Message Object specified by the given XPath" category="SMO services" template="&lt;%return%> &lt;%smo%>.get(&lt;%xpath%>);">
		//    <parameters name="smo" dataInputs="//@executableElements.0/@dataOutputs.0" displayName="service message object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="xpath" dataInputs="//@executableElements.1/@dataOutputs.0" displayName="XPath">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="smo part" displayName="service message object part">
		//      <dataOutputs target="//@executableElements.8"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@result/@dataOutputs.0" value="CorrelationContext" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CorrelationContextHolder" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESConstantBundle.GES_GATEWAY_CONFIG" category="com.us.aig.ges.constants.GESConstantBundle" className="com.us.aig.ges.constants.GESConstantBundle" static="true" memberName="GES_GATEWAY_CONFIG" field="true">
		//    <parameters name="GES_GATEWAY_CONFIG">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.19/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Key formed for Look Up : &quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.17/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="CorrelationContext.TypeName" field="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;_&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.11/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.12/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="CorrelationContext.URI" field="true">
		//    <dataOutputs target="//@executableElements.15/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.13/@result/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.14/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.16"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@result/@dataOutputs.0" value="ResultPropertiesKey" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.17/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.10/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.16/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.18/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfoNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="LogMsg" dataInputs="//@executableElements.17/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getValueFromCache" category="com.aig.us.ges.cache.utils.GESCacheLoader" className="com.aig.us.ges.cache.utils.GESCacheLoader" static="true" memberName="getValueFromCache">
		//    <parameters name="aKey" dataInputs="//@executableElements.9/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.20"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.19/@result/@dataOutputs.0" value="ResultProperties" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.21/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isEmpty" category="java.util.HashMap" className="java.util.HashMap" memberName="isEmpty">
		//    <parameters name="HashMap" dataInputs="//@executableElements.20/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.22/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="inverse" description="Convert true to false or false to true" category="logic" template="&lt;%return%> !&lt;%input%>;">
		//    <parameters name="input" dataInputs="//@executableElements.21/@result/@dataOutputs.0" displayName="input">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.23"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.22/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RouterConfig.MethodName" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.7"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ResultProperties.get( ResultPropertiesKey)" assignable="false">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="valueOf" category="java.lang.String" className="java.lang.String" static="true" memberName="valueOf">
		//        <parameters name="value" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="RoutingConfigStringXML" localVariable="//@executableElements.23/@conditionalActivities.0/@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="stringToDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="stringToDataObject">
		//        <parameters name="value" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.6"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.5/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.4/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.5/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0" value="RouterConfig" localVariable="//@executableElements.23/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RoutingConfig" namespace="http://GES_Lib_Common/bo"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="smo.context.correlation.MethodName" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RouterConfig.WSDLUri" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.9"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.8/@dataOutputs.0" value="smo.context.correlation.WSDLURI" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RouterConfig.MessageName" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.11"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.10/@dataOutputs.0" value="smo.context.correlation.MessageName" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RouterConfig.PartnerName" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.13"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.12/@dataOutputs.0" value="smo.context.correlation.PartnerName" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.14"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.13/@dataOutputs.0" value="PartnerName" localVariable="//@executableElements.23/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.23/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.23/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Context Information Populated with required fields for Service Invocation : &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.23/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.23/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CorrelationContextHolder" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.isHTTPGET" field="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.20"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.19/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers" field="true">
		//            <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="HeadersType" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.TargetURI" field="true">
		//            <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndpointURLWithReqParams" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="getEndpointURLWithReqParams">
		//            <parameters name="headers" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="endpointURL" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="smo.context.correlation.TargetURI" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.0 //@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.1 //@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.2 //@executableElements.23/@conditionalActivities.0/@executableElements.20/@conditionalActivities.0/@executableElements.3"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.22"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.21/@dataOutputs.0" value="smo.context.correlation.isInovkeService" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.15/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.16/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.17/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.18/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex2" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.23/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.3/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.3/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex2.getMessage()" assignable="false">
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.3/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//          <parameters name="SCAServices" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.0/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </parameters>
		//          <parameters name="MediationServices" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.1/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </parameters>
		//          <parameters name="LogMsg" dataInputs="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.2/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.0 //@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.1 //@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.2 //@executableElements.23/@conditionalActivities.0/@executableElements.24/@executableElements.3"/>
		//      </executableElements>
		//      <localVariables name="RouterConfig">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RoutingConfig" namespace="http://GES_Lib_Common/bo" nillable="false"/>
		//      </localVariables>
		//      <localVariables name="PartnerName">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </localVariables>
		//      <localVariables name="RoutingConfigStringXML">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.1 //@executableElements.23/@conditionalActivities.0/@executableElements.2 //@executableElements.23/@conditionalActivities.0/@executableElements.3 //@executableElements.23/@conditionalActivities.0/@executableElements.4 //@executableElements.23/@conditionalActivities.0/@executableElements.5 //@executableElements.23/@conditionalActivities.0/@executableElements.6"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.0 //@executableElements.23/@conditionalActivities.0/@executableElements.7"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.8 //@executableElements.23/@conditionalActivities.0/@executableElements.9"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.10 //@executableElements.23/@conditionalActivities.0/@executableElements.11"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.12 //@executableElements.23/@conditionalActivities.0/@executableElements.13 //@executableElements.23/@conditionalActivities.0/@executableElements.14"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.19 //@executableElements.23/@conditionalActivities.0/@executableElements.20"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.21 //@executableElements.23/@conditionalActivities.0/@executableElements.22"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.0/@executableElements.15 //@executableElements.23/@conditionalActivities.0/@executableElements.16 //@executableElements.23/@conditionalActivities.0/@executableElements.17 //@executableElements.23/@conditionalActivities.0/@executableElements.18 //@executableElements.23/@conditionalActivities.0/@executableElements.23 //@executableElements.23/@conditionalActivities.0/@executableElements.24"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.6/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.6/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Unable to get Required properties from Configuration for service invocation &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE" field="true">
		//        <parameters name="COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.4/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.2/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.3/@result/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.6/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.6/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.0/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.4/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.5/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler" collapsed="true">
		//        <parameters name="ex" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.6/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.3/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.3/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex.getMessage()" assignable="false">
		//          <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.3/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//          <parameters name="SCAServices" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.0/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </parameters>
		//          <parameters name="MediationServices" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.1/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </parameters>
		//          <parameters name="LogMsg" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.2/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.0 //@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.1 //@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.2 //@executableElements.23/@conditionalActivities.1/@executableElements.7/@executableElements.3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="false" assignable="false">
		//        <dataOutputs target="//@executableElements.23/@conditionalActivities.1/@executableElements.9"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@conditionalActivities.1/@executableElements.8/@dataOutputs.0" value="smo.context.correlation.isInovkeService" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.1/@executableElements.0 //@executableElements.23/@conditionalActivities.1/@executableElements.1 //@executableElements.23/@conditionalActivities.1/@executableElements.2 //@executableElements.23/@conditionalActivities.1/@executableElements.3 //@executableElements.23/@conditionalActivities.1/@executableElements.4 //@executableElements.23/@conditionalActivities.1/@executableElements.5 //@executableElements.23/@conditionalActivities.1/@executableElements.6 //@executableElements.23/@conditionalActivities.1/@executableElements.7"/>
		//      <executableGroups executableElements="//@executableElements.23/@conditionalActivities.1/@executableElements.8 //@executableElements.23/@conditionalActivities.1/@executableElements.9"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="CorrelationContext">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CorrelationContextHolder" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="ResultPropertiesKey">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="ResultProperties">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.HashMap"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15 //@executableElements.16 //@executableElements.17 //@executableElements.18"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.19 //@executableElements.20 //@executableElements.21 //@executableElements.22 //@executableElements.23"/>
		//  <executableGroups executableElements="//@executableElements.24 //@executableElements.25 //@executableElements.26"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!2:6,1
		//!SMAP!3:2,1
		//!SMAP!4:3,1
		//!SMAP!5:4,1
		//!SMAP!7:5,1
		//!SMAP!8:7,4
		//!SMAP!9:11,1
		//!SMAP!10:30,1
		//!SMAP!11:12,1
		//!SMAP!12:13,1
		//!SMAP!13:14,1
		//!SMAP!14:15,4
		//!SMAP!15:19,1
		//!SMAP!16:20,4
		//!SMAP!17:24,1
		//!SMAP!18:25,4
		//!SMAP!19:29,1
		//!SMAP!20:31,1
		//!SMAP!21:32,1
		//!SMAP!22:33,1
		//!SMAP!23:34,4
		//!SMAP!24:38,1
		//!SMAP!26:49,1
		//!SMAP!27:39,1
		//!SMAP!28:40,1
		//!SMAP!29:41,1
		//!SMAP!30:44,2
		//!SMAP!33:48,1
		//!SMAP!34:50,1
		//!SMAP!35:51,1
		//!SMAP!36:52,1
		//!SMAP!37:53,1
		//!SMAP!38:54,1
		//!SMAP!39:55,1
		//!SMAP!40:56,2
		//!SMAP!41:58,1
		//!SMAP!42:70,1
		//!SMAP!43:71,1
		//!SMAP!44:72,1
		//!SMAP!45:73,1
		//!SMAP!46:59,1
		//!SMAP!47:60,1
		//!SMAP!49:61,1
		//!SMAP!50:62,1
		//!SMAP!51:63,1
		//!SMAP!52:64,1
		//!SMAP!54:68,1
		//!SMAP!55:69,1
		//!SMAP!56:75,1
		//!SMAP!58:78,1
		//!SMAP!59:79,1
		//!SMAP!60:80,1
		//!SMAP!61:81,1
		//!SMAP!63:85,1
		//!SMAP!64:86,1
		//!SMAP!65:87,1
		//!SMAP!66:88,1
		//!SMAP!67:89,4
		//!SMAP!69:94,1
		//!SMAP!71:97,1
		//!SMAP!72:98,1
		//!SMAP!73:99,1
		//!SMAP!74:100,1
		//!SMAP!75:102,1
		//!SMAP!76:103,1
		//!SMAP!79:105,1
		//!SMAP!1000000:706,1
	}
}
