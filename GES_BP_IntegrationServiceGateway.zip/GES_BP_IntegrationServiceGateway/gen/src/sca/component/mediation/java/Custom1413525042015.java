package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestResponse Type: request Custom Mediation: IdentifyBindingTypeAndConstructBO
 */
public class Custom1413525042015 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;
	private OutputTerminal ValidateDO;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		ValidateDO = mediationServices.getOutputTerminal("out1");
		if (ValidateDO == null) {
			throw new MediationConfigurationException(
					"No terminal named out1 defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		boolean __result__1 = null != __smo.getDataObject("headers")
				.getDataObject("SMOHeader").getString("SourceBindingType")
				&& "HTTP".equalsIgnoreCase(__smo.getDataObject("headers")
						.getDataObject("SMOHeader").getString(
								"SourceBindingType"));
		if (__result__1) {
			java.lang.String __result__5 = "/headers/HTTPHeader/control/Method";
			java.lang.Object __result__6;
			{// get SMO part
				__result__6 = ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
						.get(__result__5);
			}
			java.lang.String method = (java.lang.String) __result__6;
			boolean __result__8 = "GET".equalsIgnoreCase(method);
			if (__result__8) {
				boolean __result__11 = true;
				__smo.getDataObject("context").getDataObject("correlation")
						.setBoolean("isHTTPGET", __result__11);
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__13 = getSCAServices();
				java.lang.String __result__14 = __result__13.getModuleName();
				__smo.getDataObject("context").getDataObject("correlation")
						.setString("ModuleName", __result__14);
				java.lang.String __result__16 = "HTTP";
				__smo.getDataObject("context").getDataObject("correlation")
						.setString("TypeName", __result__16);
				java.lang.String __result__18 = "GET";
				__smo.getDataObject("context").getDataObject("correlation")
						.setString("URI", __result__18);
			} else {
				boolean __result__21 = false;
				__smo.getDataObject("context").getDataObject("correlation")
						.setBoolean("isHTTPGET", __result__21);
			}
		} else {
			boolean __result__24 = false;
			__smo.getDataObject("context").getDataObject("correlation")
					.setBoolean("isHTTPGET", __result__24);
		}
		boolean __result__26 = __smo.getDataObject("context").getDataObject(
				"correlation").getBoolean("isHTTPGET");
		boolean __result__27;
		{// inverse
			__result__27 = !__result__26;
		}
		if (__result__27) {
			boolean __result__30 = null != __smo.getDataObject("body")
					.getDataObject("message").getString("value");
			if (__result__30) {
				java.lang.String __result__34 = __smo.getDataObject("body")
						.getDataObject("message").getString("value");
				commonj.sdo.DataObject __result__35 = null;
				try {
					__result__35 = com.us.aig.ges.dataobject.utils.DataObjectUtils
							.stringToDataObject(__result__34);
				} catch (java.lang.Exception ex) {
					com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__37 = getSCAServices();
					com.ibm.wsspi.sibx.mediation.MediationServices __result__38 = getMediationServices();
					java.lang.String __result__39 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE;
					utility.MediationLogger_LogSevere
							.mediationLogger_LogSevere(__result__37,
									__result__38, __result__39, __smo);
				}
				{// set SMO body
					((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
							.setBody(__result__35);
				}
				boolean __result__43 = false;
				boolean isValidateDO = __result__43;
				java.lang.Object __result__45 = null;
				commonj.sdo.DataObject SMOValidateDO = (commonj.sdo.DataObject) __result__45;
				try {
					com.us.aig.ges.dataobject.utils.DataObjectUtils
							.validateDataObject(__smo);
				} catch (com.ibm.websphere.sca.ServiceBusinessException ex) {
					boolean __result__50 = true;
					isValidateDO = __result__50;
					commonj.sdo.DataObject __result__52;
					{// create Fault
						com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
								.locateService("com/ibm/websphere/bo/BOFactory");
						__result__52 = factory.createByElement(
								"http://schemas.xmlsoap.org/soap/envelope/",
								"Fault");
					}
					commonj.sdo.DataObject SOAPFault = __result__52;
					commonj.sdo.DataObject __result__54;
					{// create GWTransientContext
						com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
								.locateService("com/ibm/websphere/bo/BOFactory");
						__result__54 = factory
								.create(
										"http://COM_GES_MF_IntegrationServiceGateway/bo",
										"GWTransientContext");
					}
					commonj.sdo.DataObject transientCtx = __result__54;
					java.lang.String __result__57 = "detail";
					java.lang.Object __result__58 = ex.getData();
					SOAPFault.setDataObject(__result__57,
							(commonj.sdo.DataObject) __result__58);
					java.lang.String __result__61 = "soapFault";
					transientCtx.setDataObject(__result__61, SOAPFault);
					java.lang.String __result__65 = "context/transient";
					__smo.setDataObject(__result__65, transientCtx);
				}
				if (isValidateDO) {
					ValidateDO.fire(__smo);
				} else {
					com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__81 = getSCAServices();
					java.lang.String __result__76 = __result__81
							.getModuleName();
					__smo.getDataObject("context").getDataObject("correlation")
							.setString("ModuleName", __result__76);
					commonj.sdo.DataObject __result__75 = __smo
							.getDataObject("body");
					commonj.sdo.Type __result__78 = __result__75.getType();
					java.lang.String __result__79 = __result__78.getName();
					__smo.getDataObject("context").getDataObject("correlation")
							.setString("TypeName", __result__79);
					java.lang.String __result__84 = __result__78.getURI();
					__smo.getDataObject("context").getDataObject("correlation")
							.setString("URI", __result__84);
					out.fire(__smo);
				}
			} else {
				java.lang.String __result__88 = "Unable to Process ; Request Body is EMPTY ";
				com.ibm.wsspi.sibx.mediation.MediationBusinessException __result__89 = new com.ibm.wsspi.sibx.mediation.MediationBusinessException(
						__result__88);
				throw __result__89;
			}
		} else {
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.headers.SMOHeader.SourceBindingType &amp;&amp;&quot;HTTP&quot;. equalsIgnoreCase(smo.headers.SMOHeader.SourceBindingType)" assignable="false">
		//    <dataOutputs target="//@executableElements.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.0/@dataOutputs.0">
		//    <conditionalActivities collapsed="true">
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;/headers/HTTPHeader/control/Method&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO part" description="Return the part of a Service Message Object specified by the given XPath" category="SMO services" template="&lt;%return%> &lt;%smo%>.get(&lt;%xpath%>);">
		//        <parameters name="smo" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" displayName="service message object">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//        </parameters>
		//        <parameters name="xpath" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.1/@dataOutputs.0" displayName="XPath">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="smo part" displayName="service message object part">
		//          <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="method" localVariable="//@executableElements.1/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GET&quot;.equalsIgnoreCase(method)" assignable="false">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.4/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="smo.context.correlation.isHTTPGET" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//            <result>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleName" category="com.ibm.wsspi.sibx.mediation.esb.SCAServices" className="com.ibm.wsspi.sibx.mediation.esb.SCAServices" memberName="getModuleName">
		//            <parameters name="SCAServices" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.4"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@result/@dataOutputs.0" value="smo.context.correlation.ModuleName" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;HTTP&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.6"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@dataOutputs.0" value="smo.context.correlation.TypeName" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GET&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.8"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.7/@dataOutputs.0" value="smo.context.correlation.URI" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2 //@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3 //@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.4"/>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5 //@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.6"/>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.7 //@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.8"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="false" assignable="false">
		//            <dataOutputs target="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.1/@executableElements.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="smo.context.correlation.isHTTPGET" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.1/@executableElements.0 //@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.1/@executableElements.1"/>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="method">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.0 //@executableElements.1/@conditionalActivities.0/@executableElements.1 //@executableElements.1/@conditionalActivities.0/@executableElements.2 //@executableElements.1/@conditionalActivities.0/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.0/@executableElements.4 //@executableElements.1/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="false" assignable="false">
		//        <dataOutputs target="//@executableElements.1/@conditionalActivities.1/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="smo.context.correlation.isHTTPGET" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.1/@conditionalActivities.1/@executableElements.0 //@executableElements.1/@conditionalActivities.1/@executableElements.1"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.isHTTPGET" field="true">
		//    <dataOutputs target="//@executableElements.3/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="inverse" description="Convert true to false or false to true" category="logic" template="&lt;%return%> !&lt;%input%>;">
		//    <parameters name="input" dataInputs="//@executableElements.2/@dataOutputs.0" displayName="input">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.4"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.body.message.value" assignable="false">
		//        <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.message.value" field="true">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="stringToDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="stringToDataObject">
		//            <parameters name="value" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.4/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </result>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler" collapsed="true">
		//            <parameters name="ex" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2/@exceptions.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//              <result>
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.4/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//              </result>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//              <result>
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.4/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//              </result>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE" field="true">
		//              <parameters name="COM_GES_MF_IntegrationServiceGateway_requestResponse__SEVERE">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </parameters>
		//              <result>
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.4/@parameters.2"/>
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </result>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.4/@parameters.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//              <parameters name="SCAServices" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.0/@result/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//              </parameters>
		//              <parameters name="MediationServices" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.1/@result/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//              </parameters>
		//              <parameters name="inputMessage" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.2/@result/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </parameters>
		//              <parameters name="dataObject" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.3/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//              <exceptions name="Exception1">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//              </exceptions>
		//            </executableElements>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.1 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.2 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.3 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3/@executableElements.4"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="set SMO body" description="Set the body of a Service Message Object" category="SMO services" template="&lt;%smo%>.setBody(&lt;%smo body%>);">
		//            <parameters name="smo" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" displayName="service message object">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//            </parameters>
		//            <parameters name="smo body" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" displayName="service message object body">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="false" assignable="false">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.6"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.5/@dataOutputs.0" value="isValidateDO" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@localVariables.1" variable="true">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null" assignable="false">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.8"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.7/@dataOutputs.0" value="SMOValidateDO" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.10/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="validateDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="validateDataObject">
		//            <parameters name="aDataObject" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.9/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//            <parameters name="ex" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.10/@exceptions.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="true" assignable="false">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.0/@dataOutputs.0" value="isValidateDO" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@localVariables.1" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create Fault" description="create a new Fault {http://schemas.xmlsoap.org/soap/envelope/}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.createByElement(&quot;http://schemas.xmlsoap.org/soap/envelope/&quot;,&quot;Fault&quot;);">
		//              <result>
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.3"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Fault" namespace="http://schemas.xmlsoap.org/soap/envelope/" nillable="false"/>
		//              </result>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.2/@result/@dataOutputs.0" value="SOAPFault" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@localVariables.0" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Fault" namespace="http://schemas.xmlsoap.org/soap/envelope/"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create GWTransientContext" description="create a new GWTransientContext {http://COM_GES_MF_IntegrationServiceGateway/bo}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://COM_GES_MF_IntegrationServiceGateway/bo&quot;,&quot;GWTransientContext&quot;);">
		//              <result>
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.5"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GWTransientContext" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo" nillable="false"/>
		//              </result>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.4/@result/@dataOutputs.0" value="transientCtx" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@localVariables.1" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GWTransientContext" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SOAPFault" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@localVariables.0" variable="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.9/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Fault" namespace="http://schemas.xmlsoap.org/soap/envelope/"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;detail&quot;" assignable="false">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.9/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex.data" field="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.9/@parameters.2"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//              <parameters name="DataObject" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.6/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//              <parameters name="arg0" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.7/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </parameters>
		//              <parameters name="arg1" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.8/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="transientCtx" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@localVariables.1" variable="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.13/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GWTransientContext" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;soapFault&quot;" assignable="false">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.13/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SOAPFault" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@localVariables.0" variable="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.13/@parameters.2"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Fault" namespace="http://schemas.xmlsoap.org/soap/envelope/"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//              <parameters name="DataObject" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.10/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//              <parameters name="arg0" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.11/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </parameters>
		//              <parameters name="arg1" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.12/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.17/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;context/transient&quot;" assignable="false">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.17/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="transientCtx" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@localVariables.1" variable="true">
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.17/@parameters.2"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GWTransientContext" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//              <parameters name="DataObject" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.14/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//              <parameters name="arg0" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.15/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </parameters>
		//              <parameters name="arg1" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.16/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//            </executableElements>
		//            <localVariables name="SOAPFault">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Fault" namespace="http://schemas.xmlsoap.org/soap/envelope/"/>
		//            </localVariables>
		//            <localVariables name="transientCtx">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GWTransientContext" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//            </localVariables>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.1"/>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.2 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.3"/>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.4 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.5"/>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.6 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.7 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.8 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.9"/>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.10 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.11 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.12 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.13"/>
		//            <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.14 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.15 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.16 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11/@executableElements.17"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="isValidateDO" localVariable="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@localVariables.1" variable="true">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.12/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ValidateDO" variable="true">
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//                <parameters name="OutputTerminal" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//                </parameters>
		//                <parameters name="smo" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.1 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body" field="true">
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.3/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="gatewayMessage_SetType0" namespace="wsdl.http://www.ibm.com/websphere/sibx/ServiceGateway"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleName" category="com.ibm.wsspi.sibx.mediation.esb.SCAServices" className="com.ibm.wsspi.sibx.mediation.esb.SCAServices" memberName="getModuleName">
		//                <parameters name="SCAServices" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.6/@result/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//                </parameters>
		//                <result>
		//                  <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.2"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </result>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0" value="smo.context.correlation.ModuleName" field="true">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getType" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getType">
		//                <parameters name="DataObject" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <result>
		//                  <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.4/@parameters.0"/>
		//                  <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.9/@parameters.0"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//                </result>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getName" category="commonj.sdo.Type" className="commonj.sdo.Type" memberName="getName">
		//                <parameters name="Type" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.3/@result/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//                </parameters>
		//                <result>
		//                  <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.5"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </result>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.4/@result/@dataOutputs.0" value="smo.context.correlation.TypeName" field="true">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//                <result>
		//                  <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.1/@parameters.0"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//                </result>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.11/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//                <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.11/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getURI" category="commonj.sdo.Type" className="commonj.sdo.Type" memberName="getURI">
		//                <parameters name="Type" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.3/@result/@dataOutputs.1">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//                </parameters>
		//                <result>
		//                  <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.10"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </result>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.9/@result/@dataOutputs.0" value="smo.context.correlation.URI" field="true">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//                <parameters name="OutputTerminal" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.7/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//                </parameters>
		//                <parameters name="smo" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.8/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.1 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.2 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.6"/>
		//              <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.3 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.4 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.5"/>
		//              <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.9 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.10"/>
		//              <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.7 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.8 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13/@conditionalActivities.1/@executableElements.11"/>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="SMOValidateDO">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//          </localVariables>
		//          <localVariables name="isValidateDO">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.1 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.3 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.4"/>
		//          <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.5 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.6"/>
		//          <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.7 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.8"/>
		//          <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.9 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.10 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.11"/>
		//          <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.12 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.13"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Unable to Process ; Request Body is EMPTY &quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new MediationBusinessException" category="com.ibm.wsspi.sibx.mediation.MediationBusinessException" className="com.ibm.wsspi.sibx.mediation.MediationBusinessException" constructor="true" memberName="MediationBusinessException">
		//            <parameters name="arg0" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//            <parameters name="Throwable" dataInputs="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1 //@executableElements.4/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2"/>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.4/@conditionalActivities.0/@executableElements.0 //@executableElements.4/@conditionalActivities.0/@executableElements.1"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!5:4,1
		//!SMAP!6:5,4
		//!SMAP!7:9,1
		//!SMAP!8:10,1
		//!SMAP!9:11,1
		//!SMAP!11:12,1
		//!SMAP!12:13,1
		//!SMAP!13:14,1
		//!SMAP!14:15,1
		//!SMAP!15:16,1
		//!SMAP!16:17,1
		//!SMAP!17:18,1
		//!SMAP!18:19,1
		//!SMAP!19:20,1
		//!SMAP!21:23,1
		//!SMAP!22:24,1
		//!SMAP!24:28,1
		//!SMAP!25:29,1
		//!SMAP!26:31,1
		//!SMAP!27:32,4
		//!SMAP!28:36,1
		//!SMAP!30:37,1
		//!SMAP!31:38,1
		//!SMAP!34:39,1
		//!SMAP!35:42,2
		//!SMAP!37:45,1
		//!SMAP!38:46,1
		//!SMAP!39:47,1
		//!SMAP!41:48,1
		//!SMAP!42:50,3
		//!SMAP!43:53,1
		//!SMAP!44:54,1
		//!SMAP!45:55,1
		//!SMAP!46:56,1
		//!SMAP!48:58,1
		//!SMAP!50:61,1
		//!SMAP!51:62,1
		//!SMAP!52:63,6
		//!SMAP!53:69,1
		//!SMAP!54:70,6
		//!SMAP!55:76,1
		//!SMAP!57:77,1
		//!SMAP!58:78,1
		//!SMAP!59:79,1
		//!SMAP!61:80,1
		//!SMAP!63:81,1
		//!SMAP!65:82,1
		//!SMAP!67:83,1
		//!SMAP!69:85,1
		//!SMAP!73:86,1
		//!SMAP!75:92,1
		//!SMAP!76:90,1
		//!SMAP!77:91,1
		//!SMAP!78:93,1
		//!SMAP!79:94,1
		//!SMAP!80:95,1
		//!SMAP!81:89,1
		//!SMAP!84:96,1
		//!SMAP!85:97,1
		//!SMAP!86:98,1
		//!SMAP!88:102,1
		//!SMAP!89:103,1
		//!SMAP!90:104,1
		//!SMAP!1000000:692,1
	}
}
