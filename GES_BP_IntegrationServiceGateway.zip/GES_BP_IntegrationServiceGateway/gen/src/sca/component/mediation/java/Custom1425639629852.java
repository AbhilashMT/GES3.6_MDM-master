package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: LogAuditToMQ Interface: subflow Operation:  Type: request Custom Mediation: ConstructAuditMessage
 */
public class Custom1425639629852 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__3;
		{// create SMO body with insertAuditMessageRequestMsg
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://GES_Lib_DBArtefacts/bo/DBService",
							"insertAuditMessageRequestMsg"));
			__result__3 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject AuditRequestMsgBody = __result__3;
		byte __result__6 = 0;
		commonj.sdo.DataObject __result__7 = AuditRequestMsgBody
				.createDataObject(__result__6);
		commonj.sdo.DataObject AuditRequestBody = __result__7;
		commonj.sdo.DataObject __result__10;
		{// create AuditMessageRequest_Type
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__10 = factory.create("http://GES_Lib_DBArtefacts/bo",
					"AuditMessageRequest_Type");
		}
		commonj.sdo.DataObject AuditMessageRequestType = __result__10;
		java.lang.String __result__12 = __smo.getDataObject("headers")
				.getDataObject("SMOHeader").getString("MessageUUID");
		AuditMessageRequestType.setString("msg_id", __result__12);
		commonj.sdo.DataObject __result__9 = __smo.getDataObject("context")
				.getDataObject("correlation");
		commonj.sdo.DataObject CorrBO = __result__9;
		boolean __result__15 = null != CorrBO;
		if (__result__15) {
			boolean __result__18 = CorrBO.getBoolean("isAuditUpdate");
			if (__result__18) {
				java.lang.String __result__21 = CorrBO.getString("AuditStatus");
				AuditMessageRequestType.setString("tx_status", __result__21);
			} else {
				boolean __result__24 = __smo.getDataObject("headers").getList(
						"SOAPHeader").isEmpty();
				boolean __result__25;
				{// inverse
					__result__25 = !__result__24;
				}
				if (__result__25) {
					commonj.sdo.DataObject __result__28 = ((commonj.sdo.DataObject) __smo
							.getDataObject("headers").getList("SOAPHeader")
							.get(0)).getDataObject("value");
					commonj.sdo.DataObject RequestHeader = __result__28;
					java.lang.String __result__30 = RequestHeader
							.getDataObject("ServiceRequestContext").getString(
									"ServiceInvoker");
					AuditMessageRequestType.setString("src_sys", __result__30);
				} else {
					java.lang.String __result__33 = "GES";
					AuditMessageRequestType.setString("src_sys", __result__33);
				}
				javax.xml.datatype.XMLGregorianCalendar __result__35 = com.us.chartisinsurance.ges.transformation.utils.TransformationUtils
						.getXgc();
				java.util.Date __result__36 = com.us.chartisinsurance.ges.transformation.utils.TransformationUtils
						.getDateFromXGC(__result__35);
				AuditMessageRequestType.setDate("lg_ts", __result__36);
				commonj.sdo.DataObject __result__38 = __smo
						.getDataObject("body");
				java.lang.String __result__39 = com.us.aig.ges.dataobject.utils.CreateAndSetTargetBO
						.dataObjectLinearize(__result__38);
				AuditMessageRequestType.setString("msg", __result__39);
				java.lang.String __result__41 = "IN PROGRESS";
				AuditMessageRequestType.setString("tx_status", __result__41);
			}
		} else {
		}
		byte __result__45 = 0;
		AuditRequestBody.setDataObject(__result__45, AuditMessageRequestType);
		__smo.set("body", AuditRequestBody);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__50 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__51 = getMediationServices();
		java.lang.String __result__52 = "Log Constructed Audit Message";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__50,
				__result__51, __result__52, __smo);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with insertAuditMessageRequestMsg" description="Create SMO body with message {http://GES_Lib_DBArtefacts/bo/DBService}insertAuditMessageRequestMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://GES_Lib_DBArtefacts/bo/DBService&quot;, &quot;insertAuditMessageRequestMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.2/@result/@dataOutputs.0" value="AuditRequestMsgBody" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AuditRequestMsgBody" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="createDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="createDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.7"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.6/@result/@dataOutputs.0" value="AuditRequestBody" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation" field="true">
		//    <dataOutputs target="//@executableElements.13"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CorrelationContextHolder" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create AuditMessageRequest_Type" description="create a new AuditMessageRequest_Type {http://GES_Lib_DBArtefacts/bo}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://GES_Lib_DBArtefacts/bo&quot;,&quot;AuditMessageRequest_Type&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.10"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AuditMessageRequest_Type" namespace="http://GES_Lib_DBArtefacts/bo" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@result/@dataOutputs.0" value="AuditMessageRequestType" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AuditMessageRequest_Type" namespace="http://GES_Lib_DBArtefacts/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.SMOHeader.MessageUUID" field="true">
		//    <dataOutputs target="//@executableElements.12"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@dataOutputs.0" value="AuditMessageRequestType.msg_id" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@dataOutputs.0" value="CorrBO" localVariable="//@localVariables.3" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CorrelationContextHolder" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=CorrBO" assignable="false">
		//    <dataOutputs target="//@executableElements.15"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.14/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="CorrBO.isAuditUpdate" field="true">
		//        <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="CorrBO.AuditStatus" field="true">
		//            <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="AuditMessageRequestType.tx_status" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.0 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.1"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.SOAPHeader.isEmpty()" assignable="false">
		//            <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="inverse" description="Convert true to false or false to true" category="logic" template="&lt;%return%> !&lt;%input%>;">
		//            <parameters name="input" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" displayName="input">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.SOAPHeader.get(0).value" field="true">
		//                <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="RequestHeader" localVariable="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@localVariables.0" variable="true">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RequestHeader.ServiceRequestContext.ServiceInvoker" field="true">
		//                <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.3"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.2/@dataOutputs.0" value="AuditMessageRequestType.src_sys" field="true">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//              </executableElements>
		//              <localVariables name="RequestHeader">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12" nillable="false"/>
		//              </localVariables>
		//              <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.0 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.1"/>
		//              <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.2 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.0/@executableElements.3"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.1/@executableElements.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="AuditMessageRequestType.src_sys" field="true">
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.1/@executableElements.0 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@conditionalActivities.1/@executableElements.1"/>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getXgc" category="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" className="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" static="true" memberName="getXgc">
		//            <result>
		//              <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.4/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="javax.xml.datatype.XMLGregorianCalendar"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getDateFromXGC" category="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" className="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" static="true" memberName="getDateFromXGC">
		//            <parameters name="xgc" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.3/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="javax.xml.datatype.XMLGregorianCalendar"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Date"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.4/@result/@dataOutputs.0" value="AuditMessageRequestType.lg_ts" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="dateTime" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body" field="true">
		//            <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.7/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="dataObjectLinearize" category="com.us.aig.ges.dataobject.utils.CreateAndSetTargetBO" className="com.us.aig.ges.dataobject.utils.CreateAndSetTargetBO" static="true" memberName="dataObjectLinearize">
		//            <parameters name="aDataObject" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.6/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.8"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.7/@result/@dataOutputs.0" value="AuditMessageRequestType.msg" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;IN PROGRESS&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.10"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.9/@dataOutputs.0" value="AuditMessageRequestType.tx_status" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.0 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2"/>
		//          <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.3 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.4 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.5"/>
		//          <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.6 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.7 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.8"/>
		//          <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.9 //@executableElements.15/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.10"/>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.15/@conditionalActivities.0/@executableElements.0 //@executableElements.15/@conditionalActivities.0/@executableElements.1"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AuditRequestBody" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.19/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.19/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AuditMessageRequestType" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.19/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AuditMessageRequest_Type" namespace="http://GES_Lib_DBArtefacts/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AuditRequestBody" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.21"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.20/@dataOutputs.0" value="smo.body" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.26/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.26/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log Constructed Audit Message&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.26/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.22/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.23/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="AuditRequestMsgBody">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="AuditMessageRequestType">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AuditMessageRequest_Type" namespace="http://GES_Lib_DBArtefacts/bo"/>
		//  </localVariables>
		//  <localVariables name="AuditRequestBody">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="CorrBO">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CorrelationContextHolder" namespace="http://COM_GES_MF_IntegrationServiceGateway/bo" nillable="false"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.13"/>
		//  <executableGroups executableElements="//@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.16 //@executableElements.17 //@executableElements.18 //@executableElements.19"/>
		//  <executableGroups executableElements="//@executableElements.20 //@executableElements.21"/>
		//  <executableGroups executableElements="//@executableElements.22 //@executableElements.23 //@executableElements.24 //@executableElements.25 //@executableElements.26"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.27"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:2,8
		//!SMAP!4:10,1
		//!SMAP!6:11,1
		//!SMAP!7:12,1
		//!SMAP!8:13,1
		//!SMAP!9:23,1
		//!SMAP!10:14,6
		//!SMAP!11:20,1
		//!SMAP!12:21,1
		//!SMAP!13:22,1
		//!SMAP!14:24,1
		//!SMAP!15:25,1
		//!SMAP!16:26,1
		//!SMAP!18:27,1
		//!SMAP!19:28,1
		//!SMAP!21:29,1
		//!SMAP!22:30,1
		//!SMAP!24:33,1
		//!SMAP!25:34,4
		//!SMAP!26:38,1
		//!SMAP!28:39,1
		//!SMAP!29:40,1
		//!SMAP!30:41,1
		//!SMAP!31:42,1
		//!SMAP!33:45,1
		//!SMAP!34:46,1
		//!SMAP!35:48,1
		//!SMAP!36:49,1
		//!SMAP!37:50,1
		//!SMAP!38:51,1
		//!SMAP!39:52,1
		//!SMAP!40:53,1
		//!SMAP!41:54,1
		//!SMAP!42:55,1
		//!SMAP!45:60,1
		//!SMAP!47:61,1
		//!SMAP!49:62,1
		//!SMAP!50:63,1
		//!SMAP!51:64,1
		//!SMAP!52:65,1
		//!SMAP!54:66,1
		//!SMAP!55:67,1
		//!SMAP!1000000:417,1
	}
}
