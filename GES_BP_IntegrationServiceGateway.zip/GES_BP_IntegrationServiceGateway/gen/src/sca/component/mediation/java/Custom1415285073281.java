package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: COM_GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestOnly Type: request Custom Mediation: StringToDataOject
 */
public class Custom1415285073281 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		java.lang.String __result__2 = __smo.getDataObject("body")
				.getDataObject("message").getString("value");
		commonj.sdo.DataObject __result__3 = null;
		try {
			__result__3 = com.us.aig.ges.dataobject.utils.DataObjectUtils
					.stringToDataObject(__result__2);
		} catch (java.lang.Exception ex) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__5 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__6 = getMediationServices();
			java.lang.String __result__7 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_IntegrationServiceGateway_requestOnly__SEVERE;
			utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
					__result__5, __result__6, __result__7, __smo);
		}
		{// set SMO body
			((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
					.setBody(__result__3);
		}
		commonj.sdo.DataObject __result__11 = __smo.getDataObject("body");
		commonj.sdo.Type __result__12 = __result__11.getType();
		java.lang.String __result__13 = __result__12.getName();
		__smo.getDataObject("context").getDataObject("correlation").setString(
				"TypeName", __result__13);
		java.lang.String __result__18 = __result__12.getURI();
		__smo.getDataObject("context").getDataObject("correlation").setString(
				"URI", __result__18);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__17 = getSCAServices();
		java.lang.String __result__20 = __result__17.getModuleName();
		__smo.getDataObject("context").getDataObject("correlation").setString(
				"ModuleName", __result__20);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.message.value" field="true">
		//    <dataOutputs target="//@executableElements.2/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="stringToDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="stringToDataObject">
		//    <parameters name="value" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.3/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex" dataInputs="//@executableElements.2/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.3/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.3/@executableElements.4/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_IntegrationServiceGateway_requestOnly__SEVERE" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_IntegrationServiceGateway_requestOnly__SEVERE" field="true">
		//      <parameters name="COM_GES_MF_IntegrationServiceGateway_requestOnly__SEVERE">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.3/@executableElements.4/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//      <dataOutputs target="//@executableElements.3/@executableElements.4/@parameters.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//      <parameters name="SCAServices" dataInputs="//@executableElements.3/@executableElements.0/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </parameters>
		//      <parameters name="MediationServices" dataInputs="//@executableElements.3/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </parameters>
		//      <parameters name="inputMessage" dataInputs="//@executableElements.3/@executableElements.2/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <parameters name="dataObject" dataInputs="//@executableElements.3/@executableElements.3/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </parameters>
		//      <exceptions name="Exception1">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//      </exceptions>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.3/@executableElements.0 //@executableElements.3/@executableElements.1 //@executableElements.3/@executableElements.2 //@executableElements.3/@executableElements.3 //@executableElements.3/@executableElements.4"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="set SMO body" description="Set the body of a Service Message Object" category="SMO services" template="&lt;%smo%>.setBody(&lt;%smo body%>);">
		//    <parameters name="smo" dataInputs="//@executableElements.0/@dataOutputs.0" displayName="service message object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="smo body" dataInputs="//@executableElements.2/@result/@dataOutputs.0" displayName="service message object body">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body" field="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="gatewayMessage_SetType0" namespace="wsdl.http://www.ibm.com/websphere/sibx/ServiceGateway"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getType" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getType">
		//    <parameters name="DataObject" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getName" category="commonj.sdo.Type" className="commonj.sdo.Type" memberName="getName">
		//    <parameters name="Type" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.8"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@result/@dataOutputs.0" value="smo.context.correlation.TypeName" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getURI" category="commonj.sdo.Type" className="commonj.sdo.Type" memberName="getURI">
		//    <parameters name="Type" dataInputs="//@executableElements.6/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.13"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.12/@result/@dataOutputs.0" value="smo.context.correlation.URI" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleName" category="com.ibm.wsspi.sibx.mediation.esb.SCAServices" className="com.ibm.wsspi.sibx.mediation.esb.SCAServices" memberName="getModuleName">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.11/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.15"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.14/@result/@dataOutputs.0" value="smo.context.correlation.ModuleName" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.9/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2 //@executableElements.3 //@executableElements.4"/>
		//  <executableGroups executableElements="//@executableElements.5 //@executableElements.6 //@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.12 //@executableElements.13"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10 //@executableElements.16"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!2:2,1
		//!SMAP!3:5,2
		//!SMAP!5:8,1
		//!SMAP!6:9,1
		//!SMAP!7:10,1
		//!SMAP!9:11,1
		//!SMAP!10:13,3
		//!SMAP!11:16,1
		//!SMAP!12:17,1
		//!SMAP!13:18,1
		//!SMAP!14:19,1
		//!SMAP!17:22,1
		//!SMAP!18:20,1
		//!SMAP!19:21,1
		//!SMAP!20:23,1
		//!SMAP!21:24,1
		//!SMAP!22:25,1
		//!SMAP!1000000:218,1
	}
}
