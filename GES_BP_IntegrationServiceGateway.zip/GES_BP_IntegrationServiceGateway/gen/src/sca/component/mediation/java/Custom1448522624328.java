package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_IntegrationGateway Interface: ServiceGateway Operation: requestResponse Type: request Custom Mediation: Fetch_Invoke_Dynamic_Endpoint
 */
public class Custom1448522624328 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__6 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__7 = getMediationServices();
		java.lang.String __result__8 = "Log Entry , DynamicIntegrationGateway ";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__6,
				__result__7, __result__8, __smo);
		java.lang.String __result__11 = "/body/message/value";
		java.lang.Object __result__13;
		{// get SMO part
			__result__13 = ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
					.get(__result__11);
		}
		java.lang.String valueStr = (java.lang.String) __result__13;
		commonj.sdo.DataObject __result__15 = null;
		try {
			__result__15 = com.us.aig.ges.dataobject.utils.DataObjectUtils
					.stringToDataObject(valueStr);
		} catch (java.lang.Exception ex) {
			{// print to log
				System.out.println(ex);
			}
			java.lang.String __result__20 = "Log Exception , Retreiving SMO Part and Conversion of String to DataObject ";
		}
		commonj.sdo.DataObject RequestDO = __result__15;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__21 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__22 = getMediationServices();
		java.lang.String __result__23 = "Log ,Request DataObject ";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__21,
				__result__22, __result__23, RequestDO);
		java.lang.String __result__5 = com.us.aig.ges.constants.GESConstantBundle.GES_REVIVED_GATEWAY;
		java.lang.Object __result__26 = com.aig.us.ges.cache.utils.GESCacheLoader
				.getValueFromCache(__result__5);
		java.lang.String GESServiceDefinition = (java.lang.String) __result__26;
		{// print to log
			System.out.println(GESServiceDefinition);
		}
		java.lang.String __result__4 = "/headers/HTTPHeader";
		java.lang.Object __result__29;
		{// get SMO part
			__result__29 = ((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo)
					.get(__result__4);
		}
		com.ibm.websphere.sibx.smobo.HTTPHeaderType HTTPHeaderType = (com.ibm.websphere.sibx.smobo.HTTPHeaderType) __result__29;
		java.lang.String __result__31 = HTTPHeaderType.getControl().getURL();
		java.lang.String controlURL = __result__31;
		{// print to log
			System.out.println(controlURL);
		}
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__34 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__35 = getMediationServices();
		java.lang.String __result__36 = "Log , Control URL  " + controlURL;
		utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
				__result__34, __result__35, __result__36);
		java.lang.String[] __result__39 = null;
		try {
			__result__39 = com.us.chartisinsurance.ges.mediation.module.utils.ServiceDataHandler
					.getServiceNameAndVersion(controlURL);
		} catch (java.lang.Exception ex2) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__41 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__42 = getMediationServices();
			java.lang.String __result__44 = com.us.aig.ges.dataobject.utils.DataObjectUtils
					.exceptionToStringConverter(ex2);
			utility.MediationLogger_LogSevereNoBO
					.mediationLogger_LogSevereNoBO(__result__41, __result__42,
							__result__44);
		}
		java.lang.String[] serviceDataArray = __result__39;
		byte __result__52 = 0;
		java.lang.String __result__54;
		{// get array element 
			__result__54 = serviceDataArray[__result__52];
		}
		java.lang.String serviceName = __result__54;
		{// print to log
			System.out.println(serviceName);
		}
		byte __result__57 = 1;
		java.lang.String __result__59;
		{// get array element 
			__result__59 = serviceDataArray[__result__57];
		}
		java.lang.String versionName = __result__59;
		{// print to log
			System.out.println(versionName);
		}
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__63 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__64 = getMediationServices();
		java.lang.String __result__65 = "Log , ServiceName=" + serviceName
				+ " &" + "Version" + versionName;
		utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
				__result__63, __result__64, __result__65);
		java.lang.String __result__62 = "";
		java.lang.String endPointAddrs = __result__62;
		boolean __result__70 = null != serviceName
				&& null != versionName
				&& (!("" == null ? serviceName == null : "".equals(serviceName)))
				&& (!("" == null ? versionName == null : "".equals(versionName)));
		if (__result__70) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__73 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__74 = getMediationServices();
			java.lang.String __result__75 = "Log , Entered EndPointReference Retreival Case ";
			utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
					__result__73, __result__74, __result__75);
			java.lang.String __result__80 = null;
			try {
				__result__80 = com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp
						.getEndPointReferenceForServiceAndVersion(
								GESServiceDefinition, serviceName, versionName);
			} catch (java.lang.Exception ex) {
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__82 = getSCAServices();
				com.ibm.wsspi.sibx.mediation.MediationServices __result__83 = getMediationServices();
				java.lang.String __result__85 = com.us.aig.ges.dataobject.utils.DataObjectUtils
						.exceptionToStringConverter(ex);
				utility.MediationLogger_LogSevereNoBO
						.mediationLogger_LogSevereNoBO(__result__82,
								__result__83, __result__85);
			}
			endPointAddrs = __result__80;
		} else {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__90 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__91 = getMediationServices();
			java.lang.String __result__92 = "Log , Entered EndPoint Retreival Case for Type - NameSpace Combination";
			utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
					__result__90, __result__91, __result__92);
			commonj.sdo.Type __result__89 = RequestDO.getType();
			commonj.sdo.Type typeSDO = __result__89;
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__95 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__96 = getMediationServices();
			java.lang.String __result__97 = "Printing TypeName : ";
			java.lang.String __result__98 = typeSDO.getName();
			java.lang.String __result__99;
			{// append text
				__result__99 = __result__97.concat(__result__98);
			}
			java.lang.String __result__100 = "Printing the URI :";
			java.lang.String __result__101 = typeSDO.getURI();
			java.lang.String __result__102;
			{// append text
				__result__102 = __result__100.concat(__result__101);
			}
			java.lang.String __result__103;
			{// append text
				__result__103 = __result__99.concat(__result__102);
			}
			utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
					__result__95, __result__96, __result__103);
			java.lang.String __result__106 = typeSDO.getName();
			java.lang.String ObjName = __result__106;
			java.lang.String __result__108 = typeSDO.getURI();
			java.lang.String ObjURI = __result__108;
			java.lang.String __result__110 = null;
			try {
				__result__110 = com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp
						.getEndPointReferenceForTypeAndNS(GESServiceDefinition,
								ObjName, ObjURI);
			} catch (java.lang.Exception ex) {
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__112 = getSCAServices();
				com.ibm.wsspi.sibx.mediation.MediationServices __result__113 = getMediationServices();
				java.lang.String __result__115 = com.us.aig.ges.dataobject.utils.DataObjectUtils
						.exceptionToStringConverter(ex);
				utility.MediationLogger_LogSevereNoBO
						.mediationLogger_LogSevereNoBO(__result__112,
								__result__113, __result__115);
			}
			endPointAddrs = __result__110;
		}
		{// print to log
			System.out.println(endPointAddrs);
		}
		utility.SCA_and_BO_services.SetTargetAddress.setTargetAddress(
				(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo,
				endPointAddrs);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__47 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__48 = getMediationServices();
		java.lang.String __result__49 = "Printing the final outgoing messge :";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__47,
				__result__48, __result__49, __smo);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.66/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.66/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.25/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;/headers/HTTPHeader&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.25/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESConstantBundle.GES_REVIVED_GATEWAY" category="com.us.aig.ges.constants.GESConstantBundle" className="com.us.aig.ges.constants.GESConstantBundle" static="true" memberName="GES_REVIVED_GATEWAY" field="true">
		//    <parameters name="GES_REVIVED_GATEWAY">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.22/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.9/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.9/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log Entry , DynamicIntegrationGateway &quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.9/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.9/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfo" category="utility.MediationLogger_LogInfo" className="utility.MediationLogger_LogInfo" static="true" memberName="mediationLogger_LogInfo">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.5/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.8/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;/body/message/value&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.12/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO part" description="Return the part of a Service Message Object specified by the given XPath" category="SMO services" template="&lt;%return%> &lt;%smo%>.get(&lt;%xpath%>);">
		//    <parameters name="smo" dataInputs="//@executableElements.11/@dataOutputs.0" displayName="service message object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="xpath" dataInputs="//@executableElements.10/@dataOutputs.0" displayName="XPath">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="smo part" displayName="service message object part">
		//      <dataOutputs target="//@executableElements.13"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.12/@result/@dataOutputs.0" value="valueStr" localVariable="//@localVariables.7" variable="true">
		//    <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="stringToDataObject" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="stringToDataObject">
		//    <parameters name="value" dataInputs="//@executableElements.13/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.15"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.14/@result/@dataOutputs.0" value="RequestDO" localVariable="//@localVariables.8" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex" dataInputs="//@executableElements.14/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//      <dataOutputs target="//@executableElements.16/@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//      <parameters name="object" dataInputs="//@executableElements.16/@executableElements.0/@dataOutputs.0" displayName="object">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </parameters>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log Exception , Retreiving SMO Part and Conversion of String to DataObject &quot;" assignable="false">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.16/@executableElements.0 //@executableElements.16/@executableElements.1"/>
		//    <executableGroups executableElements="//@executableElements.16/@executableElements.2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.21/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.21/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log ,Request DataObject &quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.21/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RequestDO" localVariable="//@localVariables.8" variable="true">
		//    <dataOutputs target="//@executableElements.21/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfo" category="utility.MediationLogger_LogInfo" className="utility.MediationLogger_LogInfo" static="true" memberName="mediationLogger_LogInfo">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.17/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.18/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.20/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getValueFromCache" category="com.aig.us.ges.cache.utils.GESCacheLoader" className="com.aig.us.ges.cache.utils.GESCacheLoader" static="true" memberName="getValueFromCache">
		//    <parameters name="aKey" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.23"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.22/@result/@dataOutputs.0" value="GESServiceDefinition" localVariable="//@localVariables.5" variable="true">
		//    <dataOutputs target="//@executableElements.24/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//    <parameters name="object" dataInputs="//@executableElements.23/@dataOutputs.0" displayName="object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get SMO part" description="Return the part of a Service Message Object specified by the given XPath" category="SMO services" template="&lt;%return%> &lt;%smo%>.get(&lt;%xpath%>);">
		//    <parameters name="smo" dataInputs="//@executableElements.2/@dataOutputs.0" displayName="service message object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="xpath" dataInputs="//@executableElements.3/@dataOutputs.0" displayName="XPath">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="smo part" displayName="service message object part">
		//      <dataOutputs target="//@executableElements.26"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.25/@result/@dataOutputs.0" value="HTTPHeaderType" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.HTTPHeaderType"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="HTTPHeaderType.control.uRL" field="true">
		//    <dataOutputs target="//@executableElements.28"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.27/@dataOutputs.0" value="controlURL" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.29/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//    <parameters name="object" dataInputs="//@executableElements.28/@dataOutputs.0" displayName="object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.33/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.33/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log , Control URL  &quot;+ controlURL" assignable="false">
		//    <dataOutputs target="//@executableElements.33/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.30/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.31/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="LogMsg" dataInputs="//@executableElements.32/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="controlURL" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.35/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getServiceNameAndVersion" category="com.us.chartisinsurance.ges.mediation.module.utils.ServiceDataHandler" className="com.us.chartisinsurance.ges.mediation.module.utils.ServiceDataHandler" static="true" memberName="getServiceNameAndVersion">
		//    <parameters name="controlURL" dataInputs="//@executableElements.34/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.37"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//    </result>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.36/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex2" dataInputs="//@executableElements.35/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.36/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.36/@executableElements.4/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex2" variable="true">
		//      <dataOutputs target="//@executableElements.36/@executableElements.3/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="exceptionToStringConverter" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="exceptionToStringConverter">
		//      <parameters name="ex" dataInputs="//@executableElements.36/@executableElements.2/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.36/@executableElements.4/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogSevereNoBO" category="utility.MediationLogger_LogSevereNoBO" className="utility.MediationLogger_LogSevereNoBO" static="true" memberName="mediationLogger_LogSevereNoBO">
		//      <parameters name="SCAServices" dataInputs="//@executableElements.36/@executableElements.0/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </parameters>
		//      <parameters name="MediationServices" dataInputs="//@executableElements.36/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </parameters>
		//      <parameters name="LogMsg" dataInputs="//@executableElements.36/@executableElements.3/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.36/@executableElements.0 //@executableElements.36/@executableElements.1 //@executableElements.36/@executableElements.2 //@executableElements.36/@executableElements.3 //@executableElements.36/@executableElements.4"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.35/@result/@dataOutputs.0" value="serviceDataArray" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.65/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.65/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Printing the final outgoing messge :&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.65/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.65/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.64/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.45/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="serviceDataArray" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.45/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get array element " description="Access an element in an array" category="arrays" template="&lt;%return%> &lt;%array%>[&lt;%index%>];">
		//    <parameters name="array" dataInputs="//@executableElements.44/@dataOutputs.0" displayName="array">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//    </parameters>
		//    <parameters name="index" dataInputs="//@executableElements.43/@dataOutputs.0" displayName="index">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result name="value" displayName="value">
		//      <dataOutputs target="//@executableElements.46"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.45/@result/@dataOutputs.0" value="serviceName" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.47/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//    <parameters name="object" dataInputs="//@executableElements.46/@dataOutputs.0" displayName="object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="1" assignable="false">
		//    <dataOutputs target="//@executableElements.50/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="serviceDataArray" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.50/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="get array element " description="Access an element in an array" category="arrays" template="&lt;%return%> &lt;%array%>[&lt;%index%>];">
		//    <parameters name="array" dataInputs="//@executableElements.49/@dataOutputs.0" displayName="array">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//    </parameters>
		//    <parameters name="index" dataInputs="//@executableElements.48/@dataOutputs.0" displayName="index">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result name="value" displayName="value">
		//      <dataOutputs target="//@executableElements.51"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.50/@result/@dataOutputs.0" value="versionName" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.52/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//    <parameters name="object" dataInputs="//@executableElements.51/@dataOutputs.0" displayName="object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.58"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.57/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.57/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log , ServiceName=&quot;+ serviceName+&quot; &amp;&quot; +&quot;Version&quot;+ versionName" assignable="false">
		//    <dataOutputs target="//@executableElements.57/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.54/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.55/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="LogMsg" dataInputs="//@executableElements.56/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.53/@dataOutputs.0" value="endPointAddrs" localVariable="//@localVariables.6" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="endPointAddrs" localVariable="//@localVariables.6" variable="true">
		//    <dataOutputs target="//@executableElements.64/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="endPointAddrs" localVariable="//@localVariables.6" variable="true">
		//    <dataOutputs target="//@executableElements.63/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!= serviceName &amp;&amp;  null != versionName &amp;&amp; &quot;&quot; !=serviceName  &amp;&amp;  &quot;&quot; !=versionName" assignable="false">
		//    <dataOutputs target="//@executableElements.62"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.61/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.3/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.3/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log , Entered EndPointReference Retreival Case &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.3/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.0/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="LogMsg" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESServiceDefinition" localVariable="//@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.7/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="serviceName" localVariable="//@localVariables.3" variable="true">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.7/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="versionName" localVariable="//@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.7/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPointReferenceForServiceAndVersion" category="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" className="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" static="true" memberName="getEndPointReferenceForServiceAndVersion">
		//        <parameters name="gesServiceDefinitionConfig" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.4/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="serviceName" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.5/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="serviceVersion" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.9"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.7/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.4/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.3/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="exceptionToStringConverter" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="exceptionToStringConverter">
		//          <parameters name="ex" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.2/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//          </parameters>
		//          <result>
		//            <dataOutputs target="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.4/@parameters.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogSevereNoBO" category="utility.MediationLogger_LogSevereNoBO" className="utility.MediationLogger_LogSevereNoBO" static="true" memberName="mediationLogger_LogSevereNoBO">
		//          <parameters name="SCAServices" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.0/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </parameters>
		//          <parameters name="MediationServices" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.1/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </parameters>
		//          <parameters name="LogMsg" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.3/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.0 //@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.1 //@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.2 //@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.3 //@executableElements.62/@conditionalActivities.0/@executableElements.8/@executableElements.4"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.62/@conditionalActivities.0/@executableElements.7/@result/@dataOutputs.0" value="endPointAddrs" localVariable="//@localVariables.6" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.62/@conditionalActivities.0/@executableElements.0 //@executableElements.62/@conditionalActivities.0/@executableElements.1 //@executableElements.62/@conditionalActivities.0/@executableElements.2 //@executableElements.62/@conditionalActivities.0/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.62/@conditionalActivities.0/@executableElements.4 //@executableElements.62/@conditionalActivities.0/@executableElements.5 //@executableElements.62/@conditionalActivities.0/@executableElements.6 //@executableElements.62/@conditionalActivities.0/@executableElements.7 //@executableElements.62/@conditionalActivities.0/@executableElements.8 //@executableElements.62/@conditionalActivities.0/@executableElements.9"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RequestDO.getType()" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.5"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.4/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.4/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log , Entered EndPoint Retreival Case for Type - NameSpace Combination&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.4/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.2/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="LogMsg" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="typeSDO" localVariable="//@executableElements.62/@conditionalActivities.1/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.15/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.15/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Printing TypeName : &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.10/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="typeSDO.getName()" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.10/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.8/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.9/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.14/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Printing the URI :&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.13/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="typeSDO.getURI()" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.13/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.11/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.12/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.14/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//        <parameters name="input1" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.10/@result/@dataOutputs.0" displayName="input 1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="input2" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.13/@result/@dataOutputs.0" displayName="input 2">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result name="combined text" displayName="combined text">
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.15/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfoNoBO" category="utility.MediationLogger_LogInfoNoBO" className="utility.MediationLogger_LogInfoNoBO" static="true" memberName="mediationLogger_LogInfoNoBO">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.6/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.7/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="LogMsg" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.14/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESServiceDefinition" localVariable="//@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.21/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="typeSDO.getName()" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.18"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.17/@dataOutputs.0" value="ObjName" localVariable="//@executableElements.62/@conditionalActivities.1/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.21/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="typeSDO.getURI()" assignable="false">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.20"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.19/@dataOutputs.0" value="ObjURI" localVariable="//@executableElements.62/@conditionalActivities.1/@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.21/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPointReferenceForTypeAndNS" category="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" className="com.us.chartisinsurance.ges.common.utils.DynamicEndpointLookUp" static="true" memberName="getEndPointReferenceForTypeAndNS">
		//        <parameters name="gesServiceDefinitionConfig" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.16/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="rootType" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.18/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="NS" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.20/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.23"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.21/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//          <result>
		//            <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.4/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//          <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.3/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="exceptionToStringConverter" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="exceptionToStringConverter">
		//          <parameters name="ex" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.2/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//          </parameters>
		//          <result>
		//            <dataOutputs target="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.4/@parameters.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogSevereNoBO" category="utility.MediationLogger_LogSevereNoBO" className="utility.MediationLogger_LogSevereNoBO" static="true" memberName="mediationLogger_LogSevereNoBO">
		//          <parameters name="SCAServices" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.0/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//          </parameters>
		//          <parameters name="MediationServices" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.1/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//          </parameters>
		//          <parameters name="LogMsg" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.3/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.0 //@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.1 //@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.2 //@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.3 //@executableElements.62/@conditionalActivities.1/@executableElements.22/@executableElements.4"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.62/@conditionalActivities.1/@executableElements.21/@result/@dataOutputs.0" value="endPointAddrs" localVariable="//@localVariables.6" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <localVariables name="typeSDO">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//      </localVariables>
		//      <localVariables name="ObjName">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="ObjURI">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.62/@conditionalActivities.1/@executableElements.1 //@executableElements.62/@conditionalActivities.1/@executableElements.2 //@executableElements.62/@conditionalActivities.1/@executableElements.3 //@executableElements.62/@conditionalActivities.1/@executableElements.4"/>
		//      <executableGroups executableElements="//@executableElements.62/@conditionalActivities.1/@executableElements.0 //@executableElements.62/@conditionalActivities.1/@executableElements.5"/>
		//      <executableGroups executableElements="//@executableElements.62/@conditionalActivities.1/@executableElements.6 //@executableElements.62/@conditionalActivities.1/@executableElements.7 //@executableElements.62/@conditionalActivities.1/@executableElements.8 //@executableElements.62/@conditionalActivities.1/@executableElements.9 //@executableElements.62/@conditionalActivities.1/@executableElements.10 //@executableElements.62/@conditionalActivities.1/@executableElements.11 //@executableElements.62/@conditionalActivities.1/@executableElements.12 //@executableElements.62/@conditionalActivities.1/@executableElements.13 //@executableElements.62/@conditionalActivities.1/@executableElements.14 //@executableElements.62/@conditionalActivities.1/@executableElements.15"/>
		//      <executableGroups executableElements="//@executableElements.62/@conditionalActivities.1/@executableElements.16 //@executableElements.62/@conditionalActivities.1/@executableElements.17 //@executableElements.62/@conditionalActivities.1/@executableElements.18 //@executableElements.62/@conditionalActivities.1/@executableElements.19 //@executableElements.62/@conditionalActivities.1/@executableElements.20 //@executableElements.62/@conditionalActivities.1/@executableElements.21 //@executableElements.62/@conditionalActivities.1/@executableElements.22 //@executableElements.62/@conditionalActivities.1/@executableElements.23"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="print to log" description="Print a text representation of the input to System.out" category="utility" template="System.out.println(&lt;%object%>);">
		//    <parameters name="object" dataInputs="//@executableElements.60/@dataOutputs.0" displayName="object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="SetTargetAddress" category="SCA and BO services" targetNamespace="http://GES_Lib_Common/utility/SCA%20and%20BO%20services/">
		//    <parameters name="smo" dataInputs="//@executableElements.42/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="targetURI" dataInputs="//@executableElements.59/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="mediationLogger_LogInfo" category="utility.MediationLogger_LogInfo" className="utility.MediationLogger_LogInfo" static="true" memberName="mediationLogger_LogInfo">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.38/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.39/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.40/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.41/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="HTTPHeaderType">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.HTTPHeaderType"/>
		//  </localVariables>
		//  <localVariables name="controlURL">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="serviceDataArray">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String[]"/>
		//  </localVariables>
		//  <localVariables name="serviceName">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="versionName">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="GESServiceDefinition">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="endPointAddrs">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </localVariables>
		//  <localVariables name="valueStr">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="RequestDO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.5 //@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15 //@executableElements.16"/>
		//  <executableGroups executableElements="//@executableElements.17 //@executableElements.18 //@executableElements.19 //@executableElements.20 //@executableElements.21"/>
		//  <executableGroups executableElements="//@executableElements.4 //@executableElements.22 //@executableElements.23 //@executableElements.24"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.25 //@executableElements.26"/>
		//  <executableGroups executableElements="//@executableElements.27 //@executableElements.28 //@executableElements.29"/>
		//  <executableGroups executableElements="//@executableElements.30 //@executableElements.31 //@executableElements.32 //@executableElements.33"/>
		//  <executableGroups executableElements="//@executableElements.34 //@executableElements.35 //@executableElements.36 //@executableElements.37"/>
		//  <executableGroups executableElements="//@executableElements.43 //@executableElements.44 //@executableElements.45 //@executableElements.46 //@executableElements.47"/>
		//  <executableGroups executableElements="//@executableElements.48 //@executableElements.49 //@executableElements.50 //@executableElements.51 //@executableElements.52"/>
		//  <executableGroups executableElements="//@executableElements.54 //@executableElements.55 //@executableElements.56 //@executableElements.57"/>
		//  <executableGroups executableElements="//@executableElements.53 //@executableElements.58"/>
		//  <executableGroups executableElements="//@executableElements.61 //@executableElements.62"/>
		//  <executableGroups executableElements="//@executableElements.60 //@executableElements.63"/>
		//  <executableGroups executableElements="//@executableElements.42 //@executableElements.59 //@executableElements.64"/>
		//  <executableGroups executableElements="//@executableElements.38 //@executableElements.39 //@executableElements.40 //@executableElements.41 //@executableElements.65"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.66"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!4:33,1
		//!SMAP!5:27,1
		//!SMAP!6:2,1
		//!SMAP!7:3,1
		//!SMAP!8:4,1
		//!SMAP!10:5,1
		//!SMAP!11:6,1
		//!SMAP!13:7,4
		//!SMAP!14:11,1
		//!SMAP!15:14,2
		//!SMAP!16:22,1
		//!SMAP!19:17,3
		//!SMAP!20:20,1
		//!SMAP!21:23,1
		//!SMAP!22:24,1
		//!SMAP!23:25,1
		//!SMAP!25:26,1
		//!SMAP!26:28,1
		//!SMAP!27:29,1
		//!SMAP!28:30,3
		//!SMAP!29:34,4
		//!SMAP!30:38,1
		//!SMAP!31:39,1
		//!SMAP!32:40,1
		//!SMAP!33:41,3
		//!SMAP!34:44,1
		//!SMAP!35:45,1
		//!SMAP!36:46,1
		//!SMAP!37:47,1
		//!SMAP!39:50,2
		//!SMAP!41:53,1
		//!SMAP!42:54,1
		//!SMAP!44:55,1
		//!SMAP!45:56,1
		//!SMAP!46:58,1
		//!SMAP!47:147,1
		//!SMAP!48:148,1
		//!SMAP!49:149,1
		//!SMAP!52:59,1
		//!SMAP!54:60,4
		//!SMAP!55:64,1
		//!SMAP!56:65,3
		//!SMAP!57:68,1
		//!SMAP!59:69,4
		//!SMAP!60:73,1
		//!SMAP!61:74,3
		//!SMAP!62:81,1
		//!SMAP!63:77,1
		//!SMAP!64:78,1
		//!SMAP!65:79,1
		//!SMAP!66:80,1
		//!SMAP!67:82,1
		//!SMAP!70:83,1
		//!SMAP!71:84,1
		//!SMAP!73:85,1
		//!SMAP!74:86,1
		//!SMAP!75:87,1
		//!SMAP!76:88,1
		//!SMAP!80:91,2
		//!SMAP!82:94,1
		//!SMAP!83:95,1
		//!SMAP!85:96,1
		//!SMAP!86:97,1
		//!SMAP!87:99,1
		//!SMAP!89:106,1
		//!SMAP!90:102,1
		//!SMAP!91:103,1
		//!SMAP!92:104,1
		//!SMAP!93:105,1
		//!SMAP!94:107,1
		//!SMAP!95:108,1
		//!SMAP!96:109,1
		//!SMAP!97:110,1
		//!SMAP!98:111,1
		//!SMAP!99:112,4
		//!SMAP!100:116,1
		//!SMAP!101:117,1
		//!SMAP!102:118,4
		//!SMAP!103:122,4
		//!SMAP!104:126,1
		//!SMAP!106:127,1
		//!SMAP!107:128,1
		//!SMAP!108:129,1
		//!SMAP!109:130,1
		//!SMAP!110:133,2
		//!SMAP!112:136,1
		//!SMAP!113:137,1
		//!SMAP!115:138,1
		//!SMAP!116:139,1
		//!SMAP!117:141,1
		//!SMAP!118:143,3
		//!SMAP!119:146,1
		//!SMAP!120:150,1
		//!SMAP!121:151,1
		//!SMAP!1000000:1089,1
	}
}
