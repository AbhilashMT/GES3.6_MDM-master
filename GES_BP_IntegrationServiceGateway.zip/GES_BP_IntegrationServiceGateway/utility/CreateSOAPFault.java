package utility;
public class CreateSOAPFault {
	public static commonj.sdo.DataObject createSOAPFault(commonj.sdo.DataObject Input_Fault, commonj.sdo.DataObject Input_Body) {
		java.lang.String __result__2 = "faultstring";
		java.lang.String __result__3 = " An Internal Error Occurred while processing the request ";
		Input_Fault.setString(__result__2, __result__3);
		java.lang.String __result__7 = "http://aig.us.com/ges/services/LocationExposureServiceV3";
		java.lang.String faultcode = __result__7;
		java.lang.String __result__6 = "faultcode";
		Input_Fault.set(__result__6, faultcode);
		java.lang.String __result__12 = "faultactor";
		java.lang.String __result__13 = "http://aig.us.com/ges/services/LocationExposureServiceV3";
		Input_Fault.set(__result__12, __result__13);
		java.lang.String __result__16 = "detail";
		Input_Fault.set(__result__16, Input_Body);
		return Input_Fault;
	}
}