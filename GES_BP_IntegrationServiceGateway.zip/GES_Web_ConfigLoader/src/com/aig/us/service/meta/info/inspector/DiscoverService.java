package com.aig.us.service.meta.info.inspector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class DiscoverService
 */
public class DiscoverService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DiscoverService() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#getServletConfig()
	 */
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpURLConnection connection = null;
		int code = 0;
		InputStream is = null;
		try {

			String weatherService = "https://ftwldscimw129.r1-core.r1.aig.net:46600/GES_BP_LocationScrubbingProcess_v3_1_0Web/sca/JMSUtils_WSExp?WSDL";

			URL u = new URL(weatherService);
			connection = (HttpURLConnection) u.openConnection();
			connection.setRequestMethod("GET");
			connection.setReadTimeout(10000);
			connection.setConnectTimeout(10000);
			code = connection.getResponseCode();
			

			if (code != HttpURLConnection.HTTP_OK) {

				System.out.println("\t" + " EndPoint " + weatherService
						+ " Is UNAVAILABLE " + "Http Error Code is : " + code
						+ " Error Message is : "
						+ connection.getResponseMessage() + "\n");

			} else {
				System.out.println("\t" + " EndPoint " + weatherService
						+ " Is AVAILABLE \n");
				InputStreamReader in = new InputStreamReader(
						(InputStream) connection.getInputStream());
				BufferedReader buff = new BufferedReader(in);
				StringBuffer wsdlContentBuffer = new StringBuffer();

				String line;
				while ((line = buff.readLine()) != null) {
					wsdlContentBuffer.append(line);
				}
				// String responseMsg = connection.getResponseMessage();
			
				response.setContentType("text/xml; charset=UTF-8");
				PrintWriter writer = response.getWriter();
				String wsdlContent = wsdlContentBuffer.toString();
				//System.out.println(wsdlContent);
				writer.println( wsdlContent );

			}
		} finally {
			if (is != null) {
				is.close();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
