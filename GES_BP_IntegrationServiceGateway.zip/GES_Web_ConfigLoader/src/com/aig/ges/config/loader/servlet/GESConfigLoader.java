package com.aig.ges.config.loader.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.aig.us.ges.cache.utils.LatLongPriorityConfigLoader;
import com.ibm.websphere.cache.DistributedMap;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.common.utils.AsyncTaskExecutor;
import com.us.chartisinsurance.ges.common.utils.AsyncTaskExecutorImpl;
import com.us.chartisinsurance.ges.dynamicendpoints.ServiceGatewayXMLConfig;
import com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig;
import com.us.chartisinsurance.ges.dynamicendpoints.DynamicServiceGatewayConfig;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import com.us.chartisinsurance.ges.logger.SetupUtilLogger;

/**
 * Servlet implementation class GESConfigLoader
 */
public class GESConfigLoader extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final GESLoggerV4 GESConfigLoaderLogger = GESLoggerFactory
			.getLogger();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GESConfigLoader() {
		super();

		SetupUtilLogger.setupUtilLogger();

	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("GESLogger Initialized");

		// Set up Cache First

		// Load All Partners

		// Load all COnfig Parameters
		GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
				GESConfigLoader.class.getName(), "init", GESConfigLoader.class
						.getSimpleName(), "GESLogger Initialized",
				java.util.logging.Level.INFO);

		boolean cacheSetup = GESCacheLoader.setUpCache();

		if (cacheSetup) {
			GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
					GESConfigLoader.class.getName(), "init",
					GESConfigLoader.class.getSimpleName(),
					"IprepareConfig Initialization complete",
					java.util.logging.Level.INFO);
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents",
							java.util.logging.Level.INFO);

			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_BATCHSIZE
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_BATCHSIZE),
							java.util.logging.Level.INFO);

			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_INITIALFETCH
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_INITIALFETCH),
							java.util.logging.Level.INFO);
			;
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_ISALGENABLED
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_ISALGENABLED),
							java.util.logging.Level.INFO);
			;
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_ISBURSTMODE
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_ISBURSTMODE),
							java.util.logging.Level.INFO);

			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_ISSEQUENCED
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_ISSEQUENCED),
							java.util.logging.Level.INFO);

			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_MAXFETCH
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_MAXFETCH),
							java.util.logging.Level.INFO);

			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.SCRUBBING_ISMDMENABLED
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.SCRUBBING_ISMDMENABLED),
							java.util.logging.Level.INFO);

		}

		XMLConfig.loadAllPartners();

		try {
			ServiceGatewayXMLConfig.prepareConfig();
			// DynamicServiceGatewayConfig.prepareConfig();
			LatLongPriorityConfigLoader.prepareConfig();
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.GES_GATEWAY_CONFIG
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.GES_GATEWAY_CONFIG),
							java.util.logging.Level.INFO);
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"init",
							GESConfigLoader.class.getSimpleName(),
							"IprepareConfig Initialization complete , Verifying Cache Contents , Property : "
									+ GESConstantBundle.GES_REVIVED_GATEWAY
									+ " Value in Cache : "
									+ GESCacheLoader
											.getValueFromCache(GESConstantBundle.GES_REVIVED_GATEWAY),
							java.util.logging.Level.INFO);
		} catch (Exception e) {

			GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
					GESConfigLoader.class.getName(), "init",
					GESConfigLoader.class.getSimpleName(),
					"Unable to initialize Configuration",
					java.util.logging.Level.SEVERE);
			throw new ServletException("Unable to initialize Configuration");
		}

		runTasks();

	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {

		SetupUtilLogger.destroyAllLoggers();

		AsyncTaskExecutor taskExecutor = AsyncTaskExecutorImpl.AsyncTaskExecutor;
		taskExecutor.cancelTask("mecheck");
		taskExecutor.cancelTask("logmonitor");
		taskExecutor.cancelTask("generic");
		taskExecutor.cancelTask("matchlogmonitor");
		System.out.println(" All Async Threads shutdown");

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		Enumeration<String> parameterNames = request.getParameterNames();

		while (parameterNames.hasMoreElements()) {
			String paramName = parameterNames.nextElement();
			pw.write(paramName + "\n");

			String[] paramValues = request.getParameterValues(paramName);

			for (int i = 0; i < paramValues.length; i++) {
				String paramValue = paramValues[i];
				pw.write("\t" + paramValue + "\n");
			}
		}

		String serviceName = request.getParameter("ServiceName");
		String environment = request.getParameter("Env");
		String operationName = request.getParameter("OperationName");

		if (StringUtils.isEmpty(serviceName)
				|| StringUtils.isBlank(serviceName)
				|| StringUtils.isEmpty(environment)
				|| StringUtils.isBlank(environment)
				|| StringUtils.isEmpty(operationName)
				|| StringUtils.isBlank(operationName)) {
			pw
					.write("ServiceName is Mandatory , Proper Usage : "
							+ "<br/>"
							+ "<TRANSPORT>://<HOST_NAME>:<PORT>/<CONTEXT_ROOT>/<SERVLET_NAME>?ServiceName=<SERVICE_NAME>&Env=<ENV>&OperationName=<OPERATION_NAME>");
		} else {
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"HTTP - doGet Update Interaction Specification to CORE / WBIFC",
							GESConfigLoader.class.getSimpleName(),
							"Supplied Params : " + "ServiceName : "
									+ serviceName + " Environment : "
									+ environment + " OperationName : "
									+ operationName,
							java.util.logging.Level.INFO);

		}

		String ispec = request.getParameter("ispec");
		String notify = request.getParameter("notify");

		String getCache = request.getParameter("getCache");

		String cleanLogs = request.getParameter("cleanLogs");

		if (null != ispec) {
			GESConfigLoaderLogger
					.logCategory(
							LogCategory.CONFIG,
							GESConfigLoader.class.getName(),
							"HTTP - doGet Update Interaction Specification to CORE / WBIFC",
							GESConfigLoader.class.getSimpleName(),
							"Request Received : Parameter : ispec " + ispec,
							java.util.logging.Level.INFO);

			System.setProperty("ispec", ispec);
			pw.println(" Ispec Property Set to : "
					+ System.getProperty("ispec"));
		}
		if (null != notify) {
			GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
					GESConfigLoader.class.getName(),
					"HTTP - doGet - Enable Notification", GESConfigLoader.class
							.getSimpleName(),
					"Request Received : Parameter : notify" + notify,
					java.util.logging.Level.INFO);

			System.setProperty("ispec", notify);
			pw.println(" Email Notification Enabled ? : "
					+ System.getProperty("notify"));
		}

		if (null != getCache) {
			GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
					GESConfigLoader.class.getName(), "HTTP - doGet - getCache",
					GESConfigLoader.class.getSimpleName(),
					"Request Received : Parameter : getCache",
					java.util.logging.Level.INFO);

			StringBuffer cacheBuffer = new StringBuffer();
			DistributedMap gesCache = GESCacheLoader.gesdbCache;

			Set keySet = gesCache.keySet();

			Iterator keyIterator = keySet.iterator();
			String htmlPrefix = "<html><body>";

			String htmlSuffix = "</body></html>";
			cacheBuffer.append(htmlPrefix
					+ "<table><tr><td>Key</td><td>Value</td></tr>");
			while (keyIterator.hasNext()) {

				String key = keyIterator.next().toString();
				String keyValue = (null != gesCache.get(key) ? gesCache
						.get(key).toString() : "");
				cacheBuffer.append("<tr><td>" + key + "</td><td> " + keyValue
						+ "</td></tr>");
			}
			cacheBuffer.append("</table>" + htmlSuffix);

			pw.write(cacheBuffer.toString());

		}

		if (null != cleanLogs) {
		}

		GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
				GESConfigLoader.class.getName(), "HTTP - doGet - getCache",
				GESConfigLoader.class.getSimpleName(),
				"Request Received : Parameter : cleanLogs , Log Files Cleared",
				java.util.logging.Level.INFO);

		pw.close();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected String handleHttpRequestParam(String aServiceName,
			String aOperationName, String aEnvironment) {
		GESConfigLoaderLogger.logCategory(LogCategory.CONFIG,
				GESConfigLoader.class.getName(), "handleHttpRequestParam",
				GESConfigLoader.class.getSimpleName(),
				"Request Received : Parameters : <" + aServiceName + ">," + "<"
						+ aOperationName + ">," + "<" + aEnvironment + ">",
				java.util.logging.Level.INFO);

		return "";
	}

	private void runTasks() {
		AsyncTaskExecutor taskExecutor = AsyncTaskExecutorImpl.AsyncTaskExecutor;

		taskExecutor.runTask("mecheck");
		taskExecutor.runTask("logmonitor");
		taskExecutor.runTask("generic");
		taskExecutor.runTask("matchlogmonitor");
		System.out.println(" All Tasks Activated ");
	}
}
