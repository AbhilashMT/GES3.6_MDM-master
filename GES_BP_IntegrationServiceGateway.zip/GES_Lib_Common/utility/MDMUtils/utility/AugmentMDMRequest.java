package utility.MDMUtils.utility;
public class AugmentMDMRequest {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject augmentMDMRequest(commonj.sdo.DataObject sovLocation, com.ibm.websphere.sibx.smobo.ServiceMessageObject inputSMO) {
		boolean __result__1 = null != sovLocation;
		if (__result__1){
			boolean __result__4 = null != sovLocation.getDataObject("physicalObject");
			if (__result__4){
				boolean __result__7 = null != sovLocation.getDataObject("physicalObject").getDataObject("graspInfo");
				if (__result__7){
					commonj.sdo.DataObject __result__10 = sovLocation.getDataObject("physicalObject").getDataObject("graspInfo");
					commonj.sdo.DataObject graspInfoDO = __result__10;
					java.lang.String __result__13 = "body";
					commonj.sdo.DataObject __result__14 = inputSMO.getDataObject(__result__13);
					byte __result__15 = 0;
					commonj.sdo.DataObject __result__16 = __result__14.getDataObject(__result__15);
					commonj.sdo.DataObject MDMBO = __result__16;
					java.lang.String __result__19 = "request";
					commonj.sdo.DataObject __result__20 = MDMBO.getDataObject(__result__19);
					commonj.sdo.DataObject MDMRequest = __result__20;
					boolean __result__22 = MDMRequest.getList("SecondaryModifier").isEmpty();
					if (__result__22){
						java.util.ArrayList __result__25 = new java.util.ArrayList();
						MDMRequest.set("SecondaryModifier", __result__25);
					}
					else{
					}
					boolean __result__28 = MDMRequest.getList("LocationHazard").isEmpty();
					if (__result__28){
						java.util.ArrayList __result__31 = new java.util.ArrayList();
						MDMRequest.set("LocationHazard", __result__31);
					}
					else{
					}
					boolean __result__35 = null != graspInfoDO.getString("floodZnWithinPropLn");
					if (__result__35){
						java.util.List __result__38 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__39 = graspInfoDO.getString("floodZnWithinPropLn");
						java.lang.String __result__40 = "-";
						java.lang.String __result__41;
						{// append text
							__result__41 = __result__39.concat(__result__40);
						}
						java.lang.String __result__42 = "Flood Zone within Property Line";
						java.lang.String __result__43;
						{// append text
							__result__43 = __result__41.concat(__result__42);
						}
						commonj.sdo.DataObject __result__44 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__42, __result__43);
						boolean __result__45 = __result__38.add(__result__44);
					}
					else{
					}
					boolean __result__34 = null != graspInfoDO.getString("surgeXpsr");
					if (__result__34){
						java.util.List __result__49 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__50 = graspInfoDO.getString("surgeXpsr");
						java.lang.String __result__51 = "-";
						java.lang.String __result__52;
						{// append text
							__result__52 = __result__50.concat(__result__51);
						}
						java.lang.String __result__53 = "Surge Exposure";
						java.lang.String __result__54;
						{// append text
							__result__54 = __result__52.concat(__result__53);
						}
						commonj.sdo.DataObject __result__55 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__53, __result__54);
						boolean __result__56 = __result__49.add(__result__55);
					}
					else{
					}
					boolean __result__58 = null != graspInfoDO.getString("floodZn1000ftFromPropLn");
					if (__result__58){
						java.util.List __result__61 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__62 = graspInfoDO.getString("floodZn1000ftFromPropLn");
						java.lang.String __result__63 = "-";
						java.lang.String __result__64;
						{// append text
							__result__64 = __result__62.concat(__result__63);
						}
						java.lang.String __result__65 = "Flood Zone 1000 ft. from Property Line";
						java.lang.String __result__66;
						{// append text
							__result__66 = __result__64.concat(__result__65);
						}
						commonj.sdo.DataObject __result__67 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__65, __result__66);
						boolean __result__68 = __result__61.add(__result__67);
					}
					else{
					}
					boolean __result__70 = null != graspInfoDO.getString("hailstormXpsr");
					if (__result__70){
						java.util.List __result__73 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__74 = graspInfoDO.getString("hailstormXpsr");
						java.lang.String __result__75 = "-";
						java.lang.String __result__76;
						{// append text
							__result__76 = __result__74.concat(__result__75);
						}
						java.lang.String __result__77 = "Hailstorm Exposure";
						java.lang.String __result__78;
						{// append text
							__result__78 = __result__76.concat(__result__77);
						}
						commonj.sdo.DataObject __result__79 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__77, __result__78);
						boolean __result__80 = __result__73.add(__result__79);
					}
					else{
					}
					boolean __result__82 = null != graspInfoDO.getString("snowLodXpsr");
					if (__result__82){
						java.util.List __result__85 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__86 = graspInfoDO.getString("snowLodXpsr");
						java.lang.String __result__87 = "-";
						java.lang.String __result__88;
						{// append text
							__result__88 = __result__86.concat(__result__87);
						}
						java.lang.String __result__89 = "Snow Load Exposure";
						java.lang.String __result__90;
						{// append text
							__result__90 = __result__88.concat(__result__89);
						}
						commonj.sdo.DataObject __result__91 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__89, __result__90);
						boolean __result__92 = __result__85.add(__result__91);
					}
					else{
					}
					boolean __result__94 = null != graspInfoDO.getString("othCatXpsr");
					if (__result__94){
						java.util.List __result__97 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__98 = graspInfoDO.getString("othCatXpsr");
						java.lang.String __result__99 = "-";
						java.lang.String __result__100;
						{// append text
							__result__100 = __result__98.concat(__result__99);
						}
						java.lang.String __result__101 = "Other CAT Exposure";
						java.lang.String __result__102;
						{// append text
							__result__102 = __result__100.concat(__result__101);
						}
						commonj.sdo.DataObject __result__103 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__101, __result__102);
						boolean __result__104 = __result__97.add(__result__103);
					}
					else{
					}
					boolean __result__106 = null != graspInfoDO.getString("fireIndx");
					if (__result__106){
						java.util.List __result__109 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__110 = graspInfoDO.getString("fireIndx");
						java.lang.String __result__111 = "-";
						java.lang.String __result__112;
						{// append text
							__result__112 = __result__110.concat(__result__111);
						}
						java.lang.String __result__113 = "Fire Index";
						java.lang.String __result__114;
						{// append text
							__result__114 = __result__112.concat(__result__113);
						}
						commonj.sdo.DataObject __result__115 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__113, __result__114);
						boolean __result__116 = __result__109.add(__result__115);
					}
					else{
					}
					boolean __result__118 = null != graspInfoDO.getString("xplosnIndx");
					if (__result__118){
						java.util.List __result__121 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__122 = graspInfoDO.getString("xplosnIndx");
						java.lang.String __result__123 = "-";
						java.lang.String __result__124;
						{// append text
							__result__124 = __result__122.concat(__result__123);
						}
						java.lang.String __result__125 = "Explosion Index";
						java.lang.String __result__126;
						{// append text
							__result__126 = __result__124.concat(__result__125);
						}
						commonj.sdo.DataObject __result__127 = utility.MDMUtils.utility.PopulateMDMLocationHazards.populateMDMLocationHazards(__result__125, __result__126);
						boolean __result__128 = __result__121.add(__result__127);
					}
					else{
					}
					boolean __result__130 = null != graspInfoDO.getBigDecimal("ovrlHeRtg");
					if (__result__130){
						java.util.List __result__133 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__134 = "Overall HE Rating";
						java.lang.String __result__135 = graspInfoDO.getBigDecimal("ovrlHeRtg").toString();
						commonj.sdo.DataObject __result__136 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__134, __result__135);
						boolean __result__137 = __result__133.add(__result__136);
					}
					else{
					}
					boolean __result__139 = null != graspInfoDO.getBigDecimal("locRskRtgFire");
					if (__result__139){
						java.util.List __result__142 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__143 = "Location Risk Rating Score (Fire)";
						java.lang.String __result__144 = graspInfoDO.getBigDecimal("locRskRtgFire").toString();
						commonj.sdo.DataObject __result__145 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__143, __result__144);
						boolean __result__146 = __result__142.add(__result__145);
					}
					else{
					}
					boolean __result__150 = null != graspInfoDO.getBigDecimal("locRskRtgCat");
					if (__result__150){
						java.util.List __result__153 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__154 = "Location Risk Rating Score (CAT)";
						java.lang.String __result__155 = graspInfoDO.getBigDecimal("locRskRtgCat").toString();
						commonj.sdo.DataObject __result__156 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__154, __result__155);
						boolean __result__157 = __result__153.add(__result__156);
					}
					else{
					}
					boolean __result__159 = null != graspInfoDO.getBigDecimal("locRskRtgCompst");
					if (__result__159){
						java.util.List __result__162 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__163 = "Location Risk Rating Score (Composite)";
						java.lang.String __result__164 = graspInfoDO.getBigDecimal("locRskRtgCompst").toString();
						commonj.sdo.DataObject __result__165 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__163, __result__164);
						boolean __result__166 = __result__162.add(__result__165);
					}
					else{
					}
					boolean __result__168 = null != graspInfoDO.getBigDecimal("surgeTtlLe");
					if (__result__168){
						java.util.List __result__171 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__172 = "Surge Total LE";
						java.lang.String __result__173 = graspInfoDO.getBigDecimal("surgeTtlLe").toString();
						commonj.sdo.DataObject __result__174 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__172, __result__173);
						boolean __result__175 = __result__171.add(__result__174);
					}
					else{
					}
					boolean __result__177 = null != graspInfoDO.getBigDecimal("floodTtlLe100Yr");
					if (__result__177){
						java.util.List __result__180 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__181 = "Flood Total LE (100 year)";
						java.lang.String __result__182 = graspInfoDO.getBigDecimal("floodTtlLe100Yr").toString();
						commonj.sdo.DataObject __result__183 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__181, __result__182);
						boolean __result__184 = __result__180.add(__result__183);
					}
					else{
					}
					boolean __result__186 = null != graspInfoDO.getBigDecimal("floodTtlLe500Yr");
					if (__result__186){
						java.util.List __result__189 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__190 = "Flood Total LE (500 year)";
						java.lang.String __result__191 = graspInfoDO.getBigDecimal("floodTtlLe500Yr").toString();
						commonj.sdo.DataObject __result__192 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__190, __result__191);
						boolean __result__193 = __result__189.add(__result__192);
					}
					else{
					}
					boolean __result__195 = null != graspInfoDO.getBigDecimal("wndTtlLe100Yr");
					if (__result__195){
						java.util.List __result__198 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__199 = "100 Year Wind LE";
						java.lang.String __result__200 = graspInfoDO.getBigDecimal("wndTtlLe100Yr").toString();
						commonj.sdo.DataObject __result__201 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__199, __result__200);
						boolean __result__202 = __result__198.add(__result__201);
					}
					else{
					}
					boolean __result__204 = null != graspInfoDO.getString("wndTtlLe500Yr");
					if (__result__204){
						java.util.List __result__207 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__208 = "500 Year Wind LE";
						java.lang.String __result__209 = graspInfoDO.getString("wndTtlLe500Yr").toString();
						commonj.sdo.DataObject __result__210 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__208, __result__209);
						boolean __result__211 = __result__207.add(__result__210);
					}
					else{
					}
					boolean __result__213 = null != graspInfoDO.getBigDecimal("eqLe");
					if (__result__213){
						java.util.List __result__216 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__217 = "EQ LE";
						java.lang.String __result__218 = graspInfoDO.getBigDecimal("eqLe").toString();
						commonj.sdo.DataObject __result__219 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__217, __result__218);
						boolean __result__220 = __result__216.add(__result__219);
					}
					else{
					}
					boolean __result__222 = null != graspInfoDO.getBigDecimal("floodTtlMfl");
					if (__result__222){
						java.util.List __result__225 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__226 = "Flood Total MFL";
						java.lang.String __result__227 = graspInfoDO.getBigDecimal("floodTtlMfl").toString();
						commonj.sdo.DataObject __result__228 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__226, __result__227);
						boolean __result__229 = __result__225.add(__result__228);
					}
					else{
					}
					boolean __result__231 = null != graspInfoDO.getBigDecimal("wndTtlNle");
					if (__result__231){
						java.util.List __result__234 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__235 = "Wind NLE";
						java.lang.String __result__236 = graspInfoDO.getBigDecimal("wndTtlNle").toString();
						commonj.sdo.DataObject __result__237 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__235, __result__236);
						boolean __result__238 = __result__234.add(__result__237);
					}
					else{
					}
					boolean __result__240 = null != graspInfoDO.getBigDecimal("ttlMfl");
					if (__result__240){
						java.util.List __result__243 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__244 = "Total MFL";
						java.lang.String __result__245 = graspInfoDO.getBigDecimal("ttlMfl").toString();
						commonj.sdo.DataObject __result__246 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__244, __result__245);
						boolean __result__247 = __result__243.add(__result__246);
					}
					else{
					}
					boolean __result__249 = null != graspInfoDO.getBigDecimal("ttlEml");
					if (__result__249){
						java.util.List __result__252 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__253 = "Total EML";
						java.lang.String __result__254 = graspInfoDO.getBigDecimal("ttlEml").toString();
						commonj.sdo.DataObject __result__255 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__253, __result__254);
						boolean __result__256 = __result__252.add(__result__255);
					}
					else{
					}
					boolean __result__258 = null != graspInfoDO.getBigDecimal("ttlPml");
					if (__result__258){
						java.util.List __result__261 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__262 = "Total PML";
						java.lang.String __result__263 = graspInfoDO.getBigDecimal("ttlPml").toString();
						commonj.sdo.DataObject __result__264 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__262, __result__263);
						boolean __result__265 = __result__261.add(__result__264);
					}
					else{
					}
					boolean __result__267 = null != graspInfoDO.getBigDecimal("ttlMas");
					if (__result__267){
						java.util.List __result__270 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__271 = "Total MAS";
						java.lang.String __result__272 = graspInfoDO.getBigDecimal("ttlMas").toString();
						commonj.sdo.DataObject __result__273 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__271, __result__272);
						boolean __result__274 = __result__270.add(__result__273);
					}
					else{
					}
					boolean __result__276 = null != graspInfoDO.getBigDecimal("ttlNle");
					if (__result__276){
						java.util.List __result__279 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__280 = "Total NLE";
						java.lang.String __result__281 = graspInfoDO.getBigDecimal("ttlNle").toString();
						commonj.sdo.DataObject __result__282 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__280, __result__281);
						boolean __result__283 = __result__279.add(__result__282);
					}
					else{
					}
					boolean __result__285 = null != graspInfoDO.getBigDecimal("floodTtlLe");
					if (__result__285){
						java.util.List __result__288 = MDMRequest.getList("LocationHazard");
						java.lang.String __result__289 = "Flood Total LE (Immediately Adjacent)";
						java.lang.String __result__290 = graspInfoDO.getBigDecimal("floodTtlLe").toString();
						commonj.sdo.DataObject __result__291 = utility.MDMUtils.utility.PopulateMDMLocationHazardValueTxt.populateMDMLocationHazardValueTxt(__result__289, __result__290);
						boolean __result__292 = __result__288.add(__result__291);
					}
					else{
					}
					boolean __result__294 = null != graspInfoDO.getString("xplosnRskAdqtlyEngnred");
					if (__result__294){
						java.util.List __result__297 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__298 = "Explosion Risk Adequately Engineered?";
						java.lang.String __result__299 = graspInfoDO.getString("xplosnRskAdqtlyEngnred");
						commonj.sdo.DataObject __result__300 = utility.MDMUtils.utility.PopulateMDMSecondaryModifierValueTxt.populateMDMSecondaryModifierValueTxt(__result__298, __result__299);
						boolean __result__301 = __result__297.add(__result__300);
					}
					else{
					}
					boolean __result__303 = null != graspInfoDO.getBigDecimal("adqtAutmtcSprnklrsPct");
					if (__result__303){
						java.util.List __result__306 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__307 = "% Automatic Sprinklers Adequate";
						java.lang.String __result__308 = graspInfoDO.getBigDecimal("adqtAutmtcSprnklrsPct").toString();
						commonj.sdo.DataObject __result__309 = utility.MDMUtils.utility.PopulateMDMSecondaryModifierValueTxt.populateMDMSecondaryModifierValueTxt(__result__307, __result__308);
						boolean __result__310 = __result__306.add(__result__309);
					}
					else{
					}
					boolean __result__312 = null != graspInfoDO.getBigDecimal("neededAutmtcSprnklrsPct");
					if (__result__312){
						java.util.List __result__315 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__316 = "% Automatic Sprinklers Needed";
						java.lang.String __result__317 = graspInfoDO.getBigDecimal("neededAutmtcSprnklrsPct").toString();
						commonj.sdo.DataObject __result__318 = utility.MDMUtils.utility.PopulateMDMSecondaryModifierValueTxt.populateMDMSecondaryModifierValueTxt(__result__316, __result__317);
						boolean __result__319 = __result__315.add(__result__318);
					}
					else{
					}
					boolean __result__321 = null != graspInfoDO.getString("fldDesktpAsesd");
					if (__result__321){
						java.util.List __result__324 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__325 = graspInfoDO.getString("fldDesktpAsesd");
						java.lang.String __result__326 = "-";
						java.lang.String __result__327;
						{// append text
							__result__327 = __result__325.concat(__result__326);
						}
						java.lang.String __result__328 = "Field/Desktop Assessed?";
						java.lang.String __result__329;
						{// append text
							__result__329 = __result__327.concat(__result__328);
						}
						commonj.sdo.DataObject __result__330 = utility.MDMUtils.utility.PopulateMDMSecondaryModifier.populateMDMSecondaryModifier(__result__328, __result__329);
						boolean __result__331 = __result__324.add(__result__330);
					}
					else{
					}
					boolean __result__333 = null != graspInfoDO.getString("engnrgSrc");
					if (__result__333){
						java.util.List __result__336 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__337 = graspInfoDO.getString("engnrgSrc");
						java.lang.String __result__338 = "-";
						java.lang.String __result__339;
						{// append text
							__result__339 = __result__337.concat(__result__338);
						}
						java.lang.String __result__340 = "Engineering Source";
						java.lang.String __result__341;
						{// append text
							__result__341 = __result__339.concat(__result__340);
						}
						commonj.sdo.DataObject __result__342 = utility.MDMUtils.utility.PopulateMDMSecondaryModifier.populateMDMSecondaryModifier(__result__340, __result__341);
						boolean __result__343 = __result__336.add(__result__342);
					}
					else{
					}
					boolean __result__345 = null != graspInfoDO.getString("predominantConstrnCls");
					if (__result__345){
						java.util.List __result__348 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__349 = graspInfoDO.getString("predominantConstrnCls");
						java.lang.String __result__350 = "-";
						java.lang.String __result__351;
						{// append text
							__result__351 = __result__349.concat(__result__350);
						}
						java.lang.String __result__352 = "Predominant Construction Class";
						java.lang.String __result__353;
						{// append text
							__result__353 = __result__351.concat(__result__352);
						}
						commonj.sdo.DataObject __result__354 = utility.MDMUtils.utility.PopulateMDMSecondaryModifier.populateMDMSecondaryModifier(__result__352, __result__353);
						boolean __result__355 = __result__348.add(__result__354);
					}
					else{
					}
					boolean __result__357 = null != graspInfoDO.getString("predominantPrtctnCls");
					if (__result__357){
						java.util.List __result__360 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__361 = graspInfoDO.getString("predominantPrtctnCls");
						java.lang.String __result__362 = "-";
						java.lang.String __result__363;
						{// append text
							__result__363 = __result__361.concat(__result__362);
						}
						java.lang.String __result__364 = "Predominant Protection Class";
						java.lang.String __result__365;
						{// append text
							__result__365 = __result__363.concat(__result__364);
						}
						commonj.sdo.DataObject __result__366 = utility.MDMUtils.utility.PopulateMDMSecondaryModifier.populateMDMSecondaryModifier(__result__364, __result__365);
						boolean __result__367 = __result__360.add(__result__366);
					}
					else{
					}
					boolean __result__369 = null != graspInfoDO.getBigDecimal("autmtcSprnklrsPct");
					if (__result__369){
						java.util.List __result__372 = MDMRequest.getList("SecondaryModifier");
						java.lang.String __result__373 = "% Automatic Sprinklers";
						java.lang.String __result__374 = graspInfoDO.getBigDecimal("autmtcSprnklrsPct").toString();
						commonj.sdo.DataObject __result__375 = utility.MDMUtils.utility.PopulateMDMSecondaryModifierValueTxt.populateMDMSecondaryModifierValueTxt(__result__373, __result__374);
						boolean __result__376 = __result__372.add(__result__375);
					}
					else{
					}
					java.lang.String __result__149 = "body";
					commonj.sdo.DataObject __result__378 = inputSMO.getDataObject(__result__149);
					byte __result__379 = 0;
					commonj.sdo.DataObject __result__380 = __result__378.getDataObject(__result__379);
					java.lang.String __result__381 = "request";
					__result__380.setDataObject(__result__381, MDMRequest);
				}
				else{
				}
			}
			else{
			}
		}
		else{
		}
		return inputSMO;
	}
}