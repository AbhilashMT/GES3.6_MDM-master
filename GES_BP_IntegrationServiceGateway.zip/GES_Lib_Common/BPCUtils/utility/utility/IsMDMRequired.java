package BPCUtils.utility.utility;
public class IsMDMRequired {
	public static java.lang.Boolean isMDMRequired(commonj.sdo.DataObject Location) {
		boolean __result__2 = false;
		boolean MDMIngestion = __result__2;
		boolean __result__1 = null != Location;
		if (__result__1){
			java.lang.String __result__7 = "sovLocation";
			boolean __result__8 = Location.isSet(__result__7);
			if (__result__8){
				commonj.sdo.DataObject __result__11 = Location.getDataObject("sovLocation");
				commonj.sdo.DataObject sovLocation = __result__11;
				boolean __result__13 = com.us.chartisinsurance.ges.common.utils.ScrubbingAIModule.isMDMRequired(sovLocation);
				MDMIngestion = __result__13;
			}
			else{
			}
		}
		else{
		}
		return new java.lang.Boolean(MDMIngestion);
	}
}