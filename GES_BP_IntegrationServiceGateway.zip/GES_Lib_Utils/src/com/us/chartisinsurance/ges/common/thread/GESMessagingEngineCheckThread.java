/**
 * 
 */
package com.us.chartisinsurance.ges.common.thread;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.cache.DistributedMap;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.common.utils.VerifySIBus;

/**
 * @author M1019070
 * 
 */
public class GESMessagingEngineCheckThread implements Runnable {

	/**
	 * 
	 */

	public GESMessagingEngineCheckThread() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		DistributedMap gesDbCache = GESCacheLoader.getDbCache();

		if (null != gesDbCache) {

			boolean checkME = Boolean.valueOf(gesDbCache.get(
					GESConstantBundle.GES_ME_CHECK).toString());

			if (checkME) {
				VerifySIBus.checkMEBus();
			}
		}

	}

	/**
	 * @param args
	 */

}
