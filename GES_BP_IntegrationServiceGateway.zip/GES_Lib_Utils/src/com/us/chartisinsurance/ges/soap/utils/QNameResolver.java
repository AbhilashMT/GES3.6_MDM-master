/**
 * 
 */
package com.us.chartisinsurance.ges.soap.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;

/**
 * @author Asurendr
 * 
 */

public class QNameResolver {

	private static final String CONFIGURATION_FILE = "AIGGES_QNames.xml";
	private static XMLConfiguration xmlConfig;
	private static boolean _localPropertiesRead = false;
	private static final String ModuleXPath = "Module";
	private static final String FilterPrefix = "[@name = \"";
	private static final String FilterSuffix = "\"]";
	private static final String OperationXpath = "/OperationName";

	private static final String QNameXPath = "/QName";

	private static final String FaultNameXpath = "/FaultName";
	private static final String outputMessageNameXpath = "/OutputMessageName";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static synchronized String getQName(String aModuleName,
			String aOperationName) {

		String QNameResolved = "";

		if (!_localPropertiesRead) {
			try {
				readProperties();

			} catch (ConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (null != xmlConfig) {
			String QName = xmlConfig
					.getString(ModuleXPath + FilterPrefix + aModuleName
							+ FilterSuffix + OperationXpath + FilterPrefix
							+ aOperationName + FilterSuffix + QNameXPath);
			if (null != QName) {
				QNameResolved = QName;
			}
		}
		return QNameResolved;
	}

	public static synchronized String getFaultName(String aModuleName,
			String aOperationName) {

		String FaultNameResolved = "";

		if (!_localPropertiesRead) {
			try {
				readProperties();

			} catch (ConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (null != xmlConfig) {
			String FaultName = xmlConfig.getString(ModuleXPath + FilterPrefix
					+ aModuleName + FilterSuffix + OperationXpath
					+ FilterPrefix + aOperationName + FilterSuffix
					+ FaultNameXpath);
			if (null != FaultName) {
				FaultNameResolved = FaultName;
			}
		}
		return FaultNameResolved;
	}

	public static synchronized String getOutputName(String aModuleName,
			String aOperationName) {

		String outputMsgNameResolved = "";
		if (!_localPropertiesRead) {
			try {
				readProperties();

			} catch (ConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (null != xmlConfig) {
			String outputMsgName = xmlConfig.getString(ModuleXPath
					+ FilterPrefix + aModuleName + FilterSuffix
					+ OperationXpath + FilterPrefix + aOperationName
					+ FilterSuffix + outputMessageNameXpath);
			if (null != outputMsgName) {
				outputMsgNameResolved = outputMsgName;
			}
		}
		return outputMsgNameResolved;
	}

	static synchronized void readProperties() throws IOException,
			ConfigurationException {
		InputStream is = null;
		is = (InputStream) SOAPActionConfig.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/soap/utils/"

				+ CONFIGURATION_FILE);
	
		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfig = new XMLConfiguration();
			xmlConfig.load(reader);
			xmlConfig.setExpressionEngine(new XPathExpressionEngine());

		

			_localPropertiesRead = true;

			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}

	}

}
