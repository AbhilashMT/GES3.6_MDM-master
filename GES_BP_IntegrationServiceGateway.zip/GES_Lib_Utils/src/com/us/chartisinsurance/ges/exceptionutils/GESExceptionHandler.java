/**
 * 
 */
package com.us.chartisinsurance.ges.exceptionutils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;

import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;

/**
 * @author SVarghes
 * 
 */
public class GESExceptionHandler {

	/**
	 * @param args
	 */

	private static final String CONFIGURATION_FILE = "ChartisExceptionRepository.xml";
	private static XMLConfiguration exceptionConfig = null;
	private static boolean _propertiesRead = false;
	private static GESLoggerV4 GESExceptionHandlerLogger = GESLoggerFactory.getLogger();

	static {
		InputStream is = null;

		is = (InputStream) GESExceptionHandler.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/exceptionutils/"
						+ CONFIGURATION_FILE);

		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			exceptionConfig = new XMLConfiguration();
			try {
				exceptionConfig.load(reader);
				exceptionConfig
						.setExpressionEngine(new XPathExpressionEngine());

				set_propertiesRead(true);

				if (null != reader || null != is) {
					try {
						reader.close();
						is.close();
					} catch (IOException e) {

						e.printStackTrace();
					}

				}
			} catch (ConfigurationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

	public static void main(String[] args) {
		try {

			
		} catch (Exception e) {

			e.printStackTrace();
		}
		getErrorDesc("GES-SYS-U1O12010E1", "XMLConfig", "getURIE1");
	}

	public static String formatException(String aExcepCode,
			String aExcepMessage, String aModuleName, String aOperationName) {
		GESExceptionHandlerLogger.entering(GESExceptionHandler.class.getName(),
				"formatException", GESExceptionHandler.class.getName(),
				"Entering");

		StringBuffer formattedMessageBuilder = new StringBuffer(255);

		String errorMessage = getErrorDesc(aExcepCode, aModuleName,
				aOperationName);

		String formattedMessage = formattedMessageBuilder.append(
				aExcepCode + ":" + errorMessage).toString();
		GESExceptionHandlerLogger.exiting(GESExceptionHandler.class.getName(),
				"formatException", GESExceptionHandler.class.getName(),
				"Formatted Error Message : " + formattedMessage);

		return formattedMessage;
	}

	private static String getErrorDesc(String excepCode, String moduleName,
			String operationName) {
		GESExceptionHandlerLogger.entering(GESExceptionHandler.class.getName(),
				"getErrorDesc", GESExceptionHandler.class.getName(),
				"Get the Error Description Based on the Code : " + excepCode);

		String errorDesc = "System Error , Please contact support team ";

		if (null != exceptionConfig) {

			String xpath1 = "ModuleExcep[@moduleName=" + "\"" + moduleName
					+ "\"" + "]";
			String xpath2 = "/operationExcep[@operationName=" + "\""
					+ operationName + "\"" + "]";

			String xpath3 = "/errors[errorCode=" + "\"" + excepCode + "\""
					+ "]";

			String xpath4 = "/errorDesc";

			GESExceptionHandler.GESExceptionHandlerLogger.logInfo(
					GESExceptionHandler.class.getName(), "getErrorDesc",
					GESExceptionHandler.class.getName(), "XPATH : " + xpath1
							+ xpath2 + xpath3 + xpath4);
			GESExceptionHandlerLogger.logInfo(GESExceptionHandler.class
					.getName(), "getErrorDesc", GESExceptionHandler.class
					.getName(),
					" Error Description to be derived from XPATH : " + xpath1
							+ xpath2 + xpath3 + xpath4);

			try {
				errorDesc = (String) exceptionConfig.getString(xpath1 + xpath2
						+ xpath3 + xpath4);
				GESExceptionHandlerLogger.logInfo(GESExceptionHandler.class
						.getName(), "getErrorDesc", GESExceptionHandler.class
						.getName(), " Error Description Based on the Code : {"
						+ excepCode + "}" + " is : " + errorDesc);
			} catch (Exception e) {
				e.printStackTrace();
				
			}

		}
		GESExceptionHandlerLogger.exiting(GESExceptionHandler.class.getName(),
				"getErrorDesc", GESExceptionHandler.class.getName(),
				" Error Description Based on the Code : {" + excepCode + "}"
						+ " is : " + errorDesc);
		return errorDesc;
	}

	// static synchronized void readLocalProperties()
	// throws ConfigurationException {
	//
	// InputStream is = null;
	//
	// is = (InputStream) GESExceptionHandler.class
	// .getResourceAsStream("/com/us/chartisinsurance/ges/exceptionutils/"
	// + CONFIGURATION_FILE);
	//
	// if (null != is) {
	// InputStreamReader reader = new InputStreamReader(is);
	// exceptionConfig = new XMLConfiguration();
	// exceptionConfig.load(reader);
	// exceptionConfig.setExpressionEngine(new XPathExpressionEngine());
	//
	// set_propertiesRead(true);
	//
	// if (null != reader || null != is) {
	// try {
	// reader.close();
	// is.close();
	// } catch (IOException e) {
	//
	// e.printStackTrace();
	// }
	//
	// }
	//
	// }
	//
	// }

	public static void set_propertiesRead(boolean _propertiesRead) {
		GESExceptionHandler._propertiesRead = _propertiesRead;
	}

	public static boolean is_propertiesRead() {
		return _propertiesRead;
	}

}
