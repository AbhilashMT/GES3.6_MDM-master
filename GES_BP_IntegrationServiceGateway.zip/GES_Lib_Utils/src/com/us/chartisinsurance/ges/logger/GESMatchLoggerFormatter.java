/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 * @author Asurendr
 * 
 */
public class GESMatchLoggerFormatter extends Formatter {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.logging.Formatter#format(java.util.logging.LogRecord)
	 */

	private static com.us.chartisinsurance.ges.logger.GESMatchLoggerFormatter formatter;

	public static Formatter getGESMatchLoggerFormatter() {

		if (null == formatter) {
			formatter = new com.us.chartisinsurance.ges.logger.GESMatchLoggerFormatter();
		}
		return formatter;
	}

	@Override
	public String format(LogRecord record) {

		StringBuffer sb = new StringBuffer();

		sb.append(record.getMessage());
		sb.append("\n");

		return sb.toString();

	}

}
