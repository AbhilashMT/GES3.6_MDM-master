package com.us.chartisinsurance.ges.logger;

public interface ScrubbingStatus {

	public static final String COMPLETED = "COMPLETED";
	public static final String INPROGRESS = "INPROGRESS";
	public static final String FAILED = "FAILED";
	public static final String UNKNOWN = "UNKNOWN";
}
