/**
 * 
 */
package com.us.chartisinsurance.ges.gateway.constants;

/**
 * @author ASurendr
 * 
 */
public interface GESGatewayConstants {

	static final String LocationEngineeringUpdatesRequest = "LocationEngineeringUpdatesRequest";
	static final String DiscardLocationsRequest = "DiscardLocationsRequest";
	static final String ASYNCOPERATIONNAME = "requestOnly";
	static final String SYNCOPERATIONNAME = "requestResponse";
	static final String ReceiveUpdatesRequest = "receiveLocationUpdatesRequest";

}
