package utility;
public class ConstructSMOMessage {
	public static commonj.sdo.DataObject constructSMOMessage(java.lang.String WSDLURI, java.lang.String MessageName, java.lang.String PartnerName, java.lang.String MethodName, commonj.sdo.DataObject InputDO) {
		commonj.sdo.DataObject __result__3;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(WSDLURI, MessageName));
			__result__3 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject SMOBody = __result__3;
		com.ibm.websphere.sca.ServiceManager __result__5 = com.ibm.websphere.sca.ServiceManager.INSTANCE;
		java.lang.Object __result__7 = __result__5.locateService(PartnerName);
		com.ibm.websphere.sca.Service TargetService = (com.ibm.websphere.sca.Service)__result__7;
		com.ibm.websphere.sca.scdl.Reference __result__9 = TargetService.getReference();
		com.ibm.websphere.sca.scdl.Reference SCAReference = __result__9;
		com.ibm.websphere.sca.scdl.OperationType __result__12 = SCAReference.getOperationType(MethodName);
		commonj.sdo.Type __result__13 = ((com.ibm.wsspi.sca.scdl.OperationType)__result__12).getInputType();
		commonj.sdo.Type InputType = __result__13;
		com.ibm.websphere.sca.scdl.OperationType OperationType = __result__12;
		boolean __result__17 = OperationType.isWrapperType(InputType);
		if (__result__17){
			byte __result__21 = 0;
			commonj.sdo.DataObject __result__22 = SMOBody.createDataObject(__result__21);
			byte __result__23 = 0;
			__result__22.setDataObject(__result__23, InputDO);
		}
		else{
			byte __result__28 = 0;
			SMOBody.setDataObject(__result__28, InputDO);
		}
		return SMOBody;
	}
}