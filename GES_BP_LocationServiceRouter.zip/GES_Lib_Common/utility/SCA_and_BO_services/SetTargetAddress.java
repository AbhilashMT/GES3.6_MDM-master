package utility.SCA_and_BO_services;
public class SetTargetAddress {
	public static void setTargetAddress(com.ibm.websphere.sibx.smobo.ServiceMessageObject smo, java.lang.String targetURI) {
		com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory __result__1 = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
		com.ibm.websphere.sibx.smobo.TargetAddressType __result__2 = __result__1.createTargetAddressType();
		com.ibm.websphere.sibx.smobo.TargetAddressType TargetAddressType = __result__2;
		java.lang.String __result__5 = ";";
		java.lang.String __result__6 = org.apache.commons.lang3.StringUtils.substringBefore(targetURI, __result__5);
		TargetAddressType.setAddress(__result__6);
		smo.getHeaders().getSMOHeader().setTarget(TargetAddressType);
		java.lang.String __result__10 = org.apache.commons.lang3.StringUtils.substringAfter(targetURI, __result__5);
		java.lang.String AlternateTargetAddresses = __result__10;
		java.lang.String[] __result__12 = org.apache.commons.lang3.StringUtils.split(AlternateTargetAddresses, __result__5);
		java.lang.String[] TargetURIStringArray = __result__12;
		java.util.List __result__15 = java.util.Arrays.asList(TargetURIStringArray);
		java.util.List TargetURIList = __result__15;
		java.util.Iterator iter17 = TargetURIList.iterator();
		while(iter17.hasNext()){
			java.lang.String TargetURIString = (java.lang.String)iter17.next();
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory __result__19 = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.TargetAddressType __result__20 = __result__19.createTargetAddressType();
			com.ibm.websphere.sibx.smobo.TargetAddressType LTargetAddressType = __result__20;
			LTargetAddressType.setAddress(TargetURIString);
			java.util.List __result__24 = smo.getHeaders().getSMOHeader().getAlternateTarget();
			boolean __result__26 = __result__24.add(LTargetAddressType);
		}
	}
}