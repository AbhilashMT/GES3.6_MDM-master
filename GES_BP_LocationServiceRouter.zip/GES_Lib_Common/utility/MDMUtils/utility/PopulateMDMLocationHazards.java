package utility.MDMUtils.utility;
public class PopulateMDMLocationHazards {
	public static commonj.sdo.DataObject populateMDMLocationHazards(java.lang.String locationHazardName, java.lang.String locationHazardValue) {
		commonj.sdo.DataObject __result__1;
		{// create LocationHazard
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__1 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","LocationHazard");
		}
		commonj.sdo.DataObject LocationHazard_1 = __result__1;
		commonj.sdo.DataObject __result__3;
		{// create XCdHazardCategoryTP
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__3 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","XCdHazardCategoryTP");
		}
		commonj.sdo.DataObject LocNameBO1 = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create XCdHazardTP
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","XCdHazardTP");
		}
		commonj.sdo.DataObject LocValueBO1 = __result__5;
		LocNameBO1.setString("value", locationHazardName);
		LocValueBO1.setString("value", locationHazardValue);
		LocationHazard_1.set("LocationHazardName", LocNameBO1);
		LocationHazard_1.set("LocationHazard", LocValueBO1);
		return LocationHazard_1;
	}
}