package com.us.chartisinsurance.ges.soap.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;

public class SOAPActionConfig {

	private static final String CONFIGURATION_FILE = "Chartis_SoapActions.xml";
	private static XMLConfiguration xmlConfig;
	private static boolean _localPropertiesRead = false;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			readProperties();
			getDerivedSoapAction("");
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static synchronized String getDerivedSoapAction(String httpSoapAction) {
		String derivedSoapAction = "";

		if (!_localPropertiesRead) {
			try {
				readProperties();

			} catch (ConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if (null != xmlConfig) {
			derivedSoapAction = xmlConfig
					.getString("soapAction[qualifiedSoapAction=\""
							+ httpSoapAction + "\"]/derivedSoapAction");
			
		}
		return derivedSoapAction;
	}

	static synchronized void readProperties() throws IOException,
			ConfigurationException {
		InputStream is = null;
		is = (InputStream) SOAPActionConfig.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/soap/utils/"

				+ CONFIGURATION_FILE);
		
		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfig = new XMLConfiguration();
			xmlConfig.load(reader);
			xmlConfig.setExpressionEngine(new XPathExpressionEngine());

			

			_localPropertiesRead = true;

			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}

	}
}
