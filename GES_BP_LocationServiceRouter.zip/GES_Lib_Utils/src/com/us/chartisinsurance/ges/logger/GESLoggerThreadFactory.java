/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.util.concurrent.ThreadFactory;

/**
 * @author ASurendr
 * 
 */
public class GESLoggerThreadFactory implements ThreadFactory {

	/**
	 * @param args
	 */

	private String prefix = "";
	private int count = 0;

	/**
	 * @param prefix
	 */
	public GESLoggerThreadFactory(String prefix) {
		super();
		this.prefix = prefix;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		

	
	}

	@Override
	public Thread newThread(Runnable r) {
		// TODO Auto-generated method stub

		return new Thread(r, prefix + "-" + count++);
	}

}
