/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import commonj.sdo.DataObject;

/**
 * @author Asurendr
 * 
 */
public class GESAuditImpl {

	/**
	 * @param args
	 */

	public static final GESLoggerV4 logger = GESLoggerFactory.getLogger();
	public static final BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	public static final String CLASSNAME = GESAuditImpl.class.getName();
	public static final String CLASSNAMESHORT = GESAuditImpl.class
			.getSimpleName();

	public static Service DBService = (Service) ServiceManager.INSTANCE
			.locateService("DBServicePartner");

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void auditLog(DataObject aAuditDO, String aAuditStat,
			boolean isUpdate) {

		logger.logFinest(CLASSNAME, "auditLog", CLASSNAMESHORT,
				"Audit Request with Status :  " + aAuditStat + "is Update ? "
						+ isUpdate, aAuditDO);

		DBService.invoke("insertAuditMessage", aAuditDO);

		logger.logFinest(CLASSNAME, "auditLog", CLASSNAMESHORT,
				"Audit Complete ");

	}
}
