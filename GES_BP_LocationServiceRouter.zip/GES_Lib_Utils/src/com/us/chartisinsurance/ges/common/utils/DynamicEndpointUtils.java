/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;

import com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints;
import com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import commonj.sdo.DataObject;

/**
 * @author Abhilash
 * 
 */
public class DynamicEndpointUtils {

	private static XMLConfiguration xmlConfig = null;

	/**
	 * 
	 */
	public DynamicEndpointUtils() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		buildEndpointXpath("TEST", "TEST", "");

	}

	private static void getDynamicEndpointConfig() {

		xmlConfig = XMLConfig.getDynamicEndpointConfig();
		xmlConfig.setExpressionEngine(new XPathExpressionEngine());
	}

	public static String updateXMLConfig(String aModuleName,
			String aPartnerName, String aEnv, String aVersion,
			String aValToUpdate) {
		String result = "NO updates perfomed for : " + aPartnerName;

		

		

		return result;
	}

	public static DataObject updateXMLConfig(DataObject aDobj) throws Exception {
		GESLoggerFactory.getLogger().entering(
				DynamicEndpointUtils.class.getSimpleName(),
				DynamicEndpointUtils.class.getSimpleName(), "updateXMLConfig",
				" Request for Endpoint change", aDobj);
		String moduleName = aDobj.getString("moduleName");

		boolean moduleNameSet = aDobj.isSet("moduleName");
		String aPartnerName = aDobj.getString("partnerName");
		String aEnv = aDobj.getString("env");
		String aVersion = aDobj.getString("version");
		String aValueToUpdate = aDobj.get("updatedEndpoint").toString();
		String xPath = "";
		String keyToEndPoint = "";
		getDynamicEndpointConfig();
		if (null != moduleName & moduleNameSet) {

		
			aDobj.set("orgnlEndPoint", ReferenceEndPoints.getEndPoint(
					moduleName, aPartnerName, aVersion));
			/**
			 * Changed below code on 04-12-2014
			 */
			// String result = updateEndpointProperty(xPath, aValueToUpdate);
			keyToEndPoint = moduleName + "_" + aPartnerName;
			ReferenceEndPoints.setEndPoint(keyToEndPoint, aVersion,
					aValueToUpdate);
			aDobj.set("updatedEndpoint", ReferenceEndPoints.getEndPoint(
					moduleName, aPartnerName, aVersion));

		} else {

			throw new Exception(" Module Name not Provided in Request ");

		}
		
		aDobj.setString("hostName", MetaInfo.getHostName());

		return aDobj;
	}

	private static String buildEndpointXpath(String aModuleName,
			String aPartnerName, String aEnv, String aVersion) {
		String xPathResult = "";

		if (null != aModuleName && !("".equalsIgnoreCase(aModuleName))) {
		

			String moduleNameXpath = "moduleNames/moduleName" + "[" + "name=\""
					+ aModuleName + "\"" + "]";
			String partnerXpath = "/wsImport" + "[" + "partnerName=\""
					+ aPartnerName + "\"" + "]";
			String endpointXpath = "/endpointRef" + "[" + "@env=\"" + aEnv
					+ "\"" + "]";
			String versionXpath = "/version" + "[" + "@value=\"" + aVersion
					+ "\"" + "]";
			xPathResult = moduleNameXpath + partnerXpath + endpointXpath
					+ versionXpath;

		} else {
			xPathResult = buildEndpointXpath(aPartnerName, aEnv, aVersion);
		}

		return xPathResult;
	}

	

	

	public static String getEndpointProperty(String aModuleName,
			String aPartnerName, String aEnv, String aVersion) {
		String updatedProperty = "";

		getDynamicEndpointConfig();
		if (null != xmlConfig) {
			String aXpathToEval = buildEndpointXpath(aModuleName, aPartnerName,
					aEnv, aVersion);

			updatedProperty = xmlConfig.getString(aXpathToEval);

		}
		return updatedProperty;
	}

	public static String getAnyEndpointProperties(String aPartnerName,
			String aEnv, String aVersion) {
		String updatedProperty = "";

		getDynamicEndpointConfig();
		if (null != xmlConfig) {
			String aXpathToEval = buildEndpointXpath(aPartnerName, aEnv,
					aVersion);

			updatedProperty = xmlConfig.getString(aXpathToEval);

	

		}
		return updatedProperty;
	}

	private static String buildEndpointXpath(String aPartnerName, String aEnv,
			String aVersion) {
		String partnerXpath = "";

		if (null != aPartnerName && !("".equalsIgnoreCase(aPartnerName))) {
		

			partnerXpath = "//wsImport[partnerName=\"" + aPartnerName
					+ "\"]/endpointRef[@env=\"" + aEnv + "\"]/version";
			

		}

		return partnerXpath;
	}

}
