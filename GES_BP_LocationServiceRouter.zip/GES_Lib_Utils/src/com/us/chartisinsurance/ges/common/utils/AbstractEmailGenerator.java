/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Asurendr
 * 
 */
public abstract class AbstractEmailGenerator {

	/**
	 * 
	 */

	private final static String EMAIL_HOST = "usmxrelay.aig.com";

	private final static String EMAIL_SMTP_PORT = "25";
	public static String env = System.getProperty("env");

	public AbstractEmailGenerator() {
		// TODO Auto-generated constructor stub
	}

	public static Date getCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat(
				"yyyy/MM/dd 'T' HH:mm:ss Z");
		Calendar cal = Calendar.getInstance();
		Date currDate = cal.getTime();
		String currentDate = dateFormat.format(cal.getTime());
		
		return currDate;
	}

	private class Authenticator extends javax.mail.Authenticator {
		private PasswordAuthentication authentication;

		public Authenticator() {
			String username = "ASurendr";
			String password = "Welcome567";
			authentication = new PasswordAuthentication(username, password);
		}

		protected PasswordAuthentication getPasswordAuthentication() {
			return authentication;
		}

	}

	public Session getSession() {
		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
		// "getSession()",
		// aMediationComponentName, "Obtain Email Session", Level.INFO);
		Authenticator authenticator = new Authenticator();
		Session session = null;
		// env = "local";
		Properties props = new Properties();
		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
		// "getSession()",
		// aMediationComponentName, "Environmeynt is " + env, Level.INFO);
		if ("local".equalsIgnoreCase(env)) {

			props.setProperty("mail.smtp.submitter", authenticator
					.getPasswordAuthentication().getUserName());
			props.setProperty("mail.smtp.auth", "true");
			//props.put("mail.smtp.host", "10.235.0.133");
			props.put("mail.smtp.host", "10.32.8.7");
			props.put("mail.smtp.port", "25");
			props.put("mail.debug", "false");
			props.put("mail.transport.protocol", "smtp");

			session = Session.getInstance(props, authenticator);
			//session = Session.getInstance(props);

		} else {
			props.put("mail.smtp.host", EMAIL_HOST);
			props.put("mail.smtp.port", EMAIL_SMTP_PORT);
			props.put("mail.debug", "false");
			props.put("mail.transport.protocol", "smtp");
			session = Session.getInstance(props);
		}

		// props.put("mail.user", user);

		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
		// "getSession()",
		// aMediationComponentName, "Obtain Email Session", Level.INFO);

		return session;
	}

	public static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}

	

	public String getFileAsString(String aFileName) {
		InputStream is = null;
		String responseContent = "";
		is = (InputStream) EMAILTaskExecutor.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/common/utils/"
						+ aFileName);

		if (null != is) {

			InputStreamReader reader = new InputStreamReader(is);
			responseContent = getStringFromInputStream(is);

			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}
		return responseContent;
	}

	public String transformXMLtoHtml(String aXMLString, String aXSLSource) {
		String htmlString = "";
		try {
			Source xsltSource = new StreamSource(new StringReader(aXSLSource));
			Source xmlSource = new StreamSource(new StringReader(aXMLString));
			TransformerFactory txFactory = TransformerFactory.newInstance();
			// Templates cachedTemplate = txFactory.newTemplates(xsltSource);
			Transformer xslTransformer = txFactory.newTransformer(xsltSource);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			StreamResult xsltResult = new StreamResult(baos);
			xslTransformer.transform(xmlSource, xsltResult);

			htmlString = new String(((ByteArrayOutputStream) xsltResult
					.getOutputStream()).toByteArray());

		
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return htmlString;
	}

	public String[] getQualifiedAddress(String csvAddressesHolder) {

		String[] qualifiedAddress = StringUtils.split(csvAddressesHolder, ",");

		return qualifiedAddress;
	}
}
