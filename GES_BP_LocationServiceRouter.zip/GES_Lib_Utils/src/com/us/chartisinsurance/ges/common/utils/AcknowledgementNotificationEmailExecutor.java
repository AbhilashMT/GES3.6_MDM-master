package com.us.chartisinsurance.ges.common.utils;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.lang.StringUtils;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import commonj.sdo.DataObject;

public class AcknowledgementNotificationEmailExecutor extends
		AbstractEmailGenerator {

	private final static String ACKNWXSL = "FailureNotification.xsl";
	public final static String env = System.getProperty("env");

	public AcknowledgementNotificationEmailExecutor() {

	}

	public boolean sendGraspNotification(DataObject aDobj, String rfsID,
			String attachment) {
		// TODO Auto-generated method stub
		String aXSLSource = getFileAsString(ACKNWXSL);
		String aXMLString = GESLoggerFactory.getLogger().dataObjectToString(
				aDobj, "FailureMessages");
		String htmlString = transformXMLtoHtml(aXMLString, aXSLSource);

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		String derivedAddress = GESCacheLoader.getDbCache().get(
				GESConstantBundle.GRASP_NOTIFY_ADDR).toString();
		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();
				String[] toAddress = getQualifiedAddress(derivedAddress);
				simpleMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}

				simpleMessage
						.setSubject("GES WBI Notification : GRASP Acknowledgement for  RFS processed : "
								+ rfsID
								+ "Region:"
								+ StringUtils.upperCase(env));

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");
				// Added for attachments
				String attachmentFileName = "RFSRequest" + rfsID.substring(26)
						+ ".txt";
				Multipart multipart = new MimeMultipart("mixed");
				MimeBodyPart messagePart = new MimeBodyPart();

				if (null != htmlString) {

					messagePart.setContent(htmlString, "text/html");

					multipart.addBodyPart(messagePart);

					// Code added now
					String zipName = "RFSTriageRequest_RFS"
							+ rfsID.substring(26) + ".zip";
					// File attachFile = new File(zipName);

					try {

						FileOutputStream out = new FileOutputStream(zipName);

						ZipOutputStream zipOutput = new ZipOutputStream(out);
						ZipEntry e = new ZipEntry(attachmentFileName);
						zipOutput.putNextEntry(e);
						byte[] data = attachment.getBytes();
						out.write(data, 0, data.length);
						out.close();
						MimeBodyPart attachmentPart = new MimeBodyPart();
						DataSource source = new FileDataSource(zipName);
						attachmentPart.setDataHandler(new DataHandler(source));
						attachmentPart.setFileName(zipName);

						// adding Text File to the attachment

						FileOutputStream outText = new FileOutputStream(
								attachmentFileName);
						byte[] datatext = attachment.getBytes();
						outText.write(datatext, 0, datatext.length);
						outText.close();
						MimeBodyPart textPart = new MimeBodyPart();
						DataSource sourceText = new FileDataSource(
								attachmentFileName);
						textPart.setDataHandler(new DataHandler(sourceText));
						textPart.setFileName(attachmentFileName);

						// multipart.addBodyPart(attachmentPart);
						multipart.addBodyPart(textPart);

						simpleMessage.setContent(multipart);

					} catch (IOException e) {
						// TODO Auto-generated catch block

						e.printStackTrace();
					}

				}
				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public boolean sendGraspNotification(String successMessage, String rfsID) {
		// TODO Auto-generated method stub

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		String derivedAddress = GESCacheLoader.getDbCache().get(
				GESConstantBundle.GRASP_NOTIFY_ADDR).toString();
		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();
				String[] toAddress = getQualifiedAddress(derivedAddress);
				simpleMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}

				simpleMessage
						.setSubject("GES WBI Notification : GRASP Acknowledgement for processed RFS : "
								+ rfsID
								+ "Region:"
								+ StringUtils.upperCase(env));

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");

				if (null != successMessage) {

					simpleMessage.setContent(successMessage + rfsID,
							"text/html");
				}
				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	// fOR TESTING PURPOSE

	public boolean sendGraspNotification(String htmlString, String rfsID,
			String attachment) {
		// TODO Auto-generated method stub
		// String aXSLSource = getFileAsString(ACKNWXSL);
		// String aXMLString = GESLoggerFactory.getLogger().dataObjectToString(
		// aDobj, "FailureMessages");
		// String htmlString = transformXMLtoHtml(aXMLString, aXSLSource);

		Session mailSession = getSession();
		MimeMessage mimeMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		String derivedAddress = "varulmal@adc.mindtree.com";
		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();
				String[] toAddress = getQualifiedAddress(derivedAddress);
				mimeMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					mimeMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}

				mimeMessage
						.setSubject("GES WBI Notification : GRASP Acknowledgement for processed RFS : "
								+ rfsID
								+ "Region:"
								+ StringUtils.upperCase(env));

				mimeMessage.setSentDate(getCurrentDate());

				mimeMessage.setHeader("X-Priority", "1");
				// Added for attachments
				String attachmentFileName = rfsID + ".txt";
				Multipart multipart = new MimeMultipart("mixed");
				MimeBodyPart messagePart = new MimeBodyPart();

				if (null != htmlString) {

					messagePart.setContent(htmlString, "text/plain");

					multipart.addBodyPart(messagePart);

					String zipName = "RFSTriage_" + rfsID + ".zip";
					FileOutputStream fileOutStream = new FileOutputStream(
							zipName);
					ZipOutputStream zipOutputStream = new ZipOutputStream(
							fileOutStream);

					// File file = new File(attachmentFileName);

					ZipEntry entry = new ZipEntry(attachmentFileName);
					zipOutputStream.putNextEntry(entry);

					int length;
					if ((length = attachment.getBytes().length) >= 0) {
						zipOutputStream.write(attachment.getBytes(), 0, length);
					}

					// Code added now

					zipOutputStream.close();

					MimeBodyPart attachmentPart = new MimeBodyPart();
					DataSource source = new FileDataSource(zipName);
					attachmentPart.setDataHandler(new DataHandler(source));
					attachmentPart.setFileName(zipName);

					multipart.addBodyPart(attachmentPart);
					mimeMessage.setContent(multipart);

				}
				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = mimeMessage.getAllRecipients();

					transport.sendMessage(mimeMessage, address);

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public static void main(String args[]) {

	}

	public boolean sendEventNotification(String aMessage, String EventId,
			String EventType, String EventOperation, String ObjectKey) {
		// TODO Auto-generated method stub

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		String derivedAddress = GESCacheLoader.getDbCache().get(
				GESConstantBundle.GES_NOFIFY_SCRUBBINGADDR).toString();
		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();
				String[] toAddress = getQualifiedAddress(derivedAddress);
				simpleMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}

				simpleMessage
						.setSubject("GES WBI Notification : WPS Event Handled Event Id : "
								+ EventId
								+ " Region:"
								+ StringUtils.upperCase(env));

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");

				if (null != aMessage) {

					simpleMessage.setContent(aMessage + " Event Id :  "
							+ EventId + " Event Type : " + EventType + " Id : "
							+ ObjectKey + " OperationType : " + EventOperation,
							"text/html");
				}
				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
