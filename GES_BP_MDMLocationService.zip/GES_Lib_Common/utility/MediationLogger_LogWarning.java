package utility;
public class MediationLogger_LogWarning {
	public static void mediationLogger_LogWarning(com.ibm.wsspi.sibx.mediation.esb.SCAServices SCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MediationServices, java.lang.String inputMessage, commonj.sdo.DataObject dataObject)throws com.ibm.websphere.sca.ServiceRuntimeException  {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = SCAServices.getModuleName();
		java.lang.String __result__5 = MediationServices.getMediationName();
		java.lang.String __result__7 = MediationServices.getMediationDisplayName();
		__result__1.logWarning(__result__3, __result__5, __result__7, inputMessage, dataObject);
	}
}