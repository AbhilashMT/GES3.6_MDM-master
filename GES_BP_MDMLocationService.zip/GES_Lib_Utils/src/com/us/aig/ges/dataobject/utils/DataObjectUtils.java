/**
 * 
 */
package com.us.aig.ges.dataobject.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.emf.ecore.xmi.XMIResource;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOInstanceValidator;
import com.ibm.websphere.bo.BOXMLDocument;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import commonj.sdo.DataObject;
import commonj.sdo.Property;

/**
 * @author Abhilash
 * 
 */
public class DataObjectUtils {
	private static ServiceManager serviceManager = ServiceManager.INSTANCE;

	private static final BOInstanceValidator boValidator = (BOInstanceValidator) serviceManager
			.locateService("com/ibm/websphere/bo/BOInstanceValidator");

	private static BOFactory bof = (BOFactory) serviceManager
			.locateService("com/ibm/websphere/bo/BOFactory");

	private static final BOXMLSerializer serializer = (BOXMLSerializer) serviceManager
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");

	static GESLoggerV4 DataObjectUtilsLogger = GESLoggerFactory.getLogger();

	public static void validateDataObject(DataObject aDataObject)
			throws ServiceBusinessException {

		DataObjectUtilsLogger.entering(DataObjectUtils.class.getName(),
				"validateDataObject", DataObjectUtils.class.getName(),
				"Validate dataObject : ", aDataObject);
		ArrayList<DataObject> validationErrorList = new ArrayList<DataObject>();

		boolean validationResult = boValidator.validate(aDataObject,
				validationErrorList);
		DataObjectUtilsLogger.logInfo(DataObjectUtils.class.getName(),
				"validateDataObject", DataObjectUtils.class.getName(),
				"Is DataObject Valid ? : " + validationResult);

		if (!validationResult) {
			DataObject arrayOfGesFault = bof.create(
					"http://aig.us.com/ges/common/v3", "ArrayOfGESFault");
			ArrayList<DataObject> faultList = new ArrayList<DataObject>();

			for (DataObject errorBo : validationErrorList) {

				DataObject gesFaultObjType = bof
						.create("http://aig.us.com/ges/common/v3",
								"GesFaultObjectType");
				gesFaultObjType.setString("faultCode", "Invalid element : "
						+ errorBo.get("property"));
				gesFaultObjType.setString("faultString", errorBo.get("message")
						.toString());
				faultList.add(gesFaultObjType);

			}

			arrayOfGesFault.setList("gesFaults", faultList);
			DataObjectUtilsLogger.logSevere(DataObjectUtils.class.getName(),
					"validateDataObject", DataObjectUtils.class.getName(),
					"Containment Property failed basic validation  ? : "
							+ !validationResult + " error details captured \n",
					arrayOfGesFault);

			throw new ServiceBusinessException(arrayOfGesFault);

		}
	}

	public static DataObject stringToDataObject(String value) throws Exception {
		DataObject convertedDO = null;
		BOXMLSerializer boXMLSer = (BOXMLSerializer) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOXMLSerializer");
		if (value != null) {
			try {
				BOXMLDocument document = boXMLSer
						.readXMLDocument(new ByteArrayInputStream(value
								.getBytes("UTF-8")));
				convertedDO = document.getDataObject();
			} catch (Exception e) {
				
				throw new Exception();
			}
		} else {
			throw new Exception();
		}
		return convertedDO;

	}

	public static DataObject stringToDataObjectUnsetMode(String value)
			throws Exception {
		DataObjectUtilsLogger.entering(DataObjectUtils.class.getName(),
				"stringToDataObjectUnsetMode", DataObjectUtils.class.getName(),
				"In XML  " + value);
		DataObject convertedDO = null;
		DataObject unsetBO = null;

		if (value != null) {
			try {
				BOXMLDocument document = serializer
						.readXMLDocument(new ByteArrayInputStream(value
								.getBytes("UTF-8")));
				convertedDO = document.getDataObject();
				unsetBO = unSetProperties(convertedDO);
			} catch (Exception e) {
				
				throw new Exception();
			}
		} else {
			throw new Exception();
		}

		DataObjectUtilsLogger.exiting(DataObjectUtils.class.getName(),
				"stringToDataObjectUnsetMode", DataObjectUtils.class.getName(),
				"stringToDataObjectUnsetMode , DataObject Returned  ", unsetBO);
		return unsetBO;

	}

	private static DataObject unSetProperties(DataObject aDobj)
			throws Exception {

		DataObjectUtilsLogger.entering(DataObjectUtils.class.getName(),
				"unSetProperties", DataObjectUtils.class.getName(),
				"Unset dataObject : ", aDobj);
		if (null != aDobj) {

			List<Property> doProperties = aDobj.getInstanceProperties();

			try {
				for (Property boProp : doProperties) {

					DataObjectUtilsLogger.logInfo(DataObjectUtils.class
							.getName(), "unSetProperties",
							DataObjectUtils.class.getName(),
							"Inspect Property : " + boProp.getName());

					if (aDobj.isSet(boProp)) {
						if (!boProp.isContainment()) {
							DataObjectUtilsLogger.logInfo(DataObjectUtils.class
									.getName(), "unSetProperties",
									DataObjectUtils.class.getName(),
									"Property : " + boProp.getName()
											+ " is  simple and of Type : "
											+ boProp.getType().getName());
							if (StringUtils.isBlank(aDobj.get(boProp)
									.toString())
									|| StringUtils.isEmpty(aDobj.get(boProp)
											.toString())) {

								aDobj.unset(boProp);
							}

						}

						if (boProp.isContainment()) {
							DataObjectUtilsLogger.logInfo(DataObjectUtils.class
									.getName(), "unSetProperties",
									DataObjectUtils.class.getName(),
									"Property : " + boProp.getName()
											+ " is a DataObject");
							if (boProp.isMany()) {

								DataObjectUtilsLogger.logInfo(
										DataObjectUtils.class.getName(),
										"unSetProperties",
										DataObjectUtils.class.getName(),
										"Property : " + boProp.getName()
												+ " is Many");
								List<DataObject> listDo = aDobj.getList(boProp);

								for (DataObject dObj : listDo) {
									DataObjectUtilsLogger.logInfo(
											DataObjectUtils.class.getName(),
											"unSetProperties",
											DataObjectUtils.class.getName(),
											"Handling  : " + boProp.getName()
													+ " Instance ");

									unSetProperties(dObj);
								}
							} else {
								unSetProperties(aDobj.getDataObject(boProp));
							}

						}

						else {

						}
					}
				}
			} catch (Exception e) {

				DataObjectUtilsLogger.logSevere(
						DataObjectUtils.class.getName(), "unSetProperties",
						DataObjectUtils.class.getName(), "unSetProperties  "
								+ e.getMessage());

				throw e;
			}
		}

		DataObjectUtilsLogger.exiting(DataObjectUtils.class.getName(),
				"unSetProperties", DataObjectUtils.class.getName(),
				"Unset dataObject : ", aDobj);

		return aDobj;
	}

	public static String dataObjectToString(DataObject aDataObject,
			String aElementName) {

		DataObjectUtilsLogger.entering(DataObjectUtils.class.getName(),
				"DataObjectToString", DataObjectUtils.class.getName(),
				"Log Entering DO", aDataObject);

		String dataObjectString = null;
		if (null != aDataObject) {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				Map<Object, Object> options = new HashMap<Object, Object>();
				options.put(XMIResource.OPTION_FORMATTED, Boolean.FALSE);
				options.put(XMIResource.OPTION_DECLARE_XML, Boolean.FALSE);
				// options.put(XMIResource.OPTION_SKIP_ESCAPE, Boolean.TRUE);
				serializer.writeDataObjectWithOptions(aDataObject, aDataObject
						.getType().getURI(), aElementName, baos, options);
				dataObjectString = baos.toString("UTF-8");
			} catch (Exception ioe) {
				ioe.printStackTrace();
			}
		} else {
			dataObjectString = " DataObject is NULL ";
		}

		DataObjectUtilsLogger.exiting(DataObjectUtils.class.getName(),
				"DataObjectToString Exiting", DataObjectUtils.class.getName(),
				StringUtils.substring(dataObjectString, 10), aDataObject);

		return dataObjectString;
	}

	public static String dataObjectToStringAndRemoveXMLProlog(
			DataObject aDataObject, String aElementName) {

		String dataObjectString = null;
		if (null != aDataObject) {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {

				serializer.writeDataObject(aDataObject, aDataObject.getType()
						.getURI(), aElementName, baos);
				dataObjectString = baos.toString("UTF-8");
				String newLine = System.getProperty("line.separator");
				dataObjectString = dataObjectString.substring(dataObjectString
						.indexOf(newLine) + 1);
			} catch (Exception ioe) {
				ioe.printStackTrace();
			}

		} else {
			dataObjectString = " DataObject is NULL ";
		}
		return dataObjectString;
	}

	public static DataObject truncateHeaderFromResponse(DataObject inputBO) {
		if (inputBO != null) {
			if (inputBO.isSet(1)) {
				inputBO.unset(1);
			}
		}
		return inputBO;
	}



	public static String getEndpointURLWithReqParams(DataObject headers,
			String endpointURL) {
		if (null != headers) {
			if (headers.isSet("/headers/HTTPHeader/control/URL")) {
				String inputURL = headers
						.getString("/headers/HTTPHeader/control/URL");
				String reqParamsIdentifier = "?";
				String reqParams = "";

				if (inputURL.contains(reqParamsIdentifier)) {
					int paramsIndex = inputURL.indexOf(reqParamsIdentifier)
							+ reqParamsIdentifier.length();
					reqParams = inputURL.substring(paramsIndex);
					endpointURL = endpointURL + reqParamsIdentifier + reqParams;
					return endpointURL;
				}
			}
		}
		return null;
	}
	public static String exceptionToStringConverter(Exception ex)
	{
		StringWriter sw = new StringWriter();
		ex.printStackTrace(new PrintWriter(sw));
		String exceptionAsString = sw.toString();
		
		return exceptionAsString;
	}
}
