/**
 * 
 */
package com.us.chartisinsurance.ges.common.thread;

import java.util.concurrent.ThreadFactory;

/**
 * @author ASurendr
 * 
 */
public class GESThreadFactory implements ThreadFactory {

	/**
	 * @param args
	 */

	private String prefix = "";
	private int count = 0;

	/**
	 * @param prefix
	 */
	public GESThreadFactory(String prefix) {
		super();
		this.prefix = prefix;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public Thread newThread(Runnable r) {
		// TODO Auto-generated method stub

		return new Thread(r, prefix + "-" + count++);
	}

}
