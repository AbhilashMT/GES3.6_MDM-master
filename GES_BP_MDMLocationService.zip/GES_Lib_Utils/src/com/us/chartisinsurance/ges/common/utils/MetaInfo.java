/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

import com.us.chartisinsurance.ges.logger.GESLoggerFactory;

/**
 * @author ASurendr
 * 
 */
public class MetaInfo {

	/**
	 * @param args
	 */

	static MetaInfo metaInfo = null;

	private MetaInfo() {

	}

	public static MetaInfo getMetaInfo() {
		if (null == metaInfo) {
			metaInfo = new MetaInfo();
		}

		return metaInfo;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ClassLoader cl = MetaInfo.class.getClassLoader();

		URL[] urls = ((URLClassLoader) cl).getURLs();

		for (URL url : urls) {
			System.out.println(url.getFile());

			if (url.getFile().indexOf("GES_Schema_LibV1") != -1) {

				System.out.println("Obtained : " + url.getFile());
				break;
			}
		}

	}

	public String getversion() throws IOException {

		String LABEL_PREFIX = "============================================= \n\n";
		String LABEL_SUFFIX = "=============================================\n";

		ClassLoader clsLoad = this.getClass().getClassLoader();

		GESLoggerFactory.getLogger().logInfo(MetaInfo.class.getName(),
				"getVersion", MetaInfo.class.getName(), clsLoad.toString());

		Enumeration enumMf = clsLoad.getResources(JarFile.MANIFEST_NAME);

		while (enumMf.hasMoreElements()) {

			{
				URL url = (URL) enumMf.nextElement();
				// System.out.println(" URL IS : " + url.toString());

				if (url.toString().indexOf("GES_Lib_SchemaV2.jar") != -1) {

					InputStream is = url.openStream();
					if (null != is) {
						Manifest mf = new Manifest(is);
						Attributes attrs = mf.getMainAttributes();
						String LABEL = attrs.getValue("Implementation-Version");
						GESLoggerFactory.getLogger().logInfo(
								MetaInfo.class.getName(),
								"getVersion",
								MetaInfo.class.getName(),
								"\n" + LABEL_PREFIX + "\t\t\t"
										+ "VERSION LABEL : " + LABEL + "\n\n"
										+ LABEL_SUFFIX);
					}
				}
			}
		}

		
		return null;
	}

	public static String getHostName() {
		String hostName = "Unable to resolve";
		try {
			InetAddress iAddr = InetAddress.getLocalHost();

			hostName = iAddr.getHostName();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return hostName;

	}

	public static void setDeDupeLimit(String aDeDupeLimit) {
		if (null != aDeDupeLimit && aDeDupeLimit.length() != 0) {
			System.setProperty("DeDupeLimit", aDeDupeLimit);
		}
	}

	public static String getDeDupeLimit() {

		String limit = System.getProperty("DeDupeLimit");

		return limit;
	}

}
