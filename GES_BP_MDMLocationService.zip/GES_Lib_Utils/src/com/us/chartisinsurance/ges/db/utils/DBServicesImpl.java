/**
 * 
 */
package com.us.chartisinsurance.ges.db.utils;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;

import org.eclipse.emf.ecore.xmi.XMLResource;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.transformation.utils.TransformationUtils;
import commonj.sdo.DataObject;

/**
 * @author ASurendr
 * 
 */
public class DBServicesImpl {
	private static Service DBServicePartner;
	private static BOFactory bof;
	private static BOXMLSerializer boXMLse;
	private static final String XML_CHARSET = "UTF-8";

	static GESLoggerV4 DBServicesLogger =GESLoggerFactory.getLogger();
	static {
		DBServicePartner = (Service) ServiceManager.INSTANCE
				.locateService("DBServicePartner");
		bof = (BOFactory) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOFactory");
		boXMLse = (BOXMLSerializer) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOXMLSerializer");
	}

	public static void auditMessage(DataObject aSmo, String aMediationName,
			String aModuleName, String aMode) {

		DBServicesLogger.entering(DBServicesImpl.class.getName(),
				"auditMessage", DBServicesImpl.class.getName(),
				" Entering Audit Message", aSmo);

		if (null != DBServicePartner) {

			DataObject GexpdbaMsglogBO = bof
					.create("http://GES_Lib_DBArtefacts/bo",
							"AuditMessageRequest_Type");
			GexpdbaMsglogBO.set("mdul_nm", aModuleName);
			GexpdbaMsglogBO.set("mediation_nm", aMediationName);
			GexpdbaMsglogBO.set("msg_id", getMessageID(aSmo));
			GexpdbaMsglogBO.set("msg", dataObjectToStringPlain(aSmo));
			GexpdbaMsglogBO.set("lg_versn", aMode);
			GexpdbaMsglogBO.set("lg_ts", TransformationUtils.getCurrentTime());
			try {
				DBServicesLogger.logInfo(DBServicesImpl.class.getName(),
						"auditMessage", DBServicesImpl.class.getName(),
						" About to Invoke DataServices Partner",
						GexpdbaMsglogBO);
				DataObject Response = (DataObject) DBServicePartner.invoke(
						"insertAuditMessage", GexpdbaMsglogBO);
				DBServicesLogger.logInfo(DBServicesImpl.class.getName(),
						"auditMessage", DBServicesImpl.class.getName(),
						" Response from  DataServices Partner", Response);
			} catch (Exception e) {

				DBServicesLogger.logSevere(DBServicesImpl.class.getName(),
						"auditMessage", DBServicesImpl.class.getName(),
						"Exception Occurred Invoking Data Services Partner : "
								+ e.getMessage());

			}

		}

	}

	private static String getMessageID(DataObject aSmo) {
		String messageId = null;

		DataObject headersTypeDO = aSmo.getDataObject("headers");
		if (null != headersTypeDO) {
			DataObject SMOHeaderDO = headersTypeDO.getDataObject("SMOHeader");
			messageId = SMOHeaderDO.getString("MessageUUID");

		}
		return messageId;
	}

	private static String dataObjectToStringPlain(DataObject aDataObject) {

		String dataObjectString = null;
		if (null != aDataObject) {
			DataObject aBody = aDataObject.getDataObject("body");

			HashMap options = new HashMap();
			options.put(XMLResource.OPTION_FORMATTED, Boolean.FALSE);
			if (null != aBody) {

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				try {

					boXMLse
							.writeDataObjectWithOptions(aBody, aBody.getType()
									.getURI(), aBody.getType().getName(), baos,
									options);

					dataObjectString = baos.toString(XML_CHARSET);
				} catch (Exception ioe) {
					StringWriter writer = new StringWriter();
					ioe.printStackTrace(new PrintWriter(writer));
					dataObjectString = writer.toString();
				}

			}
		} else {
			dataObjectString = " DataObject is NULL ";
		}
		return dataObjectString;
	}
}
