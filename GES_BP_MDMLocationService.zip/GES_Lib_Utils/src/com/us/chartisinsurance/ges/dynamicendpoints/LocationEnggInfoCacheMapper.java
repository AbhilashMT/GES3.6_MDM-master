package com.us.chartisinsurance.ges.dynamicendpoints;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import commonj.sdo.DataObject;
import commonj.sdo.Property;

public class LocationEnggInfoCacheMapper {
	private static BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");;
	static GESLoggerV4 EnggLogger = GESLoggerFactory.getLogger();

	static final String CLASSNAME = LocationEnggInfoCacheMapper.class.getName();
	static final String CLASSNAMESHORT = LocationEnggInfoCacheMapper.class
			.getSimpleName();
	public static java.util.Properties UpdateLocDetailsisprop = new Properties();
	public static java.util.Properties GetLocationDetailsDetailsisprop = new Properties();
	public static String UpdateLocDetailsFileName = "/com/us/chartisinsurance/ges/dynamicendpoints/UpdateEngineeringMapper.properties";
	public static String GetLocationDetailsFileName = "/com/us/chartisinsurance/ges/dynamicendpoints/LocationEngineeringMapper.properties";

	public static InputStream UpdateLocDetailsis = LocationEnggInfoCacheMapper.class
			.getClassLoader().getResourceAsStream(UpdateLocDetailsFileName);

	public static InputStream GetLocationDetailsDetailsis = LocationEnggInfoCacheMapper.class
			.getClassLoader().getResourceAsStream(GetLocationDetailsFileName);
	static {

		if (null != UpdateLocDetailsis) {
			try {
				UpdateLocDetailsisprop.load(UpdateLocDetailsis);

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (null != GetLocationDetailsDetailsis) {
			try {
				GetLocationDetailsDetailsisprop
						.load(GetLocationDetailsDetailsis);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	public static String getUpdateElement(String input)
			throws FileNotFoundException {

		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "getUpdateElement",
				"Inside getUpdateElement Method");
		String result = "";
		result = UpdateLocDetailsisprop.getProperty(input);
		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "getUpdateElement",
				"Element name from property File is--->" + result);
		return result;
	}

	public static String getLocDetailsElement(String input)
			throws FileNotFoundException {

		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "getLocDetailsElement",
				"Inside getLocDetailsElement Method");
		String result = "";
		result = GetLocationDetailsDetailsisprop.getProperty(input);
		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "getLocDetailsElement",
				"Element name from property File is--->" + result);
		return result;
	}

	public static DataObject LocationEnggMapper(DataObject arrayofLochazard,
			DataObject locationSecMod, DataObject locationEnggInfo)
			throws FileNotFoundException {

		EnggLogger.entering(LocationEnggInfoCacheMapper.class.getName(),
				"LocationEnggMapper", LocationEnggInfoCacheMapper.class
						.getName(), " Entering Message--Hazards",
				arrayofLochazard);

		EnggLogger.entering(LocationEnggInfoCacheMapper.class.getName(),
				"LocationEnggMapper", LocationEnggInfoCacheMapper.class
						.getName(), " Entering Message--Secondary Modifiers",
				locationSecMod);

		EnggLogger.entering(LocationEnggInfoCacheMapper.class.getName(),
				"LocationEnggMapper", LocationEnggInfoCacheMapper.class
						.getName(),
				" Entering Message--LocationEngineeringInfo", locationEnggInfo);

		DataObject locEnggInfoDO = null;

		if (null != locationEnggInfo) {
			locEnggInfoDO = locationEnggInfo;
		} else {
			locEnggInfoDO = bof.create("http://aig.us.com/ges/grasp/ext/V1",
					"LocationEngineering_Type");
		}

		if (null != arrayofLochazard || null != locationSecMod) {

			EnggLogger.logInfo(LocationEnggInfoCacheMapper.class.getName(),
					"LocationEnggMapper", LocationEnggInfoCacheMapper.class
							.getName(),
					" Either of Hazard or SecondaryModidieres is Not Null");

			if (null != arrayofLochazard) {

				EnggLogger.logInfo(LocationEnggInfoCacheMapper.class.getName(),
						"LocationEnggMapper", LocationEnggInfoCacheMapper.class
								.getName(), " Hazard is Not Null");
				List<DataObject> lochazardList = arrayofLochazard
						.getList("LocationHazardType");
				if (!lochazardList.isEmpty()) {
					EnggLogger.logInfo(LocationEnggInfoCacheMapper.class
							.getName(), "LocationEnggMapper",
							LocationEnggInfoCacheMapper.class.getName(),
							" Hazard List is Not Empty");
					locEnggInfoDO = LocationHazardMapper(lochazardList,
							locEnggInfoDO);
				}
			}
			if (null != locationSecMod) {
				EnggLogger.logInfo(LocationEnggInfoCacheMapper.class.getName(),
						"LocationEnggMapper", LocationEnggInfoCacheMapper.class
								.getName(), "SecondaryModidieres is Not Null");
				List<DataObject> secModList = locationSecMod
						.getList("SecondaryModifier_Type");
				if (!secModList.isEmpty()) {
					EnggLogger.logInfo(LocationEnggInfoCacheMapper.class
							.getName(), "LocationEnggMapper",
							LocationEnggInfoCacheMapper.class.getName(),
							" Secondary Modidiers List is Not Empty");
					locEnggInfoDO = SecondaryModifierMapper(secModList,
							locEnggInfoDO);
				}
			}
		}

		return locEnggInfoDO;
	}

	public static DataObject UpdateLocEnggMapper(
			DataObject locationDetailContext, DataObject locationDetailsBody)
			throws FileNotFoundException {

		EnggLogger.entering(LocationEnggInfoCacheMapper.class.getName(),
				"UpdateLocEnggMapper", LocationEnggInfoCacheMapper.class
						.getName(), " Entering Message--Body",
				locationDetailsBody);

		EnggLogger.entering(LocationEnggInfoCacheMapper.class.getName(),
				"UpdateLocEnggMapper", LocationEnggInfoCacheMapper.class
						.getName(), " Entering Message--Context",
				locationDetailContext);

		if (null != locationDetailsBody && null != locationDetailContext) {

			List<DataObject> LocationDetailsListBody = locationDetailsBody
					.getList("LocationDetails");
			List<DataObject> LocationDetailsListContext = locationDetailContext
					.getList("LocationDetails");

			for (int i = 0; i < LocationDetailsListBody.size(); i++) {

				DataObject locDetailNew = LocationDetailsListBody.get(i);
				DataObject locDetailOld = LocationDetailsListContext.get(i);

				EnggLogger.logInfo(LocationEnggInfoCacheMapper.class.getName(),
						"UpdateLocEnggMapper",
						LocationEnggInfoCacheMapper.class.getName(),
						" Inside For Loop--Body", locDetailNew);

				EnggLogger.logInfo(LocationEnggInfoCacheMapper.class.getName(),
						"UpdateLocEnggMapper",
						LocationEnggInfoCacheMapper.class.getName(),
						" Inside For Loop--Context", locDetailOld);

				DataObject structure = locDetailNew
						.getDataObject("StructureInfo");
				DataObject locEnggInfo = locDetailOld
						.getDataObject("LocationEnggInfo");

				if (null == locEnggInfo) {
					return locationDetailsBody;
				}

				if (null == structure) {

					structure = bof.create("http://aig.us.com/ges/common/v3",
							"Structure_Type");

					DataObject SecondaryModifiersListDO = bof.create(
							"http://aig.us.com/ges/common/v3",
							"LocationSecondaryModifiers_Type");
					DataObject LocationHazardsDO = bof.create(
							"http://aig.us.com/ges/common/v3",
							"ArrayOfLocationHazard");
					structure.setDataObject("SecondaryModifiersList",
							SecondaryModifiersListDO);
					structure.setDataObject("LocationHazards",
							LocationHazardsDO);

				}
				DataObject secModifiers = structure
						.getDataObject("SecondaryModifiersList");
				List<DataObject> secModList = new ArrayList<DataObject>();

				if (null != secModifiers
						&& !secModifiers.getList("SecondaryModifiers")
								.isEmpty()) {
					secModList.addAll(secModifiers
							.getList("SecondaryModifiers"));
				} else {
					secModifiers = bof.create(
							"http://aig.us.com/ges/common/v3",
							"LocationSecondaryModifiers_Type");
				}

				DataObject hazards = structure.getDataObject("LocationHazards");
				List<DataObject> hazardsList = new ArrayList<DataObject>();
				if (null != hazards
						&& !hazards.getList("LocationHazard").isEmpty()) {
					hazardsList.addAll(hazards.getList("LocationHazard"));
				} else {
					hazards = bof.create("http://aig.us.com/ges/common/v3",
							"ArrayOfLocationHazard");
				}

				List<Property> boPropertiesList = locEnggInfo
						.getInstanceProperties();

				EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
						"UpdateLocEnggMapper",
						"About to enter For Loop of BOProperties");

				for (Property boProperty : boPropertiesList) {

					if (locEnggInfo.isSet(boProperty)) {
						String locEnggInfoElementName = boProperty.getName();
						EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
								"UpdateLocEnggMapper",
								"LocEnggInfo Property is Set : PropertyName : "
										+ boProperty.getName());

						if (locEnggInfoElementName.equalsIgnoreCase("SicGrp")) {
							String value = locEnggInfo
									.getString(locEnggInfoElementName);
							structure.set("SicGrp", value);
						} else if (locEnggInfoElementName
								.equalsIgnoreCase("SicSubGrpCd")) {
							String value = locEnggInfo
									.getString(locEnggInfoElementName);
							DataObject sicSubGrpCdType = bof.create(
									"http://aig.us.com/ges/common/v3",
									"Code_Type");
							sicSubGrpCdType.set("Value", value);
							structure.set("SicSubGrpCd", sicSubGrpCdType);
						} else if (locEnggInfoElementName
								.equalsIgnoreCase("SiteId")) {
							String value = locEnggInfo
									.getString(locEnggInfoElementName);
							structure.set("SiteId", value);
						}

						if (ElementCheckForSecMod(locEnggInfoElementName)) {

							DataObject secModType = bof.create(
									"http://aig.us.com/ges/common/v3",
									"SecondaryModifier_Type");
							String secModifierValue = locEnggInfo
									.getString(locEnggInfoElementName);
							String secModifierName = getUpdateElement(locEnggInfoElementName);
							EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
									"Sec Mod Name and Value is", " "
											+ secModifierName + "Value is"
											+ secModifierValue);

							if (null != secModifierName
									&& !secModifierName.isEmpty()) {
								secModType.set("SecondaryModifierName",
										secModifierName);
								secModType.set("SecondaryModifierValue",
										secModifierValue);
								secModList.add(secModType);
								EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
										"UpdateLocEnggMapper",
										"Added Secondary Modifier to List ",
										secModType);
							}

						} else {
							EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
									"UpdateLocEnggMapper",
									"Inside Hazard Mapper for Update Details ");
							DataObject locationHazardType = bof.create(
									"http://aig.us.com/ges/common/v3",
									"LocationHazardType");
							String hazardValue = locEnggInfo
									.getString(locEnggInfoElementName);

							EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
									"UpdateLocEnggMapper",
									"Inside Hazard Mapper for Update Details, hazard Value is-->"
											+ hazardValue);

							String hazardName = getUpdateElement(locEnggInfoElementName);
							EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
									"UpdateLocEnggMapper",
									"Inside Hazard Mapper for Update Details, hazard Name is-->"
											+ hazardName);
							if (null != hazardName && !hazardName.isEmpty()) {
								locationHazardType
										.set("HazardName", hazardName);
								locationHazardType.set("HazardValue",
										hazardValue);
								hazardsList.add(locationHazardType);
								EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
										"UpdateLocEnggMapper",
										"Added Location Hazard to List ",
										locationHazardType);
							}

						}
					}

				}
				EnggLogger
						.logInfo(CLASSNAME, CLASSNAMESHORT,
								"UpdateLocEnggMapper",
								"Location Engineering Info Scanning Complete for a Location ");
				if (null != secModList && !secModList.isEmpty()) {

					secModifiers.setList("SecondaryModifiers", secModList);
					EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
							"UpdateLocEnggMapper",
							" Secondary Modifiers Updated for Location ",
							secModifiers);

				}
				if (null != hazardsList && !hazardsList.isEmpty()) {

					hazards.setList("LocationHazard", hazardsList);
					EnggLogger
							.logInfo(CLASSNAME, CLASSNAMESHORT,
									"UpdateLocEnggMapper",
									" Location Hazards  Updated for Location ",
									hazards);
				}

				structure.setDataObject("SecondaryModifiersList", secModifiers);
				EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
						"UpdateLocEnggMapper",
						"Structure Updated with Secondary Modifiers ",
						structure);
				structure.setDataObject("LocationHazards", hazards);
				EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
						"UpdateLocEnggMapper",
						"Structure Updated with Location Hazards ", structure);

				EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT,
						"UpdateLocEnggMapper", "Location Details Updated one ",
						locationDetailsBody);

			}

		}

		EnggLogger.exiting(LocationEnggInfoCacheMapper.class.getName(),
				"UpdateLocEnggMapper", LocationEnggInfoCacheMapper.class
						.getName(), " Updated Location Details ",
				locationDetailsBody);
		return locationDetailsBody;
	}

	public static DataObject LocationHazardMapper(
			List<DataObject> locHazarList, DataObject locEnggInfoDO)
			throws FileNotFoundException {

		EnggLogger.entering(CLASSNAME, CLASSNAMESHORT, "UpdateLocEnggMapper",
				"Location Hazard Mapper In ", locEnggInfoDO);
		DataObject locationHazardType = bof.create(
				"http://aig.us.com/ges/common/v3", "LocationHazardType");

		ListIterator<DataObject> itr = locHazarList.listIterator();
		while (itr.hasNext()) {
			EnggLogger
					.logInfo(
							CLASSNAME,
							CLASSNAMESHORT,
							"LocationHazardMapper",
							"Location Details Hazard Mapping, inside While loop, LocationHazard List is not empty ");
			locationHazardType = itr.next();
			String hazardName = locationHazardType.getString("HazardName");
			String hazardValue = locationHazardType.getString("HazardValue");
			String locEnggInfoElement = getLocDetailsElement(hazardName);
			EnggLogger
					.logInfo(
							CLASSNAME,
							CLASSNAMESHORT,
							"LocationHazardMapper",
							"Location Details Secondary Modifiers Mapping, inside While loop Hazard Name is-"
									+ hazardName
									+ " Hazard Value is- "
									+ hazardValue
									+ " LocEnggInfoElement is- "
									+ locEnggInfoElement);

			try {
				locEnggInfoDO.set(locEnggInfoElement, hazardValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		EnggLogger.exiting(CLASSNAME, CLASSNAMESHORT, "UpdateLocEnggMapper",
				"Location Hazard Mapper In-Log Exit from Hazard Mapping ",
				locEnggInfoDO);

		return locEnggInfoDO;
	}

	public static DataObject SecondaryModifierMapper(
			List<DataObject> secModList, DataObject locEnggInfoDO)
			throws FileNotFoundException {

		EnggLogger.entering(CLASSNAME, CLASSNAMESHORT,
				"SecondaryModifierMapper",
				"Location Secondary Modofiers Mapper In ", locEnggInfoDO);
		DataObject secModType = bof.create(
				"http://aig.us.com/ges/grasp/ext/v1", "SecondaryModifier_Type");

		ListIterator<DataObject> itr = secModList.listIterator();
		while (itr.hasNext()) {
			EnggLogger
					.logInfo(
							CLASSNAME,
							CLASSNAMESHORT,
							"LocationHazardMapper",
							"Location Details Secondary Modifiers Mapping, inside While loop, Secondary Modifiers List is not empty ");
			secModType = itr.next();
			String secModNameName = secModType
					.getString("SecondaryModifierName");
			String secModValueValue = secModType
					.getString("SecondaryModifierValue");
			String locEnggInfoElement = getLocDetailsElement(secModNameName);
			EnggLogger
					.logInfo(
							CLASSNAME,
							CLASSNAMESHORT,
							"LocationHazardMapper",
							"Location Details Secondary Modifiers Mapping, inside While loop SecModifiersName is-"
									+ secModNameName
									+ " SecModValue is- "
									+ secModValueValue
									+ " LocEnggInfoElement is- "
									+ locEnggInfoElement);
			try {
				locEnggInfoDO.set(locEnggInfoElement, secModValueValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		EnggLogger
				.exiting(
						CLASSNAME,
						CLASSNAMESHORT,
						"UpdateLocEnggMapper",
						"Location Sec Modifier Mapper In-Log Exit from Sec Modifiers Mapping ",
						locEnggInfoDO);
		return locEnggInfoDO;
	}

	public static List<String> otherElements = new ArrayList<String>();

	static {
		otherElements.add("SicGrp");
		otherElements.add("SicSubGrpCd");
		otherElements.add("SiteId");

	}

	public static boolean otherElementsCheck(String otherElementName) {
		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "OtherElementsCheck",
				"Inside otherElementsCheck Method");
		boolean exists = false;

		if (otherElements.contains(otherElementName)) {
			exists = true;
		} else {
			exists = false;
		}

		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "otherElementsCheck",
				"Other Element Exists ? " + exists);
		return exists;
	}

	public static List<String> SecModlist = new ArrayList<String>();
	static {
		SecModlist.add("EngnrgOvrrdHzrdGrd");
		SecModlist.add("AdqtAutmtcSprnklrsPct");
		SecModlist.add("NeededAutmtcSprnklrsPct");
		SecModlist.add("AutmtcSprnklrsPct");
		SecModlist.add("PredominantConstrnCls");
		SecModlist.add("PredominantPrtctnCls");
		SecModlist.add("XplosnRskAdqtlyEngnred");
		SecModlist.add("FldDesktpAsesd");
	}

	public static boolean ElementCheckForSecMod(String secModName) {
		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "ElementCheckForSecMod",
				"Inside ElementCheckForSecMo Method");
		boolean exists = false;

		if (SecModlist.contains(secModName)) {
			exists = true;
		} else {
			exists = false;
		}

		EnggLogger.logInfo(CLASSNAME, CLASSNAMESHORT, "ElementCheckForSecMod",
				"Secondary Modifier exists ? " + exists);
		return exists;
	}

}
