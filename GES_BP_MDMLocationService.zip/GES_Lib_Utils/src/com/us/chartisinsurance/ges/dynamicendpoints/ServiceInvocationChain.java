/**
 * 
 */
package com.us.chartisinsurance.ges.dynamicendpoints;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import commonj.sdo.DataObject;

/**
 * @author Abhilash
 * 
 */
public class ServiceInvocationChain {

	static ArrayList ServiceInvocationInfoList = new ArrayList<DataObject>();

	public static void addServiceInvocationInfo(
			DataObject[] ServiceInvocationInfo)

	{
		ServiceInvocationInfoList = (ArrayList) Arrays
				.asList(ServiceInvocationInfo);

	}

	public static String getProvider(DataObject aSMO)

	{

		String type = aSMO.getDataObject("body").getType().getURI();

		String serviceProvider = StringUtils.substringAfterLast(type, "/");
		return serviceProvider;
	}
}
