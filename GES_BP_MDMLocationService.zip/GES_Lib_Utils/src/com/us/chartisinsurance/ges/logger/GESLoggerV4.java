/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.emf.ecore.xmi.XMIResource;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.bo.BOXMLDocument;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.ServiceRuntimeException;
import com.ibm.websphere.sibx.smobo.ContextType;
import com.ibm.websphere.sibx.smobo.FailInfoType;
import com.ibm.websphere.sibx.smobo.FanOutContextType;
import com.ibm.websphere.sibx.smobo.HeadersType;
import com.ibm.websphere.sibx.smobo.InvocationPathType;
import com.ibm.websphere.sibx.smobo.PrimitiveContextType;
import com.ibm.websphere.sibx.smobo.SMOHeaderType;
import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.websphere.sibx.smobo.TargetAddressType;
import com.us.aig.ges.constants.GESConstantBundle;
import commonj.sdo.DataObject;

/**
 * @author Abhilash
 * 
 *         GESLoggerV4 facilitates logging at all levels ( INFO , FINER , FINEST
 *         , etc .. )
 * 
 */
public class GESLoggerV4 {

	private static final String XML_CHARSET = "UTF-8";

	public static final String subSystemName = "GESLoggerV36";

	private static BOXMLSerializer boXMLse = (BOXMLSerializer) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");

	private static LogManager logManager = LogManager.getLogManager();

	/**
	 * @param aModuleName
	 *            - MediationModule Name , Java Project Name
	 * @param aMediationFlowName
	 *            - MediationFlow Name , Java method Name
	 * @param aMediationComponentName
	 *            - Mediation Component being entered , Java Class Name
	 * @param aMessage
	 *            - Custom message to be logged
	 * 
	 *            Entry is logged only if log level is INFO
	 */

	public static GESLoggerV4 geslogger;

	private GESLoggerV4() {

	}

	public static void main(String[] ags) {

		new GESLoggerV4().logEvent(LogCategory.MONITOR, Level.INFO, "TEST",
				"Update", "TEST", "HELLO WORLD", null);
	}

	protected static GESLoggerV4 getGesLogger() throws ServiceRuntimeException {
		if (null == geslogger) {

			geslogger = new GESLoggerV4();
			/*
			 * int poolSize = ((ThreadPoolExecutor) loggingService)
			 * .getMaximumPoolSize();
			 * 
			 * loggingService.submit(new GESLoggerV4(LogCategory.CONFIG,
			 * GESLoggerV4.class.getName(), "getGesLogger()",
			 * GESLoggerV4.class.getSimpleName(), "Max Pool Size : " + poolSize,
			 * Level.INFO));
			 */}

		return geslogger;
	}

	public void entering(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.INFO, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);
	}

	/**
	 * @param aModuleName
	 *            - MediationModule Name , Java Project Name
	 * @param aMediationFlowName
	 *            - MediationFlow Name , Java method Name
	 * @param aMediationComponentName
	 *            - Mediation Component being entered , Java Class Name
	 * @param aMessage
	 *            - Custom message to be logged
	 * @param aDataObject
	 *            - DataObject to print
	 * 
	 *            Entry is logged only if log level is INFO
	 */
	public void entering(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);

	}

	/**
	 * @param aModuleName
	 *            - MediationModule Name , Java Project Name
	 * @param aMediationFlowName
	 *            - MediationFlow Name , Java method Name
	 * @param aMediationComponentName
	 *            - Mediation Component being entered , Java Class Name
	 * @param aMessage
	 *            - Custom message to be logged
	 * @param aDataObject
	 *            - DataObject to print
	 * 
	 *            Exit is logged only if log level is INFO
	 */
	public void exiting(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.INFO, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);
	}

	/**
	 * @param aModuleName
	 *            - MediationModule Name , Java Project Name
	 * @param aMediationFlowName
	 *            - MediationFlow Name , Java method Name
	 * @param aMediationComponentName
	 *            - Mediation Component being entered , Java Class Name
	 * @param aMessage
	 *            - Custom message to be logged
	 * @param aDataObject
	 *            - DataObject to print
	 * 
	 *            Exit is logged only if log level is INFO
	 */
	public void exiting(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);
	}

	/**
	 * @param aDataObject
	 *            - The dataObject to be transformed into a String
	 * @return
	 */
	public String dataObjectToString(DataObject aDataObject) {
		// String[] searchList = { "\r", "\n" };
		// /String[] replacementList = { "", "" };
		String dataObjectString = null;

		if (null != aDataObject) {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				Map<Object, Object> options = new HashMap<Object, Object>();
				options.put(XMIResource.OPTION_FORMATTED, Boolean.TRUE);
				// options.put(XMIResource.OPTION_LINE_WIDTH, 400);
				boXMLse.writeDataObjectWithOptions(aDataObject, aDataObject
						.getType().getURI(), aDataObject.getType().getName(),
						baos, options);
				dataObjectString = baos.toString(XML_CHARSET);
			} catch (Exception ioe) {
				ioe.printStackTrace();
			}

		} else {
			dataObjectString = " DataObject is NULL ";
		}
		return dataObjectString;
	}

	public String dataObjectToString(DataObject aDataObject, String aElementName) {

		String dataObjectString = null;

		if (null != aDataObject) {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				Map<Object, Object> options = new HashMap<Object, Object>();
				// options.put(XMIResource.OPTION_FORMATTED, Boolean.FALSE);
				// options.put(XMIResource.OPTION_LINE_WIDTH, 400);
				boXMLse.writeDataObjectWithOptions(aDataObject, aDataObject
						.getType().getURI(), aElementName, baos, options);
				dataObjectString = baos.toString(XML_CHARSET);
			} catch (Exception ioe) {
				ioe.printStackTrace();
			}

		} else {
			dataObjectString = " DataObject is NULL ";
		}
		return dataObjectString;
	}

	public DataObject stringToDataObject(String xmlString) {
		DataObject outBO = null;
		try {
			BOXMLDocument boxmlDoc = boXMLse
					.readXMLDocument(new ByteArrayInputStream(xmlString
							.getBytes("UTF-8")));

			outBO = boxmlDoc.getDataObject();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outBO;

	}

	public void logInfo(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage) {
		logEvent(null, Level.INFO, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);
	}

	public void logWSReq(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);
	}

	public void logWSRes(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);

	}

	public void logInfo(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);

	}

	public void logCategory(String aLogCategory, String aModuleName,
			String aMediationFlowName, String aMediationComponentName,
			String aMessage, DataObject aDataObject, Level logLevel) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(aLogCategory, logLevel, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);

	}

	public void logCategory(String aLogCategory, String aModuleName,
			String aMediationFlowName, String aMediationComponentName,
			String aMessage, Level logLevel) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(aLogCategory, logLevel, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);

	}

	public void logFinest(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);

	}

	public void logFinest(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);
	}

	public void logSevere(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.SEVERE, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);
	}

	public void logSevere(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.SEVERE, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);
	}

	public void logWarning(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage) {
		/*
		 * aModuleName = aModuleName + " Chain - " +
		 * Thread.currentThread().getName();
		 */
		logEvent(null, Level.WARNING, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, null);
	}

	public void logWarning(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		logEvent(null, Level.WARNING, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);

	}

	public void logGESAudit(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		logEvent(null, Level.FINEST, aModuleName, aMediationFlowName,
				aMediationComponentName, aMessage, aDataObject);
	}

	public void logGESCleansing(String aSovId, String aSovVersionId,
			String aLocationId, String aStatus, DataObject aDataObject) {
		logEvent(LogCategory.CLEANSING, Level.FINEST, aSovId, aSovVersionId,
				aLocationId, aStatus.toString(), aDataObject);
	}

	public void logGESCleansingNoBO(String aSovId, String aSovVersionId,
			String aLocationId, String aStatus) {
		logEvent(LogCategory.CLEANSING, Level.FINEST, "{SOV_ID : " + aSovId
				+ " }", "{SOV_VERSION_ID : " + aSovVersionId + " }",
				"{LOCATION_ID : " + aLocationId + " }", aStatus.toString(),
				null);
	}

	public void logGESMonitor(String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {
		logEvent(LogCategory.MONITOR, Level.FINEST, aModuleName,
				aMediationFlowName, aMediationComponentName, aMessage,
				aDataObject);
	}

	public void logGESMonitorNoBO(String aModuleName,
			String aMediationFlowName, String aMediationComponentName,
			String aMessage) {
		logEvent(LogCategory.MONITOR, Level.FINEST, aModuleName,
				aMediationFlowName, aMediationComponentName, aMessage, null);
	}

	public void logEvent(String aLogCategory, Level logLevel,
			String aModuleName, String aMediationFlowName,
			String aMediationComponentName, String aMessage,
			DataObject aDataObject) {

		java.util.logging.Logger logger = null;
		if (null == aLogCategory || StringUtils.isEmpty(aLogCategory)
				|| StringUtils.isBlank(aLogCategory)) {
			logger = logManager.getLogger(subSystemName);

		} else if (aLogCategory.equalsIgnoreCase(LogCategory.PBBI)) {
			logger = logManager.getLogger(LogCategory.PBBI);

		} else if (aLogCategory.equalsIgnoreCase(LogCategory.MDM)) {
			logger = logManager.getLogger(LogCategory.MDM);

		} else if (aLogCategory.equalsIgnoreCase(LogCategory.CONFIG)) {
			logger = logManager.getLogger(LogCategory.CONFIG);
		} else if (aLogCategory.equalsIgnoreCase(LogCategory.EPR)) {
			logger = logManager.getLogger(LogCategory.EPR);
		} else if (aLogCategory.equalsIgnoreCase(LogCategory.EMAIL)) {
			logger = logManager.getLogger(LogCategory.EMAIL);
		} else if (aLogCategory.equalsIgnoreCase(LogCategory.CLEANSING)) {
			logger = logManager.getLogger(LogCategory.CLEANSING);
		} else if (aLogCategory.equalsIgnoreCase(LogCategory.MONITOR)) {
			logger = logManager.getLogger(LogCategory.MONITOR);

		} else if (aLogCategory.equalsIgnoreCase(LogCategory.DBUPDATE)) {
			logger = logManager.getLogger(LogCategory.DBUPDATE);
		} else if (aLogCategory.equalsIgnoreCase(LogCategory.MATCH)) {
			logger = logManager.getLogger(LogCategory.MATCH);
		} else if (aLogCategory.equalsIgnoreCase(LogCategory.SUSPECTS)) {
			logger = logManager.getLogger(LogCategory.SUSPECTS);
		}

		logger.setUseParentHandlers(false);
		boolean logOnlyEvents = false;

		try {
			if (null != GESCacheLoader
					.getValueFromCache(GESConstantBundle.LOGONLYEVENTS)) {

				String val = String.valueOf(GESCacheLoader
						.getValueFromCache(GESConstantBundle.LOGONLYEVENTS));
				logOnlyEvents = Boolean.valueOf(val);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (logger.isLoggable(logLevel)) {

			String threadName = Thread.currentThread().getName();
			if (null == aDataObject) {

				logger.logp(logLevel, "<" + threadName + "> " + aModuleName,
						aMediationFlowName, aMessage + "\n");

			} else {

				if (!logOnlyEvents) {

					if (Level.FINEST.equals(logLevel)
							|| Level.SEVERE.equals(logLevel)) {
						logger.logp(logLevel, "<" + threadName + "> "
								+ aModuleName, aMediationFlowName, aMessage
								+ "\n" + formatDataObject(aDataObject));
					} else {
						logger.logp(logLevel, "<" + threadName + "> "
								+ aModuleName, aMediationFlowName, aMessage
								+ "\n");
					}
				} else {
					logger.logp(logLevel,
							"<" + threadName + "> " + aModuleName,
							aMediationFlowName, aMessage + "\n");
				}

			}

		}
	}

	private String formatDataObject(DataObject aDataObject) {
		StringBuffer dataObjectStringBuffer = new StringBuffer();
		if (1 == 0) {

			if (aDataObject instanceof ServiceMessageObject) {

				ServiceMessageObject smo = (ServiceMessageObject) aDataObject;

				ContextType context = smo.getContext();

				if (null != context) {

					DataObject corrBO = (DataObject) context.getCorrelation();

					if (null != corrBO) {

						dataObjectStringBuffer
								.append("{CORRELATION CTXT START : " + "\n"
										+ dataObjectToString(corrBO) + "\n"
										+ "CORRELATION CTXT END \n");

					}
					DataObject sharedBO = (DataObject) context.getShared();

					if (null != sharedBO) {
						dataObjectStringBuffer.append("{SHARED CTXT START : "
								+ "\n" + dataObjectToString(sharedBO) + "\n"
								+ "SHARED CTXT END \n");
					}
					DataObject transientBO = (DataObject) context
							.getTransient();

					if (null != transientBO) {
						dataObjectStringBuffer
								.append("{TRANSIENT CTXT START : " + "\n"
										+ dataObjectToString(sharedBO) + "\n"
										+ "TRANSIENT CTXT END \n");
					}
					PrimitiveContextType pmtContext = context
							.getPrimitiveContext();

					if (null != pmtContext) {
						FanOutContextType fanOutCtxt = pmtContext
								.getFanOutContext();

						if (null != fanOutCtxt) {
							BigInteger iteration = fanOutCtxt.getIteration();
							dataObjectStringBuffer
									.append("{ IN ITERATION MODE : "
											+ iteration + "\n");
						}
					}

					FailInfoType failInfo = context.getFailInfo();

					if (null != failInfo) {
						String failureSTring = failInfo.getFailureString();

						String Origin = failInfo.getOrigin();
						dataObjectStringBuffer.append("Failure String : "
								+ failureSTring + "  Origin : " + Origin);
						if (null != failInfo.getInvocationPath()) {
							InvocationPathType invocationPath = failInfo
									.getInvocationPath();
							dataObjectStringBuffer
									.append("  Invocation Path : "
											+ StringUtils.join(invocationPath
													.getPrimitive(), "-->")
											+ "\n");
						}
					}

				}

				DataObject body = (DataObject) smo.getBody();

				HeadersType headers = smo.getHeaders();

				if (null != headers) {

					SMOHeaderType smoHeader = headers.getSMOHeader();

					if (null != smoHeader) {

						TargetAddressType targetAddress = smoHeader.getTarget();

						if (null != targetAddress) {

							dataObjectStringBuffer
									.append("{TARGET ADDRESS SET TO  : "
											+ targetAddress.getAddress()
											+ " Invoking IMPORT : "
											+ targetAddress.getImport() + "\n");
						}
					}
				}

				if (null != body) {
					dataObjectStringBuffer.append("{BODY START : \n "
							+ dataObjectToString(body) + "\n" + " BODY END  "
							+ "\n");
				}

			} else {
				dataObjectStringBuffer.append(dataObjectToString(aDataObject));
			}
		} else {

			dataObjectStringBuffer.append(dataObjectToString(aDataObject));
		}

		return dataObjectStringBuffer.toString();
	}

	public static void logSuspectRecords(String sovLocId, String MDMContractId,
			String MDMContractComponentId, String MDMHoldingId,
			String MDMAddressId, String MDMSource, String aMatchResult) {
		Logger suspectLogger = Logger.getLogger(LogCategory.SUSPECTS);

		suspectLogger.log(Level.INFO, SuspectsLogFormatter.getFormattedMessage(
				sovLocId, MDMContractId, MDMContractComponentId, MDMHoldingId,
				MDMAddressId, MDMSource, aMatchResult));
	}

	public static void logLocation(String aSovId, String aSovVersionId,
			String aLocationId) {
		Logger DBUpdateLogger = Logger.getLogger(LogCategory.DBUPDATE);

		DBUpdateLogger.log(Level.INFO, "SOV ID :" + aSovId + " SOV VERSION :"
				+ aSovVersionId + " LocationId:" + aLocationId);

	}
}
