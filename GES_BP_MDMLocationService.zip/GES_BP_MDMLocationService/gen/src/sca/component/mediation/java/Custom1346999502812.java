package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: MDMLocationServiceV2 Interface: LocationServiceV2 Operation: getLocations Type: request Custom Mediation: Prepare Final Response 
 */
public class Custom1346999502812 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__3 = __smo.getDataObject("body")
				.getDataObject("getLocationsResponseParameter");
		commonj.sdo.DataObject getLocationsResponseParams = __result__3;
		java.lang.String __result__2 = "searchContractResponseWrapper";
		boolean __result__5 = __result__3.isSet(__result__2);
		if (__result__5) {
			boolean __result__8 = getLocationsResponseParams.getDataObject(
					"searchContractResponseWrapper").getBoolean(
					"searchContractFailed");
			if (__result__8) {
				commonj.sdo.DataObject __result__11 = getLocationsResponseParams
						.getDataObject("searchContractResponseWrapper");
				java.lang.String __result__12 = "searchContractResponse";
				__result__11.unset(__result__12);
			} else {
				commonj.sdo.DataObject __result__15 = getLocationsResponseParams
						.getDataObject("searchContractResponseWrapper");
				java.lang.String __result__16 = "addContractResponse";
				__result__15.unset(__result__16);
			}
		} else {
		}
		commonj.sdo.DataObject __result__19 = __smo.getDataObject("context")
				.getDataObject("correlation").getDataObject("RequestHeader");
		commonj.sdo.DataObject __result__20 = com.us.chartisinsurance.ges.transformation.utils.TransformationUtils
				.prepareRespContextFromReqContext(__result__19);
		__smo.getDataObject("body").set("ResponseHeader", __result__20);
		java.lang.String __result__22 = "** AddContract Response prepared , Response sent to searchLocations , Location Service ** \n";
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__24 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__25 = getMediationServices();
		try {
			utility.MediationLogger_LogExit.mediationLogger_LogExit(
					__result__22, __smo, __result__24, __result__25);
		} catch (com.ibm.websphere.sca.ServiceRuntimeException ex2) {
			java.lang.String __result__28 = "GES-SYS-M3O82010O";
			com.ibm.websphere.sca.ServiceRuntimeException __result__29 = new com.ibm.websphere.sca.ServiceRuntimeException(
					__result__28);
			throw __result__29;
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;searchContractResponseWrapper&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.getLocationsResponseParameter" field="true">
		//    <dataOutputs target="//@executableElements.3"/>
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="searchContractResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.2/@dataOutputs.0" value="getLocationsResponseParams" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="searchContractResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.2/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.5"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="getLocationsResponseParams.searchContractResponseWrapper.searchContractFailed" field="true">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="getLocationsResponseParams.searchContractResponseWrapper" field="true">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="searchContractWrapper" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;searchContractResponse&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="getLocationsResponseParams.searchContractResponseWrapper" field="true">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="searchContractWrapper" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;addContractResponse&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.1/@conditionalActivities.1/@executableElements.2"/>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.RequestHeader" field="true">
		//    <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="prepareRespContextFromReqContext" category="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" className="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" static="true" memberName="prepareRespContextFromReqContext">
		//    <parameters name="contextHeader" dataInputs="//@executableElements.6/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.8"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@result/@dataOutputs.0" value="smo.body.ResponseHeader" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ResponseHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** AddContract Response prepared , Response sent to searchLocations , Location Service ** \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <dataOutputs target="//@executableElements.15/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.13/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.13/@parameters.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogExit" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="inputMessage" dataInputs="//@executableElements.9/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="SCAServices" dataInputs="//@executableElements.11/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.12/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex2" dataInputs="//@executableElements.13/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-M3O82010O&quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.14/@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ServiceRuntimeException" category="com.ibm.websphere.sca.ServiceRuntimeException" className="com.ibm.websphere.sca.ServiceRuntimeException" constructor="true" memberName="ServiceRuntimeException">
		//      <parameters name="message" dataInputs="//@executableElements.14/@executableElements.0/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.14/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//      <parameters name="Throwable" dataInputs="//@executableElements.14/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.14/@executableElements.0 //@executableElements.14/@executableElements.1 //@executableElements.14/@executableElements.2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.10/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="getLocationsResponseParams">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="searchContractResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.1 //@executableElements.4 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.15"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!2:4,1
		//!SMAP!3:2,1
		//!SMAP!4:3,1
		//!SMAP!5:5,1
		//!SMAP!6:6,1
		//!SMAP!8:7,1
		//!SMAP!9:8,1
		//!SMAP!11:9,1
		//!SMAP!12:10,1
		//!SMAP!13:11,1
		//!SMAP!15:14,1
		//!SMAP!16:15,1
		//!SMAP!17:16,1
		//!SMAP!19:21,1
		//!SMAP!20:22,1
		//!SMAP!21:23,1
		//!SMAP!22:24,1
		//!SMAP!24:25,1
		//!SMAP!25:26,1
		//!SMAP!26:28,1
		//!SMAP!28:31,1
		//!SMAP!29:32,1
		//!SMAP!30:33,1
		//!SMAP!31:35,1
		//!SMAP!1000000:259,1
	}
}
