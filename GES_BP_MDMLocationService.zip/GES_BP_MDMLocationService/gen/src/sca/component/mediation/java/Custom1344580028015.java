package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: MDMLocationServiceV2 Interface: LocationServiceV2 Operation: addLocations Type: request Custom Mediation: Log WS Request
 */
public class Custom1344580028015 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String aIGMDMBusinessProxyServicePartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (aIGMDMBusinessProxyServicePartner == null
				|| "".equals(aIGMDMBusinessProxyServicePartner.trim())) {
			throw new MediationConfigurationException(
					"Property 'aIGMDMBusinessProxyServicePartner' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the aIGMDMBusinessProxyServicePartner
	 */
	public String getAIGMDMBusinessProxyServicePartner() {
		return aIGMDMBusinessProxyServicePartner;
	}

	/**
	 * @generated
	 * @param aIGMDMBusinessProxyServicePartner The aIGMDMBusinessProxyServicePartner to set.
	 */
	public void setAIGMDMBusinessProxyServicePartner(
			String aIGMDMBusinessProxyServicePartner)
			throws IllegalArgumentException {
		if (aIGMDMBusinessProxyServicePartner == null
				|| "".equals(aIGMDMBusinessProxyServicePartner.trim())) {
			throw new IllegalArgumentException(
					aIGMDMBusinessProxyServicePartner
							+ " is not a valid value for property 'aIGMDMBusinessProxyServicePartner'");
		}

		this.aIGMDMBusinessProxyServicePartner = aIGMDMBusinessProxyServicePartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__5 = getSCAServices();
		java.lang.String __result__6 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(aIGMDMBusinessProxyServicePartner, __result__5);
		utility.SCA_and_BO_services.SetTargetAddress.setTargetAddress(
				(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo,
				__result__6);
		boolean __result__2 = null != __smo.getDataObject("body")
				.getDataObject("AIGAddContractLocation").getDataObject(
						"request").getDataObject("Contract");
		if (__result__2) {
			java.util.List __result__10 = __smo.getDataObject("body")
					.getDataObject("AIGAddContractLocation").getDataObject(
							"request").getDataObject("Contract").getList(
							"component");
			java.util.List contractComponentList = __result__10;
			java.util.Iterator iter12 = contractComponentList.iterator();
			while (iter12.hasNext()) {
				commonj.sdo.DataObject contractComponent = (commonj.sdo.DataObject) iter12
						.next();
				boolean __result__14 = null != contractComponent
						.getDataObject("holding");
				if (__result__14) {
					java.lang.String __result__18 = "holding";
					commonj.sdo.DataObject __result__19 = contractComponent
							.getDataObject(__result__18);
					commonj.sdo.DataObject Holding = __result__19;
					boolean __result__21 = null != Holding;
					if (__result__21) {
						commonj.sdo.DataObject xProperty = Holding;
						boolean __result__26 = xProperty.getInt("YearBuilt") == 0;
						if (__result__26) {
							java.lang.String __result__30 = "YearBuilt";
							xProperty.unset(__result__30);
						} else {
						}
						boolean __result__33 = xProperty.getInt("YearUpgrade") == 0;
						if (__result__33) {
							java.lang.String __result__37 = "YearUpgrade";
							xProperty.unset(__result__37);
						} else {
						}
					} else {
					}
				} else {
				}
			}
		} else {
		}
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__43 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__44 = getMediationServices();
		java.lang.String __result__45 = "** Log MDM addContractRequestMsg, Location Service **\n";
		commonj.sdo.DataObject __result__46 = ((commonj.sdo.DataObject) __smo
				.getDataObject("context").getDataObject("correlation")
				.getDataObject("addLocationsRequest").getDataObject(
						"addLocationsRequest").getDataObject("locations")
				.getList("location").get(0)).getDataObject("sovLocation");
		com.ibm.websphere.sibx.smobo.ServiceMessageObject __result__48 = utility.MDMUtils.utility.AugmentMDMRequest
				.augmentMDMRequest(
						__result__46,
						(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo);
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__43,
				__result__44, __result__45, __result__48);
		java.lang.String __result__50 = com.us.chartisinsurance.ges.logger.LogCategory.MDM;
		commonj.sdo.DataObject __result__51 = __smo.getDataObject("body");
		utility.LogEvent.logEvent(__result__50, __result__43, __result__44,
				__result__45, __result__51);
		out.fire(__result__48);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.18/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.body.AIGAddContractLocation.request.Contract" assignable="false">
		//    <dataOutputs target="//@executableElements.7"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aIGMDMBusinessProxyServicePartner" variable="true">
		//    <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="SetTargetAddress" category="SCA and BO services" targetNamespace="http://GES_Lib_Common/utility/SCA%20and%20BO%20services/">
		//    <parameters name="smo" dataInputs="//@executableElements.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="targetURI" dataInputs="//@executableElements.5/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.1/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.AIGAddContractLocation.request.Contract.component" field="true">
		//        <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="contractComponentList" localVariable="//@executableElements.7/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="contractComponentList" localVariable="//@executableElements.7/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:IterationActivity" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.2/@dataOutputs.0" iterationVariable="contractComponent" iterationType="java.util.Collection">
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=contractComponent.holding" assignable="false">
		//          <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.0/@dataOutputs.0">
		//          <conditionalActivities>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="contractComponent" localVariable="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@localVariables.0" variable="true">
		//              <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ContractComponent" namespace="http://www.ibm.com/xmlns/prod/websphere/wcc/financial/schema"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;holding&quot;" assignable="false">
		//              <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getDataObject">
		//              <parameters name="DataObject" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </parameters>
		//              <parameters name="arg0" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//              </parameters>
		//              <result>
		//                <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.3"/>
		//                <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//              </result>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="Holding" localVariable="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@localVariables.0" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=Holding" assignable="false">
		//              <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.4/@dataOutputs.0">
		//              <conditionalActivities>
		//                <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="Holding" localVariable="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@localVariables.0" variable="true">
		//                  <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </executableElements>
		//                <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="xProperty" localVariable="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@localVariables.0" variable="true">
		//                  <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="XProperty" namespace="http://extensions.mdm.aig.com/Party/Ext/schema"/>
		//                </executableElements>
		//                <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="xProperty.YearBuilt ==0" assignable="false">
		//                  <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//                </executableElements>
		//                <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//                  <conditionalActivities>
		//                    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="xProperty" localVariable="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@localVariables.0" variable="true">
		//                      <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="XProperty" namespace="http://extensions.mdm.aig.com/Party/Ext/schema"/>
		//                    </executableElements>
		//                    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;YearBuilt&quot;" assignable="false">
		//                      <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//                    </executableElements>
		//                    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                      <parameters name="DataObject" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                      </parameters>
		//                      <parameters name="arg0" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                      </parameters>
		//                    </executableElements>
		//                    <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2"/>
		//                    <condition value="true"/>
		//                  </conditionalActivities>
		//                  <conditionalActivities>
		//                    <condition value=""/>
		//                  </conditionalActivities>
		//                </executableElements>
		//                <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="xProperty.YearUpgrade ==0" assignable="false">
		//                  <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5"/>
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//                </executableElements>
		//                <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.4/@dataOutputs.0">
		//                  <conditionalActivities>
		//                    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="xProperty" localVariable="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@localVariables.0" variable="true">
		//                      <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="XProperty" namespace="http://extensions.mdm.aig.com/Party/Ext/schema"/>
		//                    </executableElements>
		//                    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;YearUpgrade&quot;" assignable="false">
		//                      <dataOutputs target="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//                    </executableElements>
		//                    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                      <parameters name="DataObject" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                      </parameters>
		//                      <parameters name="arg0" dataInputs="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                      </parameters>
		//                    </executableElements>
		//                    <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//                    <condition value="true"/>
		//                  </conditionalActivities>
		//                  <conditionalActivities>
		//                    <condition value=""/>
		//                  </conditionalActivities>
		//                </executableElements>
		//                <localVariables name="xProperty">
		//                  <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="XProperty" namespace="http://extensions.mdm.aig.com/Party/Ext/schema"/>
		//                </localVariables>
		//                <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//                <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.3"/>
		//                <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.4 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.5"/>
		//                <condition value="true"/>
		//              </conditionalActivities>
		//              <conditionalActivities>
		//                <condition value=""/>
		//              </conditionalActivities>
		//            </executableElements>
		//            <localVariables name="Holding">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </localVariables>
		//            <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.0 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.1 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.2 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.3"/>
		//            <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.4 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1/@conditionalActivities.0/@executableElements.5"/>
		//            <condition value="true"/>
		//          </conditionalActivities>
		//          <conditionalActivities>
		//            <condition value=""/>
		//          </conditionalActivities>
		//        </executableElements>
		//        <localVariables name="contractComponent">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="ContractComponent"/>
		//        </localVariables>
		//        <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.0 //@executableElements.7/@conditionalActivities.0/@executableElements.3/@executableElements.1"/>
		//        <iterationVariableType xsi:type="com.ibm.wbit.activity:XSDElementType" name="ContractComponent" namespace="http://www.ibm.com/xmlns/prod/websphere/wcc/financial/schema" nillable="false"/>
		//      </executableElements>
		//      <localVariables name="contractComponentList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.0 //@executableElements.7/@conditionalActivities.0/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.7/@conditionalActivities.0/@executableElements.2 //@executableElements.7/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.17/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.14/@parameters.1"/>
		//      <dataOutputs target="//@executableElements.17/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** Log MDM addContractRequestMsg, Location Service **\n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.14/@parameters.2"/>
		//    <dataOutputs target="//@executableElements.17/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.addLocationsRequest.addLocationsRequest.locations.location.get(0).sovLocation" field="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="sovLocation" namespace="http://aig.us.com/ges"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="AugmentMDMRequest" category="utility" targetNamespace="http://GES_Lib_Common/utility/MDMUtils/utility/">
		//    <parameters name="sovLocation" dataInputs="//@executableElements.11/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="sovLocation" namespace="http://aig.us.com/ges" nillable="false"/>
		//    </parameters>
		//    <parameters name="inputSMO" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <result name="outputSMO">
		//      <dataOutputs target="//@executableElements.14/@parameters.3"/>
		//      <dataOutputs target="//@executableElements.18/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.9/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.13/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="LogCategory.MDM" category="com.us.chartisinsurance.ges.logger.LogCategory" className="com.us.chartisinsurance.ges.logger.LogCategory" static="true" memberName="MDM" field="true">
		//    <parameters name="MDM">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.17/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body" field="true">
		//    <dataOutputs target="//@executableElements.17/@parameters.4"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AIGAddContractLocationRequest" namespace="wsdl.http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="LogEvent" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="LogCategory" dataInputs="//@executableElements.15/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aSCAServices" dataInputs="//@executableElements.8/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MedServices" dataInputs="//@executableElements.9/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="InMessage" dataInputs="//@executableElements.10/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="InDataObject" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.13/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.1 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.15 //@executableElements.16 //@executableElements.17"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.18"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!2:5,1
		//!SMAP!5:2,1
		//!SMAP!6:3,1
		//!SMAP!7:4,1
		//!SMAP!8:6,1
		//!SMAP!10:7,1
		//!SMAP!11:8,1
		//!SMAP!12:9,3
		//!SMAP!14:12,1
		//!SMAP!15:13,1
		//!SMAP!18:14,1
		//!SMAP!19:15,1
		//!SMAP!20:16,1
		//!SMAP!21:17,1
		//!SMAP!22:18,1
		//!SMAP!25:19,1
		//!SMAP!26:20,1
		//!SMAP!27:21,1
		//!SMAP!30:22,1
		//!SMAP!31:23,1
		//!SMAP!33:27,1
		//!SMAP!34:28,1
		//!SMAP!37:29,1
		//!SMAP!38:30,1
		//!SMAP!43:44,1
		//!SMAP!44:45,1
		//!SMAP!45:46,1
		//!SMAP!46:47,1
		//!SMAP!48:48,1
		//!SMAP!49:49,1
		//!SMAP!50:50,1
		//!SMAP!51:51,1
		//!SMAP!52:52,1
		//!SMAP!53:53,1
		//!SMAP!1000000:405,1
	}
}
