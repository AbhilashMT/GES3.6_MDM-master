package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: MDMLocationServiceV2 Interface: LocationServiceV2 Operation: updateContract Type: request Custom Mediation: Handle Run Time Errors
 */
public class Custom1346314962330 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String runTimeError;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (runTimeError == null || "".equals(runTimeError.trim())) {
			throw new MediationConfigurationException(
					"Property 'runTimeError' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the runTimeError
	 */
	public String getRunTimeError() {
		return runTimeError;
	}

	/**
	 * @generated
	 * @param runTimeError The runTimeError to set.
	 */
	public void setRunTimeError(String runTimeError)
			throws IllegalArgumentException {
		if (runTimeError == null || "".equals(runTimeError.trim())) {
			throw new IllegalArgumentException(runTimeError
					+ " is not a valid value for property 'runTimeError'");
		}

		this.runTimeError = runTimeError;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__2 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__3 = getMediationServices();
		java.lang.String __result__4 = "** Runtime Failure occurred  \n";
		try {
			utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
					__result__2, __result__3, __result__4, __smo);
		} catch (com.ibm.websphere.sca.ServiceRuntimeException ex2) {
			java.lang.String __result__8 = "GES-SYS-M3O42010O";
			com.ibm.websphere.sca.ServiceRuntimeException __result__9 = new com.ibm.websphere.sca.ServiceRuntimeException(
					__result__8);
			throw __result__9;
		}
		java.lang.String __result__11 = "";
		java.lang.String errorMsg = __result__11;
		boolean __result__1 = null != __smo.getDataObject("context")
				.getDataObject("transient").getString("errorCode");
		if (__result__1) {
			java.lang.String __result__15 = __smo.getDataObject("context")
					.getDataObject("transient").getString("errorCode");
			errorMsg = __result__15;
		} else {
			java.lang.String __result__18 = __smo.getDataObject("context")
					.getDataObject("failInfo").getString("failureString");
			errorMsg = __result__18;
		}
		java.lang.String __result__25 = "updateContract_updateContractFaultMsg";
		java.lang.String __result__20 = "http://aig.us.com/ges/services/LocationServiceV2";
		java.lang.String __result__21 = __result__2.getModuleName();
		java.lang.String __result__22 = "updateContract";
		com.ibm.websphere.sibx.smobo.ServiceMessageObject __result__26 = ExceptionHandlingUtils.utility.utility.UpdateGESFaultObjectType
				.updateGESFaultObjectType(
						(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo,
						errorMsg, __result__25, __result__20, __result__21,
						__result__22);
		try {
			utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
					__result__2, __result__3, errorMsg, __result__26);
		} catch (com.ibm.websphere.sca.ServiceRuntimeException ex3) {
			java.lang.String __result__29 = "GES-SYS-M3O42010O";
			com.ibm.websphere.sca.ServiceRuntimeException __result__30 = new com.ibm.websphere.sca.ServiceRuntimeException(
					__result__29);
			throw __result__30;
		}
		out.fire(__result__26);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.context.transient.errorCode" assignable="false">
		//    <dataOutputs target="//@executableElements.9"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.11/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.17/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.1"/>
		//      <dataOutputs target="//@executableElements.17/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** Runtime Failure occurred  \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.5/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.5/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.1/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex2" dataInputs="//@executableElements.5/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-M3O42010O&quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.6/@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ServiceRuntimeException" category="com.ibm.websphere.sca.ServiceRuntimeException" className="com.ibm.websphere.sca.ServiceRuntimeException" constructor="true" memberName="ServiceRuntimeException">
		//      <parameters name="message" dataInputs="//@executableElements.6/@executableElements.0/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.6/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//      <parameters name="Throwable" dataInputs="//@executableElements.6/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.6/@executableElements.0 //@executableElements.6/@executableElements.1 //@executableElements.6/@executableElements.2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.8"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@dataOutputs.0" value="errorMsg" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.0/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.transient.errorCode" field="true">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="errorMsg" localVariable="//@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.9/@conditionalActivities.0/@executableElements.0 //@executableElements.9/@conditionalActivities.0/@executableElements.1"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.failInfo.failureString" field="true">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.1/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="errorMsg" localVariable="//@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.9/@conditionalActivities.1/@executableElements.0 //@executableElements.9/@conditionalActivities.1/@executableElements.1"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;http://aig.us.com/ges/services/LocationServiceV2&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.16/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleName" category="com.ibm.wsspi.sibx.mediation.esb.SCAServices" className="com.ibm.wsspi.sibx.mediation.esb.SCAServices" memberName="getModuleName">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.1/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.16/@parameters.4"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;updateContract&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.16/@parameters.5"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="errorMsg" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.17/@parameters.2"/>
		//    <dataOutputs target="//@executableElements.16/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;updateContract_updateContractFaultMsg&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.16/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="updateGESFaultObjectType" category="utility" targetNamespace="http://GES_Lib_Common/ExceptionHandlingUtils/utility/utility/">
		//    <parameters name="smoInput" dataInputs="//@executableElements.14/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="customMessage" dataInputs="//@executableElements.13/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="outputMessageName" dataInputs="//@executableElements.15/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="outputMessageQName" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="moduleName" dataInputs="//@executableElements.11/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="operartionName" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="smoOutput">
		//      <dataOutputs target="//@executableElements.17/@parameters.3"/>
		//      <dataOutputs target="//@executableElements.20/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.1/@result/@dataOutputs.2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.2/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.13/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.16/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <dataOutputs target="//@executableElements.18/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex3" dataInputs="//@executableElements.17/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-M3O42010O&quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.18/@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ServiceRuntimeException" category="com.ibm.websphere.sca.ServiceRuntimeException" className="com.ibm.websphere.sca.ServiceRuntimeException" constructor="true" memberName="ServiceRuntimeException">
		//      <parameters name="message" dataInputs="//@executableElements.18/@executableElements.0/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.18/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//      <parameters name="Throwable" dataInputs="//@executableElements.18/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.18/@executableElements.0 //@executableElements.18/@executableElements.1 //@executableElements.18/@executableElements.2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.16/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="errorMsg">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.1 //@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15 //@executableElements.16 //@executableElements.17 //@executableElements.18"/>
		//  <executableGroups executableElements="//@executableElements.19 //@executableElements.20"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:15,1
		//!SMAP!2:2,1
		//!SMAP!3:3,1
		//!SMAP!4:4,1
		//!SMAP!6:6,1
		//!SMAP!8:9,1
		//!SMAP!9:10,1
		//!SMAP!10:11,1
		//!SMAP!11:13,1
		//!SMAP!12:14,1
		//!SMAP!13:16,1
		//!SMAP!15:17,1
		//!SMAP!16:18,1
		//!SMAP!18:21,1
		//!SMAP!19:22,1
		//!SMAP!20:25,1
		//!SMAP!21:26,1
		//!SMAP!22:27,1
		//!SMAP!25:24,1
		//!SMAP!26:28,1
		//!SMAP!27:30,1
		//!SMAP!29:33,1
		//!SMAP!30:34,1
		//!SMAP!31:35,1
		//!SMAP!33:37,1
		//!SMAP!1000000:301,1
	}
}
