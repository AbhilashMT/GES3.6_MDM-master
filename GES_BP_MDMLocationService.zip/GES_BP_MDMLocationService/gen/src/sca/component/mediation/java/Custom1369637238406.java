package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: MDMLocationServiceV2 Interface: LocationServiceV2 Operation: addLocations Type: request Custom Mediation: PrepareAddContractRequest
 */
public class Custom1369637238406 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String aIGMDMBusinessProxyServicePartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (aIGMDMBusinessProxyServicePartner == null
				|| "".equals(aIGMDMBusinessProxyServicePartner.trim())) {
			throw new MediationConfigurationException(
					"Property 'aIGMDMBusinessProxyServicePartner' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the aIGMDMBusinessProxyServicePartner
	 */
	public String getAIGMDMBusinessProxyServicePartner() {
		return aIGMDMBusinessProxyServicePartner;
	}

	/**
	 * @generated
	 * @param aIGMDMBusinessProxyServicePartner The aIGMDMBusinessProxyServicePartner to set.
	 */
	public void setAIGMDMBusinessProxyServicePartner(
			String aIGMDMBusinessProxyServicePartner)
			throws IllegalArgumentException {
		if (aIGMDMBusinessProxyServicePartner == null
				|| "".equals(aIGMDMBusinessProxyServicePartner.trim())) {
			throw new IllegalArgumentException(
					aIGMDMBusinessProxyServicePartner
							+ " is not a valid value for property 'aIGMDMBusinessProxyServicePartner'");
		}

		this.aIGMDMBusinessProxyServicePartner = aIGMDMBusinessProxyServicePartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.websphere.sibx.smobo.ServiceMessageObject __result__2;
		{// copy SMO
			com.ibm.websphere.bo.BOCopy _copyService = (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOCopy");
			__result__2 = (com.ibm.websphere.sibx.smobo.ServiceMessageObject) _copyService
					.copy(((com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo));
		}
		com.ibm.websphere.sibx.smobo.ServiceMessageObject NewSMO = __result__2;
		commonj.sdo.DataObject __result__4;
		{// create SMO body with AIGAddContractLocationRequest
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port",
							"AIGAddContractLocationRequest"));
			__result__4 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject AIGAddContractLocationRequestBody = __result__4;
		byte __result__6 = 0;
		commonj.sdo.DataObject __result__7 = AIGAddContractLocationRequestBody
				.createDataObject(__result__6);
		commonj.sdo.DataObject AIGAddContractLocation = __result__7;
		commonj.sdo.DataObject __result__9 = __smo.getDataObject("context")
				.getDataObject("correlation").getDataObject("Control");
		AIGAddContractLocation.set("control", __result__9);
		commonj.sdo.DataObject __result__11 = __smo.getDataObject("context")
				.getDataObject("correlation").getDataObject(
						"AIGContractLocation");
		AIGAddContractLocation.set("request", __result__11);
		byte __result__14 = 0;
		AIGAddContractLocationRequestBody.setDataObject(__result__14,
				AIGAddContractLocation);
		NewSMO.setBody(AIGAddContractLocationRequestBody);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__27 = getSCAServices();
		java.lang.String __result__28 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(aIGMDMBusinessProxyServicePartner, __result__27);
		utility.SCA_and_BO_services.SetTargetAddress.setTargetAddress(NewSMO,
				__result__28);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__21 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__22 = getMediationServices();
		java.lang.String __result__23 = "** Retrying MDM Add Transaction \n";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__21,
				__result__22, __result__23, NewSMO);
		out.fire(NewSMO);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.1/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="copy SMO" description="Copy a Service Message Object" category="SMO services" template="com.ibm.websphere.bo.BOCopy _copyService = &#xA;   (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOCopy&quot;); &#xA;&lt;%return%> (com.ibm.websphere.sibx.smobo.ServiceMessageObject) _copyService.copy(&lt;%smo%>);">
		//    <parameters name="smo" dataInputs="//@executableElements.0/@dataOutputs.0" displayName="service message object">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <result name="smo copy" displayName="service message object copy">
		//      <dataOutputs target="//@executableElements.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@result/@dataOutputs.0" value="NewSMO" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with AIGAddContractLocationRequest" description="Create SMO body with message {http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port}AIGAddContractLocationRequest" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port&quot;, &quot;AIGAddContractLocationRequest&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.4"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@result/@dataOutputs.0" value="AIGAddContractLocationRequestBody" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="createDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="createDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.7"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.6/@result/@dataOutputs.0" value="AIGAddContractLocation" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AIGAddContractLocation" namespace="http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.Control" field="true">
		//    <dataOutputs target="//@executableElements.9"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Control" namespace="http://www.ibm.com/xmlns/prod/websphere/wcc/common/intf/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@dataOutputs.0" value="AIGAddContractLocation.control" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Control" namespace="http://www.ibm.com/xmlns/prod/websphere/wcc/common/intf/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.AIGContractLocation" field="true">
		//    <dataOutputs target="//@executableElements.11"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AIGContractLocation" namespace="http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@dataOutputs.0" value="AIGAddContractLocation.request" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AIGContractLocation" namespace="http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AIGAddContractLocationRequestBody" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.15/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AIGAddContractLocation" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.15/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AIGAddContractLocation" namespace="http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.13/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.14/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.30/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NewSMO" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.30/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="AIGAddContractLocationRequestBody" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.19"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@dataOutputs.0" value="NewSMO.body" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.29/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.29/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** Retrying MDM Add Transaction \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.29/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NewSMO" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.29/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NewSMO" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.28/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aIGMDMBusinessProxyServicePartner" variable="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.27/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.26/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.28/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="SetTargetAddress" category="SCA and BO services" targetNamespace="http://GES_Lib_Common/utility/SCA%20and%20BO%20services/">
		//    <parameters name="smo" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="targetURI" dataInputs="//@executableElements.27/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.20/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.21/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="NewSMO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </localVariables>
		//  <localVariables name="AIGAddContractLocationRequestBody">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="AIGAddContractLocation">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="AIGAddContractLocation" namespace="http://businessproxy.mdm.aig.com/aigmdmbusinessproxy/port" nillable="false"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2"/>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11"/>
		//  <executableGroups executableElements="//@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.18 //@executableElements.19"/>
		//  <executableGroups executableElements="//@executableElements.24 //@executableElements.25 //@executableElements.26 //@executableElements.27 //@executableElements.28"/>
		//  <executableGroups executableElements="//@executableElements.20 //@executableElements.21 //@executableElements.22 //@executableElements.23 //@executableElements.29"/>
		//  <executableGroups executableElements="//@executableElements.16 //@executableElements.17 //@executableElements.30"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!2:2,6
		//!SMAP!3:8,1
		//!SMAP!4:9,8
		//!SMAP!5:17,1
		//!SMAP!6:18,1
		//!SMAP!7:19,1
		//!SMAP!8:20,1
		//!SMAP!9:21,1
		//!SMAP!10:22,1
		//!SMAP!11:23,1
		//!SMAP!12:24,1
		//!SMAP!14:25,1
		//!SMAP!16:26,1
		//!SMAP!20:27,1
		//!SMAP!21:31,1
		//!SMAP!22:32,1
		//!SMAP!23:33,1
		//!SMAP!27:28,1
		//!SMAP!28:29,1
		//!SMAP!29:30,1
		//!SMAP!30:34,1
		//!SMAP!31:35,1
		//!SMAP!1000000:273,1
	}
}
