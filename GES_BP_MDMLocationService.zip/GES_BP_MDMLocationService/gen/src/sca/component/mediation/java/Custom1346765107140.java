package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: MDMLocationServiceV2 Interface: LocationServiceV2 Operation: getLocations Type: request Custom Mediation: TransformAddContractFault_To_SearchLocationsFault
 */
public class Custom1346765107140 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__1;
		{// create SMO body with getLocationsFaultMsg
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://aig.us.com/ges/services/LocationServiceV2",
							"getLocationsFaultMsg"));
			__result__1 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject getLocationsFaultMgsBody = __result__1;
		commonj.sdo.DataObject __result__3;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__3 = factory.create("http://aig.us.com/ges/common/v3",
					"ArrayOfGESFault");
		}
		commonj.sdo.DataObject TargetArrayOfGESFault = __result__3;
		commonj.sdo.DataObject __result__8 = __smo.getDataObject("body")
				.getDataObject("addLocationsFault");
		commonj.sdo.DataObject arrayOfGesFault1 = __result__8;
		java.util.Vector __result__7 = new java.util.Vector();
		java.util.Vector TargetFaultVector = __result__7;
		java.util.List __result__11 = arrayOfGesFault1.getList("gesFaults");
		java.util.Iterator iter11 = __result__11.iterator();
		while (iter11.hasNext()) {
			commonj.sdo.DataObject gesFaultObjectType = (commonj.sdo.DataObject) iter11
					.next();
			commonj.sdo.DataObject __result__13;
			{// create GesFaultObjectType
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__13 = factory
						.create("http://aig.us.com/ges/common/v3",
								"GesFaultObjectType");
			}
			commonj.sdo.DataObject TargetGESFaultObjectType1 = __result__13;
			java.lang.String __result__15 = gesFaultObjectType
					.getString("faultCode");
			TargetGESFaultObjectType1.setString("faultCode", __result__15);
			java.lang.String __result__17 = gesFaultObjectType
					.getString("faultString");
			TargetGESFaultObjectType1.setString("faultString", __result__17);
			java.lang.String __result__19 = gesFaultObjectType
					.getString("faultOrigin");
			TargetGESFaultObjectType1.setString("faultOrigin", __result__19);
			boolean __result__23 = TargetFaultVector
					.add(TargetGESFaultObjectType1);
		}
		byte __result__6 = 0;
		TargetArrayOfGESFault.setList(__result__6, TargetFaultVector);
		byte __result__27 = 0;
		commonj.sdo.DataObject __result__28 = getLocationsFaultMgsBody
				.createDataObject(__result__27);
		byte __result__30 = 0;
		getLocationsFaultMgsBody.setDataObject(__result__30,
				TargetArrayOfGESFault);
		java.lang.String __result__34 = "..";
		commonj.sdo.DataObject __result__35 = getLocationsFaultMgsBody
				.getDataObject(__result__34);
		commonj.sdo.DataObject NewSMO = __result__35;
		out.fire(NewSMO);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with getLocationsFaultMsg" description="Create SMO body with message {http://aig.us.com/ges/services/LocationServiceV2}getLocationsFaultMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://aig.us.com/ges/services/LocationServiceV2&quot;, &quot;getLocationsFaultMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@result/@dataOutputs.0" value="getLocationsFaultMgsBody" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create ArrayOfGESFault" description="create a new ArrayOfGESFault {http://aig.us.com/ges/common/v3}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/common/v3&quot;,&quot;ArrayOfGESFault&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.2/@result/@dataOutputs.0" value="TargetArrayOfGESFault" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetArrayOfGESFault" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new Vector" category="java.util.Vector" className="java.util.Vector" constructor="true" memberName="Vector">
		//    <result>
		//      <dataOutputs target="//@executableElements.9"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Vector"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.addLocationsFault" field="true">
		//    <dataOutputs target="//@executableElements.8"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.7/@dataOutputs.0" value="arrayOfGesFault1" localVariable="//@localVariables.4" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.6/@result/@dataOutputs.0" value="TargetFaultVector" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Vector"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="arrayOfGesFault1.gesFaults" field="true">
		//    <dataOutputs target="//@executableElements.11"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:IterationActivity" dataInputs="//@executableElements.10/@dataOutputs.0" iterationVariable="gesFaultObjectType" iterationType="java.util.Collection">
		//    <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create GesFaultObjectType" description="create a new GesFaultObjectType {http://aig.us.com/ges/common/v3}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/common/v3&quot;,&quot;GesFaultObjectType&quot;);">
		//      <result>
		//        <dataOutputs target="//@executableElements.11/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.0/@result/@dataOutputs.0" value="TargetGESFaultObjectType1" localVariable="//@executableElements.11/@localVariables.1" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="gesFaultObjectType.faultCode" field="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.2/@dataOutputs.0" value="TargetGESFaultObjectType1.faultCode" field="true">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="gesFaultObjectType.faultString" field="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.5"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.4/@dataOutputs.0" value="TargetGESFaultObjectType1.faultString" field="true">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="gesFaultObjectType.faultOrigin" field="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.7"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@executableElements.6/@dataOutputs.0" value="TargetGESFaultObjectType1.faultOrigin" field="true">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetFaultVector" localVariable="//@localVariables.2" variable="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.10/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Vector"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetGESFaultObjectType1" localVariable="//@executableElements.11/@localVariables.1" variable="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.10/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="add" category="java.util.Vector" className="java.util.Vector" memberName="add">
		//      <parameters name="Vector" dataInputs="//@executableElements.11/@executableElements.8/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Vector"/>
		//      </parameters>
		//      <parameters name="arg0" dataInputs="//@executableElements.11/@executableElements.9/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="E"/>
		//      </parameters>
		//      <result>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </result>
		//    </executableElements>
		//    <localVariables name="gesFaultObjectType">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//    </localVariables>
		//    <localVariables name="TargetGESFaultObjectType1">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//    </localVariables>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.0 //@executableElements.11/@executableElements.1"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.2 //@executableElements.11/@executableElements.3"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.4 //@executableElements.11/@executableElements.5"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.6 //@executableElements.11/@executableElements.7"/>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.8 //@executableElements.11/@executableElements.9 //@executableElements.11/@executableElements.10"/>
		//    <iterationVariableType xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetFaultVector" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Vector"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setList">
		//    <parameters name="DataObject" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="getLocationsFaultMgsBody" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.16/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="createDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="createDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.14/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.15/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="getLocationsFaultMgsBody" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.20/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetArrayOfGESFault" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="getLocationsFaultMgsBody" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.23/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;..&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.23/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.21/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.24"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@result/@dataOutputs.0" value="NewSMO" localVariable="//@localVariables.3" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NewSMO" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.26/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="getLocationsFaultMgsBody">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="TargetArrayOfGESFault">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="TargetFaultVector">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Vector"/>
		//  </localVariables>
		//  <localVariables name="NewSMO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="arrayOfGesFault1">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfGESFault" namespace="http://aig.us.com/ges/common/v3"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11"/>
		//  <executableGroups executableElements="//@executableElements.4 //@executableElements.5 //@executableElements.12 //@executableElements.13"/>
		//  <executableGroups executableElements="//@executableElements.14 //@executableElements.15 //@executableElements.16"/>
		//  <executableGroups executableElements="//@executableElements.17 //@executableElements.18 //@executableElements.19 //@executableElements.20"/>
		//  <executableGroups executableElements="//@executableElements.21 //@executableElements.22 //@executableElements.23 //@executableElements.24"/>
		//  <executableGroups executableElements="//@executableElements.25 //@executableElements.26 //@executableElements.27"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,8
		//!SMAP!2:10,1
		//!SMAP!3:11,6
		//!SMAP!4:17,1
		//!SMAP!6:41,1
		//!SMAP!7:20,1
		//!SMAP!8:18,1
		//!SMAP!9:19,1
		//!SMAP!10:21,1
		//!SMAP!11:22,4
		//!SMAP!13:26,6
		//!SMAP!14:32,1
		//!SMAP!15:33,1
		//!SMAP!16:34,1
		//!SMAP!17:35,1
		//!SMAP!18:36,1
		//!SMAP!19:37,1
		//!SMAP!20:38,1
		//!SMAP!23:39,1
		//!SMAP!25:42,1
		//!SMAP!27:43,1
		//!SMAP!28:44,1
		//!SMAP!30:45,1
		//!SMAP!32:46,1
		//!SMAP!34:47,1
		//!SMAP!35:48,1
		//!SMAP!36:49,1
		//!SMAP!39:50,1
		//!SMAP!1000000:330,1
	}
}
