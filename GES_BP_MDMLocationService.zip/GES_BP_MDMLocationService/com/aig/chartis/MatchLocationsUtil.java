package com.aig.chartis;

public class MatchLocationsUtil {
	
	public static String getBuiltyear(short bltYr){
		
		return bltYr+"";
	}

}
