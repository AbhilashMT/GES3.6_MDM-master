/**
 * 
 */
package com.us.chartisinsurance.ges.gateway.utils;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import com.us.chartisinsurance.ges.gateway.constants.GESGatewayConstants;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import commonj.connector.runtime.FunctionSelector;
import commonj.connector.runtime.SelectorException;

/**
 * @author ASurendr
 * 
 */
public class AIGFunctionSelectorForGRASPJMS implements FunctionSelector {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * commonj.connector.runtime.FunctionSelector#generateEISFunctionName(java
	 * .lang.Object[])
	 */

	public String generateEISFunctionName(Object[] arg0)
			throws SelectorException {
		GESLoggerV4 FunctionSelectorLogger = GESLoggerFactory.getLogger();
		String functionName = "UnsupportedOperation";
		FunctionSelectorLogger.entering(AIGFunctionSelectorForGRASPJMS.class
				.getName(), "generateEISFunctionName",
				AIGFunctionSelectorForGRASPJMS.class.getName(),
				"Entering AIGFunctionSelector");
		// Route all updates from GRASP to one way methods

		Message jmsMessage = (Message) arg0[0];

		if (jmsMessage instanceof TextMessage) {
			FunctionSelectorLogger.logInfo(AIGFunctionSelectorForGRASPJMS.class
					.getName(), "generateEISFunctionName",
					AIGFunctionSelectorForGRASPJMS.class.getName(),
					"Message is of JMS Text Message Type");
			try {
				String messageText = ((TextMessage) jmsMessage).getText();

				if (messageText
						.indexOf(GESGatewayConstants.DiscardLocationsRequest) != -1
						|| messageText
								.indexOf(GESGatewayConstants.LocationEngineeringUpdatesRequest) != -1
						|| messageText
								.indexOf(GESGatewayConstants.ReceiveUpdatesRequest) != -1) {
					FunctionSelectorLogger
							.logInfo(AIGFunctionSelectorForGRASPJMS.class
									.getName(), "generateEISFunctionName",
									AIGFunctionSelectorForGRASPJMS.class
											.getName(),
									"Message is an Location update request from GRASP ");
					functionName = GESGatewayConstants.ASYNCOPERATIONNAME;
					FunctionSelectorLogger.logInfo(
							AIGFunctionSelectorForGRASPJMS.class.getName(),
							"generateEISFunctionName",
							AIGFunctionSelectorForGRASPJMS.class.getName(),
							"Derived Function Name is : " + functionName);
				} else {
					FunctionSelectorLogger.logSevere(
							AIGFunctionSelectorForGRASPJMS.class.getName(),
							"generateEISFunctionName",
							AIGFunctionSelectorForGRASPJMS.class.getName(),
							"Unsupported Root Element Found::::" + messageText);
					throw new SelectorException(
							"@@@@@ Poisonous Message Detected...");
				}
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				FunctionSelectorLogger.logSevere(
						AIGFunctionSelectorForGRASPJMS.class.getName(),
						"generateEISFunctionName",
						AIGFunctionSelectorForGRASPJMS.class.getName(), e
								.getMessage());
			}

		} else {
			FunctionSelectorLogger.logInfo(AIGFunctionSelectorForGRASPJMS.class
					.getName(), "generateEISFunctionName",
					AIGFunctionSelectorForGRASPJMS.class.getName(),
					" @@@@@ Poisonous Message Detected...");
			throw new SelectorException("@@@@@ Poisonous Message Detected...");
		}
		return functionName;
	}

}
