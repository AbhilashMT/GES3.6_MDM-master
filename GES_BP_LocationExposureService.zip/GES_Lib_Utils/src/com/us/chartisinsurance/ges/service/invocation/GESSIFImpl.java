/**
 * 
 */
package com.us.chartisinsurance.ges.service.invocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import org.apache.commons.lang3.StringUtils;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sca.ServiceRuntimeException;
import com.ibm.websphere.sca.addressing.EndpointReference;
import com.ibm.websphere.sca.addressing.EndpointReferenceFactory;
import com.ibm.websphere.sca.scdl.OperationType;
import com.ibm.websphere.sca.scdl.Reference;
import com.ibm.wsspi.sca.container.Container;
import com.us.chartisinsurance.ges.common.utils.ScrubbingAIModule;
import com.us.chartisinsurance.ges.db.utils.QueryAccess;
import com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;
import commonj.sdo.Type;

/**
 * @author M1019070
 * 
 */

public class GESSIFImpl implements GESSIF {

	private static final GESLoggerV4 gesLogger = GESLoggerFactory.getLogger();
	private static final String CLASSNAME = GESSIFImpl.class.getName();
	private static final String CLASSNAMESHORT = GESSIFImpl.class
			.getSimpleName();

	public static final GESSIF INSTANCE = new GESSIFImpl();
	public static final String GES_EIS_ROOT = "getDataFromSPRequest";

	public static final BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	public static final BOXMLSerializer boXML = (BOXMLSerializer) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");

	public GESSIFImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.us.chartisinsurance.ges.service.invocation.GESSIF#(java
	 * .lang.String, java.lang.String)
	 */
	@Override
	public DataObject invokeService(String methodName, String aPartnerName,
			DataObject aDataObject) throws ServiceBusinessException,
			ServiceRuntimeException, Exception {

		gesLogger
				.entering(CLASSNAME, "invokeService", CLASSNAMESHORT,
						"MethodName : " + methodName + " PartnerName : "
								+ aPartnerName, aDataObject);
		DataObject responseBO = null;
		try {
			Service aSCAService = (Service) ServiceManager.INSTANCE
					.locateService(aPartnerName);
			gesLogger.logInfo(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"Service Obtained for Partner : " + aPartnerName
							+ " About to Invoke : ", aDataObject);
			responseBO = (DataObject) aSCAService.invoke(methodName,
					aDataObject);
			gesLogger
					.logInfo(CLASSNAME, "invokeService", CLASSNAMESHORT,
							"Service Invoked for Partner : " + aPartnerName,
							responseBO);
			if (null == responseBO) {
				throw new ServiceRuntimeException("Empty / NULL Response ");
			}

		} catch (ServiceRuntimeException scaEx) {
			scaEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"Service Runtime Exception : " + scaEx.getMessage());

			DataObject errorBO = constructSBE("GES-SYS-SIFS1", CLASSNAMESHORT,
					"invokeService");

			throw new ServiceBusinessException(errorBO);

		} catch (ServiceBusinessException scaSBEx) {
			scaSBEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"Service Business Exception : " + scaSBEx.getMessage());

			throw scaSBEx;

		}

		gesLogger
				.exiting(CLASSNAME, "invokeService", CLASSNAMESHORT,
						"MethodName : " + methodName + " PartnerName : "
								+ aPartnerName, responseBO);
		return responseBO;
	}

	@Override
	public DataObject invokeService(String methodName, String aPartnerName,
			String targetAddress, DataObject aDataObject)
			throws ServiceBusinessException, ServiceRuntimeException, Exception {

		gesLogger.entering(CLASSNAME, "invokeService", CLASSNAMESHORT,
				"MethodName : " + methodName + " PartnerName : " + aPartnerName
						+ " Target Address : " + targetAddress, aDataObject);
		DataObject responseBO = null;
		try {

			EndpointReference epr = createEndpointReference(targetAddress);

			if (null == epr) {
				throw new ServiceRuntimeException(
						"Endpoint Reference could not be obtained / prepared");
			}
			Service aSCAService = (Service) ServiceManager.INSTANCE.getService(
					aPartnerName, epr);
			gesLogger.logInfo(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"Service Obtained for Partner : " + aPartnerName
							+ " About to Invoke : ", aDataObject);
			responseBO = (DataObject) aSCAService.invoke(methodName,
					aDataObject);
			gesLogger
					.logInfo(CLASSNAME, "invokeService", CLASSNAMESHORT,
							"Service Invoked for Partner : " + aPartnerName,
							responseBO);

			if (null == responseBO) {
				throw new ServiceBusinessException(
						createSBEException("GES-SYS-SIIF"));
			}

		} catch (ServiceRuntimeException scaEx) {
			scaEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"Service Runtime Exception Occurred : " + aPartnerName
							+ scaEx.getMessage());
			throw new ServiceBusinessException(
					createSBEException("GES-SYS-INVFBSRE"));

		} catch (ServiceBusinessException scaSBEx) {
			scaSBEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"Service Runtime Exception Occurred : " + aPartnerName
							+ scaSBEx.getMessage());
			throw scaSBEx;

		} catch (Exception e) {
			e.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeService", CLASSNAMESHORT,
					"An Unexpected Exception Occurred : " + aPartnerName
							+ e.getMessage());
			throw new ServiceBusinessException(
					createSBEException("GES-SYS-INVFRE"));
		}

		gesLogger.exiting(CLASSNAME, "invokeService", CLASSNAMESHORT,
				"MethodName : " + methodName + " PartnerName : " + aPartnerName
						+ " Target Address : " + targetAddress, aDataObject);
		return responseBO;

	}

	private EndpointReference createEndpointReference(String aTargetAddress) {
		gesLogger.entering(CLASSNAME, "createEndpointReference",
				CLASSNAMESHORT, " Target Address : " + aTargetAddress);
		EndpointReference epr = null;
		try {
			epr = EndpointReferenceFactory.INSTANCE.createEndpointReference();
			epr.setAddress(aTargetAddress);
		} catch (Exception e) {
			e.printStackTrace();
		}
		gesLogger.exiting(CLASSNAME, "createEndpointReference", CLASSNAMESHORT,
				" Target Address : " + aTargetAddress);
		return epr;
	}

	public DataObject createSBEException(String aErrorCode) {

		gesLogger.entering(CLASSNAME, "createSBEException", CLASSNAMESHORT,
				" Supplied Error Code : " + aErrorCode);

		DataObject GESServicesFault = bof.createByElement(
				"http://aig.us.com/ges/common/v3", "GESServicesFault");

		DataObject GESFaultObjType = bof.create(
				"http://aig.us.com/ges/common/v3", "GesFaultObjectType");

		List<DataObject> FaultObjList = new ArrayList<DataObject>();

		if (org.apache.commons.lang3.StringUtils.isNotBlank(aErrorCode)
				&& org.apache.commons.lang3.StringUtils.isNotEmpty(aErrorCode)) {

			GESFaultObjType.setString("faultCode", aErrorCode);

		} else {
			GESFaultObjType.setString("faultCode", "GES-SYS-INVFR");
		}

		GESFaultObjType
				.setString("faultString",
						"An Unexpected error occurred , please contact system adminsitrator");
		GESFaultObjType.setString("faultType", aErrorCode);
		FaultObjList.add(GESFaultObjType);
		GESServicesFault.setList("gesFaults", FaultObjList);
		gesLogger.exiting(CLASSNAME, "createSBEException", CLASSNAMESHORT,
				" GES Services Fault  : ", GESServicesFault);
		return GESServicesFault;
	}

	public DataObject invokeEISServiceSP(DataObject aDataObject,
			String aParentOperatioName) throws ServiceBusinessException,
			ServiceRuntimeException {
		gesLogger.entering(CLASSNAME, "invokeEISServiceSP", CLASSNAMESHORT,
				"Request received for EIS Service invocation" + "\n",
				aDataObject);

		boolean isValid = validateEISRequest(aDataObject);

		// Check Type @Payload

		// $http://www.example.org/DataAccessV1_0$PolicyDetailsSearchType
		// $http://www.example.org/DataAccessV1_0$AccountSearchType
		// $http://www.example.org/DataAccessV1_0$PolicyOptionDetailsSearchType

		// <?xml version="1.0" encoding="UTF-8"?><getDataFromSPRequest
		// xmlns:ns0="http://www.example.org/DataAccessV1_0"
		// xmlns:ns2="http://aig.us.com/ges/common/v3"
		// xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
		// xsi:type="ns0:GetDataType">
		// <RequestFor>GRASP</RequestFor>
		// <ns0:ServicePartnerRef PartnerRef="GESExposureDataPartner"
		// xsi:type="ns0:GESExposureDataPartner">
		// <OperationNm>getAccountsSP</OperationNm>
		// </ns0:ServicePartnerRef>
		// <MaxRecords>100</MaxRecords>
		// <ns2:SourceSystemCd>
		// <ns2:SourceSystemCode>GPW</ns2:SourceSystemCode>
		// <ns2:SourceSystemkey/>
		// </ns2:SourceSystemCd>
		// <ns0:QueryParams QueryBy="UnderWriterId">
		// <ns2:Value/>
		// <ns0:QueryOperator>0</ns0:QueryOperator>
		// </ns0:QueryParams>
		// </getDataFromSPRequest>

		// DataObject payLoad = aDataObject.getDataObject("Payload");

		if (!isValid) {

			String errorCode = "GES-SYS-EISSIFO";
			String moduleName = Container.INSTANCE.getModule().getName();
			throw new ServiceBusinessException(constructSBE(errorCode,
					moduleName, "invokeEISServiceSP"));
		}

		try {
			Type boType = null;
			if (null != aDataObject) {
				boType = aDataObject.getType();
				String boTypeName = (null != boType.getName() ? boType
						.getName() : "");

				gesLogger.logInfo(CLASSNAME, "invokeEISServiceSP",
						CLASSNAMESHORT, " TypeName   : " + boTypeName + "\n",
						aDataObject);

				// Based on Type getMethodName

				DataObject servicePartnerRef = aDataObject
						.getDataObject("ServicePartnerRef");

				String sourceSysCd = aDataObject
						.getString("SourceSystemCd/SourceSystemCode");

				if (null != servicePartnerRef) {
					String PartnerRef = servicePartnerRef
							.getString("PartnerRef");
					String OperationNm = servicePartnerRef
							.getString("OperationNm");
					gesLogger.logInfo(CLASSNAME, "invokeEISServiceSP",
							CLASSNAMESHORT, " Partner Name    : " + PartnerRef
									+ " Method Name : " + OperationNm + "\n");

					// Now get Service

					Service derivedService = getService(PartnerRef);

					if (null != derivedService) {
						gesLogger.logInfo(CLASSNAME, "invokeEISServiceSP",
								CLASSNAMESHORT, " Derived Service : "
										+ derivedService.toString() + "\n");

						// Get Service Reference

						Reference serviceReference = derivedService
								.getReference();

						if (null != serviceReference) {
							gesLogger
									.logInfo(CLASSNAME, "invokeEISServiceSP",
											CLASSNAMESHORT,
											" Derived Reference  : "
													+ serviceReference
															.getName() + "\n");

							// Get Operation on Service Reference

							OperationType derivedOpType = serviceReference
									.getOperationType(OperationNm);
							if (null != derivedOpType) {

								String derivedOperationName = derivedOpType
										.getName();
								gesLogger.logInfo(CLASSNAME,
										"invokeEISServiceSP", CLASSNAMESHORT,
										" Derived Operation Name   : "
												+ derivedOperationName + "\n");

								// Is a Wrapper Type Operation ?

								Type inputType = derivedOpType.getInputType();

								if (null != inputType) {
									boolean isWrapperType = derivedOpType
											.isWrapperType(inputType);

									gesLogger.logInfo(CLASSNAME,
											"invokeEISServiceSP",
											CLASSNAMESHORT,
											" Derived Operation Name   : "
													+ derivedOpType.getName()
													+ " has wrapper Input ? "
													+ isWrapperType + "\n");

									String inputTypeURI = inputType.getURI();
									gesLogger.logInfo(CLASSNAME,
											"invokeEISServiceSP",
											CLASSNAMESHORT,
											" Operation Input Type URI : "
													+ inputTypeURI + "\n");

									DataObject targetBO = null;

									// get PayLoad String

									// THis is not what it is . Dont Ignore

									String inXML = gesLogger
											.dataObjectToString(aDataObject,
													GES_EIS_ROOT);
									if (isWrapperType) {
										// Create By Element

										// get Local Name from Type URI :

										inputTypeURI = StringUtils
												.substringAfter(inputTypeURI,
														":");
										gesLogger.logInfo(CLASSNAME,
												"invokeEISServiceSP",
												CLASSNAMESHORT,
												" Create Target DataObject with QName : "
														+ inputTypeURI
														+ " BOName:"
														+ derivedOperationName
														+ "\n");
										targetBO = bof.createByElement(
												inputTypeURI,
												derivedOperationName);
										DataObject childBO = targetBO
												.createDataObject(0);
										childBO.set(0, inXML); // set XMLString
										childBO.set(1, sourceSysCd); // Set
										// Module
										// Name
										targetBO.setDataObject(0, childBO);

									} else {
										// Create By Type
										targetBO = bof.createByType(inputType);
									}

									gesLogger.logInfo(CLASSNAME,
											"invokeEISServiceSP",
											CLASSNAMESHORT,
											" Target BO Constructed for   : "
													+ OperationNm + "\n",
											targetBO);

									gesLogger.logInfo(CLASSNAME,
											"invokeEISServiceSP",
											CLASSNAMESHORT,
											" About to Invoke EIS Service Partner     : "
													+ PartnerRef
													+ " Operation : "
													+ OperationNm + "\n",
											targetBO);

									try {
										DataObject ResponseBO = invokeService(
												derivedOperationName,
												PartnerRef, targetBO);

										gesLogger.logInfo(CLASSNAME,
												"invokeEISServiceSP",
												CLASSNAMESHORT,
												" Response from EIS Service Partner     : "
														+ PartnerRef
														+ " Operation : "
														+ OperationNm + "\n",
												ResponseBO);

										// Inspect EIS Response

										boolean isSucess = inspectEISResponse(
												ResponseBO, isWrapperType);

										// Handle Success

										if (isSucess) {
											String value = ResponseBO
													.getDataObject(0)
													.getString(4);

											DataObject textBody = bof
													.create(
															"http://com.ibm.wbiserver.gateway/schema",
															"TextBody");

											textBody.setString("value", value);
											aDataObject.set("Data", textBody);

											return aDataObject;
										} else {
											// Handle SBE .get(0)

											DataObject errorBO = handleException(
													ResponseBO.getDataObject(0),
													"invokeEISServiceSP");

											throw new ServiceBusinessException(
													errorBO);
										}
									} catch (ServiceBusinessException sbe) {
										throw sbe;
									}

									catch (ServiceRuntimeException e) {

										gesLogger
												.logSevere(
														CLASSNAME,
														"invokeEISService",
														CLASSNAMESHORT,
														" An Exception Occurred Invoking Service  : "
																+ e
																		.getMessage()
																+ "\n");

										String errorCode = "GES-SYS-EISSIFO";

										DataObject GESServicesFaultBO = constructSBE(
												errorCode, CLASSNAMESHORT,
												"invokeEISService");
										gesLogger
												.logSevere(
														CLASSNAME,
														"invokeEISService",
														CLASSNAMESHORT,
														" An Exception Occurred Invoking Service  : "
																+ e
																		.getMessage()
																+ "\n",
														GESServicesFaultBO);

										throw new ServiceBusinessException(
												GESServicesFaultBO);
									}

								}

							}

						}
					}

				}

			}

		} catch (ServiceBusinessException sbe) {
			throw sbe;
		}

		catch (Exception e) {
			gesLogger.logSevere(CLASSNAME, "invokeEISService", CLASSNAMESHORT,
					" An Exception Occurred Invoking Service  : "
							+ e.getMessage() + "\n");

			String errorCode = "GES-SYS-DASPSVCO";
			String moduleName = Container.INSTANCE.getModule().getName();
			DataObject GESServicesFaultBO = constructSBE(errorCode, moduleName,
					"invokeEISService");
			gesLogger.logSevere(CLASSNAME, "invokeEISService", CLASSNAMESHORT,
					" An Exception Occurred Invoking Service  : "
							+ e.getMessage() + "\n", GESServicesFaultBO);

			throw new ServiceBusinessException(GESServicesFaultBO);
		}
		return aDataObject;

	}

	@SuppressWarnings("unused")
	private static String getNativeMethodNameFromBOType(String requestType) {

		// PolicyDetailsSearchType
		// PolicyOptionDetailsSearchType
		// AccountSearchType

		gesLogger.entering(CLASSNAME, "getNativeMethodNameFromBOType",
				CLASSNAMESHORT, " RequestType  : " + requestType + "\n");

		String nativeMethodName = "";

		if ("AccountDetailsSearchType".equalsIgnoreCase(requestType)) {
			nativeMethodName = "getAccountsSP";
		}
		if ("PolicyDetailsSearchType".equalsIgnoreCase(requestType)) {
			nativeMethodName = "getPolicyDetailsSP";
		}
		if ("PolicyOptionDetailsSearchType".equalsIgnoreCase(requestType)) {
			nativeMethodName = "getPolicyOptionDetailsSP";
		} else {
			nativeMethodName = "getAccountsSP";
		}
		gesLogger.exiting(CLASSNAME, "getNativeMethodNameFromBOType",
				CLASSNAMESHORT, " NativeMethodName  : " + nativeMethodName
						+ "\n");
		return nativeMethodName;
	}

	public DataObject invokeEISService(String aPartnerName, String boXMLString)
			throws ServiceBusinessException, ServiceRuntimeException {
		return null;
	}

	private boolean inspectEISResponse(DataObject inDataObject,
			boolean isWrapperType) {
		boolean isSuccess = false;
		gesLogger.entering(CLASSNAME, "inspectEISResponse", CLASSNAMESHORT,
				" Inspect EIS Response " + "\n", inDataObject);
		DataObject ResponsePayload = null;
		if (isWrapperType) {
			ResponsePayload = inDataObject.getDataObject(0);

			// inspect Error

			int errorCode = ResponsePayload.getInt(2);

			if (0 == errorCode) {
				isSuccess = true;
			}
		}
		gesLogger.entering(CLASSNAME, "inspectEISResponse", CLASSNAMESHORT,
				" Inspect EIS Response Is Sucecss : " + isSuccess + "\n",
				ResponsePayload);
		return isSuccess;
	}

	private Service getService(String aPartnerName) {

		gesLogger.entering(CLASSNAME, "getService", CLASSNAMESHORT,
				" Get Service for Partner  : " + aPartnerName + "\n");
		Service scaService = (Service) ServiceManager.INSTANCE
				.locateService(aPartnerName);

		gesLogger.exiting(CLASSNAME, "getService", CLASSNAMESHORT,
				"  Service for Partner  : " + aPartnerName + " " + scaService
						+ "\n");

		return scaService;

	}

	public DataObject handleException(DataObject eisResponseDO,
			String aOperationName) {
		gesLogger.entering(CLASSNAME, "handleEISException", CLASSNAMESHORT,
				" Handle EIS Exception : " + "\n", eisResponseDO);

		String errorCode = eisResponseDO.getString(3);
		gesLogger.logInfo(CLASSNAME, "handleEISException", CLASSNAMESHORT,
				" Error Message returned is  : " + errorCode);
		String moduleName = Container.INSTANCE.getModule().getName();

		gesLogger.logInfo(CLASSNAME, "handleEISException", CLASSNAMESHORT,
				" Module Name  : " + moduleName);
		String errorMessage = GESExceptionHandler.formatException(errorCode,
				"", moduleName, aOperationName);

		DataObject GESServicesFaultBO = bof.create(
				"http://aig.us.com/ges/common/v3", "ArrayOfGESFault");
		DataObject FaultObjBO = bof.create("http://aig.us.com/ges/common/v3",
				"GesFaultObjectType");
		FaultObjBO.setString("faultCode", errorCode);
		FaultObjBO.setString("faultString", errorMessage);

		List<DataObject> faultList = new ArrayList<DataObject>();
		faultList.add(FaultObjBO);
		GESServicesFaultBO.set(0, faultList);
		gesLogger.exiting(CLASSNAME, "handleEISException", CLASSNAMESHORT,
				" Error Message Constructed  : ", GESServicesFaultBO);

		return GESServicesFaultBO;

	}

	// <?xml version="1.0" encoding="UTF-8"?><getDataFromSPRequest
	// xmlns:ns0="http://www.example.org/DataAccessV1_0"
	// xmlns:ns2="http://aig.us.com/ges/common/v3"
	// xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	// xsi:type="ns0:GetDataType">
	// <RequestFor>GRASP</RequestFor>
	// <ns0:ServicePartnerRef PartnerRef="GESExposureDataPartner"
	// xsi:type="ns0:GESExposureDataPartner">
	// <OperationNm>getAccountsSP</OperationNm>
	// </ns0:ServicePartnerRef>
	// <MaxRecords>100</MaxRecords>
	// <ns2:SourceSystemCd>
	// <ns2:SourceSystemCode>GPW</ns2:SourceSystemCode>
	// <ns2:SourceSystemkey/>
	// </ns2:SourceSystemCd>
	// <ns0:QueryParams QueryBy="UnderWriterId">
	// <ns2:Value/>
	// <ns0:QueryOperator>0</ns0:QueryOperator>
	// </ns0:QueryParams>
	// </getDataFromSPRequest>

	private boolean validateEISRequest(DataObject aDataObject) {
		boolean isValid = false;
		if (null != aDataObject) {
			if (aDataObject.isSet("ServicePartnerRef")) {

				DataObject ServicePartnerRef = aDataObject
						.getDataObject("ServicePartnerRef");
				if (null != ServicePartnerRef) {
					String PartnerRef = ServicePartnerRef
							.getString("PartnerRef");
					String OperationNm = ServicePartnerRef
							.getString("OperationNm");

					if (StringUtils.isNotBlank(PartnerRef)
							&& StringUtils.isNotEmpty(PartnerRef)
							&& StringUtils.isNotBlank(OperationNm)
							&& StringUtils.isNotEmpty(OperationNm)) {

						if (aDataObject.isSet("SourceSystemCd")) {

							DataObject SourceSystemCd = aDataObject
									.getDataObject("SourceSystemCd");
							if (null != SourceSystemCd) {
								String SourceSystemCode = SourceSystemCd
										.getString("SourceSystemCode");

								if (StringUtils.isNotBlank(SourceSystemCode)
										&& StringUtils
												.isNotEmpty(SourceSystemCode)) {
									isValid = true;
								}
							}

						}

					}
				}
			}
		}

		return isValid;
	}

	public DataObject constructSBE(String aErrorCode, String aModuleName,
			String aOperationName) {
		DataObject GESServicesFaultBO = bof.create(
				"http://aig.us.com/ges/common/v3", "ArrayOfGESFault");
		DataObject FaultObjBO = bof.create("http://aig.us.com/ges/common/v3",
				"GesFaultObjectType");

		FaultObjBO.setString("faultCode", aErrorCode);

		String errorMessage = GESExceptionHandler.formatException(aErrorCode,
				"", aModuleName, aOperationName);
		FaultObjBO.setString("faultString", errorMessage);

		List<DataObject> faultList = new ArrayList<DataObject>();
		faultList.add(FaultObjBO);
		GESServicesFaultBO.setList(0, faultList);

		return GESServicesFaultBO;

	}

	@Override
	public void invokeServiceAsync(String methodName, String partnerName,
			DataObject dataObject) throws ServiceBusinessException,
			ServiceRuntimeException, Exception {

		gesLogger.entering(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
				"MethodName : " + methodName + " PartnerName : " + partnerName,
				dataObject);

		try {
			Service aSCAService = (Service) ServiceManager.INSTANCE
					.locateService(partnerName);
			gesLogger.logInfo(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
					"Service Obtained for Partner : " + partnerName
							+ " About to Invoke : ", dataObject);
			aSCAService.invokeAsync(methodName, dataObject);
			gesLogger.logInfo(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
					"DataObject-", dataObject);

		} catch (ServiceRuntimeException scaEx) {
			scaEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeServiceAsync",
					CLASSNAMESHORT, "Service Runtime Exception : "
							+ scaEx.getMessage());

			DataObject errorBO = constructSBE("GES-SYS-SIFS1", CLASSNAMESHORT,
					"invokeService");

			throw new ServiceBusinessException(errorBO);

		} catch (ServiceBusinessException scaSBEx) {
			scaSBEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeServiceAsync",
					CLASSNAMESHORT, "Service Business Exception : "
							+ scaSBEx.getMessage());

			throw scaSBEx;

		}

		gesLogger.exiting(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
				"MethodName : " + methodName + " PartnerName : " + partnerName);

	}

	public void invokeServiceAsync(String methodName, String aPartnerName,
			String targetAddress, DataObject aDataObject)
			throws ServiceBusinessException, ServiceRuntimeException, Exception {

		gesLogger.entering(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
				"MethodName : " + methodName + " PartnerName : " + aPartnerName
						+ " Target Address : " + targetAddress, aDataObject);

		try {

			EndpointReference epr = createEndpointReference(targetAddress);

			if (null == epr) {
				throw new ServiceRuntimeException(
						"Endpoint Reference could not be obtained / prepared");
			}
			Service aSCAService = (Service) ServiceManager.INSTANCE.getService(
					aPartnerName, epr);
			gesLogger.logInfo(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
					"Service Obtained for Partner : " + aPartnerName
							+ " About to Invoke : ", aDataObject);
			aSCAService.invokeAsync(methodName, aDataObject);

		} catch (ServiceRuntimeException scaEx) {
			scaEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeServiceAsync",
					CLASSNAMESHORT, "Service Runtime Exception Occurred : "
							+ aPartnerName + scaEx.getMessage());
			throw new ServiceBusinessException(
					createSBEException("GES-SYS-INVFBSRE"));

		} catch (ServiceBusinessException scaSBEx) {
			scaSBEx.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeServiceAsync",
					CLASSNAMESHORT, "Service Runtime Exception Occurred : "
							+ aPartnerName + scaSBEx.getMessage());
			throw scaSBEx;

		} catch (Exception e) {
			e.printStackTrace();
			gesLogger.logSevere(CLASSNAME, "invokeServiceAsync",
					CLASSNAMESHORT, "An Unexpected Exception Occurred : "
							+ aPartnerName + e.getMessage());
			throw new ServiceBusinessException(
					createSBEException("GES-SYS-INVFRE"));
		}

		gesLogger.exiting(CLASSNAME, "invokeServiceAsync", CLASSNAMESHORT,
				"MethodName : " + methodName + " PartnerName : " + aPartnerName
						+ " Target Address : " + targetAddress, aDataObject);

	}

	public DataObject invokeCustomQuery(String aQueryName,
			Map<String, String> parmMap) throws ServiceBusinessException {

		DataObject response = null;
		DataObject customPayload = null;
		gesLogger.logCategory(LogCategory.CONFIG, ScrubbingAIModule.class
				.getName(), "invokeCustomQuery", ScrubbingAIModule.class
				.getSimpleName(), " Invoke Custom Query :  " + aQueryName,
				Level.INFO);

		BOFactory boFactory = (BOFactory) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject getDataObject = boFactory.create(
				"http://GES_Lib_DataAccess/it/DataAccess", "GetDataType");
		DataObject customDataObject = boFactory.create(
				"http://aig.us.com/ges/schema/da/DataAccessV1_0",
				"GetCustomDataType");
		DataObject customQueryParamObject = boFactory.create(
				"http://aig.us.com/ges/schema/da/DataAccessV1_0",
				"CustomQueryParamType");

		gesLogger.logCategory(LogCategory.CONFIG, GESSIFImpl.class.getName(),
				"invokeCustomQuery", GESSIFImpl.class.getSimpleName(),
				" Get Custom Query , Query Name retrieved  " + aQueryName,
				Level.INFO);
		List<String> queryParams = new ArrayList<String>();
		for (Map.Entry<String, String> entryMap : parmMap.entrySet()) {
			queryParams.add(entryMap.getValue());
		}

		String finalQuery = QueryAccess.getQuerybyName(aQueryName, queryParams);
		customQueryParamObject.setString("CustomQuery", finalQuery);
		customDataObject.setDataObject("QueryParam", customQueryParamObject);
		getDataObject.setDataObject("Payload", customDataObject);

		if (null != getService("DataAccessPartner")) {
			gesLogger.logCategory(LogCategory.CONFIG, GESSIFImpl.class
					.getName(), "invokeCustomQuery", GESSIFImpl.class
					.getSimpleName(), " About to execute Query  " + finalQuery,
					Level.INFO);

			try {
				response = (DataObject) getService("DataAccessPartner").invoke(
						"getData", getDataObject);
				gesLogger.logCategory(LogCategory.CONFIG, GESSIFImpl.class
						.getName(), "invokeCustomQuery", GESSIFImpl.class
						.getSimpleName(), "Response for Query  " + finalQuery,
						response, Level.INFO);
				customPayload = response.getDataObject("Payload ");

				gesLogger.logCategory(LogCategory.CONFIG,
						ScrubbingAIModule.class.getName(), "gesLogger",
						ScrubbingAIModule.class.getSimpleName(),
						" Result from DB", customPayload, Level.INFO);
			} catch (Exception e) {
				e.printStackTrace();

				gesLogger.logCategory(LogCategory.CONFIG,
						ScrubbingAIModule.class.getName(), "gesLogger",
						ScrubbingAIModule.class.getSimpleName(),
						"Exception occured executing custom query"
								+ e.getMessage(), Level.SEVERE);
				throw new ServiceBusinessException(
						"No Results obtained from DB , Please check your query : "
								+ finalQuery);
			}
		} else {

			throw new ServiceBusinessException(
					"Unable to locate DataAccessParner , Please check whether the service is available ");

		}

		return customPayload;
	}
}
