package com.us.chartisinsurance.ges.handlers.jax.ws.custom;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.soap.SOAPBody;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

public class GenericWSHandler implements SOAPHandler<SOAPMessageContext> {

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		try {

			// Setting UserDefined Exception

			
			
			SOAPMessage soapMessage = context.getMessage();

			SOAPBody soapBody = soapMessage.getSOAPBody();

			SOAPFault soapFault = soapBody.getFault();
			
		
			
			if(soapFault!=null)
			{
				
			
				String faultString = soapFault.getFaultString();
			     
			
				faultString = faultString.substring(faultString.lastIndexOf("is")+2);
				soapFault.setFaultString(faultString);
				
				
			}
			return true;

		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		// TODO Auto-generated method stub

		try {

			// Setting UserDefined Exception

			 
			
			SOAPMessage soapMessage = context.getMessage();
        
			SOAPBody soapBody = soapMessage.getSOAPBody();

			SOAPFault soapFault = soapBody.getFault();
			if(soapFault!=null)
			{
				String faultString = soapFault.getFaultString();

			
				faultString = "Failed to create policy option";
				soapFault.setFaultString(faultString);
				
			}
			return true;

		} catch (SOAPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}

}
