/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;

/**
 * @author ASurendr
 * 
 */
public class LogUtils {

	/**
	 * 
	 */

	public static final GESLoggerV4 gesLogger = GESLoggerFactory.getLogger();

	public LogUtils() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		disableSysOut();
	}

	/*
	 * public static String setLogLevel(String logLevel) {
	 * 
	 * String updatedLevel = "";
	 * 
	 * String currentLevel = LogManager.getRootLogger().getLevel().toString();
	 * 
	 * Level derivedLevel = Level.ERROR; if (null != logLevel &&
	 * logLevel.length() != 0) { if ("ERROR".equalsIgnoreCase(logLevel)) {
	 * derivedLevel = Level.ERROR; } if ("INFO".equalsIgnoreCase(logLevel)) {
	 * derivedLevel = Level.INFO; } if ("WARN".equalsIgnoreCase(logLevel)) {
	 * derivedLevel = Level.WARN; } }
	 * LogManager.getRootLogger().setLevel(derivedLevel); updatedLevel =
	 * LogManager.getRootLogger().getLevel().toString();
	 * gesLogger.logInfo(LogUtils.class.getName(), "setLogLevel",
	 * LogUtils.class.getSimpleName(), "Updated Log Level for Logger : " +
	 * updatedLevel);
	 * 
	 * return updatedLevel; }
	 */
	public static String setLogLevel(String logLevel, String loggerName,
			LogManager logManager) {

		String updatedLevel = "";

		Logger currentLogger = logManager.getLogger(loggerName);
		String currentLevel = currentLogger.getLevel().toString();

		gesLogger.logInfo(LogUtils.class.getName(), "setLogLevel",
				LogUtils.class.getSimpleName(),
				"Current Log Level for Logger : " + currentLevel);

		Level derivedLevel = Level.SEVERE;
		if (null != logLevel && logLevel.length() != 0) {
			if ("ERROR".equalsIgnoreCase(logLevel)) {
				derivedLevel = Level.SEVERE;
			}
			if ("INFO".equalsIgnoreCase(logLevel)) {
				derivedLevel = Level.INFO;
			}
			if ("WARN".equalsIgnoreCase(logLevel)) {
				derivedLevel = Level.WARNING;
			}
			if ("FINEST".equalsIgnoreCase(logLevel)) {
				derivedLevel = Level.FINEST;
			}
		}

		Handler[] handlers = currentLogger.getHandlers();

		for (Handler handler : handlers) {
			if ("FileHandler".equalsIgnoreCase(handler.getClass()
					.getSimpleName())) {
				{
					handler.setLevel(derivedLevel);
				}
			}
		}
		currentLogger.setLevel(derivedLevel);
		updatedLevel = currentLogger.getLevel().toString();
		gesLogger.logInfo(LogUtils.class.getName(), "setLogLevel",
				LogUtils.class.getSimpleName(),
				"Updated Log Level for Logger : " + updatedLevel);

		return updatedLevel;
	}

	/*
	 * public static String setLogLevel(String logLevel, String category) {
	 * 
	 * String updatedLevel = "";
	 * 
	 * /* String currentLevel = getLogLevel(category).toString();
	 * gesLogger.logSevere(LogUtils.class.getName(), "setLogLevel",
	 * LogUtils.class.getSimpleName(), "Current Log Level for Logger : " +
	 * currentLevel); gesLogger.logInfo(LogUtils.class.getName(), "setLogLevel",
	 * LogUtils.class.getSimpleName(), "Current Log Level for Logger : " +
	 * currentLevel + "Incoming Log LEVEL" + logLevel);
	 * 
	 * // GESLog4JLogger.initializeLoggerWithUserOptions(logLevel);
	 * Logger.getLogger(category).setLevel(Level.toLevel(logLevel));
	 * updatedLevel = Logger.getLogger(category).getLevel().toString();
	 * gesLogger.logInfo(LogUtils.class.getName(), "setLogLevel",
	 * LogUtils.class.getSimpleName(), "Updated Log Level for Logger : " +
	 * updatedLevel);
	 * 
	 * return updatedLevel; }
	 */
	/*
	 * public static String getLogLevel() {
	 * 
	 * String currentLevel = Logger.getRootLogger().getLevel().toString();
	 * 
	 * return currentLevel; }
	 */
	public static String getLogLevel(String Category) {

		String currentLevel = Logger.getLogger(Category).getLevel().toString();

		return currentLevel;
	}

	public static void disableSysOut() {
		PrintStream printStream = System.out;
		boolean debug = true;
		if (!debug) {
			System.setOut(new PrintStream(new OutputStream() {

				@Override
				public void write(int b) throws IOException {
					// TODO Auto-generated method stub

				}
			}));
		}
		long a = System.currentTimeMillis();
		for (int i = 0; i < 1000000; i++) {

		}

		long b = System.currentTimeMillis() - a;

		System.setOut(printStream);

	}

	public static void addNewLoggers(String category, String aLogLevel,
			String[] newAppenders) {

	}
}
