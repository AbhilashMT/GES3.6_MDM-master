/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.wsspi.sca.container.Container;
import com.ibm.wsspi.sca.scdl.Reference;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.aig.ges.dataobject.utils.DataObjectUtils;
import com.us.chartisinsurance.ges.db.utils.QueryAccess;
import com.us.chartisinsurance.ges.db.utils.QueryAccessBundle;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;

/**
 * @author Asurendr
 * 
 */
public class ScrubbingAIModule {

	/**
	 * 
	 */

	private static final GESLoggerV4 ScrubbingAIModuleLogger = GESLoggerFactory
			.getLogger();

	private static final String MDMATTRIBUTEXSL_FILE = "MDMAttributeCheck_custom.xsl";

	public ScrubbingAIModule() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static DataObject updateContext(DataObject aDobj) {
		ScrubbingAIModuleLogger.entering(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Context Supplied to update ", aDobj);
		int totalLocations = aDobj.getInt("sendMessageRequest/NoOfLocations");

		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Total Locations in the batch -- > " + totalLocations);

		int sMaxFetchSize = Integer.parseInt(GESCacheLoader.getValueFromCache(
				GESConstantBundle.SCRUBBING_MAXFETCH).toString());
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Max Fetch Size  from Cache  -- > " + sMaxFetchSize);
		int sInitSize = Integer.parseInt(GESCacheLoader.getValueFromCache(
				GESConstantBundle.SCRUBBING_INITIALFETCH).toString());
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Inital Fetch Size  from Cache -- > " + sInitSize);

		boolean isSequenced = Boolean.valueOf(GESCacheLoader.getValueFromCache(
				GESConstantBundle.SCRUBBING_ISSEQUENCED).toString());
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Initial isSequenced Value  from Cache -- > " + isSequenced);
		boolean isAlgEnabled = Boolean.valueOf(GESCacheLoader
				.getValueFromCache(GESConstantBundle.SCRUBBING_ISALGENABLED)
				.toString());
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Initial isAlgEnabled Value  from Cache -- > " + isAlgEnabled);

		boolean isBatchEnabled = Boolean.valueOf(GESCacheLoader
				.getValueFromCache(GESConstantBundle.SCRUBBING_ISBATCHENABLED)
				.toString());
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"updateContext", ScrubbingAIModule.class.getSimpleName(),
				"Initial isBatchEnabled Value  from Cache -- > "
						+ isBatchEnabled);

		if (0 != totalLocations) {
			if (totalLocations <= 1) {

				if (isSequenced) {
					ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class
							.getName(), "updateContext",
							ScrubbingAIModule.class.getSimpleName(),
							"These locations fall within range  -- > " + "{"
									+ sInitSize + " , " + sMaxFetchSize
									+ " } and can be processed as a Sequence");
					aDobj.setBoolean("IsSequenced", true);
				}
			} else {
				if (isBatchEnabled) {
					ScrubbingAIModuleLogger.logSevere(ScrubbingAIModule.class
							.getName(), "updateContext",
							ScrubbingAIModule.class.getSimpleName(),
							"Locations are too many and fall out of range -->  "
									+ "{" + sInitSize + " , " + sMaxFetchSize
									+ " } Total Locations to process --- > "
									+ totalLocations);

					int batchSize = Integer.parseInt(GESCacheLoader
							.getValueFromCache(
									GESConstantBundle.SCRUBBING_BATCHSIZE)
							.toString());
					ScrubbingAIModuleLogger.logSevere(ScrubbingAIModule.class
							.getName(), "updateContext",
							ScrubbingAIModule.class.getSimpleName(),
							"Considering to Split the Batch size further by  "
									+ batchSize);
					aDobj.setInt("batchSize", batchSize);
					aDobj.setBoolean("IsBatchEnabled", true);
				}
			}
		}

		return aDobj;
	}

	public static int genRandom() {

		int randomNum = 0;

		randomNum = new Random().nextInt(10);

		return randomNum % 2;
	}

	public int calculateNoOfThreads(String locationCount) {

		int locCount = 0;

		try {
			locCount = Integer.parseInt(locationCount);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return locCount;
	}

	public static boolean getPBBIError() {

		boolean pbbiErrorObtained = false;

		String pbbiErrorData = getPBBIConfigFromDB();
		if (null != pbbiErrorData) {
			GESCacheLoader.setValueToCache(
					GESConstantBundle.SCRUBBING_PBBI_ERROR, pbbiErrorData);

			pbbiErrorObtained = true;
			ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
					ScrubbingAIModule.class.getName(), "getPBBIError",
					ScrubbingAIModule.class.getSimpleName(),
					" PBBI Config value from DB: " + pbbiErrorData, Level.INFO);

		}

		return pbbiErrorObtained;
	}

	private static Service _DataAccessPartner = null;

	public static Service locateService_DataAccessPartner() {
		if (_DataAccessPartner == null) {

			if (checkReferenceExists("DataAccessPartner")) {
				_DataAccessPartner = (Service) ServiceManager.INSTANCE
						.locateService("DataAccessPartner");
			}
		}
		return _DataAccessPartner;
	}

	public static String getPBBIConfigFromDB() {
		String value = null;
		if (null == GESCacheLoader
				.getValueFromCache(GESConstantBundle.SCRUBBING_PBBI_ERROR)) {

			ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
					ScrubbingAIModule.class.getName(), "getPBBIError",
					ScrubbingAIModule.class.getSimpleName(),
					" Get PBBI Config from Database  ", Level.INFO);

			BOFactory boFactory = (BOFactory) ServiceManager.INSTANCE
					.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject getDataObject = boFactory.create(
					"http://GES_Lib_DataAccess/it/DataAccess", "GetDataType");
			DataObject customDataObject = boFactory.create(
					"http://aig.us.com/ges/schema/da/DataAccessV1_0",
					"GetCustomDataType");
			DataObject customQueryParamObject = boFactory.create(
					"http://aig.us.com/ges/schema/da/DataAccessV1_0",
					"CustomQueryParamType");

			String queryname = QueryAccessBundle.PBBIConfigQuery;
			ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
					ScrubbingAIModule.class.getName(), "getPBBIError",
					ScrubbingAIModule.class.getSimpleName(),
					" Get PBBI Config from Database , Query Name retrieved  "
							+ queryname, Level.INFO);
			List<String> queryParams = new ArrayList<String>();
			queryParams.add("1");

			String finalQuery = QueryAccess.getQuerybyName(queryname,
					queryParams);
			customQueryParamObject.setString("CustomQuery", finalQuery);
			customDataObject
					.setDataObject("QueryParam", customQueryParamObject);
			getDataObject.setDataObject("Payload", customDataObject);

			if (null != locateService_DataAccessPartner()) {
				ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
						ScrubbingAIModule.class.getName(), "getPBBIError",
						ScrubbingAIModule.class.getSimpleName(),
						" About to execute Query  " + queryname, Level.INFO);

				try {
					DataObject response = (DataObject) locateService_DataAccessPartner()
							.invoke("getData", getDataObject);
					ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
							ScrubbingAIModule.class.getName(), "getPBBIError",
							ScrubbingAIModule.class.getSimpleName(),
							"Response from Query  " + queryname, response,
							Level.INFO);
					DataObject payLoad = response.getDataObject("Payload ");
					DataObject SPResult = (DataObject) ((DataObject) payLoad
							.getList("SPResults").get(0)).getList("SPResult")
							.get(0);
					DataObject ResultRow = (DataObject) SPResult.getDataObject(
							"ResultRows").getList("ResultRow").get(0);
					DataObject ColumnRecord = (DataObject) ResultRow
							.getDataObject("ColumnRecords").getList(
									"ColumnRecord").get(0);
					value = ColumnRecord.getString("ColumnValue");
					GESCacheLoader.setValueToCache(
							GESConstantBundle.SCRUBBING_PBBI_ERROR, value);
					ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
							ScrubbingAIModule.class.getName(), "getPBBIError",
							ScrubbingAIModule.class.getSimpleName(),
							"Query Value   " + value, Level.INFO);
				} catch (Exception e) {
					e.printStackTrace();

					ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
							ScrubbingAIModule.class.getName(), "getPBBIError",
							ScrubbingAIModule.class.getSimpleName(),
							"Exception occured during obtaining PBBI Config "
									+ e.getMessage(), Level.SEVERE);
				}
			}
		} else {

			if (null != GESCacheLoader
					.getValueFromCache(GESConstantBundle.SCRUBBING_PBBI_ERROR)) {
				value = GESCacheLoader.getValueFromCache(
						GESConstantBundle.SCRUBBING_PBBI_ERROR).toString();
			}
		}
		ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
				ScrubbingAIModule.class.getName(), "getPBBIError",
				ScrubbingAIModule.class.getSimpleName(),
				" Get PBBI Config from Database  Value --> " + value,
				Level.INFO);
		return value;
	}

	public static String getSingleValuedResult(DataObject aCustomQueryResponse) {

		String value = "";
		ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
				ScrubbingAIModule.class.getName(), "getPBBIError",
				ScrubbingAIModule.class.getSimpleName(), "Query Response BO ",
				aCustomQueryResponse, Level.INFO);
		DataObject payLoad = aCustomQueryResponse.getDataObject("Payload ");
		DataObject SPResult = (DataObject) ((DataObject) payLoad.getList(
				"SPResults").get(0)).getList("SPResult").get(0);
		DataObject ResultRow = (DataObject) SPResult
				.getDataObject("ResultRows").getList("ResultRow").get(0);
		DataObject ColumnRecord = (DataObject) ResultRow.getDataObject(
				"ColumnRecords").getList("ColumnRecord").get(0);
		value = ColumnRecord.getString("ColumnValue");

		return value;
	}

	public static boolean checkReferenceExists(String aReferenceName) {
		boolean exists = false;
		ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
				ScrubbingAIModule.class.getName(), "getPBBIError",
				ScrubbingAIModule.class.getSimpleName(),
				" Does the reference  --> " + aReferenceName
						+ " Exist in the Context ? ", Level.INFO);
		List<Reference> scaReferences = Container.INSTANCE.getComponent()
				.getReferences();

		for (Reference aSCAReference : scaReferences) {
			ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
					ScrubbingAIModule.class.getName(), "getPBBIError",
					ScrubbingAIModule.class.getSimpleName(),
					" Available References  " + aSCAReference.getName(),
					Level.INFO);
		}

		if (null != Container.INSTANCE.getComponent().getReference(
				aReferenceName)) {

			exists = true;
			ScrubbingAIModuleLogger.logCategory(LogCategory.CONFIG,
					ScrubbingAIModule.class.getName(), "getPBBIError",
					ScrubbingAIModule.class.getSimpleName(),
					" Does the reference  --> " + aReferenceName
							+ " Exist in the Context ? " + exists, Level.INFO);

		}

		return exists;
	}

	public static boolean isMDMRequired(DataObject aSovLocation) {

		boolean isMDMRequired = false;

		String XSLSource = getFileAsString(MDMATTRIBUTEXSL_FILE);

		String aXMLString = DataObjectUtils.dataObjectToString(aSovLocation,
				"sovLocation");

		String isMDMRequiredString = executeXSL(aXMLString, XSLSource);

		isMDMRequired = Boolean.parseBoolean(isMDMRequiredString);
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"isMDMRequired", ScrubbingAIModule.class.getSimpleName(),
				" Attribute Verification Complete , Is Location elgible for MDM Ingestion  ? "
						+ isMDMRequiredString);
		return isMDMRequired;
	}

	public static String executeXSL(String aXMLString, String aXSLSource) {

		StopWatch sw = new StopWatch();
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"executeXSL", ScrubbingAIModule.class.getSimpleName(),
				" Attribute Verification Start XSL Execute ");
		sw.start();
		String htmlString = "";
		try {
			Source xsltSource = new StreamSource(new StringReader(aXSLSource));
			Source xmlSource = new StreamSource(new StringReader(aXMLString));
			TransformerFactory txFactory = TransformerFactory.newInstance();
			// Templates cachedTemplate = txFactory.newTemplates(xsltSource);
			Transformer xslTransformer = txFactory.newTransformer(xsltSource);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			StreamResult xsltResult = new StreamResult(baos);
			xslTransformer.transform(xmlSource, xsltResult);

			htmlString = new String(((ByteArrayOutputStream) xsltResult
					.getOutputStream()).toByteArray());

	

		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sw.stop();

		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"executeXSL", ScrubbingAIModule.class.getSimpleName(),
				" Attribute Verification Start XSL End : Time taken to execute :  "
						+ sw.getTime() + " milliseconds");
		return htmlString;
	}

	public static String getFileAsString(String aFileName) {
		InputStream is = null;
		String responseContent = "";
		is = (InputStream) EMAILTaskExecutor.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/common/utils/"
						+ aFileName);

		if (null != is) {

			InputStreamReader reader = new InputStreamReader(is);
			responseContent = getStringFromInputStream(is);

			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}
		return responseContent;
	}

	public static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}

	public static String getTranslatedPrecision(String aPrecision) {
		String translatedPrecision = "Centroid";

		if (StringUtils.isNotBlank(aPrecision)
				&& StringUtils.isNotEmpty(aPrecision)) {

			if (null != GESCacheLoader.getValueFromCache(aPrecision)) {
				translatedPrecision = GESCacheLoader.getValueFromCache(
						aPrecision).toString();
			}

		}
		ScrubbingAIModuleLogger.logInfo(ScrubbingAIModule.class.getName(),
				"getTranslatedPrecision", ScrubbingAIModule.class
						.getSimpleName(),
				"Translated Precision for Precision  " + aPrecision + " is : "
						+ translatedPrecision);
		return translatedPrecision;
	}

}
