/**
 * 
 */
package com.us.chartisinsurance.ges.logger;


/**
 * @author ASurendr
 * 
 */

public class GESLoggerFactory {

	/**
	 * 
	 */

	public GESLoggerFactory() {
		// TODO Auto-generated constructor stub
	}

	public static void cleanUpLogger(GESLoggerV4 gesLogger) {

	}

	public static GESLoggerV4 getLogger() {

		return GESLoggerV4.getGesLogger();
	}
}
