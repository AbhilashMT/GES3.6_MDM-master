/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author ASurendr
 * 
 */
public class GESLoggerRejectionHandler implements RejectedExecutionHandler {

	/**
	 * 
	 */
	private String rejectName;

	public GESLoggerRejectionHandler(String rejectName) {
		super();
		this.rejectName = rejectName;
	}

	public GESLoggerRejectionHandler() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * java.util.concurrent.RejectedExecutionHandler#rejectedExecution(java.
	 * lang.Runnable, java.util.concurrent.ThreadPoolExecutor)
	 */
	@Override
	public void rejectedExecution(Runnable paramRunnable,
			ThreadPoolExecutor paramThreadPoolExecutor) {

		System.out.println("Task Rejected : " + this.rejectName
				+ " Retrying Task after delay ");

		try {
			Thread.sleep(1000);

			//GESLoggerV4.loggingService.submit(paramRunnable);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
