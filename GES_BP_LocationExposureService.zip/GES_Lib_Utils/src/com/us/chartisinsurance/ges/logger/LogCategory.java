package com.us.chartisinsurance.ges.logger;

public interface LogCategory {

	public final static String PBBI = "PBBI";
	public final static String MDM = "MDM";
	public final static String CONFIG = "CONFIG";
	public final static String EPR = "EPR";
	public final static String EMAIL = "EMAIL";
	public final static String CLEANSING = "CLEANSING";
	public final static String MONITOR = "MONITOR";
	public final static String DBUPDATE = "DBUPDATE";
	public final static String MATCH = "MATCHCONFIG";
	public final static String SUSPECTS = "SUSPECTS";

	public final static String CustomLoggers = "PBBI,MDM,EPR,CONFIG,EMAIL,CLEANSING,MONITOR,DBUPDATE,GESLoggerV36,MATCHCONFIG,SUSPECTS";

}
