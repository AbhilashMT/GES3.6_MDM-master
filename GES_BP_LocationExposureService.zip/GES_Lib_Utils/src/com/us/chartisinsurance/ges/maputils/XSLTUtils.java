/**
 * 
 */
package com.us.chartisinsurance.ges.maputils;

import java.math.BigInteger;
import java.util.UUID;

/**
 * @author Asurendr
 * 
 */
public class XSLTUtils {

	private static final String MDM_CONSTRUCTION_OCCUPANCY_SEP = "-";

	public static BigInteger getIntValue(String aStringVal) {

		BigInteger result = new BigInteger("0");
		try {
			if (null != aStringVal) {
				result = new BigInteger(aStringVal);

			}

		} catch (NumberFormatException e) {

		}
		return result;
	}

	public static String getStringValue(int aIntVal) {

		String result = "";
		try {
			result = Integer.toString(aIntVal);
		} catch (Exception e) {

		}
		return result;
	}

	public static long getLongValue(int aIntVal) {

		long result = 0L;
		try {
			result = Long.parseLong(Integer.toString(aIntVal));
		} catch (Exception e) {

		}
		return result;
	}

	public static Integer getIntegerValue(int aIntval) {
		return new Integer(aIntval);
	}

	// public static void main(String[] args) {
	// getIntValue("Hello");
	// }
	public static String concatAddressLines(String aAddrL1, String aAddrL3,
			String aAddrL4, String aExtAddr) {
		String finalAddress = "";
		StringBuffer strBuff = new StringBuffer(finalAddress);
		boolean flag = false;
		if (null != aAddrL1 && aAddrL1.length() != 0) {
			strBuff.append(aAddrL1);
			flag = true;
		}
		/*
		 * if (null != aAddrL2 && aAddrL2.length() != 0) { strBuff.append(",");
		 * strBuff.append(aAddrL2); }
		 */
		if (null != aAddrL3 && aAddrL3.length() != 0) {
			if (flag)
				strBuff.append(",");
			flag = true;
			strBuff.append(aAddrL3);
		}
		if (null != aAddrL4 && aAddrL4.length() != 0) {
			if (flag)
				strBuff.append(",");
			flag = true;
			strBuff.append(aAddrL4);
		}
		if (null != aExtAddr && aExtAddr.length() != 0) {
			if (flag)
				strBuff.append(",");
			strBuff.append(aExtAddr);
		}
		finalAddress = strBuff.toString().trim();
		return finalAddress;

	}

	public static long generateRequesterId() {
		UUID uid = UUID.randomUUID();
		return Math.abs(uid.getMostSignificantBits());
	}

	public static String getGESConstructionCodeOrOccupancyCode(
			String aMdmConstructionCodeOrOccupancyCode) {

		String result = "";
		if (null != aMdmConstructionCodeOrOccupancyCode
				&& aMdmConstructionCodeOrOccupancyCode.length() > 0
				&& aMdmConstructionCodeOrOccupancyCode
						.indexOf(MDM_CONSTRUCTION_OCCUPANCY_SEP) != -1) {
			result = aMdmConstructionCodeOrOccupancyCode
					.split(MDM_CONSTRUCTION_OCCUPANCY_SEP)[0];

		} else if (null != aMdmConstructionCodeOrOccupancyCode
				&& aMdmConstructionCodeOrOccupancyCode
						.indexOf(MDM_CONSTRUCTION_OCCUPANCY_SEP) == -1) {
			result = aMdmConstructionCodeOrOccupancyCode;
		}
		return result;

		// To DO
	}

	public static String getGESConstructionSchemeOrOccupancyScheme(
			String aMdmConstructionCodeOrOccupancyCode) {

		String result = "";
		if (null != aMdmConstructionCodeOrOccupancyCode
				&& aMdmConstructionCodeOrOccupancyCode.length() > 0
				&& aMdmConstructionCodeOrOccupancyCode
						.indexOf(MDM_CONSTRUCTION_OCCUPANCY_SEP) != -1) {
			result = aMdmConstructionCodeOrOccupancyCode
					.split(MDM_CONSTRUCTION_OCCUPANCY_SEP)[1];
		}

		return result;

		// To DO
	}

	public static String setMDMGESConstructionCodeOrOccupancyCode(
			String aGesConstructionCodeOrOccupancyCode,
			String aGesConstructionSchemeOrOccupancyScheme) {

		String result = "";
		if (null != aGesConstructionCodeOrOccupancyCode
				&& aGesConstructionCodeOrOccupancyCode.length() > 0
				&& null != aGesConstructionSchemeOrOccupancyScheme
				&& aGesConstructionSchemeOrOccupancyScheme.length() > 0) {
			result = aGesConstructionCodeOrOccupancyCode + "-"
					+ aGesConstructionSchemeOrOccupancyScheme;
		} else if (null == aGesConstructionSchemeOrOccupancyScheme) {
			result = aGesConstructionCodeOrOccupancyCode;
		} else if ("".equalsIgnoreCase(aGesConstructionSchemeOrOccupancyScheme)) {
			result = aGesConstructionCodeOrOccupancyCode;
		}
		return result;

		// To DO
	}

	public static String setStandardizeFlag(String autoScrubFlag) {
		String result = "N";
		if (null != autoScrubFlag && autoScrubFlag.length() > 0) {

			if ("Y".equalsIgnoreCase(autoScrubFlag)) {
				result = "Y";
			} else {
				result = "N";
			}

		}
		return result;
	}

	public static void main(String[] args) {


	}

	public static String setFailureReason(String aFailInfo) {

		String excepCode = "System exception occurred during StandardizeAndAugment Location process. "
				+ aFailInfo;
		return excepCode;
	}

	public static String getString(String aString, int index) {

		String result = "";
		if (null != aString) {
			if (aString.length() >= index) {
				result = aString.substring(0, index);
			} else {
				result = aString;
			}
		}
		return result;
	}

	public static String getFormatPBErrorMsg(String addrError,
			String addrStatus, String geoAddrDesc) {

		StringBuffer msg = new StringBuffer();

		if (addrError != null && addrError.trim().length() > 0) {
			msg.append("<ERRORS>" + addrError + "</ERRORS>");
		}
		// if (addrStatus != null && addrStatus.trim().length() > 0) {
		// if (msg.length() > 0) {
		// msg.append(",");
		// }
		// msg.append(addrStatus);
		// }
		// if (geoAddrDesc != null && geoAddrDesc.trim().length() > 0) {
		// if (msg.length() > 0) {
		// msg.append(",");
		// }
		// msg.append(geoAddrDesc);
		// }
		return msg.toString();
	}

}
