/**
 * 
 */
package com.us.chartisinsurance.ges.maputils;

import java.util.ArrayList;
import java.util.List;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.ServiceManager;
import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import commonj.sdo.DataObject;

/**
 * @author araju
 * 
 */

public class MapUtils {
	private static BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");

	private static DataObject inputSMO_body;
	private static String PB_MULTI_MATCH = "";
	private static String MDM_DEDUP_EXCP = "";
	private static String PENDING_DA = "";
	private static String COMPLETED = "";
	private static DataObject inputSMO_TranContext;

	// private static DataObject pbbi_doNotAutoScrub_LocationsArray;
	// private static List pbbi_doNotAutoScrub_LocationsArray_list = new
	// ArrayList<DataObject>();
	// private static DataObject pbbi_autoScrub_LocationsArray;
	// private static List pbbi_autoScrub_LocationsArray_list = new
	// ArrayList<DataObject>();

	// private static DataObject update_autoScrub_LocationsArray;
	// private static List update_autoScrub_LocationsArray_list = new
	// ArrayList<DataObject>();
	// private static DataObject update_doNotAutoScrub_LocationsArray;
	// private static List update_doNotAutoScrub_LocationsArray_list = new
	// ArrayList<DataObject>();

	public static DataObject response = null;

	private static int score_0 = 0;
	private static int score_90 = 90;
	private static int score_100 = 100;

	// private static int matchScore;
	// private static List MatchLocList = new ArrayList();

	public static synchronized DataObject prepareFilterRecordsResponse(
			ServiceMessageObject aInputSMO, DataObject aFilterRecordsResult) {

		List mdmExceptionlocations_LocationsArray_list = new ArrayList<DataObject>();
		List pbbi_multipleMatchExceptions_LocationsArray_list = new ArrayList<DataObject>();
		List newlocations_LocationsArray_list = new ArrayList<DataObject>();

		DataObject pbbiExceptionLocations = bof.create(
				"http://aig.us.com/ges/schema", "pbbiExceptions");
		DataObject mdmExceptionLocations = bof.create(
				"http://aig.us.com/ges/schema", "mdmExceptions");
		// DataObject updatedLocations = bof
		// .create("http://aig.us.com/ges/schema",
		// "updatedLocations");
		DataObject newLocations = bof.create(
				"http://aig.us.com/ges/schema", "newLocations");
		DataObject newlocations_LocationsArray = bof.create(
				"http://aig.us.com/ges/schema", "LocationsArray");

		DataObject pbbi_multipleMatchExceptions_LocationsArray = bof.create(
				"http://aig.us.com/ges/schema", "LocationsArray");
		DataObject CommonServiceTransientContext;

		DataObject mdmExceptionlocations_LocationsArray = bof.create(
				"http://aig.us.com/ges/schema", "LocationsArray");
		CommonServiceTransientContext = aInputSMO
				.getDataObject("context/transient");

		PB_MULTI_MATCH = CommonServiceTransientContext
				.getString("PB_MULTI_MATCH");
		MDM_DEDUP_EXCP = CommonServiceTransientContext
				.getString("MDM_DEDUP_EXCP");

		PENDING_DA = CommonServiceTransientContext.getString("PENDING_DA");
		inputSMO_body = aInputSMO.getDataObject("body");
		if (null != inputSMO_body) {
			if (null != inputSMO_body
					.getDataObject("filterRecordsRequestParameter/filterRecordsInput/arrayOfLocations")) {
				List locationList = inputSMO_body
						.getDataObject(
								"filterRecordsRequestParameter/filterRecordsInput/arrayOfLocations")
						.getList("location");

				for (Object obj : locationList) {
					DataObject LocationDO = (DataObject) obj;

					if (null != LocationDO.getDataObject("sovLocation")) {

						DataObject sovLocation = LocationDO
								.getDataObject("sovLocation");
						if (sovLocation.isSet("esbCrossReferenceInfo")
								&& !(sovLocation
										.getList("esbCrossReferenceInfo")
										.isEmpty())) {
							DataObject esbCrossReferenceInfo = (DataObject) sovLocation
									.getList("esbCrossReferenceInfo").get(0);

							if (PB_MULTI_MATCH
									.equalsIgnoreCase(esbCrossReferenceInfo
											.getString("prcsngStatCd"))) {

								pbbi_multipleMatchExceptions_LocationsArray_list
										.add(LocationDO);

							}
							if (MDM_DEDUP_EXCP
									.equalsIgnoreCase(esbCrossReferenceInfo
											.getString("prcsngStatCd"))) {

								mdmExceptionlocations_LocationsArray_list
										.add(LocationDO);

							}
							if (PENDING_DA
									.equalsIgnoreCase(esbCrossReferenceInfo
											.getString("prcsngStatCd"))) {

								newlocations_LocationsArray_list
										.add(LocationDO);

							}
							if (COMPLETED
									.equalsIgnoreCase(esbCrossReferenceInfo
											.getString("prcsngStatCd"))) {

								mdmExceptionlocations_LocationsArray_list
										.add(LocationDO);

							}

						}

					}
				}
				pbbi_multipleMatchExceptions_LocationsArray.setList("location",
						pbbi_multipleMatchExceptions_LocationsArray_list);
				pbbiExceptionLocations.setDataObject("multipleMatchExceptions",
						pbbi_multipleMatchExceptions_LocationsArray);
				mdmExceptionlocations_LocationsArray.setList("location",
						mdmExceptionlocations_LocationsArray_list);
				mdmExceptionLocations.setDataObject("mdmExceptionlocations",
						mdmExceptionlocations_LocationsArray);
				newlocations_LocationsArray.setList("location",
						newlocations_LocationsArray_list);
				newLocations.setDataObject("newlocations",
						newlocations_LocationsArray);
				aFilterRecordsResult.setDataObject("pbbiExceptionLocations",
						pbbiExceptionLocations);
				aFilterRecordsResult.setDataObject("mdmExceptionLocations",
						mdmExceptionLocations);
				aFilterRecordsResult
						.setDataObject("newLocations", newLocations);

				if (null != aFilterRecordsResult
						.getDataObject("pbbiExceptionLocations/multipleMatchExceptions")) {
					List PBBIMultipleMatchExceptionslocationList = aFilterRecordsResult
							.getDataObject(
									"pbbiExceptionLocations/multipleMatchExceptions")
							.getList("location");
					if (null != PBBIMultipleMatchExceptionslocationList
							&& PBBIMultipleMatchExceptionslocationList
									.isEmpty()) {
						aFilterRecordsResult.getDataObject(
								"pbbiExceptionLocations").unset(
								"multipleMatchExceptions");
					}
				}

				if (null != aFilterRecordsResult
						.getDataObject("pbbiExceptionLocations/failureExceptions")) {
					List PBBIFailureExceptionslocationList = aFilterRecordsResult
							.getDataObject(
									"pbbiExceptionLocations/failureExceptions")
							.getList("location");
					if (null != PBBIFailureExceptionslocationList
							&& PBBIFailureExceptionslocationList.isEmpty()) {
						aFilterRecordsResult.getDataObject(
								"pbbiExceptionLocations").unset(
								"failureExceptions");
					}
				}
				if (null != aFilterRecordsResult
						.getDataObject("mdmExceptionLocations/mdmExceptionlocations")) {
					List mdmExceptionlocationslocationList = aFilterRecordsResult
							.getDataObject(
									"mdmExceptionLocations/mdmExceptionlocations")
							.getList("location");
					if (null != mdmExceptionlocationslocationList
							&& mdmExceptionlocationslocationList.isEmpty()) {
						aFilterRecordsResult.getDataObject(
								"mdmExceptionLocations").unset(
								"mdmExceptionlocations");
					}
				}
				 GESLoggerFactory.getLogger()
						.logInfo(
								MapUtils.class.getName(),
								"***************************",
								"prepareFilterRecordsResponse",
								"Locations has been filtered based on ESB processing status Code ",
								aFilterRecordsResult);

			}
		}

		return aFilterRecordsResult;
	}

	public static synchronized DataObject prepareFilterRecordsMatchLocationsResponse(
			ServiceMessageObject aInputSMO, DataObject aFilterRecordsResult) {
		 GESLoggerFactory.getLogger().logInfo(MapUtils.class.getName(),
				"***************************",
				"prepareFilterRecordsMatchLocationsRequest",
				"Locations has to be filtered based on the match key ",
				aInputSMO);

		DataObject MatchLocationSOVDO;
		List Match_Locations_LocationsArrayResponse_list_100 = new ArrayList<DataObject>();
		List Match_Locations_LocationsArrayResponse_list_100_90 = new ArrayList<DataObject>();
		List Match_Locations_LocationsArrayResponse_list_0_90 = new ArrayList<DataObject>();
		DataObject Match_Locations_ArrayResponse_100 = bof.create(
				"http://aig.us.com/ges/schema", "LocationsArray");
		DataObject Match_Locations_ArrayResponse_100_90 = bof.create(
				"http://aig.us.com/ges/schema", "LocationsArray");
		DataObject Match_Locations_ArrayResponse_0_90 = bof.create(
				"http://aig.us.com/ges/schema", "LocationsArray");

		inputSMO_TranContext = aInputSMO.getDataObject("context/transient");

		if (null != inputSMO_TranContext) {
			score_0 = inputSMO_TranContext.getInt("score_0");
			score_90 = inputSMO_TranContext.getInt("score_90");
			score_100 = inputSMO_TranContext.getInt("score_100");

		

		}

		inputSMO_body = aInputSMO.getDataObject("body");
		if (null != inputSMO_body) {
			if (null != inputSMO_body
					.getDataObject("filterRecordsByMatchKeyRequestParameter/filerRecordsByMatchKeyInput/matchLocationsResponse")) {
				List MatchlocationList = inputSMO_body
						.getDataObject(
								"filterRecordsByMatchKeyRequestParameter/filerRecordsByMatchKeyInput/matchLocationsResponse")
						.getList("matchLocations");
				for (Object obj : MatchlocationList) {
					DataObject MatchLocationDO = (DataObject) obj;

					if (null != MatchLocationDO.getDataObject("matchLocations")) {

						if (score_100 == MatchLocationDO.getInt("matchScore")) {
							DataObject Location = bof
									.create(
											"http://aig.us.com/ges/schema",
											"Location");

							DataObject sovLocation = Location
									.createDataObject("sovLocation");

							MatchLocationSOVDO = MatchLocationDO
									.getDataObject("matchLocations");
							sovLocation = MatchLocationSOVDO;
							sovLocation.setInt("matchScore", score_100);
							Location.setDataObject("sovLocation", sovLocation);
							Match_Locations_LocationsArrayResponse_list_100
									.add(Location);

						}
						if ((MatchLocationDO.getInt("matchScore") >= score_90)
								&& (MatchLocationDO.getInt("matchScore") < score_100)) {
							int matchScore = MatchLocationDO
									.getInt("matchScore");
							DataObject Location = bof
									.create(
											"http://aig.us.com/ges/schema",
											"Location");
							DataObject sovLocation = Location
									.createDataObject("sovLocation");

							MatchLocationSOVDO = MatchLocationDO
									.getDataObject("matchLocations");

							sovLocation = MatchLocationSOVDO;
							sovLocation.setInt("matchScore", matchScore);
							Location.setDataObject("sovLocation", sovLocation);

							Match_Locations_LocationsArrayResponse_list_100_90
									.add(Location);

						}
						if ((MatchLocationDO.getInt("matchScore") > score_0)
								&& (MatchLocationDO.getInt("matchScore") < score_90)) {
							int matchScore = MatchLocationDO
									.getInt("matchScore");
							DataObject Location = bof
									.create(
											"http://aig.us.com/ges/schema",
											"Location");
							DataObject sovLocation = Location
									.createDataObject("sovLocation");

							MatchLocationSOVDO = MatchLocationDO
									.getDataObject("matchLocations");

							sovLocation = MatchLocationSOVDO;
							sovLocation.setInt("matchScore", matchScore);
							Location.setDataObject("sovLocation", sovLocation);

							Match_Locations_LocationsArrayResponse_list_0_90
									.add(Location);

						}
					}

				}

				Match_Locations_ArrayResponse_100.setList("location",
						Match_Locations_LocationsArrayResponse_list_100);
				Match_Locations_ArrayResponse_100_90.setList("location",
						Match_Locations_LocationsArrayResponse_list_100_90);
				Match_Locations_ArrayResponse_0_90.setList("location",
						Match_Locations_LocationsArrayResponse_list_0_90);
				aFilterRecordsResult.setDataObject("matchLocations_100",
						Match_Locations_ArrayResponse_100);
				aFilterRecordsResult.setDataObject("matchLocations_100_90",
						Match_Locations_ArrayResponse_100_90);
				aFilterRecordsResult.setDataObject("matchLocations_0_90",
						Match_Locations_ArrayResponse_0_90);
				 GESLoggerFactory.getLogger().logInfo(MapUtils.class.getName(),
						"***************************",
						"prepareFilterRecordsMatchLocationsResponse",
						"Locations has been filtered based on the match key ",
						aFilterRecordsResult);

			}
		}
		return aFilterRecordsResult;
	}

}
