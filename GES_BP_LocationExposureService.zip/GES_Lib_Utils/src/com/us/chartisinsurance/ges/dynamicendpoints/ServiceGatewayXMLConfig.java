package com.us.chartisinsurance.ges.dynamicendpoints;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.ServiceManager;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.aig.ges.dataobject.utils.DataObjectUtils;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;

/**
 * @author Kiran Miriyala
 * 
 */
public class ServiceGatewayXMLConfig {

	private static final String CONFIGURATION_FILE = "ServiceGatewayRouting.xml";
	private static XMLConfiguration xmlConfigSlave = null;
	public static HashMap<String, String> resultProperties = null;
	private static final ServiceManager sm = ServiceManager.INSTANCE;
	private static final BOFactory bof = (BOFactory) sm
			.locateService("com/ibm/websphere/bo/BOFactory");

	// read XML File to get XML Config Object

	// Get Reference Partner
	// partnerName & URI
	// Get Method
	// methodName
	// Type

	public static void prepareConfig() throws Exception {
		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				ServiceGatewayXMLConfig.class.getName(), "prepareConfig",
				ServiceGatewayXMLConfig.class.getSimpleName(),
				"prepareConfig() Entry", Level.INFO);
		InputStream is = null;
		is = (InputStream) ServiceGatewayXMLConfig.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/dynamicendpoints/"
						+ CONFIGURATION_FILE);

		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfigSlave = new XMLConfiguration();
			xmlConfigSlave.load(reader);
			xmlConfigSlave.setExpressionEngine(new XPathExpressionEngine());
			populateConfig();
			GESCacheLoader.getDbCache().put(
					GESConstantBundle.GES_GATEWAY_CONFIG, resultProperties);
		} else {
			GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
					ServiceGatewayXMLConfig.class.getName(), "prepareConfig",
					ServiceGatewayXMLConfig.class.getSimpleName(),
					"Unable to read configuration", Level.SEVERE);
			throw new Exception(" Unable to read configuration");
		}

		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				ServiceGatewayXMLConfig.class.getName(), "prepareConfig",
				ServiceGatewayXMLConfig.class.getSimpleName(),
				"prepareConfig() Exit : " + resultProperties, Level.INFO);
	}

	private static void populateConfig() {
		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				ServiceGatewayXMLConfig.class.getName(), "populateConfig",
				ServiceGatewayXMLConfig.class.getSimpleName(),
				"populateConfig() Entry : ", Level.INFO);
		if (null != xmlConfigSlave) {
			List<Object> listProperties = xmlConfigSlave.getList("/Type/@name");
			int propertySize = listProperties.size();
			resultProperties = new HashMap<String, String>();
			for (int i = 1; i <= propertySize; i++) {
				String partnerXpath = "/Type[" + i + "]"
						+ "/RoutingConfig/PartnerName";
				String partnerName = xmlConfigSlave.getString(partnerXpath);
				String methodXpath = "/Type[" + i + "]"
						+ "/RoutingConfig/MethodName";
				String methodName = xmlConfigSlave.getString(methodXpath);

				String WsdlURIXpath = "/Type[" + i + "]"
						+ "/RoutingConfig/WSDLURI";
				String WsdlURIName = xmlConfigSlave.getString(WsdlURIXpath);

				String messageXpath = "/Type[" + i + "]"
						+ "/RoutingConfig/MsgName";
				String msgName = xmlConfigSlave.getString(messageXpath);

				String typeName = xmlConfigSlave.getString("/Type[" + i
						+ "]/@name");

				String qName = xmlConfigSlave.getString("/Type[" + i
						+ "]/@qName");

				GESLoggerFactory.getLogger().logCategory(
						LogCategory.CONFIG,
						ServiceGatewayXMLConfig.class.getName(),
						"prepareConfig",
						ServiceGatewayXMLConfig.class.getSimpleName(),
						"Routing Config \n\t" + "PartnerName : " + partnerName
								+ "\n\t" + "MethodName : " + methodName
								+ "\n\t" + "WsdlQName : " + WsdlURIName
								+ "\n\t" + "ResponseMessageName : " + msgName
								+ "\n\t" + "BOTypeName : " + typeName + "\n\t"
								+ "BOTypeQName : " + qName, Level.INFO);

				DataObject routingConfig = bof.create(
						"http://GES_Lib_Common/bo", "RoutingConfig");

				/*
				 * RoutingConfig routingConfig = new RoutingConfig();
				 * 
				 * routingConfig.setMethodName(methodName);
				 * routingConfig.setPartnerName(methodName);
				 * routingConfig.setWSDLURIName(methodName);
				 * routingConfig.setMessageName(msgName);
				 */
				routingConfig.setString("PartnerName", partnerName);
				routingConfig.setString("MethodName", methodName);
				routingConfig.setString("MessageName", msgName);
				routingConfig.setString("WSDLUri", WsdlURIName);

				String routingConfigStringXML = DataObjectUtils
						.dataObjectToString(routingConfig, routingConfig
								.getType().getName());

				resultProperties.put(typeName + "_" + qName, routingConfigStringXML);

				GESLoggerFactory.getLogger().logCategory(
						LogCategory.CONFIG,
						ServiceGatewayXMLConfig.class.getName(),
						"populateConfig",
						ServiceGatewayXMLConfig.class.getSimpleName(),
						"populateConfig() Result Properties : "
								+ resultProperties, Level.INFO);
			}

		}
		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				ServiceGatewayXMLConfig.class.getName(), "populateConfig",
				ServiceGatewayXMLConfig.class.getSimpleName(),
				"populateConfig() Exit : ", Level.INFO);
	}
}
