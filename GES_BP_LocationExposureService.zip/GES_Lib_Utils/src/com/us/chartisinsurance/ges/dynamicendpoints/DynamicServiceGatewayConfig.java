package com.us.chartisinsurance.ges.dynamicendpoints;

import java.io.InputStream;
import java.util.logging.Level;

import org.apache.commons.io.IOUtils;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.LogCategory;

public class DynamicServiceGatewayConfig {
	private static final String CONFIGURATION_FILE = "GesServiceDefinition.xml";

	public static void prepareConfig() throws Exception {
		String resultData = null;
		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				DynamicServiceGatewayConfig.class.getName(), "prepareConfig",
				DynamicServiceGatewayConfig.class.getSimpleName(),
				"prepareConfig() Entry", Level.INFO);
		InputStream is = null;
		is = (InputStream) ServiceGatewayXMLConfig.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/dynamicendpoints/"
						+ CONFIGURATION_FILE);

		if (null != is) {
		
			resultData = IOUtils.toString(is);
			GESCacheLoader.getDbCache().put(
					GESConstantBundle.GES_REVIVED_GATEWAY, resultData);
		} else {
			GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
					DynamicServiceGatewayConfig.class.getName(), "prepareConfig",
					DynamicServiceGatewayConfig.class.getSimpleName(),
					"Unable to read configuration", Level.SEVERE);
			throw new Exception(" Unable to read configuration");
		}

		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				DynamicServiceGatewayConfig.class.getName(), "prepareConfig",
				DynamicServiceGatewayConfig.class.getSimpleName(),
				"prepareConfig() Exit : " + resultData, Level.INFO);
	}

	


}
