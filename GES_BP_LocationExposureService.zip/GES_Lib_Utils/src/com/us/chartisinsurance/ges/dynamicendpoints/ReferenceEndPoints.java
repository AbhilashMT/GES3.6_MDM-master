package com.us.chartisinsurance.ges.dynamicendpoints;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.cache.DistributedMap;
import com.ibm.wsspi.sibx.mediation.esb.SCAServices;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo;

public class ReferenceEndPoints {

	// public static Map<String, String> map = new HashMap<String, String>();

	static ArrayList referenceList = new ArrayList<String>();

	private static GESLoggerV4 ReferenceEndPointsLogger = GESLoggerFactory
			.getLogger();
	private static DistributedMap gesDbCache = GESCacheLoader.getDbCache();

	@Deprecated
	public static String getEndPoint(String key, String version) {
		key = key + "_" + version;
		String URL = System.getProperty(key); // map.get(key);

		ReferenceEndPointsLogger.logCategory(LogCategory.EPR,
				ReferenceEndPoints.class.getName(), "getEndPoint",
				ReferenceEndPoints.class.getName(), "  Partner Key {" + key
						+ "} available in Cache : Value " + URL, Level.INFO);

		return URL;
	}

	public static String getEndPoint(String moduleName, String key,
			String version) {
		key = moduleName + "_" + key + "_" + version;

		String URL = "";
		if (null == gesDbCache) {
			URL = System.getProperty(key);
			ReferenceEndPointsLogger.logInfo(
					ReferenceEndPoints.class.getName(), "getEndPoint",
					ReferenceEndPoints.class.getName(), "  Partner Key {" + key
							+ "} Taken from DB Cache : Value  - > " + URL);
		} else {
			URL = (String)gesDbCache.get(key);
			ReferenceEndPointsLogger.logInfo(
					ReferenceEndPoints.class.getName(), "getEndPoint",
					ReferenceEndPoints.class.getName(), "  Partner Key {" + key
							+ "} Taken from System Cache : Value  - > " + URL);

		}

		ReferenceEndPointsLogger.logCategory(LogCategory.EPR,
				ReferenceEndPoints.class.getName(), "getEndPoint",
				ReferenceEndPoints.class.getName(), "  Partner Key {" + key
						+ "} available in Cache : Value " + URL, Level.INFO);

		return URL;
	}

	public static String getEndPoint(String key, SCAServices scaService) {

		String moduleName = XMLConfig.getModuleBaseName(scaService
				.getModuleName());
		String version = MediationModuleMetaInfo.getModuleVersion(scaService);
		key = moduleName + "_" + key + "_" + version;
		String URL = "";
		if (null == gesDbCache) {
			URL = System.getProperty(key);
			ReferenceEndPointsLogger.logInfo(
					ReferenceEndPoints.class.getName(), "getEndPoint",
					ReferenceEndPoints.class.getName(), "  Partner Key {" + key
							+ "} Taken from DB Cache : Value  - > " + URL);
		} else {
			URL = gesDbCache.get(key).toString();
			ReferenceEndPointsLogger.logInfo(
					ReferenceEndPoints.class.getName(), "getEndPoint",
					ReferenceEndPoints.class.getName(), "  Partner Key {" + key
							+ "} Taken from System Cache : Value  - > " + URL);

		}
		// map.get(key);

		return URL;
	}

	public static void setEndPoint(String key, String version, String value) {
		key = key + "_" + version;
		if (null != value && value.length() != 0
				&& !key.equalsIgnoreCase("self")) {
			// map.put(key, value);
			if (null == gesDbCache) {
				System.setProperty(key, value);
			} else {
				gesDbCache.put(key, value);
			}
			ReferenceEndPointsLogger.logInfo(
					ReferenceEndPoints.class.getName(), "setEndPoint",
					ReferenceEndPoints.class.getName(), "  Partner Key {" + key
							+ "} Set Value  in Cache : Value " + value);

		}

	}

	private static boolean containsReference(String aReferenceName,
			String aVersion) {

		boolean containsRef = false;

		String key = aReferenceName + "_" + aVersion;
		// containsRef = map.containsKey(key);

		ReferenceEndPointsLogger
				.logInfo(ReferenceEndPoints.class.getName(),
						"containsReference",
						ReferenceEndPoints.class.getName(),
						" Check for Partner Key : " + key + " Exists :  "
								+ containsRef);
		ReferenceEndPointsLogger.logInfo(ReferenceEndPoints.class.getName(),
				"containsReference", ReferenceEndPoints.class.getName(),
				"  Partner Key {" + key + "} Value available in Cache ?  "
						+ containsRef);

		return containsRef;

	}

	public static void addReferences(String[] areference)

	{
		referenceList = (ArrayList) Arrays.asList(areference);

	}

}
