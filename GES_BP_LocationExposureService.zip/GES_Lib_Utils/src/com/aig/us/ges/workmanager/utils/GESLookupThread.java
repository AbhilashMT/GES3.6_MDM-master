/**
 * 
 */
package com.aig.us.ges.workmanager.utils;

import java.util.Arrays;
import java.util.logging.Level;

import com.ibm.websphere.asynchbeans.Work;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;

/**
 * @author Asurendr
 * 
 */
public class GESLookupThread implements Work {

	/**
	 * 
	 */

	private String aQueryReference;
	private String aCacheKey;
	private String[] aQueryParams;

	private boolean isSerialized = false;
	private boolean isSetupCache = false;
	private static final ServiceManager SM = ServiceManager.INSTANCE;
	private static final BOFactory bofService = (BOFactory) SM
			.locateService("com/ibm/websphere/bo/BOFactory");
	private static GESLoggerV4 GESLookupThreadLogger = GESLoggerFactory
			.getLogger();

	public GESLookupThread(String aCacheKey, String aQueryReference,
			String[] aParams) {
		super();

		this.aCacheKey = aCacheKey;
		this.aQueryReference = aQueryReference;
		this.aQueryParams = aParams;
	}

	public GESLookupThread(String aCacheKey, String aQueryReference,
			boolean aIsSerialized, String[] aParams) {
		super();

		this.aCacheKey = aCacheKey;
		this.aQueryReference = aQueryReference;
		this.aQueryParams = aParams;
		this.isSerialized = aIsSerialized;
	}

	public GESLookupThread(String aQueryReference, String[] aParams,
			boolean isSetUpCache) {
		super();

		this.aQueryReference = aQueryReference;
		this.aQueryParams = aParams;
		this.isSetupCache = isSetUpCache;
	}

	public GESLookupThread() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ibm.websphere.asynchbeans.Work#release()
	 */
	@Override
	public void release() {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
				GESLookupThread.class.getName(), "run()", GESLookupThread.class
						.getSimpleName(), "Entry - run()", Level.INFO);
		boolean isStartUpOk = false;
		if (!isSetupCache) {
			GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
					GESLookupThread.class.getName(), "run()",
					GESLookupThread.class.getSimpleName(),
					"Request for Loading Cache", Level.INFO);
			Service scaService = (Service) SM.locateService("LoadCachePartner");
			DataObject loadCacheRequest = bofService.createByElement(
					"http://aig.us.com/ges/LoadCache", "LoadCacheRequest");
			loadCacheRequest.set("Key", this.aCacheKey);

			if (null != this.aQueryReference) {
				loadCacheRequest.set("Query", this.aQueryReference);

				if (null != aQueryParams) {
					loadCacheRequest.setList("Params", Arrays
							.asList(this.aQueryParams));
				}
			}
			loadCacheRequest.setBoolean("IsSerialized", isSerialized);
			GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
					GESLookupThread.class.getName(), "run()",
					GESLookupThread.class.getSimpleName(),
					"About to Invoke Cache , loadCache Partner", Level.INFO);
			DataObject response = (DataObject) scaService.invoke("loadCache",
					loadCacheRequest);
			if (null != response) {
				isStartUpOk = response.getBoolean("cacheLoaded");
				GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
						GESLookupThread.class.getName(), "start()",
						GESLookupThread.class.getSimpleName(),
						"run() - Cache Loaded Successfully  for Key : "
								+ this.aCacheKey + " ? " + isStartUpOk,
						Level.INFO);
			}
		} else {

			GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
					GESLookupThread.class.getName(), "run()",
					GESLookupThread.class.getSimpleName(),
					"Request for SetUp Cache", Level.INFO);

			Service scaService = (Service) SM.locateService("LoadCachePartner");

			DataObject setUpCacheRequest = bofService.createByElement(
					"http://aig.us.com/ges/LoadCache", "SetUpCacheRequest");
			if (null != this.aQueryReference) {
				setUpCacheRequest.set("Query", this.aQueryReference);

				if (null != aQueryParams) {
					setUpCacheRequest.setList("Params", Arrays
							.asList(this.aQueryParams));
				}
			}
			GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
					GESLookupThread.class.getName(), "run()",
					GESLookupThread.class.getSimpleName(),
					"About to Invoke Cache , setUpCache Partner", Level.INFO);
			DataObject response = (DataObject) scaService.invoke("setUpCache",
					setUpCacheRequest);

			// Handle Response
			if (null != response) {
				isStartUpOk = response.getBoolean("cacheLoaded");
				GESLookupThreadLogger.logCategory(LogCategory.CONFIG,
						GESLookupThread.class.getName(), "start()",
						GESLookupThread.class.getSimpleName(),
						"run() - Cache Set up succesfully  ? " + isStartUpOk,
						Level.INFO);
			}

		}

	}

}
