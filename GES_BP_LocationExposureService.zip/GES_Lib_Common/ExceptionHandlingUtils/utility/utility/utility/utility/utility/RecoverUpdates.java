package ExceptionHandlingUtils.utility.utility.utility.utility.utility;
public class RecoverUpdates {
	public static commonj.sdo.DataObject recoverUpdates(commonj.sdo.DataObject inputDataObjectBody, commonj.sdo.DataObject origMessage) {
		byte __result__2 = 0;
		commonj.sdo.DataObject __result__3 = inputDataObjectBody.createDataObject(__result__2);
		byte __result__4 = 0;
		__result__3.setDataObject(__result__4, origMessage);
		return inputDataObjectBody;
	}
}