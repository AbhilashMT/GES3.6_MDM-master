package ExceptionHandlingUtils.utility.utility;
public class HandleAsyncExceptions {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject handleAsyncExceptions(com.ibm.websphere.sibx.smobo.ServiceMessageObject inputSMO, java.lang.String outputMessageName, java.lang.String outputMessageQName) {
		commonj.sdo.DataObject __result__3;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(outputMessageQName, outputMessageName));
			__result__3 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject handleRunTimeExceptionsSMOBody = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create LocationExceptionFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://aig.us.com/ges/schema","LocationExceptionFault");
		}
		commonj.sdo.DataObject LocationExceptionFault = __result__5;
		commonj.sdo.DataObject __result__7;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__7 = factory.create("http://aig.us.com/ges/common/v3","GesFaultObjectType");
		}
		commonj.sdo.DataObject GesFaultObjectType = __result__7;
		java.lang.String __result__9 = inputSMO.getContext().getFailInfo().getFailureString();
		GesFaultObjectType.setString("faultString", __result__9);
		java.lang.String __result__11 = inputSMO.getContext().getFailInfo().getOrigin();
		GesFaultObjectType.setString("faultOrigin", __result__11);
		java.util.ArrayList __result__13 = new java.util.ArrayList();
		java.util.ArrayList geFaultList = __result__13;
		boolean __result__17;
		{// add item to list
			__result__17 = geFaultList.add(GesFaultObjectType);
		}
		LocationExceptionFault.set("gesFaults", geFaultList);
		byte __result__21 = 0;
		commonj.sdo.DataObject __result__22 = handleRunTimeExceptionsSMOBody.createDataObject(__result__21);
		byte __result__23 = 0;
		__result__22.setDataObject(__result__23, LocationExceptionFault);
		java.lang.String __result__27 = "..";
		commonj.sdo.DataObject __result__28 = handleRunTimeExceptionsSMOBody.getDataObject(__result__27);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)__result__28;
	}
}