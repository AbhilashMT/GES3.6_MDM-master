package BPCUtils.utility;
public class BPCLogger_LogFinestPlain {
	public static void bPCLogger_LogFinestPlain(com.ibm.bpe.api.ActivityInstanceData ActivityInstanceData, com.ibm.bpe.api.ProcessInstanceData ProcessInstanceData, java.lang.String InputMessage, java.lang.String ValueToLog)throws com.ibm.websphere.sca.ServiceRuntimeException  {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = ActivityInstanceData.getApplicationName();
		java.lang.String __result__5 = ProcessInstanceData.getParentProcessInstanceName();
		java.lang.String __result__7 = ProcessInstanceData.getProcessTemplateName();
		java.lang.String __result__9 = "    ";
		java.lang.String __result__10;
		{// append text
			__result__10 = InputMessage.concat(__result__9);
		}
		java.lang.String __result__12;
		{// append text
			__result__12 = __result__10.concat(ValueToLog);
		}
		try {
			__result__1.logFinest(__result__3, __result__5, __result__7, __result__12);
		}
		catch(com.ibm.websphere.sca.ServiceRuntimeException ex){
			throw ex;
		}
	}
}