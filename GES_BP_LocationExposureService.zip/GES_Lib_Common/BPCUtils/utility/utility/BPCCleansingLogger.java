package BPCUtils.utility.utility;
public class BPCCleansingLogger {
	public static void bPCCleansingLogger(java.lang.String SovId, java.lang.String SovVersionId, java.lang.Object LocationId, java.lang.String ScrubbingStatus, commonj.sdo.DataObject aDataObject) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		com.us.chartisinsurance.ges.logger.GESLoggerV4 GESLogger = __result__1;
		boolean __result__3 = null == aDataObject;
		if (__result__3){
			java.lang.String __result__9 = LocationId.toString();
			GESLogger.logGESCleansingNoBO(SovId, SovVersionId, __result__9, ScrubbingStatus);
		}
		else{
			java.lang.String __result__16 = LocationId.toString();
			GESLogger.logGESCleansing(SovId, SovVersionId, __result__16, ScrubbingStatus, aDataObject);
		}
	}
}