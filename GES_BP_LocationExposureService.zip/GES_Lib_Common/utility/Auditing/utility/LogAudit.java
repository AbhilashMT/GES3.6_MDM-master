package utility.Auditing.utility;
public class LogAudit {
	public static void logAudit(commonj.sdo.DataObject smoInput, com.ibm.wsspi.sibx.mediation.esb.SCAServices SCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MediationServices, java.lang.String mode) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__6 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = SCAServices.getComponentName();
		java.lang.String __result__8 = SCAServices.getModuleName();
		java.lang.String __result__10 = MediationServices.getMediationName();
		java.lang.String __result__11 = "** Log Audit : Message to be Persisted ";
		__result__6.logGESAudit(__result__8, __result__10, __result__10, __result__11, smoInput);
		java.lang.String __result__5 = mode.toUpperCase();
		com.us.chartisinsurance.ges.db.utils.DBServicesImpl.auditMessage(smoInput, __result__3, __result__8, __result__5);
	}
}