package utility;
public class ExtractRequestHeader {
	public static commonj.sdo.DataObject extractRequestHeader(commonj.sdo.DataObject smo) {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject)smo;
		java.util.List __result__1 = __smo.getDataObject("headers").getList("SOAPHeader");
		boolean __result__2;
		{// is list empty
			__result__2 = __result__1.isEmpty();
		}
		boolean __result__3;
		{// inverse
			__result__3 = !__result__2;
		}
		if (__result__3){
			java.util.List __result__6 = __smo.getDataObject("headers").getList("SOAPHeader");
			byte __result__7 = 0;
			java.lang.Object __result__8 = __result__6.get(__result__7);
			commonj.sdo.DataObject SOAPHeaderList = (commonj.sdo.DataObject)__result__8;
			java.lang.String __result__10 = "value";
			java.lang.Object __result__11 = SOAPHeaderList.get(__result__10);
			commonj.sdo.DataObject RequestHeader = (commonj.sdo.DataObject)__result__11;
			return RequestHeader;
		}
		else{
			java.lang.Object __result__16 = null;
			return (commonj.sdo.DataObject)__result__16;
		}
	}
}