package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_PolicyServiceV1 Interface: PolicyServiceV1 Operation: createPolicyOption Type: request Custom Mediation: DataObjectConversion
 */
public class Custom1441970763442 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String aCreatePolicyOptionDB_EISImpPartner;
	private String aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging;
	private String aStartLayerOptionTypePartner;
	private String createPolicyOptionPartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (createPolicyOptionPartner == null
				|| "".equals(createPolicyOptionPartner.trim())) {
			throw new MediationConfigurationException(
					"Property 'createPolicyOptionPartner' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the aCreatePolicyOptionDB_EISImpPartner
	 */
	public String getACreatePolicyOptionDB_EISImpPartner() {
		return aCreatePolicyOptionDB_EISImpPartner;
	}

	/**
	 * @generated
	 * @param aCreatePolicyOptionDB_EISImpPartner The aCreatePolicyOptionDB_EISImpPartner to set.
	 */
	public void setACreatePolicyOptionDB_EISImpPartner(
			String aCreatePolicyOptionDB_EISImpPartner) {
		this.aCreatePolicyOptionDB_EISImpPartner = aCreatePolicyOptionDB_EISImpPartner;
	}

	/**
	 * @generated
	 * @return Returns the aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging
	 */
	public String getAexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging() {
		return aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging;
	}

	/**
	 * @generated
	 * @param aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging The aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging to set.
	 */
	public void setAexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging(
			String aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging) {
		this.aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging = aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging;
	}

	/**
	 * @generated
	 * @return Returns the aStartLayerOptionTypePartner
	 */
	public String getAStartLayerOptionTypePartner() {
		return aStartLayerOptionTypePartner;
	}

	/**
	 * @generated
	 * @param aStartLayerOptionTypePartner The aStartLayerOptionTypePartner to set.
	 */
	public void setAStartLayerOptionTypePartner(
			String aStartLayerOptionTypePartner) {
		this.aStartLayerOptionTypePartner = aStartLayerOptionTypePartner;
	}

	/**
	 * @generated
	 * @return Returns the createPolicyOptionPartner
	 */
	public String getCreatePolicyOptionPartner() {
		return createPolicyOptionPartner;
	}

	/**
	 * @generated
	 * @param createPolicyOptionPartner The createPolicyOptionPartner to set.
	 */
	public void setCreatePolicyOptionPartner(String createPolicyOptionPartner)
			throws IllegalArgumentException {
		if (createPolicyOptionPartner == null
				|| "".equals(createPolicyOptionPartner.trim())) {
			throw new IllegalArgumentException(
					createPolicyOptionPartner
							+ " is not a valid value for property 'createPolicyOptionPartner'");
		}

		this.createPolicyOptionPartner = createPolicyOptionPartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__4;
		{// create GexpusrtUsp_C46_Create_Policy_Option_Staging
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__4 = factory
					.create(
							"http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging",
							"GexpusrtUsp_C46_Create_Policy_Option_Staging");
		}
		commonj.sdo.DataObject SPRequestBO = __result__4;
		commonj.sdo.DataObject __result__2 = __smo.getDataObject("body")
				.getDataObject("CreatePolicyOptionRq");
		java.lang.String __result__3 = "CreatePolicyOptionRq";
		java.lang.String __result__6 = com.us.aig.ges.dataobject.utils.DataObjectUtils
				.dataObjectToString(__result__2, __result__3);
		SPRequestBO.setString("ppol_optn_xml", __result__6);
		commonj.sdo.DataObject __result__12 = __smo.getDataObject("body")
				.getDataObject("CreatePolicyOptionRq");
		commonj.sdo.DataObject __result__13;
		{// copy BO
			com.ibm.websphere.bo.BOCopy _copyService = (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOCopy");
			__result__13 = _copyService.copy(__result__12);
		}
		commonj.sdo.DataObject CreatePolicyOptionRequest = __result__13;
		__smo.getDataObject("context").getDataObject("correlation").set(
				"CreatePolicyOptionRqMsg", CreatePolicyOptionRequest);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__8 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__9 = getMediationServices();
		java.lang.String __result__10 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_PolicyService_createPolicyOption__WSREQ;
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__8,
				__result__9, __result__10, SPRequestBO);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__19 = getSCAServices();
		java.lang.String __result__20 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(createPolicyOptionPartner, __result__19);
		java.lang.String SpEndPoint = __result__20;
		com.us.chartisinsurance.ges.service.invocation.GESSIF __result__22 = com.us.chartisinsurance.ges.service.invocation.GESSIFImpl.INSTANCE;
		commonj.sdo.DataObject __result__27 = null;
		try {
			__result__27 = ((com.us.chartisinsurance.ges.service.invocation.GESSIFImpl) __result__22)
					.invokeService(
							aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging,
							aCreatePolicyOptionDB_EISImpPartner, SpEndPoint,
							SPRequestBO);
		} catch (java.lang.Exception ex) {
		}
		commonj.sdo.DataObject SPResponse = __result__27;
		commonj.sdo.DataObject __result__35;
		{// create SMO body with executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponseMsg
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp",
							"executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponseMsg"));
			__result__35 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject SPResponseSMO = __result__35;
		commonj.sdo.DataObject __result__37;
		{// create executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__37 = factory
					.createByElement(
							"http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp",
							"executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse");
		}
		commonj.sdo.DataObject StagingResponse = __result__37;
		byte __result__39 = 0;
		commonj.sdo.DataObject __result__40 = StagingResponse
				.createDataObject(__result__39);
		commonj.sdo.DataObject StagingResponseOutput = __result__40;
		int __result__42 = SPResponse.getDataObject(
				"executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput")
				.getInt("perror_cd");
		StagingResponseOutput.setInt("perror_cd", __result__42);
		java.lang.String __result__47 = SPResponse.getDataObject(
				"executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput")
				.getString("ppol_optn_id");
		StagingResponseOutput.setString("ppol_optn_id", __result__47);
		java.lang.String __result__49 = SPResponse.getDataObject(
				"executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput")
				.getString("pcrncy_id");
		StagingResponse.getDataObject(
				"executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput")
				.setString("pcrncy_id", __result__49);
		java.lang.String __result__51 = SPResponse.getDataObject(
				"executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput")
				.getString("perror_msg");
		StagingResponseOutput.setString("perror_msg", __result__51);
		byte __result__45 = 0;
		SPResponseSMO.setDataObject(__result__45, StagingResponse);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__31 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__32 = getMediationServices();
		java.lang.String __result__33 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_PolicyService_createPolicyOption__WSRES;
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__31,
				__result__32, __result__33, SPResponseSMO);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__58 = getSCAServices();
		java.lang.String __result__59 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(aStartLayerOptionTypePartner, __result__58);
		utility.SCA_and_BO_services.SetTargetAddress.setTargetAddress(
				(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo,
				__result__59);
		__smo.set("body", SPResponseSMO);
		out.fire(__smo);
		java.lang.String __result__64 = com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo
				.getModuleVersion(__result__58);
		java.lang.String ModuleVersion = __result__64;

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.61/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.CreatePolicyOptionRq" field="true">
		//    <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CreatePolicyOptionRqType" namespace="http://aig.us.com/ges/ext/PolicyServiceV1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;CreatePolicyOptionRq&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.5/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create GexpusrtUsp_C46_Create_Policy_Option_Staging" description="create a new GexpusrtUsp_C46_Create_Policy_Option_Staging {http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging&quot;,&quot;GexpusrtUsp_C46_Create_Policy_Option_Staging&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.4"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@result/@dataOutputs.0" value="SPRequestBO" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="dataObjectToString" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="dataObjectToString">
		//    <parameters name="aDataObject" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="aElementName" dataInputs="//@executableElements.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@result/@dataOutputs.0" value="SPRequestBO.ppol_optn_xml" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.16/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_PolicyService_createPolicyOption__WSREQ" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_PolicyService_createPolicyOption__WSREQ" field="true">
		//    <parameters name="COM_GES_MF_PolicyService_createPolicyOption__WSREQ">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.16/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPRequestBO" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.CreatePolicyOptionRq" field="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CreatePolicyOptionRqType" namespace="http://aig.us.com/ges/ext/PolicyServiceV1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="copy BO" description="Copy a Business Object or Business Graph" category="SCA and BO services" template="com.ibm.websphere.bo.BOCopy _copyService = &#xA;   (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOCopy&quot;); &#xA;&lt;%return%> _copyService.copy(&lt;%bo%>);">
		//    <parameters name="bo" dataInputs="//@executableElements.11/@dataOutputs.0" displayName="BO">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result name="copy" displayName="copy">
		//      <dataOutputs target="//@executableElements.13"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.12/@result/@dataOutputs.0" value="CreatePolicyOptionRequest" localVariable="//@localVariables.6" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="CreatePolicyOptionRequest" localVariable="//@localVariables.6" variable="true">
		//    <dataOutputs target="//@executableElements.15"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.14/@dataOutputs.0" value="smo.context.correlation.CreatePolicyOptionRqMsg" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CreatePolicyOptionRqType" namespace="http://aig.us.com/ges/ext/PolicyServiceV1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.7/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.9/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="createPolicyOptionPartner" variable="true">
		//    <dataOutputs target="//@executableElements.19/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.19/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.18/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.20"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.19/@result/@dataOutputs.0" value="SpEndPoint" localVariable="//@localVariables.7" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESSIFImpl.INSTANCE" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" static="true" memberName="INSTANCE" field="true">
		//    <parameters name="INSTANCE">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.26/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIF"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aexecuteGexpusrtUsp_C46_Create_Policy_Option_Staging" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aCreatePolicyOptionDB_EISImpPartner" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SpEndPoint" localVariable="//@localVariables.7" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPRequestBO" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.4"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeService" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeService">
		//    <parameters name="GESSIFImpl" dataInputs="//@executableElements.21/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//    </parameters>
		//    <parameters name="methodName" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aPartnerName" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="targetAddress" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aDataObject" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.28"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//    </exceptions>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.27/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex" dataInputs="//@executableElements.26/@exceptions.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.27/@executableElements.0"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.26/@result/@dataOutputs.0" value="SPResponse" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" namespace="http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.52/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.52/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_PolicyService_createPolicyOption__WSRES" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_PolicyService_createPolicyOption__WSRES" field="true">
		//    <parameters name="COM_GES_MF_PolicyService_createPolicyOption__WSRES">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.52/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponseSMO" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.52/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponseMsg" description="Create SMO body with message {http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp}executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponseMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp&quot;, &quot;executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponseMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.34"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.33/@result/@dataOutputs.0" value="SPResponseSMO" localVariable="//@localVariables.3" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" description="create a new executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse {http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.createByElement(&quot;http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp&quot;,&quot;executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.36"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" namespace="http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.35/@result/@dataOutputs.0" value="StagingResponse" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.38/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" namespace="http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.38/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="createDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="createDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.36/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.37/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.39"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.38/@result/@dataOutputs.0" value="StagingResponseOutput" localVariable="//@localVariables.5" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponse.executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput.perror_cd" field="true">
		//    <dataOutputs target="//@executableElements.41"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.40/@dataOutputs.0" value="StagingResponseOutput.perror_cd" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponseSMO" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.51/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.51/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="StagingResponse" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.51/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" namespace="http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponse.executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput.ppol_optn_id" field="true">
		//    <dataOutputs target="//@executableElements.46"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.45/@dataOutputs.0" value="StagingResponseOutput.ppol_optn_id" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponse.executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput.pcrncy_id" field="true">
		//    <dataOutputs target="//@executableElements.48"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.47/@dataOutputs.0" value="StagingResponse.executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput.pcrncy_id" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponse.executeGexpusrtUsp_C46_Create_Policy_Option_StagingOutput.perror_msg" field="true">
		//    <dataOutputs target="//@executableElements.50"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.49/@dataOutputs.0" value="StagingResponseOutput.perror_msg" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.42/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.43/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.44/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.29/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.30/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.31/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.32/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.61/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.58/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aStartLayerOptionTypePartner" variable="true">
		//    <dataOutputs target="//@executableElements.57/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.57/@parameters.1"/>
		//      <dataOutputs target="//@executableElements.62/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.55/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.56/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.58/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="SetTargetAddress" category="SCA and BO services" targetNamespace="http://GES_Lib_Common/utility/SCA%20and%20BO%20services/">
		//    <parameters name="smo" dataInputs="//@executableElements.54/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="targetURI" dataInputs="//@executableElements.57/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SPResponseSMO" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.60"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.59/@dataOutputs.0" value="smo.body" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CreatePolicyOptionRqMsg" namespace="wsdl.http://aig.us.com/ges/services/PolicyServiceV1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.53/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleVersion" category="com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo" className="com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo" static="true" memberName="getModuleVersion">
		//    <parameters name="aSCAService" dataInputs="//@executableElements.56/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.63"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.62/@result/@dataOutputs.0" value="ModuleVersion" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <localVariables name="SPRequestBO">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging"/>
		//  </localVariables>
		//  <localVariables name="SPResponse">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" namespace="http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="ModuleVersion">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="SPResponseSMO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="StagingResponse">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="executeGexpusrtUsp_C46_Create_Policy_Option_StagingResponse" namespace="http://GES_BP_LocationExposureService/CreatePolicyOptionDB_EISImp"/>
		//  </localVariables>
		//  <localVariables name="StagingResponseOutput">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_C46_Create_Policy_Option_Staging" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_c46_create_policy_option_staging" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="CreatePolicyOptionRequest">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="SpEndPoint">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4"/>
		//  <executableGroups executableElements="//@executableElements.1 //@executableElements.2 //@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12 //@executableElements.13"/>
		//  <executableGroups executableElements="//@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.7 //@executableElements.8 //@executableElements.9 //@executableElements.10 //@executableElements.16"/>
		//  <executableGroups executableElements="//@executableElements.17 //@executableElements.18 //@executableElements.19 //@executableElements.20"/>
		//  <executableGroups executableElements="//@executableElements.21 //@executableElements.22 //@executableElements.23 //@executableElements.24 //@executableElements.25 //@executableElements.26 //@executableElements.27 //@executableElements.28"/>
		//  <executableGroups executableElements="//@executableElements.33 //@executableElements.34"/>
		//  <executableGroups executableElements="//@executableElements.35 //@executableElements.36 //@executableElements.37 //@executableElements.38 //@executableElements.39"/>
		//  <executableGroups executableElements="//@executableElements.40 //@executableElements.41"/>
		//  <executableGroups executableElements="//@executableElements.45 //@executableElements.46"/>
		//  <executableGroups executableElements="//@executableElements.47 //@executableElements.48"/>
		//  <executableGroups executableElements="//@executableElements.49 //@executableElements.50"/>
		//  <executableGroups executableElements="//@executableElements.42 //@executableElements.43 //@executableElements.44 //@executableElements.51"/>
		//  <executableGroups executableElements="//@executableElements.29 //@executableElements.30 //@executableElements.31 //@executableElements.32 //@executableElements.52"/>
		//  <executableGroups executableElements="//@executableElements.54 //@executableElements.55 //@executableElements.56 //@executableElements.57 //@executableElements.58"/>
		//  <executableGroups executableElements="//@executableElements.59 //@executableElements.60"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.53 //@executableElements.61"/>
		//  <executableGroups executableElements="//@executableElements.62 //@executableElements.63"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!2:9,1
		//!SMAP!3:10,1
		//!SMAP!4:2,6
		//!SMAP!5:8,1
		//!SMAP!6:11,1
		//!SMAP!7:12,1
		//!SMAP!8:22,1
		//!SMAP!9:23,1
		//!SMAP!10:24,1
		//!SMAP!12:13,1
		//!SMAP!13:14,6
		//!SMAP!14:20,1
		//!SMAP!16:21,1
		//!SMAP!17:25,1
		//!SMAP!19:26,1
		//!SMAP!20:27,1
		//!SMAP!21:28,1
		//!SMAP!22:29,1
		//!SMAP!27:32,2
		//!SMAP!30:36,1
		//!SMAP!31:66,1
		//!SMAP!32:67,1
		//!SMAP!33:68,1
		//!SMAP!35:37,8
		//!SMAP!36:45,1
		//!SMAP!37:46,6
		//!SMAP!38:52,1
		//!SMAP!39:53,1
		//!SMAP!40:54,1
		//!SMAP!41:55,1
		//!SMAP!42:56,1
		//!SMAP!43:57,1
		//!SMAP!45:64,1
		//!SMAP!47:58,1
		//!SMAP!48:59,1
		//!SMAP!49:60,1
		//!SMAP!50:61,1
		//!SMAP!51:62,1
		//!SMAP!52:63,1
		//!SMAP!53:65,1
		//!SMAP!54:69,1
		//!SMAP!58:70,1
		//!SMAP!59:71,1
		//!SMAP!60:72,1
		//!SMAP!62:73,1
		//!SMAP!63:74,1
		//!SMAP!64:75,1
		//!SMAP!65:76,1
		//!SMAP!1000000:580,1
	}
}
