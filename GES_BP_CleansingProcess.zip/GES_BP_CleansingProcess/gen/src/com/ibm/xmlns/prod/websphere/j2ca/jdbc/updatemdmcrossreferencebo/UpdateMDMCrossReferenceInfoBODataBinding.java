package com.ibm.xmlns.prod.websphere.j2ca.jdbc.updatemdmcrossreferencebo;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class UpdateMDMCrossReferenceInfoBODataBinding extends com.ibm.j2ca.jdbc.emd.databinding.JDBCDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO";
	private String businessObjectName = "UpdateMDMCrossReferenceInfoBO";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}