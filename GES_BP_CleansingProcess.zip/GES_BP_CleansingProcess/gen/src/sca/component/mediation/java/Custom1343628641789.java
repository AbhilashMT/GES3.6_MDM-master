package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_CommonService Interface: GESCommonServiceV2 Operation: getLocationsFromGES Type: request Custom Mediation: Log Entry Request
 */
public class Custom1343628641789 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__4 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__5 = getMediationServices();
		java.lang.String __result__6 = "** Log Request Message , getLocationsRequest Message  \n";
		utility.MediationLogger_LogEntry.mediationLogger_LogEntry(__result__4,
				__result__5, __result__6, __smo);
		boolean __result__3 = null != __smo.getDataObject("body")
				.getDataObject("RequestHeader");
		if (__result__3) {
			java.lang.String __result__11 = __smo.getDataObject("headers")
					.getDataObject("SMOHeader").getString("Interface");
			java.lang.String __result__12 = com.us.chartisinsurance.ges.transformation.utils.TransformationUtils
					.getInvoker(__result__11);
			__smo.getDataObject("body").getDataObject("RequestHeader")
					.getDataObject("ServiceRequestContext").setString(
							"ServiceInvoker", __result__12);
		} else {
			commonj.sdo.DataObject __result__15;
			{// create ServiceRequestContext
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__15 = factory.createByElement(
						"http://aig.com/CommonHeaderV12",
						"ServiceRequestContext");
			}
			commonj.sdo.DataObject serviceRequestContext = __result__15;
			commonj.sdo.DataObject __result__17;
			{// create RequestHeader
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__17 = factory.createByElement(
						"http://aig.com/CommonHeaderV12", "RequestHeader");
			}
			commonj.sdo.DataObject RequestHeader = __result__17;
			java.util.Date __result__20 = com.us.chartisinsurance.ges.transformation.utils.TransformationUtils
					.getCurrentTime();
			serviceRequestContext.setDate("RequestTimestamp", __result__20);
			java.lang.String __result__19 = __smo.getDataObject("headers")
					.getDataObject("SMOHeader").getString("Interface");
			java.lang.String __result__22 = com.us.chartisinsurance.ges.transformation.utils.TransformationUtils
					.getInvoker(__result__19);
			serviceRequestContext.setString("ServiceInvoker", __result__22);
			RequestHeader.set("ServiceRequestContext", serviceRequestContext);
			__smo.getDataObject("body").set("RequestHeader", RequestHeader);
		}
		commonj.sdo.DataObject __result__28 = __smo.getDataObject("body");
		commonj.sdo.Type __result__29 = __result__28.getType();
		java.lang.String __result__30 = __result__29.getURI();
		__smo.getDataObject("context").getDataObject("correlation").setString(
				"wsdlNs", __result__30);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.body.RequestHeader" assignable="false">
		//    <dataOutputs target="//@executableElements.8"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.7/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** Log Request Message , getLocationsRequest Message  \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.7/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.7/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogEntry" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.6/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.2/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.SMOHeader.Interface" field="true">
		//        <dataOutputs target="//@executableElements.8/@conditionalActivities.0/@executableElements.1/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getInvoker" category="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" className="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" static="true" memberName="getInvoker">
		//        <parameters name="qHeader" dataInputs="//@executableElements.8/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.8/@conditionalActivities.0/@executableElements.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.0/@executableElements.1/@result/@dataOutputs.0" value="smo.body.RequestHeader.ServiceRequestContext.ServiceInvoker" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.0/@executableElements.0 //@executableElements.8/@conditionalActivities.0/@executableElements.1 //@executableElements.8/@conditionalActivities.0/@executableElements.2"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create ServiceRequestContext" description="create a new ServiceRequestContext {http://aig.com/CommonHeaderV12}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.createByElement(&quot;http://aig.com/CommonHeaderV12&quot;,&quot;ServiceRequestContext&quot;);">
		//        <result>
		//          <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceRequestContext" namespace="http://aig.com/CommonHeaderV12" nillable="false"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.0/@result/@dataOutputs.0" value="serviceRequestContext" localVariable="//@executableElements.8/@conditionalActivities.1/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceRequestContext" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create RequestHeader" description="create a new RequestHeader {http://aig.com/CommonHeaderV12}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.createByElement(&quot;http://aig.com/CommonHeaderV12&quot;,&quot;RequestHeader&quot;);">
		//        <result>
		//          <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12" nillable="false"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.2/@result/@dataOutputs.0" value="RequestHeader" localVariable="//@executableElements.8/@conditionalActivities.1/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.headers.SMOHeader.Interface" field="true">
		//        <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.7/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getCurrentTime" category="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" className="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" static="true" memberName="getCurrentTime">
		//        <result>
		//          <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.6"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.Date"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.5/@result/@dataOutputs.0" value="serviceRequestContext.RequestTimestamp" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="dateTime" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getInvoker" category="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" className="com.us.chartisinsurance.ges.transformation.utils.TransformationUtils" static="true" memberName="getInvoker">
		//        <parameters name="qHeader" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.4/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.8"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.7/@result/@dataOutputs.0" value="serviceRequestContext.ServiceInvoker" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="serviceRequestContext" localVariable="//@executableElements.8/@conditionalActivities.1/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.10"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceRequestContext" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.9/@dataOutputs.0" value="RequestHeader.ServiceRequestContext" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceRequestContext" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RequestHeader" localVariable="//@executableElements.8/@conditionalActivities.1/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.8/@conditionalActivities.1/@executableElements.12"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@conditionalActivities.1/@executableElements.11/@dataOutputs.0" value="smo.body.RequestHeader" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <localVariables name="serviceRequestContext">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceRequestContext" namespace="http://aig.com/CommonHeaderV12"/>
		//      </localVariables>
		//      <localVariables name="RequestHeader">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.1/@executableElements.0 //@executableElements.8/@conditionalActivities.1/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.1/@executableElements.2 //@executableElements.8/@conditionalActivities.1/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.1/@executableElements.5 //@executableElements.8/@conditionalActivities.1/@executableElements.6"/>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.1/@executableElements.4 //@executableElements.8/@conditionalActivities.1/@executableElements.7 //@executableElements.8/@conditionalActivities.1/@executableElements.8"/>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.1/@executableElements.9 //@executableElements.8/@conditionalActivities.1/@executableElements.10"/>
		//      <executableGroups executableElements="//@executableElements.8/@conditionalActivities.1/@executableElements.11 //@executableElements.8/@conditionalActivities.1/@executableElements.12"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body" field="true">
		//    <dataOutputs target="//@executableElements.10/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESRequestMsg" namespace="wsdl.http://aig.us.com/ges/services/GESCommonServiceV2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getType" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getType">
		//    <parameters name="DataObject" dataInputs="//@executableElements.9/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.11/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getURI" category="commonj.sdo.Type" className="commonj.sdo.Type" memberName="getURI">
		//    <parameters name="Type" dataInputs="//@executableElements.10/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.Type"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.12"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@result/@dataOutputs.0" value="smo.context.correlation.wsdlNs" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.13"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:6,1
		//!SMAP!4:2,1
		//!SMAP!5:3,1
		//!SMAP!6:4,1
		//!SMAP!8:5,1
		//!SMAP!9:7,1
		//!SMAP!11:8,1
		//!SMAP!12:9,1
		//!SMAP!13:10,1
		//!SMAP!15:13,6
		//!SMAP!16:19,1
		//!SMAP!17:20,6
		//!SMAP!18:26,1
		//!SMAP!19:29,1
		//!SMAP!20:27,1
		//!SMAP!21:28,1
		//!SMAP!22:30,1
		//!SMAP!23:31,1
		//!SMAP!25:32,1
		//!SMAP!27:33,1
		//!SMAP!28:35,1
		//!SMAP!29:36,1
		//!SMAP!30:37,1
		//!SMAP!31:38,1
		//!SMAP!32:39,1
		//!SMAP!1000000:266,1
	}
}
