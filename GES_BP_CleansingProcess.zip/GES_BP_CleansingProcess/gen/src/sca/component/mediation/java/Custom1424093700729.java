package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_CommonService Interface: GESCommonServiceV2 Operation: sendMessage Type: request Custom Mediation: SetUpInit
 */
public class Custom1424093700729 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;
	private OutputTerminal IsBatch;
	private OutputTerminal IsSequenced;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		IsBatch = mediationServices.getOutputTerminal("out1");
		if (IsBatch == null) {
			throw new MediationConfigurationException(
					"No terminal named out1 defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		IsSequenced = mediationServices.getOutputTerminal("out2");
		if (IsSequenced == null) {
			throw new MediationConfigurationException(
					"No terminal named out2 defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__1 = __smo.getDataObject("context")
				.getDataObject("transient");
		commonj.sdo.DataObject __result__2 = com.us.chartisinsurance.ges.common.utils.ScrubbingAIModule
				.updateContext(__result__1);
		__smo.getDataObject("context").set("transient", __result__2);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__6 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__7 = getMediationServices();
		java.lang.String __result__8 = "Context Set with Cache Variables \n";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__6,
				__result__7, __result__8, __smo);
		commonj.sdo.DataObject __result__4 = __smo.getDataObject("context")
				.getDataObject("transient");
		java.lang.String __result__5 = "IsSequenced";
		boolean __result__11 = __result__4.getBoolean(__result__5);
		if (__result__11) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__14 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__15 = getMediationServices();
			java.lang.String __result__16 = "Performing in Sequenced Mode ";
			utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
					__result__14, __result__15, __result__16, __smo);
			IsSequenced.fire(__smo);
		} else {
			commonj.sdo.DataObject __result__23 = __smo
					.getDataObject("context").getDataObject("transient");
			java.lang.String __result__24 = "IsBatchEnabled";
			boolean __result__25 = __result__23.getBoolean(__result__24);
			if (__result__25) {
				byte __result__28 = 1;
				__smo.getDataObject("context").getDataObject("correlation")
						.setInt("MinField", __result__28);
				java.lang.String __result__32 = com.us.aig.ges.constants.GESConstantBundle.SCRUBBING_BATCHSIZE;
				java.lang.Object __result__33 = com.aig.us.ges.cache.utils.GESCacheLoader
						.getValueFromCache(__result__32);
				java.lang.String __result__34 = java.lang.String
						.valueOf(__result__33);
				int __result__35 = 0;
				try {
					__result__35 = java.lang.Integer.parseInt(__result__34);
				} catch (java.lang.NumberFormatException ex) {
					byte __result__38 = 20;
					__smo.getDataObject("context").getDataObject("correlation")
							.setInt("MaxField", __result__38);
				}
				__smo.getDataObject("context").getDataObject("correlation")
						.setInt("MaxField", __result__35);
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__41 = getSCAServices();
				com.ibm.wsspi.sibx.mediation.MediationServices __result__42 = getMediationServices();
				java.lang.String __result__43 = "Performing Batch Mode ";
				utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
						__result__41, __result__42, __result__43, __smo);
				IsBatch.fire(__smo);
			} else {
				com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__48 = getSCAServices();
				com.ibm.wsspi.sibx.mediation.MediationServices __result__49 = getMediationServices();
				java.lang.String __result__50 = " Perfoming in Normal Mode ";
				utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
						__result__48, __result__49, __result__50, __smo);
				out.fire(__smo);
			}
		}

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.transient" field="true">
		//    <dataOutputs target="//@executableElements.1/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CommonServiceCorrContext" namespace="http://GES_MF_CommonService/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="updateContext" category="com.us.chartisinsurance.ges.common.utils.ScrubbingAIModule" className="com.us.chartisinsurance.ges.common.utils.ScrubbingAIModule" static="true" memberName="updateContext">
		//    <parameters name="aDobj" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@result/@dataOutputs.0" value="smo.context.transient" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CommonServiceCorrContext" namespace="http://GES_MF_CommonService/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.transient" field="true">
		//    <dataOutputs target="//@executableElements.10/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CommonServiceCorrContext" namespace="http://GES_MF_CommonService/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;IsSequenced&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.10/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.9/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.9/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Context Set with Cache Variables \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.9/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.9/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.5/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.8/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getBoolean" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getBoolean">
		//    <parameters name="DataObject" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.11"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.10/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.11/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.11/@conditionalActivities.0/@executableElements.4/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Performing in Sequenced Mode &quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.11/@conditionalActivities.0/@executableElements.4/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.11/@conditionalActivities.0/@executableElements.4/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.11/@conditionalActivities.0/@executableElements.0/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.11/@conditionalActivities.0/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.11/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.11/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="IsSequenced" variable="true">
		//        <dataOutputs target="//@executableElements.11/@conditionalActivities.0/@executableElements.7/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.11/@conditionalActivities.0/@executableElements.7/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//        <parameters name="OutputTerminal" dataInputs="//@executableElements.11/@conditionalActivities.0/@executableElements.5/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//        </parameters>
		//        <parameters name="smo" dataInputs="//@executableElements.11/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//        </parameters>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.11/@conditionalActivities.0/@executableElements.0 //@executableElements.11/@conditionalActivities.0/@executableElements.1 //@executableElements.11/@conditionalActivities.0/@executableElements.2 //@executableElements.11/@conditionalActivities.0/@executableElements.3 //@executableElements.11/@conditionalActivities.0/@executableElements.4"/>
		//      <executableGroups executableElements="//@executableElements.11/@conditionalActivities.0/@executableElements.5 //@executableElements.11/@conditionalActivities.0/@executableElements.6 //@executableElements.11/@conditionalActivities.0/@executableElements.7"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.transient" field="true">
		//        <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="CommonServiceCorrContext" namespace="http://GES_MF_CommonService/bo"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;IsBatchEnabled&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getBoolean" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getBoolean">
		//        <parameters name="DataObject" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="1" assignable="false">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="smo.context.correlation.MinField" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="IsBatch" variable="true">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.15/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.15/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESConstantBundle.SCRUBBING_BATCHSIZE" category="com.us.aig.ges.constants.GESConstantBundle" className="com.us.aig.ges.constants.GESConstantBundle" static="true" memberName="SCRUBBING_BATCHSIZE" field="true">
		//            <parameters name="SCRUBBING_BATCHSIZE">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.5/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getValueFromCache" category="com.aig.us.ges.cache.utils.GESCacheLoader" className="com.aig.us.ges.cache.utils.GESCacheLoader" static="true" memberName="getValueFromCache">
		//            <parameters name="aKey" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.6/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="valueOf" category="java.lang.String" className="java.lang.String" static="true" memberName="valueOf">
		//            <parameters name="obj" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.5/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.7/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="parseInt" category="java.lang.Integer" className="java.lang.Integer" static="true" memberName="parseInt">
		//            <parameters name="arg0" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.6/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.9"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//            </result>
		//            <exceptions>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.NumberFormatException"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//            <parameters name="ex" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.7/@exceptions.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.NumberFormatException"/>
		//            </parameters>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.NumberFormatException"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="20" assignable="false">
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8/@executableElements.2"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//            </executableElements>
		//            <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8/@executableElements.1/@dataOutputs.0" value="smo.context.correlation.MaxField" field="true">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//            </executableElements>
		//            <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8/@executableElements.0"/>
		//            <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8/@executableElements.1 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8/@executableElements.2"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.7/@result/@dataOutputs.0" value="smo.context.correlation.MaxField" field="true">
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Performing Batch Mode &quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.3"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//            <parameters name="SCAServices" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.10/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </parameters>
		//            <parameters name="MediationServices" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.11/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//            </parameters>
		//            <parameters name="inputMessage" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.12/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="dataObject" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.13/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <exceptions name="Exception1">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//            <parameters name="OutputTerminal" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//            </parameters>
		//            <parameters name="smo" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.1"/>
		//          <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.5 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.6 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.7 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.8 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.9"/>
		//          <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.10 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.11 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.12 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.13 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.14"/>
		//          <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.0/@executableElements.15"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.4/@parameters.0"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//            <result>
		//              <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.4/@parameters.1"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot; Perfoming in Normal Mode &quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.4/@parameters.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.4/@parameters.3"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//            <parameters name="SCAServices" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.0/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//            </parameters>
		//            <parameters name="MediationServices" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.1/@result/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//            </parameters>
		//            <parameters name="inputMessage" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.2/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <parameters name="dataObject" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.3/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <exceptions name="Exception1">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//            </exceptions>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.7/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//            <dataOutputs target="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.7/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//            <parameters name="OutputTerminal" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.5/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//            </parameters>
		//            <parameters name="smo" dataInputs="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.6/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.0 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.1 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.2 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.3 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.4"/>
		//          <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.5 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.6 //@executableElements.11/@conditionalActivities.1/@executableElements.3/@conditionalActivities.1/@executableElements.7"/>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.11/@conditionalActivities.1/@executableElements.0 //@executableElements.11/@conditionalActivities.1/@executableElements.1 //@executableElements.11/@conditionalActivities.1/@executableElements.2 //@executableElements.11/@conditionalActivities.1/@executableElements.3"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.2"/>
		//  <executableGroups executableElements="//@executableElements.5 //@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4 //@executableElements.10 //@executableElements.11"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!3:4,1
		//!SMAP!4:9,1
		//!SMAP!5:10,1
		//!SMAP!6:5,1
		//!SMAP!7:6,1
		//!SMAP!8:7,1
		//!SMAP!10:8,1
		//!SMAP!11:11,1
		//!SMAP!12:12,1
		//!SMAP!14:13,1
		//!SMAP!15:14,1
		//!SMAP!16:15,1
		//!SMAP!18:16,1
		//!SMAP!21:17,1
		//!SMAP!23:20,1
		//!SMAP!24:21,1
		//!SMAP!25:22,1
		//!SMAP!26:23,1
		//!SMAP!28:24,1
		//!SMAP!29:25,1
		//!SMAP!32:26,1
		//!SMAP!33:27,1
		//!SMAP!34:28,1
		//!SMAP!35:31,2
		//!SMAP!38:34,1
		//!SMAP!39:35,1
		//!SMAP!40:37,1
		//!SMAP!41:38,1
		//!SMAP!42:39,1
		//!SMAP!43:40,1
		//!SMAP!45:41,1
		//!SMAP!46:42,1
		//!SMAP!48:45,1
		//!SMAP!49:46,1
		//!SMAP!50:47,1
		//!SMAP!52:48,1
		//!SMAP!55:49,1
		//!SMAP!1000000:459,1
	}
}
