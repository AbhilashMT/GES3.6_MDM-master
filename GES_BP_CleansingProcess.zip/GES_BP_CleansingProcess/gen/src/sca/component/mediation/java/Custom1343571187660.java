package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_CommonService Interface: GESCommonServiceV2 Operation: sendMessage Type: request Custom Mediation: Log Entry
 */
public class Custom1343571187660 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__3 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__4 = getMediationServices();
		java.lang.String __result__5 = "** Log Request message , sendJMSMessage \n";
		try {
			utility.MediationLogger_LogEntry.mediationLogger_LogEntry(
					__result__3, __result__4, __result__5, __smo);
		} catch (com.ibm.websphere.sca.ServiceRuntimeException ex2) {
			java.lang.String __result__9 = "GES-SYS-M2O32010O";
			com.ibm.websphere.sca.ServiceRuntimeException __result__10 = new com.ibm.websphere.sca.ServiceRuntimeException(
					__result__9);
			throw __result__10;
		}
		java.lang.String __result__12 = com.us.chartisinsurance.ges.logger.LogCategory.DBUPDATE;
		java.util.logging.Logger __result__13 = java.util.logging.Logger
				.getLogger(__result__12);
		java.util.logging.Level __result__14 = java.util.logging.Level.INFO;
		boolean __result__15 = __result__13.isLoggable(__result__14);
		if (__result__15) {
			java.lang.String __result__18 = __smo.getDataObject("body")
					.getDataObject("sendMessageRequestParameter").getString(
							"SovId");
			java.lang.String SOVID = __result__18;
			java.lang.String __result__20 = __smo.getDataObject("body")
					.getDataObject("sendMessageRequestParameter").getString(
							"SovVersionId");
			java.lang.String SOVVersionId = __result__20;
			java.util.List __result__22 = __smo.getDataObject("body")
					.getDataObject("sendMessageRequestParameter").getList(
							"location");
			java.util.Iterator iter22 = __result__22.iterator();
			while (iter22.hasNext()) {
				commonj.sdo.DataObject Location = (commonj.sdo.DataObject) iter22
						.next();
				java.lang.String __result__26 = Location.getDataObject(
						"sovLocation").getString("sovLocId");
				com.us.chartisinsurance.ges.logger.GESLoggerV4.logLocation(
						SOVID, SOVVersionId, __result__26);
			}
		} else {
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** Log Request message , sendJMSMessage \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.6/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogEntry" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex2" dataInputs="//@executableElements.6/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-M2O32010O&quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.7/@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ServiceRuntimeException" category="com.ibm.websphere.sca.ServiceRuntimeException" className="com.ibm.websphere.sca.ServiceRuntimeException" constructor="true" memberName="ServiceRuntimeException">
		//      <parameters name="message" dataInputs="//@executableElements.7/@executableElements.0/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.7/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//      <parameters name="Throwable" dataInputs="//@executableElements.7/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.7/@executableElements.0 //@executableElements.7/@executableElements.1 //@executableElements.7/@executableElements.2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="LogCategory.DBUPDATE" category="com.us.chartisinsurance.ges.logger.LogCategory" className="com.us.chartisinsurance.ges.logger.LogCategory" static="true" memberName="DBUPDATE" field="true">
		//    <parameters name="DBUPDATE">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.9/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getLogger" category="java.util.logging.Logger" className="java.util.logging.Logger" static="true" memberName="getLogger">
		//    <parameters name="name" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.11/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.logging.Logger"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="Level.INFO" category="java.util.logging.Level" className="java.util.logging.Level" static="true" memberName="INFO" field="true">
		//    <parameters name="INFO">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.logging.Level"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.11/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.logging.Level"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isLoggable" category="java.util.logging.Logger" className="java.util.logging.Logger" memberName="isLoggable">
		//    <parameters name="Logger" dataInputs="//@executableElements.9/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.logging.Logger"/>
		//    </parameters>
		//    <parameters name="l" dataInputs="//@executableElements.10/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.logging.Level"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.12"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.11/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.sendMessageRequestParameter.SovId" field="true">
		//        <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="SOVID" localVariable="//@executableElements.12/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.sendMessageRequestParameter.SovVersionId" field="true">
		//        <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.2/@dataOutputs.0" value="SOVVersionId" localVariable="//@executableElements.12/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.sendMessageRequestParameter.location" field="true">
		//        <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.5"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:IterationActivity" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.4/@dataOutputs.0" iterationVariable="Location" iterationType="java.util.Collection">
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SOVID" localVariable="//@executableElements.12/@conditionalActivities.0/@localVariables.0" variable="true">
		//          <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.3/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SOVVersionId" localVariable="//@executableElements.12/@conditionalActivities.0/@localVariables.1" variable="true">
		//          <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.3/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="Location.sovLocation.sovLocId" field="true">
		//          <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.3/@parameters.2"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="logLocation" category="com.us.chartisinsurance.ges.logger.GESLoggerV4" className="com.us.chartisinsurance.ges.logger.GESLoggerV4" static="true" memberName="logLocation">
		//          <parameters name="aSovId" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.0/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//          <parameters name="aSovVersionId" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.1/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//          <parameters name="aLocationId" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.2/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//        </executableElements>
		//        <localVariables name="Location">
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Location" namespace="http://aig.us.com/ges/schema"/>
		//        </localVariables>
		//        <executableGroups executableElements="//@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.0 //@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.1 //@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.2 //@executableElements.12/@conditionalActivities.0/@executableElements.5/@executableElements.3"/>
		//        <iterationVariableType xsi:type="com.ibm.wbit.activity:XSDElementType" name="Location" namespace="http://aig.us.com/ges/schema" nillable="false"/>
		//      </executableElements>
		//      <localVariables name="SOVID">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </localVariables>
		//      <localVariables name="SOVVersionId">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.12/@conditionalActivities.0/@executableElements.0 //@executableElements.12/@conditionalActivities.0/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.12/@conditionalActivities.0/@executableElements.2 //@executableElements.12/@conditionalActivities.0/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.12/@conditionalActivities.0/@executableElements.4 //@executableElements.12/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.13"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:2,1
		//!SMAP!4:3,1
		//!SMAP!5:4,1
		//!SMAP!7:6,1
		//!SMAP!9:9,1
		//!SMAP!10:10,1
		//!SMAP!11:11,1
		//!SMAP!12:13,1
		//!SMAP!13:14,1
		//!SMAP!14:15,1
		//!SMAP!15:16,1
		//!SMAP!16:17,1
		//!SMAP!18:18,1
		//!SMAP!19:19,1
		//!SMAP!20:20,1
		//!SMAP!21:21,1
		//!SMAP!22:22,4
		//!SMAP!26:26,1
		//!SMAP!27:27,1
		//!SMAP!29:32,1
		//!SMAP!1000000:259,1
	}
}
