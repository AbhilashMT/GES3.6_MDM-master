package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_DBUpdateHandler Interface: DBUpdateHandlerV2 Operation: udpateMDMCrossReferenceInfo Type: request Custom Mediation: ConversionToSPRequest
 */
public class Custom1447932444906 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		boolean __result__3 = null != __smo.getDataObject("body")
				.getDataObject("udpateMDMCrossReferenceInfo").getDataObject(
						"udpateMDMCrossReferenceInfoRequest");
		if (__result__3) {
			commonj.sdo.DataObject __result__6 = __smo.getDataObject("body")
					.getDataObject("udpateMDMCrossReferenceInfo")
					.getDataObject("udpateMDMCrossReferenceInfoRequest");
			commonj.sdo.DataObject ArrayOfLocationUpdate = __result__6;
			java.lang.String __result__9 = "LocationUpdates";
			java.lang.String __result__10 = com.us.aig.ges.dataobject.utils.DataObjectUtils
					.dataObjectToString(ArrayOfLocationUpdate, __result__9);
			java.lang.String InputString = __result__10;
			commonj.sdo.DataObject __result__12;
			{// create UpdateMDMCrossReferenceInfoBO
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__12 = factory
						.create(
								"http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO",
								"UpdateMDMCrossReferenceInfoBO");
			}
			commonj.sdo.DataObject UpdateMDMCrossReferenceInfoBO = __result__12;
			UpdateMDMCrossReferenceInfoBO.setString("pstatus_xml", InputString);
			commonj.sdo.DataObject __result__16;
			{// create UpdateMDMCrossReferenceInfo
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__16 = factory.createByElement(
						"http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl",
						"UpdateMDMCrossReferenceInfo");
			}
			commonj.sdo.DataObject UpdateMDMCrossReferenceInfoElement = __result__16;
			UpdateMDMCrossReferenceInfoElement.set(
					"UpdateMDMCrossReferenceInfoRequest",
					UpdateMDMCrossReferenceInfoBO);
			commonj.sdo.DataObject __result__20;
			{// create SMO body with UpdateMDMCrossReferenceInfoRequestMsg
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
				com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
						.createServiceMessageObject(new javax.xml.namespace.QName(
								"http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl",
								"UpdateMDMCrossReferenceInfoRequestMsg"));
				__result__20 = (commonj.sdo.DataObject) _new_smo.getBody();
			}
			commonj.sdo.DataObject UpdateMDMCrossRefInfoBody = __result__20;
			byte __result__22 = 0;
			UpdateMDMCrossRefInfoBody.set(__result__22,
					UpdateMDMCrossReferenceInfoElement);
			__smo.set("body", UpdateMDMCrossRefInfoBody);
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__27 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__28 = getMediationServices();
			java.lang.String __result__29 = "Log updateMDMCrossRefInfoRequest to SP";
			utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
					__result__27, __result__28, __result__29, __smo);
		} else {
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.body.udpateMDMCrossReferenceInfo.udpateMDMCrossReferenceInfoRequest" assignable="false">
		//    <dataOutputs target="//@executableElements.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.2/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.udpateMDMCrossReferenceInfo.udpateMDMCrossReferenceInfoRequest" field="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfLocationUpdate" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="ArrayOfLocationUpdate" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfLocationUpdate" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ArrayOfLocationUpdate" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfLocationUpdate" namespace="http://aig.us.com/ges/common/v3"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;LocationUpdates&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="dataObjectToString" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="dataObjectToString">
		//        <parameters name="aDataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="aElementName" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0" value="InputString" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create UpdateMDMCrossReferenceInfoBO" description="create a new UpdateMDMCrossReferenceInfoBO {http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO&quot;,&quot;UpdateMDMCrossReferenceInfoBO&quot;);">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.7"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfoBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO" nillable="false"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.6/@result/@dataOutputs.0" value="UpdateMDMCrossReferenceInfoBO" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.3" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfoBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="InputString" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.9"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.8/@dataOutputs.0" value="UpdateMDMCrossReferenceInfoBO.pstatus_xml" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create UpdateMDMCrossReferenceInfo" description="create a new UpdateMDMCrossReferenceInfo {http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.createByElement(&quot;http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl&quot;,&quot;UpdateMDMCrossReferenceInfo&quot;);">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.11"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfo" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl" nillable="false"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.10/@result/@dataOutputs.0" value="UpdateMDMCrossReferenceInfoElement" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.4" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfo" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="UpdateMDMCrossReferenceInfoBO" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.3" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.13"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfoBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.12/@dataOutputs.0" value="UpdateMDMCrossReferenceInfoElement.UpdateMDMCrossReferenceInfoRequest" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfoBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with UpdateMDMCrossReferenceInfoRequestMsg" description="Create SMO body with message {http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl}UpdateMDMCrossReferenceInfoRequestMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl&quot;, &quot;UpdateMDMCrossReferenceInfoRequestMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//        <result name="message body" displayName="service message object body">
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.15"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.14/@result/@dataOutputs.0" value="UpdateMDMCrossRefInfoBody" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.18/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.18/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="UpdateMDMCrossReferenceInfoElement" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.18/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfo" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="set" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="set">
		//        <parameters name="DataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.15/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.16/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <parameters name="arg1" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.17/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="UpdateMDMCrossRefInfoBody" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.20"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.19/@dataOutputs.0" value="smo.body" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="udpateMDMCrossReferenceInfoRequestMsg" namespace="wsdl.http://aig.us.com/ges/services/DBUpdateHandlerV2"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.25/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.25/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Log updateMDMCrossRefInfoRequest to SP&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.25/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.25/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.21/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.22/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.23/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.24/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <localVariables name="ArrayOfLocationUpdate">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfLocationUpdate" namespace="http://aig.us.com/ges/common/v3"/>
		//      </localVariables>
		//      <localVariables name="InputString">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="UpdateMDMCrossRefInfoBody">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </localVariables>
		//      <localVariables name="UpdateMDMCrossReferenceInfoBO">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfoBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/UpdateMDMCrossReferenceBO"/>
		//      </localVariables>
		//      <localVariables name="UpdateMDMCrossReferenceInfoElement">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateMDMCrossReferenceInfo" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.3/@conditionalActivities.0/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.6 //@executableElements.3/@conditionalActivities.0/@executableElements.7"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.8 //@executableElements.3/@conditionalActivities.0/@executableElements.9"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.10 //@executableElements.3/@conditionalActivities.0/@executableElements.11"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.12 //@executableElements.3/@conditionalActivities.0/@executableElements.13"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.14 //@executableElements.3/@conditionalActivities.0/@executableElements.15 //@executableElements.3/@conditionalActivities.0/@executableElements.16 //@executableElements.3/@conditionalActivities.0/@executableElements.17 //@executableElements.3/@conditionalActivities.0/@executableElements.18"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.19 //@executableElements.3/@conditionalActivities.0/@executableElements.20"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.21 //@executableElements.3/@conditionalActivities.0/@executableElements.22 //@executableElements.3/@conditionalActivities.0/@executableElements.23 //@executableElements.3/@conditionalActivities.0/@executableElements.24 //@executableElements.3/@conditionalActivities.0/@executableElements.25"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.4"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:2,1
		//!SMAP!4:3,1
		//!SMAP!6:4,1
		//!SMAP!7:5,1
		//!SMAP!9:6,1
		//!SMAP!10:7,1
		//!SMAP!11:8,1
		//!SMAP!12:9,6
		//!SMAP!13:15,1
		//!SMAP!15:16,1
		//!SMAP!16:17,6
		//!SMAP!17:23,1
		//!SMAP!19:24,1
		//!SMAP!20:25,8
		//!SMAP!21:33,1
		//!SMAP!22:34,1
		//!SMAP!24:35,1
		//!SMAP!26:36,1
		//!SMAP!27:37,1
		//!SMAP!28:38,1
		//!SMAP!29:39,1
		//!SMAP!31:40,1
		//!SMAP!33:44,1
		//!SMAP!1000000:278,1
	}
}
