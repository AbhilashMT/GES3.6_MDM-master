package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: ProcessMessages Interface: subflow Operation:  Type: request Custom Mediation: Handle RunTime Failures
 */
public class Custom1424234023827 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String runTimeError;
	private String dBRequestHandlerPartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (runTimeError == null || "".equals(runTimeError.trim())) {
			throw new MediationConfigurationException(
					"Property 'runTimeError' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the runTimeError
	 */
	public String getRunTimeError() {
		return runTimeError;
	}

	/**
	 * @generated
	 * @param runTimeError The runTimeError to set.
	 */
	public void setRunTimeError(String runTimeError)
			throws IllegalArgumentException {
		if (runTimeError == null || "".equals(runTimeError.trim())) {
			throw new IllegalArgumentException(runTimeError
					+ " is not a valid value for property 'runTimeError'");
		}

		this.runTimeError = runTimeError;
	}

	/**
	 * @generated
	 * @return Returns the dBRequestHandlerPartner
	 */
	public String getDBRequestHandlerPartner() {
		return dBRequestHandlerPartner;
	}

	/**
	 * @generated
	 * @param dBRequestHandlerPartner The dBRequestHandlerPartner to set.
	 */
	public void setDBRequestHandlerPartner(String dBRequestHandlerPartner) {
		this.dBRequestHandlerPartner = dBRequestHandlerPartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		java.lang.String __result__2 = "";
		java.lang.String errorMessage = __result__2;
		commonj.sdo.DataObject __result__4 = __smo.getDataObject("context")
				.getDataObject("correlation");
		commonj.sdo.DataObject ExcepObj = __result__4;
		boolean __result__1 = null != ExcepObj.getString("errorCode");
		if (__result__1) {
			java.lang.String __result__8 = ExcepObj.getString("errorCode");
			errorMessage = __result__8;
		} else {
			java.lang.String __result__11 = __smo.getDataObject("context")
					.getDataObject("failInfo").getString("failureString");
			errorMessage = __result__11;
		}
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__13 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__14 = getMediationServices();
		java.lang.String __result__16 = " : ";
		java.lang.String __result__17;
		{// append text
			__result__17 = runTimeError.concat(__result__16);
		}
		java.lang.String __result__18 = __smo.getDataObject("context")
				.getDataObject("failInfo").getString("failureString");
		java.lang.String __result__19;
		{// append text
			__result__19 = __result__17.concat(__result__18);
		}
		try {
			utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
					__result__13, __result__14, __result__19, __smo);
		} catch (com.ibm.websphere.sca.ServiceRuntimeException ex2) {
			java.lang.String __result__23 = "GES-SYS-M2O32010O";
			com.ibm.websphere.sca.ServiceRuntimeException __result__24 = new com.ibm.websphere.sca.ServiceRuntimeException(
					__result__23);
			throw __result__24;
		}
		java.lang.String __result__28 = "handleRuntimeExceptionsRequestMsg";
		java.lang.String __result__29 = "http://aig.us.com/ges/services/DBUpdateHandlerV2";
		java.lang.String __result__30 = __result__13.getModuleName();
		java.lang.String __result__31 = "sendMessage";
		com.ibm.websphere.sibx.smobo.ServiceMessageObject __result__32 = ExceptionHandlingUtils.utility.utility.UpdateGESFaultObjectType
				.updateGESFaultObjectType(
						(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo,
						errorMessage, __result__28, __result__29, __result__30,
						__result__31);
		utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
				__result__13, __result__14, errorMessage, __result__32);
		com.ibm.websphere.sibx.smobo.ServiceMessageObject NewSMO = __result__32;
		java.lang.Object __result__36 = NewSMO.getBody();
		commonj.sdo.DataObject __local__37 = (commonj.sdo.DataObject) __result__36;
		__smo.set("body", __local__37);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!= ExcepObj.errorCode" assignable="false">
		//    <dataOutputs target="//@executableElements.5"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.1/@dataOutputs.0" value="errorMessage" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation" field="true">
		//    <dataOutputs target="//@executableElements.4"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ExceptionObj" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@dataOutputs.0" value="ExcepObj" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ExceptionObj" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.0/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ExcepObj.errorCode" field="true">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="errorMessage" localVariable="//@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.1"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.failInfo.failureString" field="true">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.1/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@conditionalActivities.1/@executableElements.0/@dataOutputs.0" value="errorMessage" localVariable="//@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.5/@conditionalActivities.1/@executableElements.0 //@executableElements.5/@conditionalActivities.1/@executableElements.1"/>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//      <dataOutputs target="//@executableElements.23/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.14/@parameters.1"/>
		//      <dataOutputs target="//@executableElements.23/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="runTimeError" variable="true">
		//    <dataOutputs target="//@executableElements.10/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot; : &quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.10/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.8/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.9/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.failInfo.failureString" field="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.10/@result/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.11/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.14/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.14/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.7/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.12/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.13/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <dataOutputs target="//@executableElements.15/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex2" dataInputs="//@executableElements.14/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-M2O32010O&quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.15/@executableElements.1/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ServiceRuntimeException" category="com.ibm.websphere.sca.ServiceRuntimeException" className="com.ibm.websphere.sca.ServiceRuntimeException" constructor="true" memberName="ServiceRuntimeException">
		//      <parameters name="message" dataInputs="//@executableElements.15/@executableElements.0/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result>
		//        <dataOutputs target="//@executableElements.15/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//      <parameters name="Throwable" dataInputs="//@executableElements.15/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.15/@executableElements.0 //@executableElements.15/@executableElements.1 //@executableElements.15/@executableElements.2"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.22/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="errorMessage" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.22/@parameters.1"/>
		//    <dataOutputs target="//@executableElements.23/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;handleRuntimeExceptionsRequestMsg&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.22/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;http://aig.us.com/ges/services/DBUpdateHandlerV2&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.22/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleName" category="com.ibm.wsspi.sibx.mediation.esb.SCAServices" className="com.ibm.wsspi.sibx.mediation.esb.SCAServices" memberName="getModuleName">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.6/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.22/@parameters.4"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;sendMessage&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.22/@parameters.5"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="updateGESFaultObjectType" category="utility" targetNamespace="http://GES_Lib_Common/ExceptionHandlingUtils/utility/utility/">
		//    <parameters name="smoInput" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="customMessage" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="outputMessageName" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="outputMessageQName" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="moduleName" dataInputs="//@executableElements.20/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="operartionName" dataInputs="//@executableElements.21/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="smoOutput">
		//      <dataOutputs target="//@executableElements.23/@parameters.3"/>
		//      <dataOutputs target="//@executableElements.25"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.6/@result/@dataOutputs.2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.7/@result/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.17/@dataOutputs.1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.22/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.29/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.22/@result/@dataOutputs.1" value="NewSMO" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="NewSMO.body" field="true">
		//    <dataOutputs target="//@executableElements.27"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.26/@dataOutputs.0" value="smo.body" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="sendMessageRequestMsg" namespace="wsdl.http://aig.us.com/ges/GES_Lib_CommonService/interface/JMSService"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.29/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.28/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="errorMessage">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </localVariables>
		//  <localVariables name="ExcepObj">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ExceptionObj" namespace="http://GES_Lib_Common/bo" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="NewSMO">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.1 //@executableElements.2"/>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9 //@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.15"/>
		//  <executableGroups executableElements="//@executableElements.16 //@executableElements.17 //@executableElements.18 //@executableElements.19 //@executableElements.20 //@executableElements.21 //@executableElements.22 //@executableElements.23"/>
		//  <executableGroups executableElements="//@executableElements.25"/>
		//  <executableGroups executableElements="//@executableElements.26 //@executableElements.27"/>
		//  <executableGroups executableElements="//@executableElements.24 //@executableElements.28 //@executableElements.29"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:6,1
		//!SMAP!2:2,1
		//!SMAP!3:3,1
		//!SMAP!4:4,1
		//!SMAP!5:5,1
		//!SMAP!6:7,1
		//!SMAP!8:8,1
		//!SMAP!9:9,1
		//!SMAP!11:12,1
		//!SMAP!12:13,1
		//!SMAP!13:15,1
		//!SMAP!14:16,1
		//!SMAP!16:17,1
		//!SMAP!17:18,4
		//!SMAP!18:22,1
		//!SMAP!19:23,4
		//!SMAP!21:28,1
		//!SMAP!23:31,1
		//!SMAP!24:32,1
		//!SMAP!25:33,1
		//!SMAP!28:35,1
		//!SMAP!29:36,1
		//!SMAP!30:37,1
		//!SMAP!31:38,1
		//!SMAP!32:39,1
		//!SMAP!33:40,1
		//!SMAP!35:41,1
		//!SMAP!36:42,1
		//!SMAP!37:43,2
		//!SMAP!39:45,1
		//!SMAP!1000000:351,1
	}
}
