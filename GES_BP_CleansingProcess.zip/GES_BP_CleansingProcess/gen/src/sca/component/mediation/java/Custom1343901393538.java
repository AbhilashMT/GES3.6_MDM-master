package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_CommonService Interface: GESCommonServiceV2 Operation: filerRecordsByMatchKey Type: request Custom Mediation: Check Filtered Records MatchKey
 */
public class Custom1343901393538 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__1 = __smo.getDataObject("body")
				.getDataObject("filterRecordsByMatchKeyResponseParameter");
		commonj.sdo.DataObject filterRecordsByMatchKeyResponse = __result__1;
		java.lang.String __result__4 = "matchLocations_100";
		boolean __result__5 = filterRecordsByMatchKeyResponse
				.isSet(__result__4);
		if (__result__5) {
			commonj.sdo.DataObject __result__8 = filterRecordsByMatchKeyResponse
					.getDataObject("matchLocations_100");
			java.lang.String __result__9 = "location";
			java.util.List __result__10 = __result__8.getList(__result__9);
			java.util.List LocationList = __result__10;
			boolean __result__12;
			{// is list empty
				__result__12 = LocationList.isEmpty();
			}
			if (__result__12) {
				java.lang.String __result__16 = "matchLocations_100";
				filterRecordsByMatchKeyResponse.unset(__result__16);
			} else {
			}
		} else {
		}
		java.lang.String __result__21 = "matchLocations_100_90";
		boolean __result__22 = filterRecordsByMatchKeyResponse
				.isSet(__result__21);
		if (__result__22) {
			commonj.sdo.DataObject __result__25 = filterRecordsByMatchKeyResponse
					.getDataObject("matchLocations_100_90");
			java.lang.String __result__26 = "location";
			java.util.List __result__27 = __result__25.getList(__result__26);
			java.util.List LocationList = __result__27;
			boolean __result__29;
			{// is list empty
				__result__29 = LocationList.isEmpty();
			}
			if (__result__29) {
				java.lang.String __result__33 = "matchLocations_100_90";
				filterRecordsByMatchKeyResponse.unset(__result__33);
			} else {
			}
		} else {
		}
		java.lang.String __result__38 = "matchLocations_0_90";
		boolean __result__39 = filterRecordsByMatchKeyResponse
				.isSet(__result__38);
		if (__result__39) {
			commonj.sdo.DataObject __result__42 = filterRecordsByMatchKeyResponse
					.getDataObject("matchLocations_0_90");
			java.lang.String __result__43 = "location";
			java.util.List __result__44 = __result__42.getList(__result__43);
			java.util.List LocationList = __result__44;
			boolean __result__46;
			{// is list empty
				__result__46 = LocationList.isEmpty();
			}
			if (__result__46) {
				java.lang.String __result__50 = "matchLocations_0_90";
				filterRecordsByMatchKeyResponse.unset(__result__50);
			} else {
			}
		} else {
		}
		java.lang.String __result__55 = "PerfectMatch";
		boolean __result__56 = filterRecordsByMatchKeyResponse
				.isSet(__result__55);
		if (__result__56) {
			commonj.sdo.DataObject __result__59 = filterRecordsByMatchKeyResponse
					.getDataObject("PerfectMatch");
			java.lang.String __result__60 = "location";
			java.util.List __result__61 = __result__59.getList(__result__60);
			java.util.List LocationList = __result__61;
			boolean __result__63;
			{// is list empty
				__result__63 = LocationList.isEmpty();
			}
			if (__result__63) {
				java.lang.String __result__67 = "PerfectMatch";
				filterRecordsByMatchKeyResponse.unset(__result__67);
			} else {
			}
		} else {
		}
		java.lang.String __result__72 = "HighProbable";
		boolean __result__73 = filterRecordsByMatchKeyResponse
				.isSet(__result__72);
		if (__result__73) {
			commonj.sdo.DataObject __result__76 = filterRecordsByMatchKeyResponse
					.getDataObject("HighProbable");
			java.lang.String __result__77 = "location";
			java.util.List __result__78 = __result__76.getList(__result__77);
			java.util.List LocationList = __result__78;
			boolean __result__80;
			{// is list empty
				__result__80 = LocationList.isEmpty();
			}
			if (__result__80) {
				java.lang.String __result__84 = "HighProbable";
				filterRecordsByMatchKeyResponse.unset(__result__84);
			} else {
			}
		} else {
		}
		java.lang.String __result__89 = "LowProbable";
		boolean __result__90 = filterRecordsByMatchKeyResponse
				.isSet(__result__89);
		if (__result__90) {
			commonj.sdo.DataObject __result__93 = filterRecordsByMatchKeyResponse
					.getDataObject("LowProbable");
			java.lang.String __result__94 = "location";
			java.util.List __result__95 = __result__93.getList(__result__94);
			java.util.List LocationList = __result__95;
			boolean __result__97;
			{// is list empty
				__result__97 = LocationList.isEmpty();
			}
			if (__result__97) {
				java.lang.String __result__101 = "LowProbable";
				filterRecordsByMatchKeyResponse.unset(__result__101);
			} else {
			}
		} else {
		}
		java.lang.String __result__106 = "NotAMatch";
		boolean __result__107 = filterRecordsByMatchKeyResponse
				.isSet(__result__106);
		if (__result__107) {
			commonj.sdo.DataObject __result__110 = filterRecordsByMatchKeyResponse
					.getDataObject("NotAMatch");
			java.lang.String __result__111 = "location";
			java.util.List __result__112 = __result__110.getList(__result__111);
			java.util.List LocationList = __result__112;
			boolean __result__114;
			{// is list empty
				__result__114 = LocationList.isEmpty();
			}
			if (__result__114) {
				java.lang.String __result__118 = "NotAMatch";
				filterRecordsByMatchKeyResponse.unset(__result__118);
			} else {
			}
		} else {
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.filterRecordsByMatchKeyResponseParameter" field="true">
		//    <dataOutputs target="//@executableElements.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@dataOutputs.0" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;matchLocations_100&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.5"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.matchLocations_100" field="true">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.5/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;matchLocations_100&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.2 //@executableElements.5/@conditionalActivities.0/@executableElements.3 //@executableElements.5/@conditionalActivities.0/@executableElements.4 //@executableElements.5/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.8/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;matchLocations_100_90&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.8/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.6/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.9"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.matchLocations_100_90" field="true">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.9/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;matchLocations_100_90&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.9/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.9/@conditionalActivities.0/@executableElements.0 //@executableElements.9/@conditionalActivities.0/@executableElements.1 //@executableElements.9/@conditionalActivities.0/@executableElements.2 //@executableElements.9/@conditionalActivities.0/@executableElements.3 //@executableElements.9/@conditionalActivities.0/@executableElements.4 //@executableElements.9/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;matchLocations_0_90&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.12/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.11/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.13"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.12/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.matchLocations_0_90" field="true">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.13/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;matchLocations_0_90&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.13/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.13/@conditionalActivities.0/@executableElements.0 //@executableElements.13/@conditionalActivities.0/@executableElements.1 //@executableElements.13/@conditionalActivities.0/@executableElements.2 //@executableElements.13/@conditionalActivities.0/@executableElements.3 //@executableElements.13/@conditionalActivities.0/@executableElements.4 //@executableElements.13/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PerfectMatch&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.16/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.14/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.15/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.17"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.16/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.PerfectMatch" field="true">
		//        <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.17/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PerfectMatch&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.17/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.17/@conditionalActivities.0/@executableElements.0 //@executableElements.17/@conditionalActivities.0/@executableElements.1 //@executableElements.17/@conditionalActivities.0/@executableElements.2 //@executableElements.17/@conditionalActivities.0/@executableElements.3 //@executableElements.17/@conditionalActivities.0/@executableElements.4 //@executableElements.17/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;HighProbable&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.20/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.21"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.20/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.HighProbable" field="true">
		//        <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.21/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;HighProbable&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.21/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.21/@conditionalActivities.0/@executableElements.0 //@executableElements.21/@conditionalActivities.0/@executableElements.1 //@executableElements.21/@conditionalActivities.0/@executableElements.2 //@executableElements.21/@conditionalActivities.0/@executableElements.3 //@executableElements.21/@conditionalActivities.0/@executableElements.4 //@executableElements.21/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.24/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;LowProbable&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.24/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.25"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.24/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.LowProbable" field="true">
		//        <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.25/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;LowProbable&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.25/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.25/@conditionalActivities.0/@executableElements.0 //@executableElements.25/@conditionalActivities.0/@executableElements.1 //@executableElements.25/@conditionalActivities.0/@executableElements.2 //@executableElements.25/@conditionalActivities.0/@executableElements.3 //@executableElements.25/@conditionalActivities.0/@executableElements.4 //@executableElements.25/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.28/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;NotAMatch&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.28/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.26/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.27/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.29"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.28/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse.NotAMatch" field="true">
		//        <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//        <parameters name="DataObject" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.29/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//        <parameters name="list" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <result name="isEmpty" displayName="is empty">
		//          <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsByMatchKeyResponse" localVariable="//@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;NotAMatch&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//            <parameters name="DataObject" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.29/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <localVariables name="LocationList">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.29/@conditionalActivities.0/@executableElements.0 //@executableElements.29/@conditionalActivities.0/@executableElements.1 //@executableElements.29/@conditionalActivities.0/@executableElements.2 //@executableElements.29/@conditionalActivities.0/@executableElements.3 //@executableElements.29/@conditionalActivities.0/@executableElements.4 //@executableElements.29/@conditionalActivities.0/@executableElements.5"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.30/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.31/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="filterRecordsByMatchKeyResponse">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsByMatchKeyResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11 //@executableElements.12 //@executableElements.13"/>
		//  <executableGroups executableElements="//@executableElements.14 //@executableElements.15 //@executableElements.16 //@executableElements.17"/>
		//  <executableGroups executableElements="//@executableElements.18 //@executableElements.19 //@executableElements.20 //@executableElements.21"/>
		//  <executableGroups executableElements="//@executableElements.22 //@executableElements.23 //@executableElements.24 //@executableElements.25"/>
		//  <executableGroups executableElements="//@executableElements.26 //@executableElements.27 //@executableElements.28 //@executableElements.29"/>
		//  <executableGroups executableElements="//@executableElements.30 //@executableElements.31 //@executableElements.32"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!4:4,1
		//!SMAP!5:5,1
		//!SMAP!6:6,1
		//!SMAP!8:7,1
		//!SMAP!9:8,1
		//!SMAP!10:9,1
		//!SMAP!11:10,1
		//!SMAP!12:11,4
		//!SMAP!13:15,1
		//!SMAP!16:16,1
		//!SMAP!17:17,1
		//!SMAP!21:24,1
		//!SMAP!22:25,1
		//!SMAP!23:26,1
		//!SMAP!25:27,1
		//!SMAP!26:28,1
		//!SMAP!27:29,1
		//!SMAP!28:30,1
		//!SMAP!29:31,4
		//!SMAP!30:35,1
		//!SMAP!33:36,1
		//!SMAP!34:37,1
		//!SMAP!38:44,1
		//!SMAP!39:45,1
		//!SMAP!40:46,1
		//!SMAP!42:47,1
		//!SMAP!43:48,1
		//!SMAP!44:49,1
		//!SMAP!45:50,1
		//!SMAP!46:51,4
		//!SMAP!47:55,1
		//!SMAP!50:56,1
		//!SMAP!51:57,1
		//!SMAP!55:64,1
		//!SMAP!56:65,1
		//!SMAP!57:66,1
		//!SMAP!59:67,1
		//!SMAP!60:68,1
		//!SMAP!61:69,1
		//!SMAP!62:70,1
		//!SMAP!63:71,4
		//!SMAP!64:75,1
		//!SMAP!67:76,1
		//!SMAP!68:77,1
		//!SMAP!72:84,1
		//!SMAP!73:85,1
		//!SMAP!74:86,1
		//!SMAP!76:87,1
		//!SMAP!77:88,1
		//!SMAP!78:89,1
		//!SMAP!79:90,1
		//!SMAP!80:91,4
		//!SMAP!81:95,1
		//!SMAP!84:96,1
		//!SMAP!85:97,1
		//!SMAP!89:104,1
		//!SMAP!90:105,1
		//!SMAP!91:106,1
		//!SMAP!93:107,1
		//!SMAP!94:108,1
		//!SMAP!95:109,1
		//!SMAP!96:110,1
		//!SMAP!97:111,4
		//!SMAP!98:115,1
		//!SMAP!101:116,1
		//!SMAP!102:117,1
		//!SMAP!106:124,1
		//!SMAP!107:125,1
		//!SMAP!108:126,1
		//!SMAP!110:127,1
		//!SMAP!111:128,1
		//!SMAP!112:129,1
		//!SMAP!113:130,1
		//!SMAP!114:131,4
		//!SMAP!115:135,1
		//!SMAP!118:136,1
		//!SMAP!119:137,1
		//!SMAP!124:144,1
		//!SMAP!1000000:911,1
	}
}
