package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_DBUpdateHandler Interface: DBUpdateHandlerV2 Operation: updateAugmentedLocation Type: request Custom Mediation: ConversionToSpRequest
 */
public class Custom1343986238440 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String locationContainerServicesPartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (locationContainerServicesPartner == null
				|| "".equals(locationContainerServicesPartner.trim())) {
			throw new MediationConfigurationException(
					"Property 'locationContainerServicesPartner' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the locationContainerServicesPartner
	 */
	public String getLocationContainerServicesPartner() {
		return locationContainerServicesPartner;
	}

	/**
	 * @generated
	 * @param locationContainerServicesPartner The locationContainerServicesPartner to set.
	 */
	public void setLocationContainerServicesPartner(
			String locationContainerServicesPartner)
			throws IllegalArgumentException {
		if (locationContainerServicesPartner == null
				|| "".equals(locationContainerServicesPartner.trim())) {
			throw new IllegalArgumentException(
					locationContainerServicesPartner
							+ " is not a valid value for property 'locationContainerServicesPartner'");
		}

		this.locationContainerServicesPartner = locationContainerServicesPartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		boolean __result__3 = null != __smo.getDataObject("body")
				.getDataObject("updateAugmentedLocation").getDataObject(
						"updateAugmentedLocationRequest").getDataObject(
						"locations");
		if (__result__3) {
			commonj.sdo.DataObject __result__6 = __smo.getDataObject("body")
					.getDataObject("updateAugmentedLocation").getDataObject(
							"updateAugmentedLocationRequest").getDataObject(
							"locations");
			commonj.sdo.DataObject LocationArray = __result__6;
			java.util.List __result__8 = LocationArray.getList("location");
			byte __result__9 = 0;
			java.lang.Object __result__10 = __result__8.get(__result__9);
			commonj.sdo.DataObject SovLocation = (commonj.sdo.DataObject) __result__10;
			java.lang.String __result__14 = "UpdateAugmentedLocationRequest";
			java.lang.String __result__15 = com.us.aig.ges.dataobject.utils.DataObjectUtils
					.dataObjectToString(SovLocation, __result__14);
			java.lang.String InputString = __result__15;
			commonj.sdo.DataObject __result__12;
			{// create SCRUBDB_LocationUpdateBO
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__12 = factory
						.create(
								"http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO",
								"SCRUBDB_LocationUpdateBO");
			}
			commonj.sdo.DataObject ScrubRequest = __result__12;
			byte __result__18 = 0;
			ScrubRequest.setString(__result__18, InputString);
			commonj.sdo.DataObject __result__21;
			{// create UpdateAugmentedLocationsSP
				com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOFactory");
				__result__21 = factory.createByElement(
						"http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl",
						"UpdateAugmentedLocationsSP");
			}
			commonj.sdo.DataObject augmentedLocationsSP = __result__21;
			byte __result__23 = 0;
			augmentedLocationsSP.setDataObject(__result__23, ScrubRequest);
			commonj.sdo.DataObject __result__26;
			{// create SMO body with UpdateAugmentedLocationsSPRequestMsg
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
				com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
						.createServiceMessageObject(new javax.xml.namespace.QName(
								"http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl",
								"UpdateAugmentedLocationsSPRequestMsg"));
				__result__26 = (commonj.sdo.DataObject) _new_smo.getBody();
			}
			commonj.sdo.DataObject UpdateAugmentBody = __result__26;
			byte __result__28 = 0;
			UpdateAugmentBody.set(__result__28, augmentedLocationsSP);
			__smo.set("body", UpdateAugmentBody);
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__31 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__32 = getMediationServices();
			java.lang.String __result__33 = "** Request Message For updateAugmentedLocation going to SP, DBRequestHandler **\n";
			try {
				utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
						__result__31, __result__32, __result__33, __smo);
			} catch (com.ibm.websphere.sca.ServiceRuntimeException ex) {
				java.lang.String __result__39 = "GES-SYS-M4O42010O";
				com.ibm.websphere.sca.ServiceRuntimeException __result__40 = new com.ibm.websphere.sca.ServiceRuntimeException(
						__result__39);
				throw __result__40;
			}
		} else {
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.body.updateAugmentedLocation.updateAugmentedLocationRequest.locations" assignable="false">
		//    <dataOutputs target="//@executableElements.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.2/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.updateAugmentedLocation.updateAugmentedLocationRequest.locations" field="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="LocationArray" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="LocationArray.location" field="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="get" category="java.util.List" className="java.util.List" memberName="get">
		//        <parameters name="List" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//        </parameters>
		//        <parameters name="location" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="E"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0" value="SovLocation" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.2" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="sovLocation" namespace="http://aig.us.com/ges"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SCRUBDB_LocationUpdateBO" description="create a new SCRUBDB_LocationUpdateBO {http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO&quot;,&quot;SCRUBDB_LocationUpdateBO&quot;);">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.11"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SCRUBDB_LocationUpdateBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO" nillable="false"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="SovLocation" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.2" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.9/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="sovLocation" namespace="http://aig.us.com/ges"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;UpdateAugmentedLocationRequest&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.9/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="dataObjectToString" category="com.us.aig.ges.dataobject.utils.DataObjectUtils" className="com.us.aig.ges.dataobject.utils.DataObjectUtils" static="true" memberName="dataObjectToString">
		//        <parameters name="aDataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.7/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="aElementName" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.8/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.10"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.9/@result/@dataOutputs.0" value="InputString" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.6/@result/@dataOutputs.0" value="ScrubRequest" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.3" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SCRUBDB_LocationUpdateBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="InputString" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.14/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setString" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setString">
		//        <parameters name="DataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.11/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.12/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <parameters name="arg1" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.13/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create UpdateAugmentedLocationsSP" description="create a new UpdateAugmentedLocationsSP {http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.createByElement(&quot;http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl&quot;,&quot;UpdateAugmentedLocationsSP&quot;);">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.16"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateAugmentedLocationsSP" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl" nillable="false"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.15/@result/@dataOutputs.0" value="augmentedLocationsSP" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.19/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateAugmentedLocationsSP" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.19/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ScrubRequest" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.3" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.19/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SCRUBDB_LocationUpdateBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//        <parameters name="DataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.16/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.17/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <parameters name="arg1" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.18/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with UpdateAugmentedLocationsSPRequestMsg" description="Create SMO body with message {http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl}UpdateAugmentedLocationsSPRequestMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl&quot;, &quot;UpdateAugmentedLocationsSPRequestMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//        <result name="message body" displayName="service message object body">
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.21"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.20/@result/@dataOutputs.0" value="UpdateAugmentBody" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.24/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.24/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="augmentedLocationsSP" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.5" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.24/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateAugmentedLocationsSP" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="set" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="set">
		//        <parameters name="DataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.21/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.22/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <parameters name="arg1" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.23/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//        </parameters>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.31/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.31/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;** Request Message For updateAugmentedLocation going to SP, DBRequestHandler **\n&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.31/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.31/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="UpdateAugmentBody" localVariable="//@executableElements.3/@conditionalActivities.0/@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.30"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.29/@dataOutputs.0" value="smo.body" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="updateAugmentedLocationRequestMsg" namespace="wsdl.http://aig.us.com/ges/services/DBUpdateHandlerV2"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.25/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.26/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.27/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.28/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.32/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.31/@exceptions.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-M4O42010O&quot;" assignable="false">
		//          <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.1/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ServiceRuntimeException" category="com.ibm.websphere.sca.ServiceRuntimeException" className="com.ibm.websphere.sca.ServiceRuntimeException" constructor="true" memberName="ServiceRuntimeException">
		//          <parameters name="message" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.0/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//          </parameters>
		//          <result>
		//            <dataOutputs target="//@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//          </result>
		//        </executableElements>
		//        <executableElements xsi:type="com.ibm.wbit.activity:ThrowActivity" name="throw Exception" exceptionType="java.lang.Throwable">
		//          <parameters name="Throwable" dataInputs="//@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.1/@result/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Throwable"/>
		//          </parameters>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.0 //@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.1 //@executableElements.3/@conditionalActivities.0/@executableElements.32/@executableElements.2"/>
		//      </executableElements>
		//      <localVariables name="LocationArray">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//      </localVariables>
		//      <localVariables name="InputString">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </localVariables>
		//      <localVariables name="SovLocation">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="sovLocation" namespace="http://aig.us.com/ges"/>
		//      </localVariables>
		//      <localVariables name="ScrubRequest">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="SCRUBDB_LocationUpdateBO" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/SCRUBDB_LocationUpdateBO"/>
		//      </localVariables>
		//      <localVariables name="UpdateAugmentBody">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//      </localVariables>
		//      <localVariables name="augmentedLocationsSP">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="UpdateAugmentedLocationsSP" namespace="http://GES_BP_DBUpdateHandler/DBUpdateHandlerTB_Impl" nillable="false"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.3/@conditionalActivities.0/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.7 //@executableElements.3/@conditionalActivities.0/@executableElements.8 //@executableElements.3/@conditionalActivities.0/@executableElements.9 //@executableElements.3/@conditionalActivities.0/@executableElements.10"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.6 //@executableElements.3/@conditionalActivities.0/@executableElements.11 //@executableElements.3/@conditionalActivities.0/@executableElements.12 //@executableElements.3/@conditionalActivities.0/@executableElements.13 //@executableElements.3/@conditionalActivities.0/@executableElements.14"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.15 //@executableElements.3/@conditionalActivities.0/@executableElements.16 //@executableElements.3/@conditionalActivities.0/@executableElements.17 //@executableElements.3/@conditionalActivities.0/@executableElements.18 //@executableElements.3/@conditionalActivities.0/@executableElements.19"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.20 //@executableElements.3/@conditionalActivities.0/@executableElements.21 //@executableElements.3/@conditionalActivities.0/@executableElements.22 //@executableElements.3/@conditionalActivities.0/@executableElements.23 //@executableElements.3/@conditionalActivities.0/@executableElements.24"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.29 //@executableElements.3/@conditionalActivities.0/@executableElements.30"/>
		//      <executableGroups executableElements="//@executableElements.3/@conditionalActivities.0/@executableElements.25 //@executableElements.3/@conditionalActivities.0/@executableElements.26 //@executableElements.3/@conditionalActivities.0/@executableElements.27 //@executableElements.3/@conditionalActivities.0/@executableElements.28 //@executableElements.3/@conditionalActivities.0/@executableElements.31 //@executableElements.3/@conditionalActivities.0/@executableElements.32"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.4"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:2,1
		//!SMAP!4:3,1
		//!SMAP!6:4,1
		//!SMAP!7:5,1
		//!SMAP!8:6,1
		//!SMAP!9:7,1
		//!SMAP!10:8,1
		//!SMAP!11:9,1
		//!SMAP!12:13,6
		//!SMAP!14:10,1
		//!SMAP!15:11,1
		//!SMAP!16:12,1
		//!SMAP!17:19,1
		//!SMAP!18:20,1
		//!SMAP!20:21,1
		//!SMAP!21:22,6
		//!SMAP!22:28,1
		//!SMAP!23:29,1
		//!SMAP!25:30,1
		//!SMAP!26:31,8
		//!SMAP!27:39,1
		//!SMAP!28:40,1
		//!SMAP!30:41,1
		//!SMAP!31:43,1
		//!SMAP!32:44,1
		//!SMAP!33:45,1
		//!SMAP!36:42,1
		//!SMAP!37:47,1
		//!SMAP!39:50,1
		//!SMAP!40:51,1
		//!SMAP!41:52,1
		//!SMAP!43:57,1
		//!SMAP!1000000:376,1
	}
}
