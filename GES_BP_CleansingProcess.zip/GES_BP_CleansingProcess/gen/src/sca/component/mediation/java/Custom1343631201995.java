package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_CommonService Interface: GESCommonServiceV2 Operation: filterRecords Type: request Custom Mediation: Check Filtered Response
 */
public class Custom1343631201995 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__1 = __smo.getDataObject("body")
				.getDataObject("filterRecordsResponseParameter").getDataObject(
						"filterRecordsResult");
		commonj.sdo.DataObject filterRecordsResult = __result__1;
		java.lang.String __result__4 = "pbbiExceptionLocations";
		boolean __result__5 = filterRecordsResult.isSet(__result__4);
		if (__result__5) {
			commonj.sdo.DataObject __result__8 = filterRecordsResult
					.getDataObject("pbbiExceptionLocations");
			java.lang.String __result__9 = "multipleMatchExceptions";
			boolean __result__10 = __result__8.isSet(__result__9);
			if (__result__10) {
				commonj.sdo.DataObject __result__13 = filterRecordsResult
						.getDataObject("pbbiExceptionLocations").getDataObject(
								"multipleMatchExceptions");
				java.lang.String __result__14 = "location";
				java.util.List __result__15 = __result__13
						.getList(__result__14);
				java.util.List LocationList = __result__15;
				boolean __result__17;
				{// is list empty
					__result__17 = LocationList.isEmpty();
				}
				if (__result__17) {
					commonj.sdo.DataObject __result__20 = filterRecordsResult
							.getDataObject("pbbiExceptionLocations");
					java.lang.String __result__21 = "multipleMatchExceptions";
					__result__20.unset(__result__21);
				} else {
				}
			} else {
			}
		} else {
		}
		java.lang.String __result__27 = "pbbiExceptionLocations";
		boolean __result__28 = filterRecordsResult.isSet(__result__27);
		if (__result__28) {
			commonj.sdo.DataObject __result__31 = filterRecordsResult
					.getDataObject("pbbiExceptionLocations");
			java.lang.String __result__32 = "failureExceptions";
			boolean __result__33 = __result__31.isSet(__result__32);
			if (__result__33) {
				commonj.sdo.DataObject __result__36 = filterRecordsResult
						.getDataObject("pbbiExceptionLocations").getDataObject(
								"failureExceptions");
				java.lang.String __result__37 = "location";
				java.util.List __result__38 = __result__36
						.getList(__result__37);
				java.util.List LocationList = __result__38;
				boolean __result__40;
				{// is list empty
					__result__40 = LocationList.isEmpty();
				}
				if (__result__40) {
					commonj.sdo.DataObject __result__43 = filterRecordsResult
							.getDataObject("pbbiExceptionLocations");
					java.lang.String __result__44 = "failureExceptions";
					__result__43.unset(__result__44);
				} else {
				}
			} else {
			}
		} else {
		}
		java.lang.String __result__51 = "mdmExceptionLocations";
		boolean __result__52 = filterRecordsResult.isSet(__result__51);
		if (__result__52) {
			commonj.sdo.DataObject __result__55 = filterRecordsResult
					.getDataObject("mdmExceptionLocations");
			java.lang.String __result__56 = "mdmExceptionlocations";
			boolean __result__57 = __result__55.isSet(__result__56);
			if (__result__57) {
				commonj.sdo.DataObject __result__60 = filterRecordsResult
						.getDataObject("mdmExceptionLocations").getDataObject(
								"mdmExceptionlocations");
				java.lang.String __result__61 = "location";
				java.util.List __result__62 = __result__60
						.getList(__result__61);
				java.util.List LocationList = __result__62;
				boolean __result__64;
				{// is list empty
					__result__64 = LocationList.isEmpty();
				}
				if (__result__64) {
					commonj.sdo.DataObject __result__67 = filterRecordsResult
							.getDataObject("mdmExceptionLocations");
					java.lang.String __result__68 = "mdmExceptionlocations";
					__result__67.unset(__result__68);
				} else {
				}
			} else {
			}
		} else {
		}
		java.lang.String __result__73 = "updatedLocations";
		boolean __result__74 = filterRecordsResult.isSet(__result__73);
		if (__result__74) {
			commonj.sdo.DataObject __result__77 = filterRecordsResult
					.getDataObject("updatedLocations");
			java.lang.String __result__78 = "doNotAutoScrubLocations";
			boolean __result__79 = __result__77.isSet(__result__78);
			if (__result__79) {
				commonj.sdo.DataObject __result__82 = filterRecordsResult
						.getDataObject("updatedLocations").getDataObject(
								"doNotAutoScrubLocations");
				java.lang.String __result__83 = "location";
				java.util.List __result__84 = __result__82
						.getList(__result__83);
				java.util.List LocationList = __result__84;
				boolean __result__86;
				{// is list empty
					__result__86 = LocationList.isEmpty();
				}
				if (__result__86) {
					commonj.sdo.DataObject __result__89 = filterRecordsResult
							.getDataObject("updatedLocations");
					java.lang.String __result__90 = "doNotAutoScrubLocations";
					__result__89.unset(__result__90);
				} else {
				}
			} else {
			}
		} else {
		}
		java.lang.String __result__96 = "updatedLocations";
		boolean __result__97 = filterRecordsResult.isSet(__result__96);
		if (__result__97) {
			commonj.sdo.DataObject __result__100 = filterRecordsResult
					.getDataObject("updatedLocations");
			java.lang.String __result__101 = "autoScrubLocations";
			boolean __result__102 = __result__100.isSet(__result__101);
			if (__result__102) {
				commonj.sdo.DataObject __result__105 = filterRecordsResult
						.getDataObject("updatedLocations").getDataObject(
								"autoScrubLocations");
				java.lang.String __result__106 = "location";
				java.util.List __result__107 = __result__105
						.getList(__result__106);
				java.util.List LocationList = __result__107;
				boolean __result__109;
				{// is list empty
					__result__109 = LocationList.isEmpty();
				}
				if (__result__109) {
					commonj.sdo.DataObject __result__112 = filterRecordsResult
							.getDataObject("updatedLocations");
					java.lang.String __result__113 = "autoScrubLocations";
					__result__112.unset(__result__113);
				} else {
				}
			} else {
			}
		} else {
		}
		java.lang.String __result__119 = "newLocations";
		boolean __result__120 = filterRecordsResult.isSet(__result__119);
		if (__result__120) {
			commonj.sdo.DataObject __result__123 = filterRecordsResult
					.getDataObject("newLocations");
			java.lang.String __result__124 = "newlocations";
			boolean __result__125 = __result__123.isSet(__result__124);
			if (__result__125) {
				commonj.sdo.DataObject __result__128 = filterRecordsResult
						.getDataObject("newLocations").getDataObject(
								"newlocations");
				java.lang.String __result__129 = "location";
				java.util.List __result__130 = __result__128
						.getList(__result__129);
				java.util.List LocationList = __result__130;
				boolean __result__132;
				{// is list empty
					__result__132 = LocationList.isEmpty();
				}
				if (__result__132) {
					commonj.sdo.DataObject __result__135 = filterRecordsResult
							.getDataObject("newLocations");
					java.lang.String __result__136 = "newlocations";
					__result__135.unset(__result__136);
				} else {
				}
			} else {
			}
		} else {
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.filterRecordsResponseParameter.filterRecordsResult" field="true">
		//    <dataOutputs target="//@executableElements.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@dataOutputs.0" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.4/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;pbbiExceptionLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.4/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.5"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.pbbiExceptionLocations" field="true">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="pbbiExceptions" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;multipleMatchExceptions&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//        <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.pbbiExceptionLocations.multipleMatchExceptions" field="true">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//            <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//            <parameters name="list" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </parameters>
		//            <result name="isEmpty" displayName="is empty">
		//              <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.pbbiExceptionLocations" field="true">
		//                <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="pbbiExceptions" namespace="http://aig.us.com/ges/schema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;multipleMatchExceptions&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                <parameters name="DataObject" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <parameters name="arg0" dataInputs="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="LocationList">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.5/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.5/@conditionalActivities.0/@executableElements.2 //@executableElements.5/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.8/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;pbbiExceptionLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.8/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.6/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.9"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.pbbiExceptionLocations" field="true">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="pbbiExceptions" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;failureExceptions&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//        <parameters name="DataObject" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.pbbiExceptionLocations.failureExceptions" field="true">
		//            <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//            <parameters name="DataObject" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//            <parameters name="list" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </parameters>
		//            <result name="isEmpty" displayName="is empty">
		//              <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.pbbiExceptionLocations" field="true">
		//                <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="pbbiExceptions" namespace="http://aig.us.com/ges/schema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;failureExceptions&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                <parameters name="DataObject" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <parameters name="arg0" dataInputs="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="LocationList">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.9/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.9/@conditionalActivities.0/@executableElements.0 //@executableElements.9/@conditionalActivities.0/@executableElements.1 //@executableElements.9/@conditionalActivities.0/@executableElements.2 //@executableElements.9/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.16/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;mdmExceptionLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.13/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.11/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.14"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.13/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.mdmExceptionLocations" field="true">
		//        <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="mdmExceptions" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;mdmExceptionlocations&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//        <parameters name="DataObject" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.mdmExceptionLocations.mdmExceptionlocations" field="true">
		//            <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//            <parameters name="DataObject" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//            <parameters name="list" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </parameters>
		//            <result name="isEmpty" displayName="is empty">
		//              <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.mdmExceptionLocations" field="true">
		//                <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="mdmExceptions" namespace="http://aig.us.com/ges/schema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;mdmExceptionlocations&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                <parameters name="DataObject" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <parameters name="arg0" dataInputs="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="LocationList">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.14/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.14/@conditionalActivities.0/@executableElements.0 //@executableElements.14/@conditionalActivities.0/@executableElements.1 //@executableElements.14/@conditionalActivities.0/@executableElements.2 //@executableElements.14/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;updatedLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.16/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.10/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.15/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.17"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.16/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.updatedLocations" field="true">
		//        <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="updatedLocations" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;doNotAutoScrubLocations&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//        <parameters name="DataObject" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.updatedLocations.doNotAutoScrubLocations" field="true">
		//            <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//            <parameters name="DataObject" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//            <parameters name="list" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </parameters>
		//            <result name="isEmpty" displayName="is empty">
		//              <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.updatedLocations" field="true">
		//                <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="updatedLocations" namespace="http://aig.us.com/ges/schema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;doNotAutoScrubLocations&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                <parameters name="DataObject" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <parameters name="arg0" dataInputs="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="LocationList">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.17/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.17/@conditionalActivities.0/@executableElements.0 //@executableElements.17/@conditionalActivities.0/@executableElements.1 //@executableElements.17/@conditionalActivities.0/@executableElements.2 //@executableElements.17/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;updatedLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.20/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.21"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.20/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.updatedLocations" field="true">
		//        <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="updatedLocations" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;autoScrubLocations&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//        <parameters name="DataObject" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.updatedLocations.autoScrubLocations" field="true">
		//            <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//            <parameters name="DataObject" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//            <parameters name="list" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </parameters>
		//            <result name="isEmpty" displayName="is empty">
		//              <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.updatedLocations" field="true">
		//                <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="updatedLocations" namespace="http://aig.us.com/ges/schema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;autoScrubLocations&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                <parameters name="DataObject" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <parameters name="arg0" dataInputs="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="LocationList">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.21/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.21/@conditionalActivities.0/@executableElements.0 //@executableElements.21/@conditionalActivities.0/@executableElements.1 //@executableElements.21/@conditionalActivities.0/@executableElements.2 //@executableElements.21/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.24/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;newLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.24/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//    <parameters name="DataObject" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.25"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.24/@result/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.newLocations" field="true">
		//        <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="newLocations" namespace="http://aig.us.com/ges/schema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;newlocations&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="isSet" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="isSet">
		//        <parameters name="DataObject" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <parameters name="arg0" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.newLocations.newlocations" field="true">
		//            <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;location&quot;" assignable="false">
		//            <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getList">
		//            <parameters name="DataObject" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//            </parameters>
		//            <parameters name="arg0" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//            </parameters>
		//            <result>
		//              <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2/@result/@dataOutputs.0" value="LocationList" localVariable="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@parameters.0"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="is list empty" description="Return true if the list is empty, false otherwise" category="list" template="&lt;%return%> &lt;%list%>.isEmpty();">
		//            <parameters name="list" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3/@dataOutputs.0" displayName="parameter">
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//            </parameters>
		//            <result name="isEmpty" displayName="is empty">
		//              <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//              <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//            </result>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4/@result/@dataOutputs.0">
		//            <conditionalActivities>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="filterRecordsResult.newLocations" field="true">
		//                <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.0"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="newLocations" namespace="http://aig.us.com/ges/schema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;newlocations&quot;" assignable="false">
		//                <dataOutputs target="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2/@parameters.1"/>
		//                <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//              </executableElements>
		//              <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="unset" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="unset">
		//                <parameters name="DataObject" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//                </parameters>
		//                <parameters name="arg0" dataInputs="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1/@dataOutputs.0">
		//                  <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//                </parameters>
		//              </executableElements>
		//              <executableGroups executableElements="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.0 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.1 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5/@conditionalActivities.0/@executableElements.2"/>
		//              <condition value="true"/>
		//            </conditionalActivities>
		//            <conditionalActivities>
		//              <condition value=""/>
		//            </conditionalActivities>
		//          </executableElements>
		//          <localVariables name="LocationList">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//          </localVariables>
		//          <executableGroups executableElements="//@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.0 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.1 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.2 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.3 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.4 //@executableElements.25/@conditionalActivities.0/@executableElements.3/@conditionalActivities.0/@executableElements.5"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.25/@conditionalActivities.0/@executableElements.0 //@executableElements.25/@conditionalActivities.0/@executableElements.1 //@executableElements.25/@conditionalActivities.0/@executableElements.2 //@executableElements.25/@conditionalActivities.0/@executableElements.3"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.28/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.28/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.26/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.27/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="filterRecordsResult">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="filterRecordsResult" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12 //@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.15 //@executableElements.16 //@executableElements.17"/>
		//  <executableGroups executableElements="//@executableElements.18 //@executableElements.19 //@executableElements.20 //@executableElements.21"/>
		//  <executableGroups executableElements="//@executableElements.22 //@executableElements.23 //@executableElements.24 //@executableElements.25"/>
		//  <executableGroups executableElements="//@executableElements.26 //@executableElements.27 //@executableElements.28"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!4:4,1
		//!SMAP!5:5,1
		//!SMAP!6:6,1
		//!SMAP!8:7,1
		//!SMAP!9:8,1
		//!SMAP!10:9,1
		//!SMAP!11:10,1
		//!SMAP!13:11,1
		//!SMAP!14:12,1
		//!SMAP!15:13,1
		//!SMAP!16:14,1
		//!SMAP!17:15,4
		//!SMAP!18:19,1
		//!SMAP!20:20,1
		//!SMAP!21:21,1
		//!SMAP!22:22,1
		//!SMAP!27:32,1
		//!SMAP!28:33,1
		//!SMAP!29:34,1
		//!SMAP!31:35,1
		//!SMAP!32:36,1
		//!SMAP!33:37,1
		//!SMAP!34:38,1
		//!SMAP!36:39,1
		//!SMAP!37:40,1
		//!SMAP!38:41,1
		//!SMAP!39:42,1
		//!SMAP!40:43,4
		//!SMAP!41:47,1
		//!SMAP!43:48,1
		//!SMAP!44:49,1
		//!SMAP!45:50,1
		//!SMAP!51:60,1
		//!SMAP!52:61,1
		//!SMAP!53:62,1
		//!SMAP!55:63,1
		//!SMAP!56:64,1
		//!SMAP!57:65,1
		//!SMAP!58:66,1
		//!SMAP!60:67,1
		//!SMAP!61:68,1
		//!SMAP!62:69,1
		//!SMAP!63:70,1
		//!SMAP!64:71,4
		//!SMAP!65:75,1
		//!SMAP!67:76,1
		//!SMAP!68:77,1
		//!SMAP!69:78,1
		//!SMAP!73:88,1
		//!SMAP!74:89,1
		//!SMAP!75:90,1
		//!SMAP!77:91,1
		//!SMAP!78:92,1
		//!SMAP!79:93,1
		//!SMAP!80:94,1
		//!SMAP!82:95,1
		//!SMAP!83:96,1
		//!SMAP!84:97,1
		//!SMAP!85:98,1
		//!SMAP!86:99,4
		//!SMAP!87:103,1
		//!SMAP!89:104,1
		//!SMAP!90:105,1
		//!SMAP!91:106,1
		//!SMAP!96:116,1
		//!SMAP!97:117,1
		//!SMAP!98:118,1
		//!SMAP!100:119,1
		//!SMAP!101:120,1
		//!SMAP!102:121,1
		//!SMAP!103:122,1
		//!SMAP!105:123,1
		//!SMAP!106:124,1
		//!SMAP!107:125,1
		//!SMAP!108:126,1
		//!SMAP!109:127,4
		//!SMAP!110:131,1
		//!SMAP!112:132,1
		//!SMAP!113:133,1
		//!SMAP!114:134,1
		//!SMAP!119:144,1
		//!SMAP!120:145,1
		//!SMAP!121:146,1
		//!SMAP!123:147,1
		//!SMAP!124:148,1
		//!SMAP!125:149,1
		//!SMAP!126:150,1
		//!SMAP!128:151,1
		//!SMAP!129:152,1
		//!SMAP!130:153,1
		//!SMAP!131:154,1
		//!SMAP!132:155,4
		//!SMAP!133:159,1
		//!SMAP!135:160,1
		//!SMAP!136:161,1
		//!SMAP!137:162,1
		//!SMAP!143:172,1
		//!SMAP!1000000:1041,1
	}
}
