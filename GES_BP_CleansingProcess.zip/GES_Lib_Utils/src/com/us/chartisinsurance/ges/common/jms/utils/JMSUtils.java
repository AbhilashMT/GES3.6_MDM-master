/**
 * 
 */
package com.us.chartisinsurance.ges.common.jms.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLDocument;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.common.utils.MetaInfo;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;

import commonj.sdo.DataObject;

/**
 * @author ASurendr
 * 
 */
public class JMSUtils {

	/**
	 * 
	 */

	private static final long serialVersionUID = 6924728094575632280L;
	static final String JNDI_QCF = "java:comp/env/jms/GESScrubbingQCFV1";
	static final String JNDI_Q_SRC = "jms/GESScrubbingRecQueueV1";
	static final String UPDATELOCATIONTYPE = "updateLocationInGESRequestType";
	static final String LOCATIONEXCEPTION = "LocationExceptionFault";
	static final String AUGMENTED = "Augmented";
	static final String PBBI = "PBBI";
	static final String MDM = "MDM";

	static QueueConnectionFactory qcf = null;
	static Queue sourceQueue = null;

	private static final String AUGMENTEDOPERATIONAME = "updateAugmentedLocation";
	private static final String PBBIOPERATIONAME = "updatePBBIExceptions";
	private static final String MDMOPERATIONAME = "updateMDMExceptions";
	private static final String EXCEPTIONOPERATIONAME = "handleRuntimeExceptions";

	static GESLoggerV4 JMSUtilsLogger = GESLoggerFactory.getLogger();

	public JMSUtils() {
		// TODO Auto-generated constructor stub
	}

	static {

		Context initContext = getInitialContext();

		try {
			
			qcf = (QueueConnectionFactory) initContext
					.lookup("jms/GESScrubbingQCFV1");

			
			sourceQueue = (Queue) initContext
					.lookup("jms/GESScrubbingRecQueueV1");
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */

	public void processMessages(DataObject processMessageInput)

	{
		boolean messageExists = true;

		try {
			MetaInfo.getMetaInfo().getversion();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean canAccessBus = true;

		Connection con = null;
		Session session = null;
		MessageConsumer consumer = null;
		String selector = "";
		JMSUtilsLogger.entering(JMSUtils.class.getName(), "processMessages",
				JMSUtils.class.getName(),
				"Start Processing recovered messages", processMessageInput);

		try {
			con = qcf.createConnection();
		} catch (JMSException e) {
			if (e.getCause().getMessage().startsWith("CWSIP0302E"))
				canAccessBus = false;
			e.printStackTrace();
		}
		try {
			if (canAccessBus) {
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				if (null != processMessageInput) {
					if (processMessageInput.isSet("messageId")
							&& processMessageInput.getString("messageId") != "") {
						String messageID = processMessageInput
								.getString("messageId");
					
						selector = "JMSMessageID ='" + messageID + "'";
						consumer = session
								.createConsumer(sourceQueue, selector);

					} else {
						consumer = session.createConsumer(sourceQueue);
				
					}
				} else {
					consumer = session.createConsumer(sourceQueue);
					
				}

				con.start();

				while (messageExists) {
			

					Message jmsMessage = consumer.receive(10L);

					if (jmsMessage instanceof TextMessage) {

						String message = ((TextMessage) jmsMessage).getText();
						

						if (null != message && message.length() != 0) {

							DataObject sendErrorMessageBO = getBOFromXMlString(message);
							String requestType = getType(sendErrorMessageBO);

							DataObject requestBO = constructDataObject(getDataObject(sendErrorMessageBO));

							if (UPDATELOCATIONTYPE.equalsIgnoreCase(requestType
									.trim())) {
								String messageFilter = getMessageFilter(requestBO);
							
								if (AUGMENTED.equalsIgnoreCase(messageFilter
										.trim())) {
									// Invoke updateAugmentedLocation
									try {
										invokeService(AUGMENTEDOPERATIONAME,
												requestBO);
									} catch (Exception e) {
										e.printStackTrace();
										break;
									}
								} else if (PBBI.equalsIgnoreCase(messageFilter
										.trim())) {
									// Invoke updatePBBIExceptions
									try {
										invokeService(PBBIOPERATIONAME,
												requestBO);
									} catch (Exception e) {
										e.printStackTrace();
										break;
									}
								} else if (MDM.equalsIgnoreCase(messageFilter
										.trim())) {
									// Invoke updateMDMExceptions
									try {
										invokeService(MDMOPERATIONAME,
												requestBO);
									} catch (Exception e) {
										e.printStackTrace();
										break;
									}
								}
							} else if (LOCATIONEXCEPTION
									.equalsIgnoreCase(requestType.trim())) {
								// Invoke handleRuntimeExceptions
								try {
									invokeService(EXCEPTIONOPERATIONAME,
											requestBO);
								} catch (Exception e) {
									e.printStackTrace();
									break;
								}
							}

							// no check for filter : PBBI , MDM ,
							// Augmented
						}

					} else {
						break;
					}

				}

				session.close();
				con.close();

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block

			messageExists = false;

			e.printStackTrace();
		} finally {
			try {

				if (null != session && null != con) {
					session.close();
					con.close();
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private static Context getInitialContext() {

		

		Context initCtxt = null;
		try {
			initCtxt = new InitialContext();

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return initCtxt;

	}

	public DataObject browseMessages(DataObject browseMessageRequest) {

		DataObject resp = null;

		Connection con = null;
		Session session = null;
		QueueBrowser queueBrowser = null;
		JMSUtilsLogger.entering(JMSUtils.class.getName(), "processMessages",
				JMSUtils.class.getName(), "Start browsing recovered messages");

		try {

			if (null != browseMessageRequest) {
				if (browseMessageRequest.isSet("qcfJndi")
						&& (browseMessageRequest.getString("qcfJndi").length() != 0)) {
					String qcfJndi = browseMessageRequest.getString("qcfJndi");
					qcf = (QueueConnectionFactory) getInitialContext().lookup(
							qcfJndi);
					
				}
				if (browseMessageRequest.isSet("queueJndi")
						&& (browseMessageRequest.getString("queueJndi")
								.length() != 0)) {
					String queueJndi = browseMessageRequest
							.getString("queueJndi");
					sourceQueue = (Queue) getInitialContext().lookup(queueJndi);
				
				}
			}
			con = qcf.createConnection();
		} catch (JMSException e) {
			if (e.getCause().getMessage().startsWith("CWSIP0302E"))

				e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);
			int numMsgs = 0;
			
			BOFactory bof = (BOFactory) ServiceManager.INSTANCE
					.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject BrowseMessageResponseBO = bof.create(
					"http://aig.us.com/jms/common/bo", "BrowseMessageResponse");
			DataObject queueContents;

			List queueContentsList = new ArrayList();

			try {
				queueBrowser = session.createBrowser(sourceQueue);
				
				Enumeration messageEnum = queueBrowser.getEnumeration();
				if (!messageEnum.hasMoreElements()) {
				
					JMSUtilsLogger.logSevere(JMSUtils.class.getName(),
							"browseMessages", JMSUtils.class.getName(),
							"No Messages in Queue");

					

				} else {
					while (messageEnum.hasMoreElements()) {

						Message textMessage = (Message) messageEnum
								.nextElement();

						if (textMessage instanceof TextMessage) {

							String jmsMsg = ((TextMessage) textMessage)
									.getText();

							DataObject boFromQueue = getBOFromXMlString(jmsMsg);

							String aType = getType(boFromQueue);
							if (UPDATELOCATIONTYPE.equalsIgnoreCase(aType)) {

								DataObject sendErrorMessageBO = getDataObject(boFromQueue);
								String messageFilter = getMessageFilter(sendErrorMessageBO);

								queueContents = bof.create(
										"http://GES_Lib_Common/bo",
										"queueContents");
								queueContents
										.setString("status", messageFilter);
								queueContents
										.setString(
												"locId",
												sendErrorMessageBO
														.getString("locations/location[1]/sovLocation/sovLocId"));
								queueContents.setString("messageId",
										textMessage.getJMSMessageID());

								queueContents.setString("message", jmsMsg);
								queueContentsList.add(queueContents);
							} else {
								DataObject sendErrorMessageBO = getDataObject(boFromQueue);
								queueContents = bof.create(
										"http://GES_Lib_Common/bo",
										"queueContents");
								queueContents.setString("status",
										"Failed Location");
								queueContents.setString("locId",
										sendErrorMessageBO
												.getString("sovLocationId"));
								queueContents.setString("messageId",
										textMessage.getJMSMessageID());
								queueContentsList.add(queueContents);

							}
						

							numMsgs++;
						}

					}
					BrowseMessageResponseBO.setList("queueContents",
							queueContentsList);

					resp = BrowseMessageResponseBO;
				}
			
				queueBrowser.close();
				session.close();
				con.close();
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return resp;
	}

	private DataObject getBOFromXMlString(String aXMLString) {
		DataObject responseBO = null;

		BOXMLSerializer BOXML = (BOXMLSerializer) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOXMLSerializer");

		byte[] xmlByte = aXMLString.getBytes();
		try {
			BOXMLDocument xmlDoc = BOXML
					.readXMLDocument(new ByteArrayInputStream(xmlByte));
			responseBO = xmlDoc.getDataObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JMSUtilsLogger.logInfo(JMSUtils.class.getName(),
				"getBOFromXMlString", JMSUtils.class.getName(),
				"DataObject from XMLString : ", responseBO);
		return responseBO;
	}

	private String getType(DataObject aDataObject) {
		String type = "";

		DataObject request = getDataObject(aDataObject);

		if (null != request) {
			type = request.getType().getName();

		
		}

		return type;
	}

	private DataObject getDataObject(DataObject parentDO) {
		DataObject request = parentDO.getDataObject("sendErrorMessage");

		return request;
	}

	private String getMessageFilter(DataObject arequestDO) {
		String filterType = "";
		if (null != arequestDO) {

			if (arequestDO.isSet("updateRequiredFor")) {
				filterType = arequestDO.getString("updateRequiredFor");
				
			} else {
				
			}
		}

		return filterType;
	}

	private void invokeService(String OperationName, DataObject aDataObject)
			throws Exception {
		Service DBUpdateHandlerV2Service = (Service) ServiceManager.INSTANCE
				.locateService("DBUpdateHandlerV2Partner");

		JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "invokeService",
				JMSUtils.class.getName(),
				"DataObject for DBUpdateHandlerService -----------> : ",
				aDataObject);

		DataObject response = (DataObject) DBUpdateHandlerV2Service.invoke(
				OperationName, aDataObject);
		GESLoggerFactory.getLogger()
				.logInfo(
						JMSUtils.class.getName(),
						"invokeService",
						JMSUtils.class.getName(),
						"RESPONSE DataObject for DBUpdateHandlerService -----------> : ",
						response);

		if (null != response) {

			
			String type = response.getType().getName();

			if (type.indexOf(AUGMENTEDOPERATIONAME) != -1) {
				if (!response.isSet(AUGMENTEDOPERATIONAME + "Response")) {

					
					throw new Exception(
							"Unable to update GES DB with the recovered message : "
									+ "Stop Processing : ");
				}
			}
			if (type.indexOf(PBBIOPERATIONAME) != -1) {
				if (!response.isSet(PBBIOPERATIONAME + "Response")) {

					
					throw new Exception(
							"Unable to update GES DB with the recovered message : "
									+ "Stop Processing : ");
				}
			}
			if (type.indexOf(MDMOPERATIONAME) != -1) {
				if (!response.isSet(MDMOPERATIONAME + "Response")) {

					
					throw new Exception(
							"Unable to update GES DB with the recovered message : "
									+ "Stop Processing : ");
				}
			}

		}
		// DBUpdateHandlerV2Service.invoke(arg0, arg1)
	}

	private DataObject constructDataObject(DataObject aDataObject) {
		BOFactory bof = (BOFactory) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject updateLocationsInGESrequestType = bof
				.create(
						"http://aig.us.com/ges/services/DBUpdateHandlerV2",
						"updateAugmentedLocation");

		updateLocationsInGESrequestType = aDataObject;

		return updateLocationsInGESrequestType;
	}

	{

	}

}
