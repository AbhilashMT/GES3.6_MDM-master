/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerThreadFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerThreadPoolExecutor;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;

/**
 * @author ASurendr
 * 
 */
public class EMAILTaskExecutor {

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */

	public EMAILTaskExecutor() {
		super();
		// TODO Auto-generated constructor stub
	}

	private final static String EMAIL_HOST = "usmxrelay.aig.com";

	private final static String EMAIL_SMTP_PORT = "25";
	private final static String FROM = "Abhilash.Surendran@adc.mindtree.com";

	private final static String MESTATUS_HTML = "MESTATUS.html";
	public static String[] sendAddressLocal = { "Abhilash.Surendran@adc.mindtree.com" };
	public static String[] sendAddress = { "AigGes.IbmEsbteam@mindtree.com" };

	static String subject = "GESWBI ALERT Notification : "
			+ System.getProperty("env");

	public Object aDataObject;
	public String customMessage;

	private static String env = System.getProperty("env");

	// private static GESLoggerV4 emailLogger = GESLoggerFactory.getLogger();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	new EMAILTaskExecutor().send("errorMessage ", "errorCategory",
		"TEST MAIL",sendAddress,sendAddress);

	}

	public boolean send(String errorMessage, String errorDesc,
			String errorCategory, String[] toAddress, String[] ccAddress) {
		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName, "send()",
		// aMediationComponentName, "Send EMail ", Level.INFO);

		boolean mailSent = false;

		String[] searchList = { "$HOST", "$ERROR_MESSAGE", "$ERROR_DESC",
				"$ERROR_CAT" };

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);
		StringBuffer body = new StringBuffer();
		InternetAddress fromAddress = null;

		try {
			fromAddress = new InternetAddress(FROM);

			// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
			// "Send()", aMediationComponentName,
			// " Body Content to be a Serialized DataObject",
			// Level.INFO);

			String response = readHTMLContent();

			try {

				String hostName = InetAddress.getLocalHost().getHostName();
				String[] replacementListNew = { hostName, errorMessage,
						errorDesc, errorCategory };

				String formattedResponse = StringUtils.replaceEach(response,
						searchList, replacementListNew);

				body.append(formattedResponse);
				simpleMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}
				for (int i = 0; i < ccAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.CC,
							new InternetAddress(ccAddress[i]));
				}

				simpleMessage.setSubject(subject);

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");

				if (null != body) {

					simpleMessage.setContent(body.toString(), "text/html");
				}
				try {

					Transport transport = mailSession.getTransport("smtp");
					// emailLogger
					// .logInfo(aModuleName, "Send()",
					// aMediationComponentName,
					// " Mail Transport Obtained");
					transport.connect();
					// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
					// "Send()", aMediationComponentName,
					// " Mail Connection Obtained", Level.INFO);
					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);
					// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
					// "Send()", aMediationComponentName,
					// " Mail Sent to : " + Arrays.toString(address),
					// Level.INFO);
					mailSent = true;
				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName, "send()",
		// aMediationComponentName, "Sent Email ?  " + mailSent,
		// Level.INFO);
		return mailSent;
	}

	private Session getSession() {
		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
		// "getSession()",
		// aMediationComponentName, "Obtain Email Session", Level.INFO);
		Authenticator authenticator = new Authenticator();
		Session session = null;
		// env = "local";
		Properties props = new Properties();
		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
		// "getSession()",
		// aMediationComponentName, "Environmeynt is " + env, Level.INFO);
		if ("local".equalsIgnoreCase(env)) {

			props.setProperty("mail.smtp.submitter", authenticator
					.getPasswordAuthentication().getUserName());
			props.setProperty("mail.smtp.auth", "true");
			props.put("mail.smtp.host", "10.32.8.7");
			props.put("mail.smtp.port", "25");
			props.put("mail.debug", "true");
			props.put("mail.transport.protocol", "smtp");

			session = Session.getInstance(props, authenticator);

		} else {
			props.put("mail.smtp.host", EMAIL_HOST);
			props.put("mail.smtp.port", EMAIL_SMTP_PORT);
			props.put("mail.debug", "true");
			props.put("mail.transport.protocol", "smtp");
			session = Session.getInstance(props);
		}

		// props.put("mail.user", user);

		// emailLogger.logCategory(LogCategory.EMAIL, aModuleName,
		// "getSession()",
		// aMediationComponentName, "Obtain Email Session", Level.INFO);

		return session;
	}

	public static Date getCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat(
				"yyyy/MM/dd 'T' HH:mm:ss Z");
		Calendar cal = Calendar.getInstance();
		Date currDate = cal.getTime();
		
		
		return currDate;
	}

	private class Authenticator extends javax.mail.Authenticator {
		private PasswordAuthentication authentication;

		public Authenticator() {
			String username = "ASurendr";
			String password = "Welcome567";
			authentication = new PasswordAuthentication(username, password);
		}

		protected PasswordAuthentication getPasswordAuthentication() {
			return authentication;
		}

	}

	static String readHTMLContent() {
		InputStream is = null;
		String responseContent = "";
		// emailLogger.logCategory(LogCategory.EMAIL, EMAILTaskExecutor.class
		// .getName(), "readHTMLContent()", EMAILTaskExecutor.class
		// .getSimpleName(), "Format HTML Content", Level.INFO);

		is = (InputStream) EMAILTaskExecutor.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/common/utils/"
						+ MESTATUS_HTML);

		if (null != is) {
			// emailLogger.logCategory(LogCategory.EMAIL,
			// EMAILTaskExecutor.class
			// .getName(), "readHTMLContent()", EMAILTaskExecutor.class
			// .getSimpleName(),
			// "InputStream for HTML Input content obtained ", Level.INFO);
			InputStreamReader reader = new InputStreamReader(is);
			responseContent = getStringFromInputStream(is);
			// emailLogger.logCategory(LogCategory.EMAIL,
			// EMAILTaskExecutor.class
			// .getName(), "readHTMLContent()", EMAILTaskExecutor.class
			// .getSimpleName(),
			// "InputStream for HTML Output content obtained "
			// + responseContent, Level.INFO);
			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}
		return responseContent;
	}

	private static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}

	private static String[] getReplacementList(DataObject aDobj) {

		DataObject contextDO = null;
		if (aDobj.isSet("context")) {
			contextDO = aDobj.getDataObject("context");
		}

		try {
			String hostName = InetAddress.getLocalHost().getHostName();
			// String[] searchList = { "$HOST", "$ERROR_MESSAGE", "$ERROR_DESC",
			// "$ERROR_CAT" };
			if (null != contextDO) {
				DataObject failInfoDO = contextDO.getDataObject("failInfo");

				if (null != failInfoDO) {
					String errorCat = "RUNTIME ERROR ";
					String failurString = failInfoDO.getString("failureString");
					String origin = failInfoDO.getString("origin");

					DataObject invocationPathDO = failInfoDO
							.getDataObject("invocationPath");
					if (null != invocationPathDO) {

						String details = Arrays.toString(invocationPathDO
								.getList("primitive").toArray());
						String[] replacementList = { hostName, failurString,
								origin + " " + details, errorCat };
						return replacementList;
					} else {
						String[] replacementList = { hostName, failurString,
								origin, errorCat };
						return replacementList;
					}
				}
			} else {

				if (aDobj.isSet("faultString") || aDobj.isSet("faultDetail")) {

					String errorCat = "Messaging Engine Runtime  ";
					String failurString = aDobj.getString("faultString");
					String failurDetail = aDobj.getString("faultDetail");

					String[] replacementList = { hostName, failurString,
							failurDetail, errorCat };

					return replacementList;
				}

				/**
				 * String[] searchList = { "$HOST", "$ERROR_MESSAGE",
				 * "$ERROR_DESC", "$ERROR_CAT" };
				 **/

			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
}
