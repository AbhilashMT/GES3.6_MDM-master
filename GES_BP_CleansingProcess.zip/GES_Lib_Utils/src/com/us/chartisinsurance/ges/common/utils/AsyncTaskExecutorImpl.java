/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.us.chartisinsurance.ges.common.thread.GESMessagingEngineCheckThread;
import com.us.chartisinsurance.ges.common.thread.GESThreadFactory;
import com.us.chartisinsurance.ges.common.thread.GenericExecutor;
import com.us.chartisinsurance.ges.common.thread.LogMonitorThread;
import com.us.chartisinsurance.ges.common.thread.MatchLogMonitor;

/**
 * @author M1019070
 * 
 */
public class AsyncTaskExecutorImpl implements AsyncTaskExecutor {

	public static AsyncTaskExecutor AsyncTaskExecutor = new AsyncTaskExecutorImpl();
	ScheduledExecutorService executorService = Executors
			.newScheduledThreadPool(1, new GESThreadFactory("MECHECK"));
	ScheduledExecutorService logMonitorexecutorService = Executors
			.newScheduledThreadPool(1, new GESThreadFactory("LogMonitor"));

	ScheduledExecutorService matchLogMonitorExecutorService = Executors
			.newScheduledThreadPool(1, new GESThreadFactory("MatchLogMonitor"));
	ExecutorService updateService = Executors.newFixedThreadPool(1,
			new GESThreadFactory("GenericUpdates"));

	public static final String env = System.getProperty("env");

	/**
	 * @param args
	 */

	private AsyncTaskExecutorImpl() {

	}

	public static void main(String[] args) {

		AsyncTaskExecutorImpl.AsyncTaskExecutor.runTask("mecheck");

	}

	@Override
	public void runTask(Object aDtaObject, String customMessage, String taskName) {
		// TODO Auto-generated method stub

	}

	@Override
	public void runTask(String taskName) {
		if ("email".equalsIgnoreCase(taskName.toLowerCase())) {
			// Run email Task

			// EMAILTaskExecutor.emailService.submit(new EMAILTaskExecutor(
			// aDtaObject, customMessage));
		}
		if ("generic".equalsIgnoreCase(taskName.toLowerCase())) {

			if (!"local".equalsIgnoreCase(env)) {
				updateService.submit(new GenericExecutor());
			}

		}
		if ("mecheck".equalsIgnoreCase(taskName.toLowerCase())) {

			executorService.scheduleAtFixedRate(
					new GESMessagingEngineCheckThread(), 10, 1800,
					TimeUnit.SECONDS);//
		}
		if ("logmonitor".equalsIgnoreCase(taskName.toLowerCase())) {

			if (!("dev".equalsIgnoreCase(env) || "local".equalsIgnoreCase(env))) {
				logMonitorexecutorService.scheduleAtFixedRate(
						new LogMonitorThread(), 10, 300, TimeUnit.SECONDS);//
			}
		}
		if ("matchlogmonitor".equalsIgnoreCase(taskName.toLowerCase())) {

			matchLogMonitorExecutorService.scheduleWithFixedDelay(
					new MatchLogMonitor(), 10, 61, TimeUnit.DAYS);
		}

	}

	@Override
	public void cancelTask(String taskName) {

		executorService.shutdown();
		matchLogMonitorExecutorService.shutdown();
		logMonitorexecutorService.shutdown();
		updateService.shutdown();

		System.out.println(" All Threads Shutdown");

	}
}
