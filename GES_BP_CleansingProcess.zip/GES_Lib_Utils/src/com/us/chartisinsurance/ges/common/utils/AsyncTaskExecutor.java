/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

/**
 * @author M1019070
 * 
 */
public interface AsyncTaskExecutor {

	public void runTask(Object aDataObject, String custoMessage, String taskName);

	public void runTask(String taskName);

	public void cancelTask(String taskName);

}
