package com.us.chartisinsurance.ges.handlers.jax.ws.custom;

import java.util.Iterator;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

public class GESCustomSOAPHandlerWS implements SOAPHandler<SOAPMessageContext> {

	private String GES_LocationService_OLDNAME = "http://chartisisnurance.us.com/ges/services/LocationServiceV3";

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.xml.ws.handler.soap.SOAPHandler#getHeaders()
	 */
	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.xml.ws.handler.Handler#close(javax.xml.ws.handler.MessageContext)
	 */
	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.xml.ws.handler.Handler#handleFault(javax.xml.ws.handler.MessageContext
	 * )
	 */
	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seejavax.xml.ws.handler.Handler#handleMessage(javax.xml.ws.handler.
	 * MessageContext)
	 */
	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		// TODO Auto-generated method stub

		SOAPMessage soapMessage = context.getMessage();
		if (null != soapMessage) {
			try {
				SOAPEnvelope soapEnv = soapMessage.getSOAPPart().getEnvelope();

				Iterator<String> nameSpacePrefixes = soapEnv
						.getNamespacePrefixes();
				while (nameSpacePrefixes.hasNext()) {
					String namespacePrefix = nameSpacePrefixes.next();
					String nameSpace = soapEnv.getNamespaceURI(namespacePrefix);

					if (GES_LocationService_OLDNAME.equalsIgnoreCase(nameSpace)) {

						soapEnv.removeNamespaceDeclaration(namespacePrefix);
						soapEnv.addNamespaceDeclaration(namespacePrefix,
								nameSpace);

					}

				}
			} catch (SOAPException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;

	}

}
