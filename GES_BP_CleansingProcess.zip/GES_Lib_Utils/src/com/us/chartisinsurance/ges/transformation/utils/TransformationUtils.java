/**
 * 
 */
package com.us.chartisinsurance.ges.transformation.utils;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOInstanceValidator;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Type;

/**
 * @author Asurendr
 * 
 */
public class TransformationUtils {
	static final BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	static final BOInstanceValidator boValidator = (BOInstanceValidator) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOInstanceValidator");

	public static DataObject prepareAcknowledgment(DataObject responseHeader)

	{
		DataObject responseContext = responseHeader.getDataObject(0);
		DataObject ackContext = bof.create("http://aig.com/CommonHeaderV12",
				"AcknowledgementContext");
		DataObject ackHeader = bof.create("http://aig.com/CommonHeaderV12",
				"AcknowledgementHeader");
		if (null != responseContext) {

			ackContext.setString("RequestMessageId", responseContext
					.getString("RequestMessageId"));
			ackContext.setString("ServiceInvoker", responseContext
					.getString("ServiceInvoker"));
			ackContext.setString("ServiceProvider", responseContext
					.getString("ServiceProvider"));
			ackContext.setString("AcknowledgementMessageId", getUniqueId());
			ackHeader.setDataObject("AcknowledgementContext", ackContext);

		}
		return ackHeader;
	}

	public static DataObject prepareAcknowledgmentFromReqContext(
			DataObject requestContext)

	{
		GESLoggerFactory.getLogger().entering(
				TransformationUtils.class.getName(),
				"prepareAcknowledgmentFromReqContext",
				TransformationUtils.class.getName(), "", requestContext);
		DataObject ackContext = bof.create("http://aig.com/CommonHeaderV12",
				"AcknowledgementContext");
		DataObject ackHeader = bof.create("http://aig.com/CommonHeaderV12",
				"AcknowledgementHeader");

		ackContext.setString("RequestMessageId", requestContext
				.getString("RequestMessageId"));
		ackContext.setString("ServiceInvoker", requestContext
				.getString("ServiceInvoker"));
		ackContext.setString("ServiceProvider", requestContext
				.getString("ServiceProvider"));
		ackContext.setString("AcknowledgementMessageId", getUniqueId());

		ackContext.set("AcknowledgementTimestamp", getDateFromXGC(getXgc()));
		ackHeader.setDataObject("AcknowledgementContext", ackContext);
		GESLoggerFactory.getLogger().exiting(
				TransformationUtils.class.getName(),
				"prepareAcknowledgmentFromReqContext",
				TransformationUtils.class.getName(), "", ackHeader);
		return ackHeader;

	}

	public static Date getDateFromXGC(XMLGregorianCalendar xgc) {
		return getXgc().toGregorianCalendar(TimeZone.getDefault(), null, null)
				.getTime();
	}

	public static DataObject prepareRespContextFromReqContext(
			DataObject contextHeader) {
		GESLoggerFactory.getLogger().entering(
				TransformationUtils.class.getName(),
				"prepareRespContextFromReqContext",
				TransformationUtils.class.getName(), "", contextHeader);
		DataObject requestHeader;
		DataObject ResponseHeader = null;
		Date requestTime;
		if (null != contextHeader) {
			//			
			if (contextHeader.getType().getURI().equalsIgnoreCase(
					"http://aig.com/CommonHeaderV12")) {
				requestHeader = contextHeader;
				requestTime = requestHeader.getDataObject(0).getDate(
						"RequestTimestamp");
			} else {
				requestHeader = contextHeader.getDataObject("RequestHeader");

			}

			GESLoggerFactory.getLogger().logInfo(
					TransformationUtils.class.getName(),
					"prepareRespContextFromReqContext",
					TransformationUtils.class.getName(),
					"Request Header Object : ", requestHeader);

			if (null != requestHeader) {
				requestTime = requestHeader.getDataObject(0).getDate(
						"RequestTimestamp");
				DataObject requestContext = requestHeader.getDataObject(0);
				GESLoggerFactory.getLogger().logInfo(
						TransformationUtils.class.getName(),
						"prepareRespContextFromReqContext",
						TransformationUtils.class.getName(),
						"Request Header/ServiceRequestContext Object : ",
						requestHeader);
				ResponseHeader = bof.create("http://aig.com/CommonHeaderV12",
						"ResponseHeader");
				DataObject responseContext = bof.create(
						"http://aig.com/CommonHeaderV12",
						"ServiceResponseContext");
				List<DataObject> serviceInvocationList = new ArrayList<DataObject>();

				DataObject serviceInvocationChain = bof.create(
						"http://aig.com/CommonHeaderV12",
						"ServiceInvocationChain");
				DataObject serviceInvocationInfo = bof.create(
						"http://aig.com/CommonHeaderV12",
						"ServiceInvocationInfo");
				if (null != requestContext) {
					Date currentTime = getCurrentTime();

					String serviceInvoker = requestContext
							.getString("ServiceInvoker");
					String serviceProvider = requestContext
							.getString("ServiceProvider");

					responseContext.setString("RequestMessageId",
							requestContext.getString("RequestMessageId"));
					responseContext.setString("ResponseMessageId",
							getUniqueId());
					responseContext.setString("ServiceInvoker", serviceInvoker);
					responseContext.setString("ServiceProvider",
							serviceProvider);

					responseContext.set("ResponseTimestamp",
							getDateFromXGC(getXgc()));

					serviceInvocationInfo.setString("ServiceInvoker",
							serviceInvoker);
					serviceInvocationInfo.setString("ServiceProvider",
							serviceProvider);
					serviceInvocationInfo.set("RequestTimestamp", requestTime);

					if (null == requestTime) {
						requestTime = currentTime;
					}

					serviceInvocationInfo.set("ResponseTimeInMilliseconds",
							getDuration(requestTime, currentTime));

					serviceInvocationList.add(serviceInvocationInfo);
					serviceInvocationChain.setList("ServiceInvocationInfo",
							serviceInvocationList);

					responseContext.setDataObject("ServiceInvocationChain",
							serviceInvocationChain);

					ResponseHeader.setDataObject("ServiceResponseContext",
							responseContext);

					GESLoggerFactory.getLogger().exiting(
							TransformationUtils.class.getName(),
							"prepareRespContextFromReqContext",
							TransformationUtils.class.getName(), "",
							ResponseHeader);
				}
			}

		}
		return ResponseHeader;
	}

	public static String getUniqueId() {

		String requesterId = UUID.randomUUID().toString();
		return requesterId.toUpperCase();

	}

	public static String getVersionIdFromString(String aString) {

		return StringUtils.split(aString, "_")[0];

	}

	public static Date getCurrentTime() {

		Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		Date date = cal.getTime();

		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSZ");

		String dateString = dateFormat.format(date);
		try {
			date = dateFormat.parse(dateString);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return date;
	}

	public static String getStringRepresentation(XMLGregorianCalendar xgc) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		String dateString = dateFormat.format(xgc.toGregorianCalendar()
				.getTime());

		return dateString;
	}

	public static Date getDateFromString(String aDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
		Date newDate = null;
		try {
			newDate = dateFormat.parse(aDate);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return newDate;
	}

	public static void main(String[] args) {

	}

	public static String validateHeader(DataObject inputHeader) {

		StringBuffer strBuff = new StringBuffer("");

		List<DataObject> errorList = new ArrayList();

		boValidator.validate(inputHeader, errorList);
		if (null != errorList) {
			for (DataObject obj : errorList) {
				String error = obj.getString("message");
				String property = obj.getString("property");
				strBuff.append(error + "{" + property + "}");
			}
		}
		return strBuff.toString();

	}

	public static String getProvider(DataObject aDataObject) {
		String provider = "";
		if (null != aDataObject) {
			provider = aDataObject.getType().getURI();
		}
		return provider;
	}

	public static String getInvoker(String qHeader) {
		String invoker = "";
		if (null != qHeader) {
			invoker = StringUtils.substringAfter(qHeader, ":");
		}
		return invoker;
	}

	public static XMLGregorianCalendar getXgc() {
		XMLGregorianCalendar xgc = null;
		GregorianCalendar gc = new GregorianCalendar(TimeZone.getDefault());
		gc.setTime(getCurrentTime());
		try {
			xgc = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return xgc;
	}

	// public String getDuration(Date aDate) {
	// String duration;
	// Calendar.getInstance().getT
	// return duration;
	//
	// }

	public static BigInteger getDuration(Date requestDate, Date responseDate) {
		long starttime = requestDate.getTime();
		long endTime = responseDate.getTime();

		return new BigInteger(Long.toString(endTime - starttime));
	}

	// ToUpper function

	public static String toUpper(String aString) {
		if (aString != null) {
			return aString.toUpperCase();
		}
		return null;

	}

	public static String generateLong() {

		return RandomStringUtils.randomNumeric(10);

	}

	public static XMLGregorianCalendar getXgcFromDate(Date aDate) {
		XMLGregorianCalendar xgc = null;
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(aDate);
		try {
			xgc = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return xgc;
	}

	public static DataObject validateAndFormatRequest(DataObject aDataObject) {
		DataObject result = null;

		@SuppressWarnings("unused")
		ArrayList errorList = new ArrayList();

		Type boType = aDataObject.getType();
		List<Property> boProps = boType.getProperties();

		for (Property property : boProps) {
			if (property.isContainment()) {

			} else {

				List props = property.getType().getProperties();

				for (int i = 0; i < props.size(); ++i) {
					System.out.println("Declared Props:  "
							+ props.get(i).toString());
				}
			}
		}

		return result;
	}

	public static String getRandomString(int length) {
		String randomStr = "";
		randomStr = RandomStringUtils.random(length, true, false);

		return randomStr;
	}

	public static String getRandomLongString(int length) {
		String randomStr = "";
		randomStr = RandomStringUtils.random(length, false, true);

		return randomStr;
	}

	public static Long incrementValue(long aLongValue) {
		return aLongValue + 1;
	}

	public static String getDecFromDouble(double aval) {

		DecimalFormat df = new DecimalFormat("###.######");

		String decimalval = df.format(aval);

		return decimalval;
	}

	public static Integer getIntegerFromInt(int aInt) {

		Integer returnInt = Integer.valueOf(aInt);

		return returnInt;
	}

}
