package com.us.chartisinsurance.ges.transformation.utils;

import java.io.IOException;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.bo.BOCopy;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.ServiceManager;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.logger.LogCategory;
import com.us.chartisinsurance.ges.logger.MatchLogFormatter;
import commonj.sdo.DataObject;

public class GESTransformationLoader {

	private static final Logger cLogger = Logger.getLogger(LogCategory.MATCH);

	private static final String sNoOfStoriesWeigh = String
			.valueOf(GESCacheLoader.getValueFromCache("sNoOfStoriesWeigh"));
	private static final String sYearBuiltWeigh = String.valueOf(GESCacheLoader
			.getValueFromCache("sYearBuiltWeigh"));
	private static final BOFactory bofService = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");

	private static final BOCopy CopyService = (BOCopy) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOCopy");

	public static void main(String[] args) {

	}

	public static String getExpression() {
		// String source =
		// "$fetchMatchResultConfig/types:Configurations//types:Configuration[types:Property[@ConfigNm='INPUT_SRC']/types:ConfigValue=$inputRequest/ges:locationSource and types:Property[@ConfigNm='SUSPECT_SRC']/types:ConfigValue=$suspectRequest/ges:locationSource and types:Property[@ConfigNm='DSTNC_FROM']/types:ConfigValue <= $suspectRequest/ges:distanceFrom and types:Property[@ConfigNm='DSTNC_TO']/types:ConfigValue >= $suspectRequest/ges:distanceFrom and types:Property[@ConfigNm='ADDR_CONFDNC_FROM']/types:ConfigValue <= $addressConfidence and  types:Property[@ConfigNm='ADDR_CONFDNC_TO']/types:ConfigValue >= $addressConfidence and types:Property[@ConfigNm='INPUT_LOC_PRECISION']/types:ConfigValue = $inputRequest/ges:geographicArea/ges:TranslatedPrecision and types:Property[@ConfigNm='SUSPECT_LOC_PRECISION']/types:ConfigValue = $suspectRequest/ges:geographicArea/ges:TranslatedPrecision and types:Property[@ConfigNm='COPE_CONFDNC_FROM']/types:ConfigValue <= $COPEConfidence and  types:Property[@ConfigNm='COPE_CONFDNC_TO']/types:ConfigValue >= $COPEConfidence]";

		String source = GESCacheLoader.getValueFromCache(
				GESConstantBundle.MATCHEXPR).toString();
		return source;
	}

	public static Document getValueFromCache(String aKey)
			throws ParserConfigurationException, SAXException, IOException {
		String xmlString = null;
		xmlString = GESCacheLoader.getValueFromCache(aKey).toString();
		DocumentBuilder db = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(xmlString));
		Document doc = db.parse(is);
		return doc;
	}

	public static void logMatchConfig(String logMessage) {
		// GESLoggerFactory.getLogger().logCategory(LogCategory.MATCH, "", "",
		// "matchConfig", logMessage, Level.INFO);

		cLogger.log(Level.INFO, MatchLogFormatter
				.getFormattedMessage(logMessage));

	}

	public static String getSimpleValueFromCache(String aKey)
			throws ParserConfigurationException, SAXException, IOException {
		String simpleString = "0";

		if (null != GESCacheLoader.getValueFromCache(aKey)) {
			simpleString = GESCacheLoader.getValueFromCache(aKey).toString();
		}

		return simpleString;
	}

	public static String convertActualToExactConversionScore(
			String aInputScore, String aInputYearBuilt,
			String aInputNoOfStories, String aSuscpectYearBuilt,
			String aSuspectNoOfStories) {
		// Pattern : Construction , YearBuilt , NoOfStories

		// sYearBuiltWeigh , sNoOfStoriesWeigh

		String[] extractedScores = StringUtils.split(aInputScore, ",");
		String constructionClassScore = extractedScores[0];
		String txYearBuiltScore = extractedScores[1];
		String txNoOfStoriesScore = extractedScores[2];

		if ("9999".equalsIgnoreCase(aSuscpectYearBuilt)
				|| "9999".equalsIgnoreCase(aInputYearBuilt)) {
			txYearBuiltScore = sYearBuiltWeigh;

		}

		if ("0".equalsIgnoreCase(aSuspectNoOfStories)
				|| "0".equalsIgnoreCase(aInputNoOfStories)) {
			txNoOfStoriesScore = sNoOfStoriesWeigh;
		}

		String finalConvertedConversionScore = constructionClassScore + ","
				+ txYearBuiltScore + "," + txNoOfStoriesScore;

		return finalConvertedConversionScore;
	}

	public static DataObject adjustLatLongValues(DataObject aDataObject) {
		DataObject outBO = CopyService.copy(aDataObject);
		DataObject PBCrosRefBO = null;

		DataObject PBCrosRefLatLongHolder = null;// $http://aig.us.com/ges$UserProvidedInfoType

		DataObject UserProvidedLatLongHolder = null;// $http://aig.us.com/ges$UserProvidedInfoType

		DataObject TargetUserProvidedLatLongHolder = null;
		if (null != aDataObject) {
			DataObject sovLocation = aDataObject.getDataObject("sovLocation");

			if (null != sovLocation) {
				if (!sovLocation.getList("pbCrossReferenceInfo").isEmpty()) {
					PBCrosRefBO = (DataObject) sovLocation.getList(
							"pbCrossReferenceInfo").get(0);
					long geoRsltnLvlId = PBCrosRefBO.getLong("geoRsltnLvlId");
					UserProvidedLatLongHolder = sovLocation
							.getDataObject("UserProvidedInfo");
					PBCrosRefLatLongHolder = PBCrosRefBO
							.getDataObject("UserProvidedInfo");
					if (null != UserProvidedLatLongHolder) {
						if (UserProvidedLatLongHolder.isSet("lattdInDegrs")) {
							String code = UserProvidedLatLongHolder
									.getDataObject("lattdInDegrs").getString(
											"Code");

							if (geoRsltnLvlId > 0
									&& "CRESTA".equalsIgnoreCase(code)) {

								TargetUserProvidedLatLongHolder = CopyService
										.copy(PBCrosRefLatLongHolder);

								outBO
										.getDataObject("sovLocation")
										.setDataObject("UserProvidedInfo",
												TargetUserProvidedLatLongHolder);

							}
						}
					} else {
						TargetUserProvidedLatLongHolder = CopyService
								.copy(PBCrosRefLatLongHolder);
						outBO.getDataObject("sovLocation").setDataObject(
								"UserProvidedInfo",
								TargetUserProvidedLatLongHolder);
					}

				}
			}
		}

		return outBO;
	}
}
