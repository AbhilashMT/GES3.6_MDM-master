package com.us.chartisinsurance.ges.logger;

import java.util.logging.Level;
import java.util.logging.Logger;

public class GESLogLevel extends Level {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1179348690997786846L;
	public static final Level GESAUDIT = new GESLogLevel("GESAUDIT", Level.SEVERE
			.intValue() + 1);

	public GESLogLevel(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

	public GESLogLevel(String name, int level, String resourceBundleName) {
		super(name, level, resourceBundleName);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {}

}
