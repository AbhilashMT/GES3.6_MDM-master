/**
 * 
 */
package com.us.chartisinsurance.ges.logger;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author ASurendr
 * 
 */
public class GESLoggerThreadPoolExecutor extends ThreadPoolExecutor {

	/**
	 * @param paramInt1
	 * @param paramInt2
	 * @param paramLong
	 * @param paramTimeUnit
	 * @param paramBlockingQueue
	 */
	public GESLoggerThreadPoolExecutor(int corePoolSize, int maxPoolSize,
			long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory,
			RejectedExecutionHandler handler) {
		super(corePoolSize, maxPoolSize, keepAliveTime, unit, workQueue,
				handler);
	
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
