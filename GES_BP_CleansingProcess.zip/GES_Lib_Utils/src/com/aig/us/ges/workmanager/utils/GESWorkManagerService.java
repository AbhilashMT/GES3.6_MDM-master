/**
 * 
 */
package com.aig.us.ges.workmanager.utils;

import java.util.logging.Level;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.websphere.asynchbeans.WorkManager;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;

/**
 * @author Asurendr
 * 
 */
public class GESWorkManagerService {

	/**
	 * 
	 */

	private static GESLoggerV4 GESWorkManagerLogger = GESLoggerFactory
			.getLogger();
	public static WorkManager gesWM;

	public GESWorkManagerService() {
		// TODO Auto-generated constructor stub
	}

	public static WorkManager locateWMService() {

		GESWorkManagerLogger.logCategory(LogCategory.CONFIG,
				GESWorkManagerService.class.getName(),
				GESWorkManagerService.class.getSimpleName(), "locateWMService",
				"Entry locateWMService", Level.INFO);

		if (null == gesWM) {
			try {
				gesWM = (WorkManager) new InitialContext()
						.lookup("wm/GESWorkManager");
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		GESWorkManagerLogger.logCategory(LogCategory.CONFIG,
				GESWorkManagerService.class.getName(),
				GESWorkManagerService.class.getSimpleName(), "locateWMService",
				"Exit locateWMService : WM Obatined " + gesWM, Level.INFO);
		return gesWM;

	}

}
