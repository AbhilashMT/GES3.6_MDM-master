package ExceptionHandlingUtils.utility.utility;
public class UpdateGESServicesFaultObjectType {
	public static commonj.sdo.DataObject updateGESServicesFaultObjectType(java.lang.String outputMessageQName, java.lang.String outputMessageName, java.lang.String customMessage, com.ibm.websphere.sibx.smobo.ServiceMessageObject smoInput, java.lang.String moduleName, java.lang.String operartionName) {
		commonj.sdo.DataObject __result__3;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(outputMessageQName, outputMessageName));
			__result__3 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject SMOOutputBody = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://aig.us.com/ges/common/v3","ArrayOfGESFault");
		}
		commonj.sdo.DataObject arrayOfGESFault = __result__5;
		commonj.sdo.DataObject __result__7;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__7 = factory.create("http://aig.us.com/ges/common/v3","GesFaultObjectType");
		}
		commonj.sdo.DataObject GesFaultObjectType = __result__7;
		java.lang.String __result__10 = "GES-";
		int __result__11 = customMessage.indexOf(__result__10);
		int strIndex = __result__11;
		java.lang.String __result__13 = "";
		java.lang.String ExcepCode = __result__13;
		boolean __result__15 = -1 == strIndex;
		if (__result__15){
			java.lang.String __result__18 = "GES-SYS-GNRCF3010";
			ExcepCode = __result__18;
		}
		else{
			java.lang.String __result__22 = ":";
			int __result__23 = customMessage.indexOf(__result__22);
			int codeIndex = __result__23;
			boolean __result__25 = -1 == codeIndex;
			if (__result__25){
				java.lang.String __result__29 = customMessage.trim();
				ExcepCode = __result__29;
			}
			else{
				int __result__33 = codeIndex + 1;
				java.lang.String __result__34 = customMessage.substring(__result__33);
				java.lang.String __result__35 = __result__34.trim();
				ExcepCode = __result__35;
			}
		}
		GesFaultObjectType.setString("faultCode", ExcepCode);
		java.lang.String __result__37 = "DummyTest";
		java.lang.String __result__42 = com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler.formatException(ExcepCode, __result__37, moduleName, operartionName);
		GesFaultObjectType.setString("faultString", __result__42);
		java.util.ArrayList __result__44 = new java.util.ArrayList();
		java.util.List faultList = __result__44;
		boolean __result__47;
		{// add item to list
			__result__47 = faultList.add(GesFaultObjectType);
		}
		byte __result__49 = 0;
		arrayOfGESFault.setList(__result__49, faultList);
		byte __result__53 = 0;
		commonj.sdo.DataObject __result__54 = SMOOutputBody.createDataObject(__result__53);
		commonj.sdo.DataObject SMOOutputBody_FirstChild = __result__54;
		SMOOutputBody_FirstChild = arrayOfGESFault;
		byte __result__60 = 0;
		SMOOutputBody.setDataObject(__result__60, SMOOutputBody_FirstChild);
		java.lang.String __result__63 = "..";
		commonj.sdo.DataObject __result__64 = SMOOutputBody.getDataObject(__result__63);
		return __result__64;
	}
}