package endpointUtils.soap.soap;
public class SetDynamicEndpoint {
	public static void setDynamicEndpoint(com.ibm.wsspi.sibx.mediation.esb.SCAServices SCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MediationServices)throws com.ibm.websphere.sca.ServiceRuntimeException  {
		com.ibm.websphere.sca.scdl.Component __result__2 = SCAServices.getParentComponent();
		java.util.List __result__3 = __result__2.getReferences();
		java.util.List References = __result__3;
		java.lang.String __result__6 = SCAServices.getModuleName();
		java.lang.String ModuleName = __result__6;
		java.lang.String __result__9 = com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo.getModuleVersion(SCAServices);
		java.lang.String version = __result__9;
		java.util.Iterator iter8 = References.iterator();
		while(iter8.hasNext()){
			com.ibm.websphere.sca.scdl.Reference Reference = (com.ibm.websphere.sca.scdl.Reference)iter8.next();
			java.lang.String __result__13 = Reference.getName();
			java.lang.String __result__16 = null;
			try {
				__result__16 = com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig.getURI(__result__13, ModuleName, version);
			}
			catch(com.ibm.websphere.sca.ServiceRuntimeException ex){
				throw ex;
			}
			com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints.setEndPoint(__result__13, version, __result__16);
		}
	}
}