/**
 * 
 */
package com.aig.us.ges.cache.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.cache.DistributedMap;
import com.ibm.websphere.sca.ServiceManager;
import com.us.aig.ges.constants.GESConstantBundle;
import commonj.sdo.DataObject;

/**
 * @author Asurendr
 * 
 */
public class GESCacheLoader {

	public static DistributedMap gesdbCache = initCache();

	private static final String env = System.getProperty("env");

	private static final Logger GESCacheLogger = Logger.getLogger("CONFIG");
	private static final ServiceManager sm = ServiceManager.INSTANCE;
	private static final BOFactory bof = (BOFactory) sm
			.locateService("com/ibm/websphere/bo/BOFactory");

	static DistributedMap initCache() {

		try {
			InitialContext ic = new InitialContext();

			return (DistributedMap) ic.lookup("cache/GESCACHE");

		} catch (NamingException e) {
			e.printStackTrace();

			return null;
		}
	}

	public static boolean setUpCache() {

		boolean cacheInitialized = false;
		AuthCredentials credentialsSetUp = new AuthCredentials();

		GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
				"setUpCache", "Initializing GES Cache");

		if (null != gesdbCache) {

			gesdbCache.put(GESConstantBundle.GES_ENABLE_GATEWAY, true);
			gesdbCache.put(GESConstantBundle.PEGA_UNAME, "serviceuser");
			gesdbCache.put(GESConstantBundle.PEGA_PASSWORD, "rules");
			gesdbCache.put(GESConstantBundle.LOGONLYEVENTS, false);
			gesdbCache.put(GESConstantBundle.USESPICOMPONENT, false);
			gesdbCache.put(GESConstantBundle.ACTIVATECMONITOR, false);
			gesdbCache.put(GESConstantBundle.EnableCleansingRetry, false);
			gesdbCache.put(GESConstantBundle.PBBI_PROCESSING_MODE, true);
			gesdbCache.put(GESConstantBundle.FILTERING_PROCESSING_MODE, true);

			String source = "$fetchMatchResultConfig/types:Configurations//types:Configuration[types:Property[@ConfigNm='INPUT_SRC']/types:ConfigValue=$inputRequest/ges:locationSource and types:Property[@ConfigNm='SUSPECT_SRC']/types:ConfigValue=$suspectRequest/ges:locationSource and types:Property[@ConfigNm='DSTNC_FROM']/types:ConfigValue <= $suspectRequest/ges:distanceFrom and types:Property[@ConfigNm='DSTNC_TO']/types:ConfigValue >= $suspectRequest/ges:distanceFrom and types:Property[@ConfigNm='ADDR_CONFDNC_FROM']/types:ConfigValue <= $addressConfidence and  types:Property[@ConfigNm='ADDR_CONFDNC_TO']/types:ConfigValue >= $addressConfidence and types:Property[@ConfigNm='INPUT_LOC_PRECISION']/types:ConfigValue = $inputRequest/ges:geographicArea/ges:TranslatedPrecision and types:Property[@ConfigNm='SUSPECT_LOC_PRECISION']/types:ConfigValue = $suspectRequest/ges:geographicArea/ges:TranslatedPrecision and types:Property[@ConfigNm='COPE_CONFDNC_FROM']/types:ConfigValue <= $COPEConfidence and  types:Property[@ConfigNm='COPE_CONFDNC_TO']/types:ConfigValue >= $COPEConfidence]";

			gesdbCache.put(GESConstantBundle.MATCHEXPR, source);
			credentialsSetUp.writeFile(null);
			credentialsSetUp.setUpAuthCache();

			String scrubbingNotifyAddress = "AigGes.IbmEsbteam@mindtree.com,Aigges.Pegateam@mindtree.com";
			String notifyGraspAddress = "AigGes.IbmEsbteam@mindtree.com,Aigges.Pegateam@mindtree.com";
			if ("prod".equalsIgnoreCase(env)) {
				scrubbingNotifyAddress = scrubbingNotifyAddress + ","
						+ "AIGES.PRODSupport@mindtree.com";
				notifyGraspAddress = notifyGraspAddress + ","
						+ "AIGES.PRODSupport@mindtree.com";

			}
			if ("qa".equalsIgnoreCase(env) || "model".equalsIgnoreCase(env)) {
				scrubbingNotifyAddress = scrubbingNotifyAddress + ","
						+ "ITS-IIG-AIGGESQA@mindtree.com";
				notifyGraspAddress = notifyGraspAddress + ","
						+ "ITS-IIG-AIGGESQA@mindtree.com";

			}

			GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
					"setUpCache",
					"Cache Loaded Successfully , Application ready for Usage");

			cacheInitialized = true;

		} else {
			GESCacheLogger.logp(Level.SEVERE, GESCacheLoader.class.getName(),
					"setUpCache",
					"Cache Loading failed , Issues while setting up cache ");

			cacheInitialized = false;
		}

		return cacheInitialized;
	}

	public static Object getValueFromCache(String aKey) {

		GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
				"getValueFromCache", "getValueFromCache Entry");
		Object value = null;

		DistributedMap gesCache = getDbCache();

		if (null != gesCache) {
			GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
					"getValueFromCache", "Cache Looked Up");

			value = gesCache.get(aKey);

			GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
					"getValueFromCache", "Cache Looked Up for Key " + aKey
							+ " Value : " + value);

		} else {

			GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
					"getValueFromCache",
					"FETCH FROM NODE LEVEL CACHE, Check Cache COnfiguration");

			value = gesdbCache.get(aKey);
		}

		GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
				"getValueFromCache", "getValueFromCache for Key " + aKey
						+ "  Value derived  ==> " + value);
		return value;
	}

	public static boolean setValueToCache(String aKey, String aValue) {

		GESCacheLogger.logp(Level.FINEST, GESCacheLoader.class.getName(),
				"setValueToCache", "setValueToCache for Key " + aKey
						+ " Value to be set == > " + aValue);
		boolean isCacheUpdated = false;
		DistributedMap gesCache = getDbCache();
		if (null != gesCache) {

			gesCache.put(aKey, aValue);
			isCacheUpdated = true;

		} else {
			gesdbCache.put(aKey, aValue);
			isCacheUpdated = true;

			GESCacheLogger.logp(Level.SEVERE, GESCacheLoader.class.getName(),
					"setValueToCache", "Local Nodel Level Cache only updated");
		}

		GESCacheLogger.logp(Level.SEVERE, GESCacheLoader.class.getName(),
				"setValueToCache", "setValueToCache for Key " + aKey
						+ "  Value to be set   ==> " + aValue);
		return isCacheUpdated;
	}

	public static DistributedMap getDbCache() {

		try {
			InitialContext ic = new InitialContext();

			return (DistributedMap) ic.lookup("cache/GESCACHE");

		} catch (NamingException e) {
			e.printStackTrace();

			return null;
		}

	}

	public static List<DataObject> retrieveCacheValues() {

		List<DataObject> responseList = new ArrayList<DataObject>();
		DistributedMap gesCache = GESCacheLoader.getDbCache();

		if (null != gesCache) {

			Set keySet = gesCache.keySet();

			Iterator keyIterator = keySet.iterator();

			while (keyIterator.hasNext()) {
				DataObject response = bof.create("http://GES_Lib_Common/bo",
						"RetrieveCacheValues");
				String key = keyIterator.next().toString();
				String keyValue = (null != gesCache.get(key) ? gesCache
						.get(key).toString() : "");
				response.setString("Key", key);
				response.setString("Value", keyValue);
				responseList.add(response);
			}

		}
		return responseList;
	}

}
