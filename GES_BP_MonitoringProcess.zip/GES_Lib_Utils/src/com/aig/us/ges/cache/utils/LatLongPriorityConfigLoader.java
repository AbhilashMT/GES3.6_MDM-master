package com.aig.us.ges.cache.utils;

import java.io.InputStream;
import java.util.logging.Level;

import org.apache.commons.io.IOUtils;

import com.us.aig.ges.constants.GESConstantBundle;
import com.us.aig.ges.dataobject.utils.DataObjectUtils;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.LogCategory;

public class LatLongPriorityConfigLoader {
	private static final String CONFIGURATION_FILE = "AssignLatLongPriority.xml";

	public static void prepareConfig() throws Exception {
		String resultData = null;
		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				LatLongPriorityConfigLoader.class.getName(), "prepareConfig",
				LatLongPriorityConfigLoader.class.getSimpleName(),
				"prepareConfig() For LatLongPriority Entry", Level.INFO);
		InputStream is = null;
		is = (InputStream) LatLongPriorityConfigLoader.class
				.getResourceAsStream("/com/aig/us/ges/cache/utils/"
						+ CONFIGURATION_FILE);

		if (null != is) {

			resultData = IOUtils.toString(is);

			String finalData = DataObjectUtils.dataObjectToString(
					DataObjectUtils.stringToDataObject(resultData),
					"Configurations");
			GESCacheLoader.getDbCache().put(GESConstantBundle.LATLONGPRIORITY,
					finalData);
		} else {
			GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
					LatLongPriorityConfigLoader.class.getName(),
					"prepareConfig",
					LatLongPriorityConfigLoader.class.getSimpleName(),
					"Unable to read configuration", Level.SEVERE);
			throw new Exception(" Unable to read configuration");
		}

		GESLoggerFactory.getLogger().logCategory(LogCategory.CONFIG,
				LatLongPriorityConfigLoader.class.getName(), "prepareConfig",
				LatLongPriorityConfigLoader.class.getSimpleName(),
				"prepareConfig() Exit : " + resultData, Level.INFO);
	}

}
