/**
 * 
 */
package com.us.chartisinsurance.ges.mediation.module.utils;

import java.util.logging.Level;

import org.apache.commons.lang3.StringUtils;

import com.ibm.wsspi.sibx.mediation.esb.SCAServices;
import com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;

/**
 * @author Abhilash
 * 
 */
public class MediationModuleMetaInfo {

	private static final String DEFAULT_VERSION = "default";
	private static final String VERSIONIDENTIFIER = "_v";
	private static final String SEARCHSTRING = "_";
	private static final String REPLACEMENTSTRING = ".";
	private static final String APP = "App";
	private static final String VERSIONSEP = "_v";
	private static GESLoggerV4 MediationModuleMetaInfoLogger = GESLoggerFactory
			.getLogger();

	public static String getModuleVersion(SCAServices aSCAService)

	{
		MediationModuleMetaInfoLogger.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(), "getModuleVersion",
				MediationModuleMetaInfo.class.getName(), " Entry -> \n",
				Level.INFO);
		String version = DEFAULT_VERSION;
		if (null != aSCAService) {
			String aModuleName = aSCAService.getModuleName();

			version = extractVersionFromModuleName(aModuleName);

			if (null != version && version.length() == 0) {
				version = DEFAULT_VERSION;
			}
		}
		MediationModuleMetaInfoLogger.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(), "getModuleVersion",
				MediationModuleMetaInfo.class.getName(),
				"Version to Consider : " + version + "\n", Level.INFO);
		MediationModuleMetaInfoLogger.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(), "getModuleVersion",
				MediationModuleMetaInfo.class.getName(), " Exit -> \n",
				Level.INFO);
		return version;

	}

	public static String extractVersionFromModuleName(String aModuleName) {
		MediationModuleMetaInfoLogger.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(),
				"extractVersionFromModuleName", MediationModuleMetaInfo.class
						.getName(), " Entry -> \n", Level.INFO);

		String versionSuffix = StringUtils.substringAfterLast(aModuleName,
				VERSIONIDENTIFIER);
		String suppliedversion = StringUtils.replace(versionSuffix,
				SEARCHSTRING, REPLACEMENTSTRING);
		MediationModuleMetaInfoLogger.logCategory(LogCategory.EPR,
				MediationModuleMetaInfo.class.getName(),
				"extractVersionFromModuleName", MediationModuleMetaInfo.class
						.getName(), " Module Version :" + suppliedversion
						+ " Exit -> \n", Level.INFO);
		return suppliedversion;

	}

	public static void main(String[] args) {

	}

	public static String getBPCModuleVersion(String aApplicationName) {
		String version = DEFAULT_VERSION;
		MediationModuleMetaInfoLogger.entering(MediationModuleMetaInfo.class
				.getName(), "getBPCModuleVersion",
				MediationModuleMetaInfo.class.getName(), " Entry -> \n");

		if (null != aApplicationName) {

			if (-1 != aApplicationName.indexOf(APP)) {

				String moduleName = StringUtils.substringBefore(
						aApplicationName, APP);
				version = extractVersionFromModuleName(moduleName);
			}

		}
		MediationModuleMetaInfoLogger.exiting(MediationModuleMetaInfo.class
				.getName(), "getBPCModuleVersion",
				MediationModuleMetaInfo.class.getName(),
				" BPC Module Version : " + version + " Exit -> \n");
		return version;

	}

	public static String getBPCModuleName(String aApplicationName) {
		MediationModuleMetaInfoLogger.entering(MediationModuleMetaInfo.class
				.getName(), "getBPCModuleName", MediationModuleMetaInfo.class
				.getName(), " Entry -> \n");

		String bpcModuleName = aApplicationName;

		if (null != aApplicationName) {
			if (-1 != aApplicationName.indexOf(APP)) {
				bpcModuleName = StringUtils.substringBefore(aApplicationName,
						APP);
				bpcModuleName = getModuleBaseName(bpcModuleName);
			}
		}
		MediationModuleMetaInfoLogger.exiting(MediationModuleMetaInfo.class
				.getName(), "getBPCModuleName", MediationModuleMetaInfo.class
				.getName(), " BPC Module Name : " + bpcModuleName
				+ "Exit -> \n");
		return bpcModuleName;

	}

	private static String getModuleBaseName(String aVersionedModuleName) {

		String moduleBaseName = aVersionedModuleName;

		if (null != aVersionedModuleName && aVersionedModuleName.length() != 0) {
			if (aVersionedModuleName.contains(VERSIONSEP)) {

				moduleBaseName = StringUtils.substringBeforeLast(
						aVersionedModuleName, VERSIONSEP);

				MediationModuleMetaInfoLogger.logInfo(
						XMLConfig.class.getName(), "getModuleBaseName",
						XMLConfig.class.getName(),
						"Module name under consideration : " + moduleBaseName);
			}

		}

		return moduleBaseName;

	}
}
