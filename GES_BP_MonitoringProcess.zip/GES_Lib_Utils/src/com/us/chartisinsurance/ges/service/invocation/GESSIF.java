/**
 * 
 */
package com.us.chartisinsurance.ges.service.invocation;

import java.util.Map;

import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceRuntimeException;
import commonj.sdo.DataObject;

/**
 * @author M1019070
 * 
 */
public interface GESSIF {

	public DataObject invokeService(String methodName, String aPartnerName,
			DataObject aDataObject) throws ServiceBusinessException,
			ServiceRuntimeException, Exception;

	public DataObject invokeService(String methodName, String aPartnerName,
			String aTargetAddress, DataObject aDataObject)
			throws ServiceBusinessException, ServiceRuntimeException, Exception;

	public DataObject invokeEISServiceSP(DataObject aDataObject,
			String aParentOperatioName) throws ServiceBusinessException,
			ServiceRuntimeException;

	public DataObject invokeEISService(String aPartnerName, String boXMLString)
			throws ServiceBusinessException, ServiceRuntimeException;

	public void invokeServiceAsync(String methodName, String aPartnerName,
			DataObject aDataObject) throws ServiceBusinessException,
			ServiceRuntimeException, Exception;

	public void invokeServiceAsync(String methodName, String aPartnerName,
			String targetAddress, DataObject aDataObject)
			throws ServiceBusinessException, ServiceRuntimeException, Exception;

	public DataObject invokeCustomQuery(String aQueryName,
			Map<String, String> aParamMap) throws ServiceBusinessException;
}
