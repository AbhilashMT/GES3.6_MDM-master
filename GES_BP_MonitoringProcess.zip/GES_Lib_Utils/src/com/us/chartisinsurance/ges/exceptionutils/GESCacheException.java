/**
 * 
 */
package com.us.chartisinsurance.ges.exceptionutils;

/**
 * @author Asurendr
 * 
 */
public class GESCacheException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5431285432315577863L;
	/**
	 * 
	 */

	public String aErrorCode;

	public String getAErrorCode() {
		return aErrorCode;
	}

	public void setAErrorCode(String errorCode) {
		aErrorCode = errorCode;
	}

	public String getAErrorMessage() {
		return aErrorMessage;
	}

	public void setAErrorMessage(String errorMessage) {
		aErrorMessage = errorMessage;
	}

	public String getAErrorDetails() {
		return aErrorDetails;
	}

	public void setAErrorDetails(String errorDetails) {
		aErrorDetails = errorDetails;
	}

	public String aErrorMessage;
	public String aErrorDetails;

	public GESCacheException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public GESCacheException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GESCacheException(String errorCode, String errorMessage,
			String errorDetails) {
		super();
		aErrorCode = errorCode;
		aErrorMessage = errorMessage;
		aErrorDetails = errorDetails;
	}

	/**
	 * @param cause
	 */
	public GESCacheException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public GESCacheException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
