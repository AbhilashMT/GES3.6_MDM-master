/**
 * 
 */
package com.us.chartisinsurance.ges.common.thread;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author M1019070
 * 
 */
public class GESRejectedExecutionHandler implements RejectedExecutionHandler {

	/**
	 * 
	 */
	private String rejectName;

	public GESRejectedExecutionHandler() {
		// TODO Auto-generated constructor stub
	}

	public GESRejectedExecutionHandler(String taskName) {

		super();
		this.rejectName = taskName;

		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * java.util.concurrent.RejectedExecutionHandler#rejectedExecution(java.
	 * lang.Runnable, java.util.concurrent.ThreadPoolExecutor)
	 */
	@Override
	public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
		System.out.println("Task Rejected : " + this.rejectName
				+ " Retrying Task after delay ");

		System.out.println(" No Action Performed on the failed execution : "
				+ r.toString());

	}

}
