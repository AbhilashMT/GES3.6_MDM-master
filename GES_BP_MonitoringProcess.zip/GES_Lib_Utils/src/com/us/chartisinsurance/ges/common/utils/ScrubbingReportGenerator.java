/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Asurendr
 * 
 */
public class ScrubbingReportGenerator {

	private final static String SCRUBBINGREPORT_HTML = "ScrubbingReport.html";
	private final static String METADATAPREFIX = "<!--METADATA:";
	private final static String METADATASUFFIX = "-->";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String htmlContent = readHTMLContent();
		
	}

	static String readHTMLContent() {
		InputStream is = null;
		String responseContent = "";
		// emailLogger.logCategory(LogCategory.EMAIL, EMAILTaskExecutor.class
		// .getName(), "readHTMLContent()", EMAILTaskExecutor.class
		// .getSimpleName(), "Format HTML Content", Level.INFO);

		is = (InputStream) ScrubbingReportGenerator.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/common/utils/"
						+ SCRUBBINGREPORT_HTML);

		if (null != is) {
			// emailLogger.logCategory(LogCategory.EMAIL,
			// EMAILTaskExecutor.class
			// .getName(), "readHTMLContent()", EMAILTaskExecutor.class
			// .getSimpleName(),
			// "InputStream for HTML Input content obtained ", Level.INFO);
			InputStreamReader reader = new InputStreamReader(is);
			responseContent = getStringFromInputStream(is);
			// emailLogger.logCategory(LogCategory.EMAIL,
			// EMAILTaskExecutor.class
			// .getName(), "readHTMLContent()", EMAILTaskExecutor.class
			// .getSimpleName(),
			// "InputStream for HTML Output content obtained "
			// + responseContent, Level.INFO);
			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}

		return responseContent;
	}

	private static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}

	private static String getMetaDataFromTemplate(String aHtmlTemplateString) {
		String response = "";

		if (StringUtils.contains(aHtmlTemplateString, METADATAPREFIX)) {

			response = StringUtils.substringBetween(aHtmlTemplateString,
					METADATAPREFIX, METADATASUFFIX);

		}

		return response;
	}
	
	public void appendTableDataForScrubbing(String sovLocationId,String Origin,String ErrorMessage)
	{
		
	}
}
