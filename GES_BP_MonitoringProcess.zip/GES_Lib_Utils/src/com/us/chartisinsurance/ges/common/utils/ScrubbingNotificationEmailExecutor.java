/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import commonj.sdo.DataObject;

/**
 * @author Asurendr
 * 
 */
public class ScrubbingNotificationEmailExecutor extends AbstractEmailGenerator {

	/**
	 * 
	 */

	public static String env = System.getProperty("env");
	private final static String SCRUBBINGXSL = "NOTIFYSCRUBBING.XSL";

	public ScrubbingNotificationEmailExecutor() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.us.chartisinsurance.ges.common.utils.AbstractEmailGenerator#send(
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String[],
	 * java.lang.String[])
	 */

	public boolean sendScrubbingNotification(DataObject aDobj, String aSovId) {
		// TODO Auto-generated method stub
		String aXSLSource = getFileAsString(SCRUBBINGXSL);
		String aXMLString = GESLoggerFactory.getLogger().dataObjectToString(
				aDobj, "NotifyExceptionsRequest");
		String htmlString = transformXMLtoHtml(aXMLString, aXSLSource);

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		String derivedAddress = GESCacheLoader.getDbCache().get(
				GESConstantBundle.GES_NOFIFY_SCRUBBINGADDR).toString();
		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();
				String[] toAddress = getQualifiedAddress(derivedAddress);
				simpleMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}

				simpleMessage
						.setSubject("GES WBI Notification : Cleansing Report for SOV : "
								+ aSovId
								+ " Region : "
								+ StringUtils.upperCase(env));

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");

				if (null != htmlString) {

					simpleMessage.setContent(htmlString, "text/html");
				}
				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);

					System.out
							.println(" ** Cleansing Report Notification Sent *** \n ");

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public boolean sendScrubbingNotification(String aXML, String aSovId,
			String aXSL) {
		// TODO Auto-generated method stub
		String aXSLSource = getFileAsString(aXSL);
		String aXMLString = getFileAsString(aXML);
		String htmlString = transformXMLtoHtml(aXMLString, aXSLSource);

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;
		String derivedAddress = GESConstantBundle.GES_NOFIFY_SCRUBBINGADDR;
		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();
				String[] toAddress = getQualifiedAddress(derivedAddress);
				simpleMessage.setFrom(fromAddress);

				for (int i = 0; i < toAddress.length; i++) {
					simpleMessage.addRecipient(RecipientType.TO,
							new InternetAddress(toAddress[i]));
				}

				simpleMessage
						.setSubject("GES WBI Notification : Cleansing Report for SOV : "
								+ aSovId);

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");

				if (null != htmlString) {

					simpleMessage.setContent(htmlString, "text/html");
				}
				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ScrubbingNotificationEmailExecutor().sendScrubbingNotification(
				"NotifyCleansingMonitor.xml", "1122", "ScrubbingTransform.xsl");
	}

	public boolean sendSimple(String content, String toAddress) {

		// TODO Auto-generated method stub

		Session mailSession = getSession();
		MimeMessage simpleMessage = new MimeMessage(mailSession);

		InternetAddress fromAddress = null;

		try {
			fromAddress = new InternetAddress(GESConstantBundle.GES_FROM_ADDR);

			try {

				// String hostName = InetAddress.getLocalHost().getHostName();

				simpleMessage.setFrom(fromAddress);

				simpleMessage.addRecipient(RecipientType.TO,
						new InternetAddress(toAddress));
				simpleMessage.setSubject("Environment Status Update : "

				+ " Region : " + StringUtils.upperCase(env));

				simpleMessage.setSentDate(getCurrentDate());

				simpleMessage.setHeader("X-Priority", "1");

				simpleMessage.setContent(content, "text/plain");

				try {

					Transport transport = mailSession.getTransport("smtp");

					transport.connect();

					Address[] address = simpleMessage.getAllRecipients();

					transport.sendMessage(simpleMessage, address);

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}
}
