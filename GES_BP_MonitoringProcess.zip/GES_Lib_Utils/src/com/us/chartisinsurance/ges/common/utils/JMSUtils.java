/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueConnectionFactory;

import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLDocument;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceManager;
import com.us.chartisinsurance.ges.gateway.utils.InspectMessageType;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import commonj.sdo.DataObject;

/**
 * @author araju
 * 
 */
public class JMSUtils {

	/**
	 * 
	 */

	static BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	private static final String AUGMENTEDOPERATIONAME = "updateAugmentedLocation";
	private static final String PBBIOPERATIONAME = "updatePBBIExceptions";
	private static final String MDMOPERATIONAME = "updateMDMExceptions";
	private static final String EXCEPTIONOPERATIONAME = "handleRuntimeExceptions";
	static final String UPDATELOCATIONTYPE = "updateLocationInGESRequestType";
	static final String LOCATIONEXCEPTION = "LocationExceptionFault";
	static final String PBBI = "PBBI";
	static final String MDM = "MDM";
	static final String AUGMENTED = "Augmented";
	static BOXMLSerializer BOXML = (BOXMLSerializer) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");
	QueueConnectionFactory qcf = null;
	Queue sourceQueue = null;
	static GESLoggerV4 JMSUtilsLogger = GESLoggerFactory.getLogger();

	public JMSUtils() {
		// TODO Auto-generated constructor stub
	}

	public static DataObject browseMessage(DataObject browseMessageRequest)
			throws ServiceBusinessException {
		JMSUtilsLogger.entering(JMSUtils.class.getName(), "browseMessage",
				JMSUtils.class.getName(),
				"About to Browse Message  -----------> : ",
				browseMessageRequest);
		String qcfJndi = "";
		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue sourceQueue = null;
		DataObject response = null;

		List<DataObject> responseBOList = new ArrayList();
		Connection con = null;
		Session session = null;
		QueueBrowser queueBrowser = null;

		try {

			if (null != browseMessageRequest) {

				if (browseMessageRequest.isSet("qcfJndi")
						&& (browseMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = browseMessageRequest.getString("qcfJndi");

				if (browseMessageRequest.isSet("queueJndi")
						&& (browseMessageRequest.getString("queueJndi")
								.length() != 0))
					queueJndi = browseMessageRequest.getString("queueJndi");

				JMSUtilsLogger.logInfo(JMSUtils.class.getName(),
						"browseMessage", JMSUtils.class.getName(), " QCF : "
								+ qcfJndi + "  Queue : " + queueJndi);

				Context initCtxt = null;

				initCtxt = new InitialContext();

				qcf = (ConnectionFactory) initCtxt.lookup(qcfJndi);
				con = qcf.createConnection();
				sourceQueue = (Queue) initCtxt.lookup(queueJndi);
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				queueBrowser = session.createBrowser(sourceQueue);

				JMSUtilsLogger
						.logSevere(
								JMSUtils.class.getName(),
								"browseMessage",
								JMSUtils.class.getName(),
								" MQ JMS Objects Created are : Conn Factory , Connection , Queue , Session & Queue Browser");

				Enumeration messageEnum = queueBrowser.getEnumeration();

				int numMsgs = 1;
				if (!messageEnum.hasMoreElements()) {
					JMSUtilsLogger.logSevere(JMSUtils.class.getName(),
							"browseMessage", JMSUtils.class.getName(),
							" NO Messages Exist in Queue");

				} else {
					while (messageEnum.hasMoreElements()) {

						Message textMessage = (Message) messageEnum
								.nextElement();
						if (textMessage instanceof TextMessage) {

							String jmsMsg = ((TextMessage) textMessage)
									.getText();

							DataObject boFromQueue = InspectMessageType
									.getBOFromXML(jmsMsg);// getBO

							if (null != boFromQueue) {
								JMSUtilsLogger.logSevere(JMSUtils.class
										.getName(), "browseMessage",
										JMSUtils.class.getName(),
										" Message No : {" + numMsgs + "}"
												+ "  \n ", boFromQueue);

								numMsgs++;
								responseBOList.add(boFromQueue);
							}
						}

					}

				}
			}
		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);

		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		}

		response = bof.create("http://aig.us.com/jms/common/bo",
				"BrowseMessageResponse");
		JMSUtilsLogger.logSevere(JMSUtils.class.getName(), "browseMessage",
				JMSUtils.class.getName(), " Queue Contents List  : "
						+ Arrays.toString(responseBOList.toArray()));
		response.setList(0, responseBOList);
		JMSUtilsLogger.logSevere(JMSUtils.class.getName(), "browseMessage",
				JMSUtils.class.getName(),
				" All Messages Browsed from Queue : ", response);

		return response;
	}

	public void processMessages(DataObject processMessageInput)
			throws ServiceBusinessException {
		boolean messageExists = true;

		try {
			MetaInfo.getMetaInfo().getversion();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean canAccessBus = true;

		Connection con = null;
		Session session = null;
		MessageConsumer consumer = null;
		String selector = "";
		JMSUtilsLogger.entering(JMSUtils.class.getName(), "processMessages",
				JMSUtils.class.getName(),
				"Start Processing recovered messages", processMessageInput);

		try {
			con = qcf.createConnection();
		} catch (JMSException e) {
			if (e.getCause().getMessage().startsWith("CWSIP0302E"))
				canAccessBus = false;
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);
		}
		try {
			if (canAccessBus) {
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				if (null != processMessageInput) {
					if (processMessageInput.isSet("messageId")
							&& processMessageInput.getString("messageId") != "") {
						String messageID = processMessageInput
								.getString("messageId");
						JMSUtilsLogger.logInfo(JMSUtils.class.getName(),
								"putMessage", JMSUtils.class.getName(),
								" Message ID is :" + messageID);
						selector = "JMSMessageID ='" + messageID + "'";
						consumer = session
								.createConsumer(sourceQueue, selector);
					} else {
						consumer = session.createConsumer(sourceQueue);
						JMSUtilsLogger.logInfo(JMSUtils.class.getName(),
								"putMessage", JMSUtils.class.getName(),
								" Message ID is Empty :");
					}
				} else {
					consumer = session.createConsumer(sourceQueue);
					JMSUtilsLogger
							.logInfo(JMSUtils.class.getName(), "putMessage",
									JMSUtils.class.getName(),
									" Message ID Not provided , All messages will be processed :");
				}

				con.start();

				while (messageExists) {

					Message jmsMessage = consumer.receive(10L);

					if (jmsMessage instanceof TextMessage) {

						String message = ((TextMessage) jmsMessage).getText();

						JMSUtilsLogger.logInfo(JMSUtils.class.getName(),
								"putMessage", JMSUtils.class.getName(),
								"Message to process :" + message);

						if (null != message && message.length() != 0) {

							DataObject sendErrorMessageBO = getBOFromXMlString(message);
							String requestType = getType(sendErrorMessageBO);

							DataObject requestBO = constructDataObject(getDataObject(sendErrorMessageBO));

							if (UPDATELOCATIONTYPE.equalsIgnoreCase(requestType
									.trim())) {
								String messageFilter = getMessageFilter(requestBO);
								JMSUtilsLogger.logInfo(
										JMSUtils.class.getName(), "putMessage",
										JMSUtils.class.getName(),
										" Request is of type :"
												+ UPDATELOCATIONTYPE);

								if (AUGMENTED.equalsIgnoreCase(messageFilter
										.trim())) {
									// Invoke updateAugmentedLocation
									try {
										invokeService(AUGMENTEDOPERATIONAME,
												requestBO);
									} catch (Exception e) {
										e.printStackTrace();
										break;
									}
								} else if (PBBI.equalsIgnoreCase(messageFilter
										.trim())) {
									// Invoke updatePBBIExceptions
									try {
										invokeService(PBBIOPERATIONAME,
												requestBO);
									} catch (Exception e) {
										e.printStackTrace();
										break;
									}
								} else if (MDM.equalsIgnoreCase(messageFilter
										.trim())) {
									// Invoke updateMDMExceptions
									try {
										invokeService(MDMOPERATIONAME,
												requestBO);
									} catch (Exception e) {
										e.printStackTrace();
										break;
									}
								}
							} else if (LOCATIONEXCEPTION
									.equalsIgnoreCase(requestType.trim())) {
								// Invoke handleRuntimeExceptions
								try {
									invokeService(EXCEPTIONOPERATIONAME,
											requestBO);
								} catch (Exception e) {
									e.printStackTrace();
									break;
								}
							}
							// no check for filter : PBBI , MDM ,
							// Augmented
						}

					} else {
						break;
					}

				}

				session.close();
				con.close();

			}
		} catch (Exception e) {
			messageExists = false;
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getMessage());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getMessage());
			throw new ServiceBusinessException(gesFaultObject);
		} finally {
			try {

				if (null != session && null != con) {
					session.close();
					con.close();
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private String getType(DataObject aDataObject) {
		String type = "";

		DataObject request = getDataObject(aDataObject);

		if (null != request) {
			type = request.getType().getName();

			
		}

		return type;
	}

	private DataObject getDataObject(DataObject parentDO) {
		DataObject request = parentDO.getDataObject("sendErrorMessage");

		return request;
	}

	private String getMessageFilter(DataObject arequestDO) {
		String filterType = "";
		if (null != arequestDO) {

			if (arequestDO.isSet("updateRequiredFor")) {
				filterType = arequestDO.getString("updateRequiredFor");
			
			} else {
			
			}
		}

		return filterType;
	}

	private void invokeService(String OperationName, DataObject aDataObject)
			throws Exception {
		Service DBUpdateHandlerV2Service = (Service) ServiceManager.INSTANCE
				.locateService("DBUpdateHandlerV2Partner");

		JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "invokeService",
				JMSUtils.class.getName(),
				"DataObject for DBUpdateHandlerService -----------> : ",
				aDataObject);

		DataObject response = (DataObject) DBUpdateHandlerV2Service.invoke(
				OperationName, aDataObject);
		GESLoggerFactory
				.getLogger()
				.logInfo(
						JMSUtils.class.getName(),
						"invokeService",
						JMSUtils.class.getName(),
						"RESPONSE DataObject for DBUpdateHandlerService -----------> : ",
						response);

		if (null != response) {

		
			String type = response.getType().getName();

			if (type.indexOf(AUGMENTEDOPERATIONAME) != -1) {
				if (!response.isSet(AUGMENTEDOPERATIONAME + "Response")) {

					throw new Exception(
							"Unable to update GES DB with the recovered message : "
									+ "Stop Processing : ");
				}
			}
			if (type.indexOf(PBBIOPERATIONAME) != -1) {
				if (!response.isSet(PBBIOPERATIONAME + "Response")) {

					
					throw new Exception(
							"Unable to update GES DB with the recovered message : "
									+ "Stop Processing : ");
				}
			}
			if (type.indexOf(MDMOPERATIONAME) != -1) {
				if (!response.isSet(MDMOPERATIONAME + "Response")) {

					
					throw new Exception(
							"Unable to update GES DB with the recovered message : "
									+ "Stop Processing : ");
				}
			}

		}
		// DBUpdateHandlerV2Service.invoke(arg0, arg1)
	}

	private DataObject constructDataObject(DataObject aDataObject) {
		BOFactory bof = (BOFactory) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject updateLocationsInGESrequestType = bof.create(
				"http://aig.us.com/ges/services/DBUpdateHandlerV2",
				"updateAugmentedLocation");

		updateLocationsInGESrequestType = aDataObject;

		return updateLocationsInGESrequestType;
	}

	private DataObject getBOFromXMlString(String aXMLString) {
		DataObject responseBO = null;

		byte[] xmlByte = aXMLString.getBytes();
		try {
			BOXMLDocument xmlDoc = BOXML
					.readXMLDocument(new ByteArrayInputStream(xmlByte));
			responseBO = xmlDoc.getDataObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "getBOFromXMlString",
				JMSUtils.class.getName(), "DataObject from XMLString : ",
				responseBO);
		return responseBO;
	}

	public String putMessage(DataObject aPutMessageRequest)
			throws ServiceBusinessException {

		String response = "Message Posted to Queue : ";

		JMSUtilsLogger.logSevere(JMSUtils.class.getName(), "putMessage",
				JMSUtils.class.getName(), " About to Put Message to MQ");

		String qcfJndi = "";
		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue queue = null;

		Context ctxt = getInitialContext();

		try {
			if (null != aPutMessageRequest) {

				if (aPutMessageRequest.isSet("qcfJndi")
						&& (aPutMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = aPutMessageRequest.getString("qcfJndi");

				if (aPutMessageRequest.isSet("queueJndi")
						&& (aPutMessageRequest.getString("queueJndi").length() != 0))
					queueJndi = aPutMessageRequest.getString("queueJndi");

				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(), " QCF : " + qcfJndi
								+ " Queue : " + queueJndi);
				String message = getStringFromBO(aPutMessageRequest
						.getDataObject("message"));

				qcf = (ConnectionFactory) ctxt.lookup(qcfJndi);
				queue = (Queue) ctxt.lookup(queueJndi);
				Connection con = qcf.createConnection();

				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(),
						" MQ JMS Object QCF , Queue & Connection Obtained");
				Session session = con.createSession(false,
						Session.AUTO_ACKNOWLEDGE);
				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(),
						" MQ JMS Object Session Obtained");
				MessageProducer producer = session.createProducer(queue);
				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(),
						" MQ JMS Object MessageProducer Created  ");
				TextMessage producerMessage = session
						.createTextMessage(message);
				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(),
						" MQ JMS Text Message About to be Sent : {" + message
								+ "}");
				producer.send(producerMessage);
				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(), " MQ JMS Text Message Sent ");
				producer.close();
				session.close();
				con.close();
				JMSUtilsLogger.exiting(JMSUtils.class.getName(), "putMessage",
						JMSUtils.class.getName(),
						" Message Sent and All handles Closed");
				response = response + queueJndi;
			}
		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);
		}

		return response;
	}

	private String getStringFromBO(DataObject aObject) {

		String xmlStringBO = "";
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try {
			BOXML.writeDataObject(aObject, aObject.getType().getURI(), aObject
					.getType().getName(), outputStream);
			xmlStringBO = outputStream.toString("UTF-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return xmlStringBO;

	}

	private Context getInitialContext() {

		Context initCtxt = null;
		try {
			initCtxt = new InitialContext();

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return initCtxt;

	}

	public static DataObject readMessage(DataObject browseMessageRequest)
			throws ServiceBusinessException {
		boolean messageExists = true;
		JMSUtilsLogger.entering(JMSUtils.class.getName(), "readMessage",
				JMSUtils.class.getName(),
				"About to Read Message  -----------> : ", browseMessageRequest);
		String qcfJndi = "";

		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue sourceQueue = null;
		DataObject response = null;

		List<DataObject> responseBOList = new ArrayList();
		Connection con = null;
		Session session = null;
		MessageConsumer queueConsumer = null;

		try {

			if (null != browseMessageRequest) {

				if (browseMessageRequest.isSet("qcfJndi")
						&& (browseMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = browseMessageRequest.getString("qcfJndi");

				if (browseMessageRequest.isSet("queueJndi")
						&& (browseMessageRequest.getString("queueJndi")
								.length() != 0))
					queueJndi = browseMessageRequest.getString("queueJndi");

				JMSUtilsLogger.logInfo(JMSUtils.class.getName(), "readMessage",
						JMSUtils.class.getName(), " QCF : " + qcfJndi
								+ "  Queue : " + queueJndi);

				Context initCtxt = null;

				initCtxt = new InitialContext();

				qcf = (ConnectionFactory) initCtxt.lookup(qcfJndi);
				con = qcf.createConnection();
				sourceQueue = (Queue) initCtxt.lookup(queueJndi);
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				queueConsumer = session.createConsumer(sourceQueue);

				JMSUtilsLogger
						.logInfo(
								JMSUtils.class.getName(),
								"readMessage",
								JMSUtils.class.getName(),
								" MQ JMS Objects Created are : Conn Factory , Connection , Queue , Session & Queue Consumer");
				int numMsgs = 0;

				while (messageExists) {
					con.start();
					Message m = queueConsumer.receive(10L);
					if (m != null) {
						JMSUtilsLogger.logInfo(JMSUtils.class.getName(),
								"readMessage", JMSUtils.class.getName(),
								" Message Exists ");
						if (m instanceof TextMessage) {

							try {
								TextMessage jmsTextMsg = (TextMessage) m;

								String jmsMsg = jmsTextMsg.getText();

								DataObject boFromQueue = InspectMessageType
										.getBOFromXML(jmsMsg);// getBO
								JMSUtilsLogger.logInfo(
										JMSUtils.class.getName(),
										"readMessage",
										JMSUtils.class.getName(),
										" Message No : {" + numMsgs + 1 + "}"
												+ "  \n ", boFromQueue);

								numMsgs++;
								responseBOList.add(boFromQueue);
							} catch (Exception e) {
								// e.printStackTrace(); just break the loop,
								// once array index out of bounds
								break;
							}
						} else {
							break;
						}
					} else {
						break;
					}
				}// while end
			}
		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);
		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		}

		response = bof.create("http://aig.us.com/jms/common/bo",
				"BrowseMessageResponse");
		response.setList(0, responseBOList);
		JMSUtilsLogger.exiting(JMSUtils.class.getName(), "browseMessage",
				JMSUtils.class.getName(), " All Messages read from Queue : ",
				response);

		return response;
	}

}
