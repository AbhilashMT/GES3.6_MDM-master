package BPCUtils.utility.utility;
public class GESMonitorBPC {
	public static void gESMonitorBPC(com.ibm.bpe.api.ActivityInstanceData ActivityInstanceData, com.ibm.bpe.api.ProcessInstanceData ProcessInstanceData, java.lang.String Message, commonj.sdo.DataObject aDataObject) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		com.us.chartisinsurance.ges.logger.GESLoggerV4 GESLoggerV4 = __result__1;
		java.lang.String __result__5 = ActivityInstanceData.getApplicationName();
		java.lang.String AppName = __result__5;
		java.lang.String __result__8 = ProcessInstanceData.getProcessTemplateName();
		java.lang.String ProcessTemplateName = __result__8;
		java.lang.String __result__10 = ProcessInstanceData.getParentProcessInstanceName();
		java.lang.String ProcessInstanceName = __result__10;
		boolean __result__3 = null == aDataObject;
		if (__result__3){
			GESLoggerV4.logGESMonitorNoBO(AppName, ProcessTemplateName, ProcessInstanceName, Message);
		}
		else{
			GESLoggerV4.logGESMonitor(AppName, ProcessTemplateName, ProcessInstanceName, Message, aDataObject);
		}
	}
}