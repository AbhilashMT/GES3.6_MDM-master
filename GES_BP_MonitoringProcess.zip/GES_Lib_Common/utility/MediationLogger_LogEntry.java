package utility;
public class MediationLogger_LogEntry {
	public static void mediationLogger_LogEntry(com.ibm.wsspi.sibx.mediation.esb.SCAServices SCAServices, com.ibm.wsspi.sibx.mediation.MediationServices MediationServices, java.lang.String inputMessage, commonj.sdo.DataObject dataObject)throws com.ibm.websphere.sca.ServiceRuntimeException  {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = SCAServices.getModuleName();
		com.ibm.websphere.sca.scdl.Component __result__5 = SCAServices.getParentComponent();
		java.lang.String __result__6 = __result__5.getName();
		java.lang.String __result__8 = SCAServices.getComponentName();
		__result__1.entering(__result__3, __result__6, __result__8, inputMessage, dataObject);
	}
}