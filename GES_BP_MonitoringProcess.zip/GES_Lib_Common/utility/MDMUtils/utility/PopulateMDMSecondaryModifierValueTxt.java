package utility.MDMUtils.utility;
public class PopulateMDMSecondaryModifierValueTxt {
	public static commonj.sdo.DataObject populateMDMSecondaryModifierValueTxt(java.lang.String secModifierName, java.lang.String secModifierValueTxt) {
		commonj.sdo.DataObject __result__1;
		{// create SecondaryModifier
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__1 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","SecondaryModifier");
		}
		commonj.sdo.DataObject SecondaryModif_1 = __result__1;
		commonj.sdo.DataObject __result__3;
		{// create XCdSecondaryModifierNameTP
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__3 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","XCdSecondaryModifierNameTP");
		}
		commonj.sdo.DataObject NameBO1 = __result__3;
		NameBO1.setString("value", secModifierName);
		SecondaryModif_1.setString("SecondaryModifierValueTxt", secModifierValueTxt);
		SecondaryModif_1.set("SecondaryModifierName", NameBO1);
		return SecondaryModif_1;
	}
}