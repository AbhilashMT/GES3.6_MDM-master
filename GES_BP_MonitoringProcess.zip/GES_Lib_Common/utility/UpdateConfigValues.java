package utility;
public class UpdateConfigValues {
	public static commonj.sdo.DataObject updateConfigValues(java.lang.String TypeName, java.lang.String QueueName, commonj.sdo.DataObject updateConfigRequestParameter) {
		java.lang.String __result__2 = TypeName + "_";
		java.lang.String __result__3 = __result__2.concat(QueueName);
		java.lang.String ObjectKey = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create UpdateConfigResponse
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://GES_Lib_Common/bo","UpdateConfigResponse");
		}
		commonj.sdo.DataObject UpdateConfigResponseParamaeter = __result__5;
		commonj.sdo.DataObject __result__7;
		{// create UpdateConfigRequest
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__7 = factory.create("http://GES_Lib_Common/bo","UpdateConfigRequest");
		}
		commonj.sdo.DataObject CurrentValues = __result__7;
		commonj.sdo.DataObject __result__10;
		{// create UpdateConfigRequest
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__10 = factory.create("http://GES_Lib_Common/bo","UpdateConfigRequest");
		}
		commonj.sdo.DataObject UpdatedValues = __result__10;
		java.lang.String __result__9 = com.us.aig.ges.constants.GESConstantBundle.GES_GATEWAY_CONFIG;
		java.lang.Object __result__12 = com.aig.us.ges.cache.utils.GESCacheLoader.getValueFromCache(__result__9);
		java.util.HashMap ResultProperties = (java.util.HashMap)__result__12;
		boolean __result__15 = ResultProperties.isEmpty();
		if (__result__15){
		}
		else{
			boolean __result__19 = null != ResultProperties.get(ObjectKey);
			if (__result__19){
				java.lang.Object __result__22 = ResultProperties.get(ObjectKey);
				commonj.sdo.DataObject RouterConfig = (commonj.sdo.DataObject)__result__22;
				java.lang.String __result__24 = RouterConfig.getString("PartnerName");
				CurrentValues.setString("PartnerName", __result__24);
				java.lang.String __result__26 = RouterConfig.getString("MethodName");
				CurrentValues.setString("MethodName", __result__26);
				java.lang.String __result__28 = RouterConfig.getString("MessageName");
				CurrentValues.setString("MessageName", __result__28);
				java.lang.String __result__30 = RouterConfig.getString("WSDLUri");
				CurrentValues.setString("WSDLURI", __result__30);
				byte __result__33 = 0;
				UpdateConfigResponseParamaeter.setDataObject(__result__33, CurrentValues);
				boolean __result__36 = updateConfigRequestParameter.getString("PartnerName") != null;
				if (__result__36){
					java.lang.String __result__39 = updateConfigRequestParameter.getString("PartnerName");
					RouterConfig.setString("PartnerName", __result__39);
					java.lang.String __result__40 = RouterConfig.getString("PartnerName");
					UpdatedValues.setString("PartnerName", __result__40);
				}
				else{
				}
				boolean __result__43 = updateConfigRequestParameter.getString("MessageName") != null;
				if (__result__43){
					java.lang.String __result__46 = updateConfigRequestParameter.getString("MessageName");
					RouterConfig.setString("MessageName", __result__46);
					java.lang.String __result__47 = RouterConfig.getString("MessageName");
					UpdatedValues.setString("MessageName", __result__47);
				}
				else{
				}
				boolean __result__50 = updateConfigRequestParameter.getString("MethodName") != null;
				if (__result__50){
					java.lang.String __result__53 = updateConfigRequestParameter.getString("MethodName");
					RouterConfig.setString("MethodName", __result__53);
					java.lang.String __result__54 = RouterConfig.getString("MethodName");
					UpdatedValues.setString("MethodName", __result__54);
				}
				else{
				}
				boolean __result__57 = updateConfigRequestParameter.getString("WSDLURI") != null;
				if (__result__57){
					java.lang.String __result__60 = updateConfigRequestParameter.getString("WSDLURI");
					RouterConfig.setString("WSDLUri", __result__60);
					java.lang.String __result__61 = RouterConfig.getString("WSDLUri");
					UpdatedValues.setString("WSDLURI", __result__61);
				}
				else{
				}
				byte __result__65 = 1;
				UpdateConfigResponseParamaeter.setDataObject(__result__65, UpdatedValues);
			}
			else{
				commonj.sdo.DataObject __result__70;
				{// create RoutingConfig
					com.ibm.websphere.bo.BOFactory factory = 
					   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
					 __result__70 = factory.create("http://GES_Lib_Common/bo","RoutingConfig");
				}
				commonj.sdo.DataObject RouterConfig = __result__70;
				java.lang.String __result__69 = updateConfigRequestParameter.getString("PartnerName");
				RouterConfig.setString("PartnerName", __result__69);
				java.lang.String __result__72 = RouterConfig.getString("PartnerName");
				CurrentValues.setString("PartnerName", __result__72);
				java.lang.String __result__74 = updateConfigRequestParameter.getString("MessageName");
				RouterConfig.setString("MessageName", __result__74);
				java.lang.String __result__75 = RouterConfig.getString("MessageName");
				CurrentValues.setString("MessageName", __result__75);
				java.lang.String __result__77 = updateConfigRequestParameter.getString("MethodName");
				RouterConfig.setString("MethodName", __result__77);
				java.lang.String __result__78 = RouterConfig.getString("MethodName");
				CurrentValues.setString("MethodName", __result__78);
				java.lang.String __result__80 = updateConfigRequestParameter.getString("WSDLURI");
				RouterConfig.setString("WSDLUri", __result__80);
				java.lang.String __result__81 = RouterConfig.getString("WSDLUri");
				CurrentValues.setString("WSDLURI", __result__81);
				java.lang.Object __result__89 = ResultProperties.put(ObjectKey, RouterConfig);
				byte __result__84 = 1;
				UpdateConfigResponseParamaeter.setDataObject(__result__84, CurrentValues);
			}
		}
		return UpdateConfigResponseParamaeter;
	}
}