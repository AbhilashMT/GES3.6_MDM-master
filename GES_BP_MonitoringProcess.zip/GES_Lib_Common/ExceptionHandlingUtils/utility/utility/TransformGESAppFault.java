package ExceptionHandlingUtils.utility.utility;
public class TransformGESAppFault {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject transformGESAppFault(commonj.sdo.DataObject inputSMOBody, java.lang.String customMessage, java.lang.String outputSMOBodyMessageName, java.lang.String outputSMOBodyMessageNameSpace, java.lang.String moduleName, java.lang.String operationName) {
		byte __result__2 = 0;
		commonj.sdo.DataObject __result__3 = inputSMOBody.getDataObject(__result__2);
		commonj.sdo.DataObject GESAppException = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://aig.us.com/ges/common/v3","GesFaultObjectType");
		}
		commonj.sdo.DataObject GESFaultObjectType = __result__5;
		GESFaultObjectType.setString("faultCode", customMessage);
		java.lang.String __result__8 = GESFaultObjectType.getString("faultCode");
		java.lang.String __result__9 = GESAppException.getString("errDesc");
		java.lang.String __result__12 = com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler.formatException(__result__8, __result__9, moduleName, operationName);
		GESFaultObjectType.setString("faultString", __result__12);
		GESFaultObjectType.setString("faultDetail", __result__9);
		java.util.ArrayList __result__14 = new java.util.ArrayList();
		java.util.ArrayList faultList = __result__14;
		boolean __result__19;
		{// add item to list
			__result__19 = faultList.add(GESFaultObjectType);
		}
		commonj.sdo.DataObject __result__22;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__22 = factory.create("http://aig.us.com/ges/common/v3","ArrayOfGESFault");
		}
		commonj.sdo.DataObject arrayOfGESFault = __result__22;
		arrayOfGESFault.set("gesFaults", faultList);
		commonj.sdo.DataObject __result__26;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(outputSMOBodyMessageNameSpace, outputSMOBodyMessageName));
			__result__26 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject outputSMOBody = __result__26;
		byte __result__28 = 0;
		commonj.sdo.DataObject __result__29 = outputSMOBody.createDataObject(__result__28);
		commonj.sdo.DataObject outputSMOBody_firstChild = __result__29;
		outputSMOBody_firstChild = arrayOfGESFault;
		byte __result__34 = 0;
		outputSMOBody.setDataObject(__result__34, outputSMOBody_firstChild);
		java.lang.String __result__38 = "..";
		commonj.sdo.DataObject __result__39 = outputSMOBody.getDataObject(__result__38);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)__result__39;
	}
}