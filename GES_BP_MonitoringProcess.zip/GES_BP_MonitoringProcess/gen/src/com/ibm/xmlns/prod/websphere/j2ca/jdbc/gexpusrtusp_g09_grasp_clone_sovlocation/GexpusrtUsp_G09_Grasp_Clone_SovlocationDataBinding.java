package com.ibm.xmlns.prod.websphere.j2ca.jdbc.gexpusrtusp_g09_grasp_clone_sovlocation;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class GexpusrtUsp_G09_Grasp_Clone_SovlocationDataBinding extends com.ibm.j2ca.jdbc.emd.databinding.JDBCDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation";
	private String businessObjectName = "GexpusrtUsp_G09_Grasp_Clone_Sovlocation";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}