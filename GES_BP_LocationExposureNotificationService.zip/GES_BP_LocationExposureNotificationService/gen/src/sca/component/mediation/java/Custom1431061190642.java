package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: BatchProcessing Interface: LocationExposureNotificationService Operation: receiveLocationUpdates Type: request Custom Mediation: CreateWIP
 */
public class Custom1431061190642 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String gRASP_CreateWIPPartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (gRASP_CreateWIPPartner == null
				|| "".equals(gRASP_CreateWIPPartner.trim())) {
			throw new MediationConfigurationException(
					"Property 'gRASP_CreateWIPPartner' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the gRASP_CreateWIPPartner
	 */
	public String getGRASP_CreateWIPPartner() {
		return gRASP_CreateWIPPartner;
	}

	/**
	 * @generated
	 * @param gRASP_CreateWIPPartner The gRASP_CreateWIPPartner to set.
	 */
	public void setGRASP_CreateWIPPartner(String gRASP_CreateWIPPartner)
			throws IllegalArgumentException {
		if (gRASP_CreateWIPPartner == null
				|| "".equals(gRASP_CreateWIPPartner.trim())) {
			throw new IllegalArgumentException(
					gRASP_CreateWIPPartner
							+ " is not a valid value for property 'gRASP_CreateWIPPartner'");
		}

		this.gRASP_CreateWIPPartner = gRASP_CreateWIPPartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__1;
		{// create GexpusrtUsp_G09_Grasp_Clone_Sovlocation
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__1 = factory
					.create(
							"http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation",
							"GexpusrtUsp_G09_Grasp_Clone_Sovlocation");
		}
		commonj.sdo.DataObject WIPBO = __result__1;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__5 = getSCAServices();
		java.lang.String __result__6 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(gRASP_CreateWIPPartner, __result__5);
		java.lang.String TargetAddress = __result__6;
		java.util.ArrayList __result__3 = new java.util.ArrayList();
		java.util.ArrayList PhysicalObjectIdList = __result__3;
		commonj.sdo.DataObject __result__10;
		{// create ArrayOfPhysicalObjectId
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__10 = factory.create("http://GES_Lib_Common/bo",
					"ArrayOfPhysicalObjectId");
		}
		commonj.sdo.DataObject PhysicalObjectID = __result__10;
		java.util.List __result__9 = __smo.getDataObject("body").getDataObject(
				"ReceiveLocationUpdatesRequest").getDataObject(
				"receiveLocationUpdatesRequest").getList("LocationDetails");
		java.util.Iterator iter9 = __result__9.iterator();
		while (iter9.hasNext()) {
			commonj.sdo.DataObject Location = (commonj.sdo.DataObject) iter9
					.next();
			java.lang.String __result__14 = Location.getDataObject(
					"LocationEnterpriseKeys").getString(
					"GESLocationPhysicalObjectID");
			boolean __result__15 = PhysicalObjectIdList.add(__result__14);
		}
		byte __result__16 = 0;
		PhysicalObjectID.setList(__result__16, PhysicalObjectIdList);
		commonj.sdo.DataObject __result__19 = __smo.getDataObject("context")
				.getDataObject("correlation");
		java.lang.String __result__20 = "PhysicalObjectIds";
		__result__19.setDataObject(__result__20, PhysicalObjectID);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__23 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__24 = getMediationServices();
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__25 = com.us.chartisinsurance.ges.logger.GESLoggerV4.geslogger;
		java.lang.String __result__27 = "PhysicalObjectIds";
		java.lang.String __result__29 = __result__25.dataObjectToString(
				PhysicalObjectID, __result__27);
		java.lang.String InXML = __result__29;
		WIPBO.setString("pobjid_xml", InXML);
		java.lang.String __result__31 = WIPBO.getString("pobjid_xml");
		utility.MediationLogger_LogInfoNoBO.mediationLogger_LogInfoNoBO(
				__result__23, __result__24, __result__31);
		boolean __result__33 = __smo.getDataObject("context").getDataObject(
				"correlation").getBoolean("CallSP") == true;
		if (__result__33) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__36 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__37 = getMediationServices();
			java.lang.String __result__38 = "Response BO from Create WIP";
			com.us.chartisinsurance.ges.service.invocation.GESSIFImpl __result__39 = new com.us.chartisinsurance.ges.service.invocation.GESSIFImpl();
			java.lang.String __result__40 = "createWIPVersion";
			java.lang.String __result__41 = "GRASP_CreateWIPPartner";
			commonj.sdo.DataObject __result__44 = null;
			try {
				__result__44 = __result__39.invokeService(__result__40,
						__result__41, TargetAddress, WIPBO);
			} catch (java.lang.Exception ex) {
			}
			java.lang.Object OutBO = __result__44;
			utility.MediationLogger_LogInfo.mediationLogger_LogInfo(
					__result__36, __result__37, __result__38,
					(commonj.sdo.DataObject) OutBO);
		} else {
		}
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create GexpusrtUsp_G09_Grasp_Clone_Sovlocation" description="create a new GexpusrtUsp_G09_Grasp_Clone_Sovlocation {http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation&quot;,&quot;GexpusrtUsp_G09_Grasp_Clone_Sovlocation&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_G09_Grasp_Clone_Sovlocation" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@result/@dataOutputs.0" value="WIPBO" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_G09_Grasp_Clone_Sovlocation" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ArrayList" category="java.util.ArrayList" className="java.util.ArrayList" constructor="true" memberName="ArrayList">
		//    <result>
		//      <dataOutputs target="//@executableElements.7"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="gRASP_CreateWIPPartner" variable="true">
		//    <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.5/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.3/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.5/@result/@dataOutputs.0" value="TargetAddress" localVariable="//@localVariables.4" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.2/@result/@dataOutputs.0" value="PhysicalObjectIdList" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.ReceiveLocationUpdatesRequest.receiveLocationUpdatesRequest.LocationDetails" field="true">
		//    <dataOutputs target="//@executableElements.11"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create ArrayOfPhysicalObjectId" description="create a new ArrayOfPhysicalObjectId {http://GES_Lib_Common/bo}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://GES_Lib_Common/bo&quot;,&quot;ArrayOfPhysicalObjectId&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.10"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@result/@dataOutputs.0" value="PhysicalObjectID" localVariable="//@localVariables.3" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:IterationActivity" dataInputs="//@executableElements.8/@dataOutputs.0" iterationVariable="Location" iterationType="java.util.Collection">
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="PhysicalObjectIdList" localVariable="//@localVariables.0" variable="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.2/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="Location.LocationEnterpriseKeys.GESLocationPhysicalObjectID" field="true">
		//      <dataOutputs target="//@executableElements.11/@executableElements.2/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="add" category="java.util.List" className="java.util.List" memberName="add">
		//      <parameters name="List" dataInputs="//@executableElements.11/@executableElements.0/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </parameters>
		//      <parameters name="object" dataInputs="//@executableElements.11/@executableElements.1/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="E"/>
		//      </parameters>
		//      <result>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </result>
		//    </executableElements>
		//    <localVariables name="Location">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="LocationDetails"/>
		//    </localVariables>
		//    <executableGroups executableElements="//@executableElements.11/@executableElements.0 //@executableElements.11/@executableElements.1 //@executableElements.11/@executableElements.2"/>
		//    <iterationVariableType xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationDetails" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.14/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="PhysicalObjectIdList" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.14/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setList" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setList">
		//    <parameters name="DataObject" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.12/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.13/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation" field="true">
		//    <dataOutputs target="//@executableElements.18/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="BatchMode" namespace="http://COM_GES_MF_LocationExposureNotificationService/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PhysicalObjectIds&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.18/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="PhysicalObjectID" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.18/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.15/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.28/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.28/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESLoggerV4.geslogger" category="com.us.chartisinsurance.ges.logger.GESLoggerV4" className="com.us.chartisinsurance.ges.logger.GESLoggerV4" static="true" memberName="geslogger" field="true">
		//    <parameters name="geslogger">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.logger.GESLoggerV4"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.25/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.logger.GESLoggerV4"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="PhysicalObjectID" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.25/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PhysicalObjectIds&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.25/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="PhysicalObjectID" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.14/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="dataObjectToString" category="com.us.chartisinsurance.ges.logger.GESLoggerV4" className="com.us.chartisinsurance.ges.logger.GESLoggerV4" memberName="dataObjectToString">
		//    <parameters name="GESLoggerV4" dataInputs="//@executableElements.21/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.logger.GESLoggerV4"/>
		//    </parameters>
		//    <parameters name="aDataObject" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="aElementName" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.26"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.25/@result/@dataOutputs.0" value="InXML" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.27"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.26/@dataOutputs.0" value="WIPBO.pobjid_xml" field="true">
		//    <dataOutputs target="//@executableElements.28/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfoNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.19/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.20/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="LogMsg" dataInputs="//@executableElements.27/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.CallSP ==true" assignable="false">
		//    <dataOutputs target="//@executableElements.30"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.29/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.11/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//        <result>
		//          <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.11/@parameters.1"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Response BO from Create WIP&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.11/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new GESSIFImpl" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" constructor="true" memberName="GESSIFImpl">
		//        <result>
		//          <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;createWIPVersion&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GRASP_CreateWIPPartner&quot;" assignable="false">
		//        <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TargetAddress" localVariable="//@localVariables.4" variable="true">
		//        <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="WIPBO" localVariable="//@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@parameters.4"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_G09_Grasp_Clone_Sovlocation" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeService" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeService">
		//        <parameters name="GESSIFImpl" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.3/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//        </parameters>
		//        <parameters name="methodName" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.4/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="aPartnerName" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.5/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="targetAddress" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="aDataObject" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.7/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.10"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//        <exceptions>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//        </exceptions>
		//        <exceptions>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//        <exceptions>
		//          <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.9/@parameters.0"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </exceptions>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//        <parameters name="ex" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@exceptions.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </parameters>
		//        <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//        </executableElements>
		//        <executableGroups executableElements="//@executableElements.30/@conditionalActivities.0/@executableElements.9/@executableElements.0"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.8/@result/@dataOutputs.0" value="OutBO" localVariable="//@executableElements.30/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.30/@conditionalActivities.0/@executableElements.11/@parameters.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//        <parameters name="SCAServices" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.0/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//        </parameters>
		//        <parameters name="MediationServices" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.1/@result/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//        </parameters>
		//        <parameters name="inputMessage" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.2/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//        </parameters>
		//        <parameters name="dataObject" dataInputs="//@executableElements.30/@conditionalActivities.0/@executableElements.10/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <exceptions name="Exception1">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//        </exceptions>
		//      </executableElements>
		//      <localVariables name="OutBO">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.30/@conditionalActivities.0/@executableElements.0 //@executableElements.30/@conditionalActivities.0/@executableElements.1 //@executableElements.30/@conditionalActivities.0/@executableElements.2 //@executableElements.30/@conditionalActivities.0/@executableElements.3 //@executableElements.30/@conditionalActivities.0/@executableElements.4 //@executableElements.30/@conditionalActivities.0/@executableElements.5 //@executableElements.30/@conditionalActivities.0/@executableElements.6 //@executableElements.30/@conditionalActivities.0/@executableElements.7 //@executableElements.30/@conditionalActivities.0/@executableElements.8 //@executableElements.30/@conditionalActivities.0/@executableElements.9 //@executableElements.30/@conditionalActivities.0/@executableElements.10 //@executableElements.30/@conditionalActivities.0/@executableElements.11"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.33/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.33/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.31/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.32/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="PhysicalObjectIdList">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//  </localVariables>
		//  <localVariables name="WIPBO">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GexpusrtUsp_G09_Grasp_Clone_Sovlocation" namespace="http://www.ibm.com/xmlns/prod/websphere/j2ca/jdbc/gexpusrtusp_g09_grasp_clone_sovlocation"/>
		//  </localVariables>
		//  <localVariables name="InXML">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <localVariables name="PhysicalObjectID">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo"/>
		//  </localVariables>
		//  <localVariables name="TargetAddress">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.11"/>
		//  <executableGroups executableElements="//@executableElements.12 //@executableElements.13 //@executableElements.14 //@executableElements.24"/>
		//  <executableGroups executableElements="//@executableElements.15 //@executableElements.16 //@executableElements.17 //@executableElements.18"/>
		//  <executableGroups executableElements="//@executableElements.19 //@executableElements.20 //@executableElements.21 //@executableElements.22 //@executableElements.23 //@executableElements.25 //@executableElements.26 //@executableElements.27 //@executableElements.28"/>
		//  <executableGroups executableElements="//@executableElements.29 //@executableElements.30"/>
		//  <executableGroups executableElements="//@executableElements.31 //@executableElements.32 //@executableElements.33"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,6
		//!SMAP!2:8,1
		//!SMAP!3:12,1
		//!SMAP!5:9,1
		//!SMAP!6:10,1
		//!SMAP!7:11,1
		//!SMAP!8:13,1
		//!SMAP!9:21,4
		//!SMAP!10:14,6
		//!SMAP!11:20,1
		//!SMAP!14:25,1
		//!SMAP!15:26,1
		//!SMAP!16:28,1
		//!SMAP!18:29,1
		//!SMAP!19:30,1
		//!SMAP!20:31,1
		//!SMAP!22:32,1
		//!SMAP!23:33,1
		//!SMAP!24:34,1
		//!SMAP!25:35,1
		//!SMAP!27:36,1
		//!SMAP!29:37,1
		//!SMAP!30:38,1
		//!SMAP!31:39,2
		//!SMAP!32:41,1
		//!SMAP!33:42,1
		//!SMAP!34:43,1
		//!SMAP!36:44,1
		//!SMAP!37:45,1
		//!SMAP!38:46,1
		//!SMAP!39:47,1
		//!SMAP!40:48,1
		//!SMAP!41:49,1
		//!SMAP!44:52,2
		//!SMAP!47:56,1
		//!SMAP!48:57,1
		//!SMAP!52:61,1
		//!SMAP!1000000:467,1
	}
}
