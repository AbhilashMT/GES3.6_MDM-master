package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: BatchProcessing Interface: LocationExposureNotificationService Operation: receiveLocationUpdates Type: request Custom Mediation: InvokeMonitoringProcess
 */
public class Custom1430981003904 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String aAggregatorServicePartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the aAggregatorServicePartner
	 */
	public String getAAggregatorServicePartner() {
		return aAggregatorServicePartner;
	}

	/**
	 * @generated
	 * @param aAggregatorServicePartner The aAggregatorServicePartner to set.
	 */
	public void setAAggregatorServicePartner(String aAggregatorServicePartner) {
		this.aAggregatorServicePartner = aAggregatorServicePartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		commonj.sdo.DataObject __result__3;
		{// create ActivateRFSMonitorRqType
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__3 = factory.create(
					"http://GES_Lib_Common/it/AggregatorService",
					"ActivateRFSMonitorRqType");
		}
		commonj.sdo.DataObject RFSMonitorType = __result__3;
		commonj.sdo.DataObject __result__5 = __smo.getDataObject("context")
				.getDataObject("correlation").getDataObject("RequestHeader");
		RFSMonitorType.set("RequestHeader", __result__5);
		int __result__7 = __smo.getDataObject("context").getDataObject(
				"correlation").getInt("TotalNoLocs");
		RFSMonitorType.setInt("RFSLocationCount", __result__7);
		boolean __result__11 = __smo.getDataObject("context").getDataObject(
				"correlation").getBoolean("CallSP");
		RFSMonitorType.setBoolean("CallSP", __result__11);
		commonj.sdo.DataObject __result__13 = __smo.getDataObject("body")
				.getDataObject("ReceiveLocationUpdatesRequest").getDataObject(
						"receiveLocationUpdatesRequest");
		commonj.sdo.DataObject __result__14;
		{// copy BO
			com.ibm.websphere.bo.BOCopy _copyService = (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOCopy");
			__result__14 = _copyService.copy(__result__13);
		}
		commonj.sdo.DataObject OriginalRequest = __result__14;
		RFSMonitorType.set("OriginalRequest", OriginalRequest);
		commonj.sdo.DataObject __result__9 = __smo.getDataObject("context")
				.getDataObject("correlation");
		java.lang.String __result__10 = "PhysicalObjectIds";
		commonj.sdo.DataObject __result__18 = __result__9
				.getDataObject(__result__10);
		RFSMonitorType.set("PhysicalObjectIds", __result__18);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__20 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__21 = getMediationServices();
		java.lang.String __result__22 = "Monitor /request";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__20,
				__result__21, __result__22, RFSMonitorType);
		com.us.chartisinsurance.ges.service.invocation.GESSIFImpl __result__25 = new com.us.chartisinsurance.ges.service.invocation.GESSIFImpl();
		java.lang.String __result__26 = "activateRFSMonitor";
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__29 = getSCAServices();
		java.lang.String __result__30 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(aAggregatorServicePartner, __result__29);
		java.lang.String TargetAddress = __result__30;
		commonj.sdo.DataObject __result__33 = null;
		try {
			__result__33 = __result__25.invokeService(__result__26,
					aAggregatorServicePartner, TargetAddress, RFSMonitorType);
		} catch (java.lang.Exception ex) {
			com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__35 = getSCAServices();
			com.ibm.wsspi.sibx.mediation.MediationServices __result__36 = getMediationServices();
			java.lang.String __result__37 = "Error Occurred Invoking Monitoring Process ";
			java.lang.String __result__38 = ex.getMessage();
			java.lang.String __result__39;
			{// append text
				__result__39 = __result__37.concat(__result__38);
			}
			utility.MediationLogger_LogSevereNoBO
					.mediationLogger_LogSevereNoBO(__result__35, __result__36,
							__result__39);
		}
		commonj.sdo.DataObject ActivateRFSMonitorRS = __result__33;
		java.lang.String __result__42 = ActivateRFSMonitorRS
				.getString("activateRFSMonitorRs");
		__smo.getDataObject("context").getDataObject("shared").getDataObject(
				"RequestHeader").getDataObject("ServiceRequestContext")
				.setString("RequestMessageId", __result__42);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__44 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__45 = getMediationServices();
		java.lang.String __result__46 = "Updated SMO";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__44,
				__result__45, __result__46, __smo);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.42/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.42/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create ActivateRFSMonitorRqType" description="create a new ActivateRFSMonitorRqType {http://GES_Lib_Common/it/AggregatorService}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://GES_Lib_Common/it/AggregatorService&quot;,&quot;ActivateRFSMonitorRqType&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ActivateRFSMonitorRqType" namespace="http://GES_Lib_Common/it/AggregatorService" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.2/@result/@dataOutputs.0" value="RFSMonitorType" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ActivateRFSMonitorRqType" namespace="http://GES_Lib_Common/it/AggregatorService"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.RequestHeader" field="true">
		//    <dataOutputs target="//@executableElements.5"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.4/@dataOutputs.0" value="RFSMonitorType.RequestHeader" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.TotalNoLocs" field="true">
		//    <dataOutputs target="//@executableElements.7"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.6/@dataOutputs.0" value="RFSMonitorType.RFSLocationCount" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation" field="true">
		//    <dataOutputs target="//@executableElements.17/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="BatchMode" namespace="http://COM_GES_MF_LocationExposureNotificationService/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;PhysicalObjectIds&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.17/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation.CallSP" field="true">
		//    <dataOutputs target="//@executableElements.11"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.10/@dataOutputs.0" value="RFSMonitorType.CallSP" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="boolean" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.ReceiveLocationUpdatesRequest.receiveLocationUpdatesRequest" field="true">
		//    <dataOutputs target="//@executableElements.13/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationEngineeringUpdatesRequest" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="copy BO" description="Copy a Business Object or Business Graph" category="SCA and BO services" template="com.ibm.websphere.bo.BOCopy _copyService = &#xA;   (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOCopy&quot;); &#xA;&lt;%return%> _copyService.copy(&lt;%bo%>);">
		//    <parameters name="bo" dataInputs="//@executableElements.12/@dataOutputs.0" displayName="BO">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result name="copy" displayName="copy">
		//      <dataOutputs target="//@executableElements.14"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.13/@result/@dataOutputs.0" value="OriginalRequest" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="OriginalRequest" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.16"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@dataOutputs.0" value="RFSMonitorType.OriginalRequest" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationEngineeringUpdatesRequest" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="getDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.8/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.9/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.18"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.17/@result/@dataOutputs.0" value="RFSMonitorType.PhysicalObjectIds" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ArrayOfPhysicalObjectId" namespace="http://GES_Lib_Common/bo"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.23/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.23/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Monitor /request&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.23/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RFSMonitorType" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.23/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ActivateRFSMonitorRqType" namespace="http://GES_Lib_Common/it/AggregatorService"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.19/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.20/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.21/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new GESSIFImpl" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" constructor="true" memberName="GESSIFImpl">
		//    <result>
		//      <dataOutputs target="//@executableElements.32/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;activateRFSMonitor&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.32/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aAggregatorServicePartner" variable="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="aAggregatorServicePartner" variable="true">
		//    <dataOutputs target="//@executableElements.29/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.29/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.27/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.28/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.30"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.29/@result/@dataOutputs.0" value="TargetAddress" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="RFSMonitorType" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.32/@parameters.4"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ActivateRFSMonitorRqType" namespace="http://GES_Lib_Common/it/AggregatorService"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="invokeService" category="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" className="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl" memberName="invokeService">
		//    <parameters name="GESSIFImpl" dataInputs="//@executableElements.24/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.us.chartisinsurance.ges.service.invocation.GESSIFImpl"/>
		//    </parameters>
		//    <parameters name="methodName" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aPartnerName" dataInputs="//@executableElements.26/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="targetAddress" dataInputs="//@executableElements.30/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aDataObject" dataInputs="//@executableElements.31/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.34"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceBusinessException"/>
		//    </exceptions>
		//    <exceptions>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.33/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex" dataInputs="//@executableElements.32/@exceptions.2/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Exception"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.33/@executableElements.5/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//      <result>
		//        <dataOutputs target="//@executableElements.33/@executableElements.5/@parameters.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Error Occurred Invoking Monitoring Process &quot;" assignable="false">
		//      <dataOutputs target="//@executableElements.33/@executableElements.4/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex.getMessage()" assignable="false">
		//      <dataOutputs target="//@executableElements.33/@executableElements.4/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//      <parameters name="input1" dataInputs="//@executableElements.33/@executableElements.2/@dataOutputs.0" displayName="input 1">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <parameters name="input2" dataInputs="//@executableElements.33/@executableElements.3/@dataOutputs.0" displayName="input 2">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//      <result name="combined text" displayName="combined text">
		//        <dataOutputs target="//@executableElements.33/@executableElements.5/@parameters.2"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </result>
		//    </executableElements>
		//    <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevereNoBO" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//      <parameters name="SCAServices" dataInputs="//@executableElements.33/@executableElements.0/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//      </parameters>
		//      <parameters name="MediationServices" dataInputs="//@executableElements.33/@executableElements.1/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//      </parameters>
		//      <parameters name="LogMsg" dataInputs="//@executableElements.33/@executableElements.4/@result/@dataOutputs.0">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//      </parameters>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.33/@executableElements.0 //@executableElements.33/@executableElements.1 //@executableElements.33/@executableElements.2 //@executableElements.33/@executableElements.3 //@executableElements.33/@executableElements.4 //@executableElements.33/@executableElements.5"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.32/@result/@dataOutputs.0" value="ActivateRFSMonitorRS" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="activateRFSMonitorResponse" namespace="http://GES_Lib_Common/it/AggregatorService"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ActivateRFSMonitorRS.activateRFSMonitorRs" field="true">
		//    <dataOutputs target="//@executableElements.36"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.35/@dataOutputs.0" value="smo.context.shared.RequestHeader.ServiceRequestContext.RequestMessageId" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.41/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.41/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Updated SMO&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.41/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.41/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.37/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.38/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.39/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.40/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="RFSMonitorType">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ActivateRFSMonitorRqType" namespace="http://GES_Lib_Common/it/AggregatorService"/>
		//  </localVariables>
		//  <localVariables name="ActivateRFSMonitorRS">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="activateRFSMonitorResponse" namespace="http://GES_Lib_Common/it/AggregatorService" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="OriginalRequest">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="TargetAddress">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.4 //@executableElements.5"/>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7"/>
		//  <executableGroups executableElements="//@executableElements.10 //@executableElements.11"/>
		//  <executableGroups executableElements="//@executableElements.12 //@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.15 //@executableElements.16"/>
		//  <executableGroups executableElements="//@executableElements.8 //@executableElements.9 //@executableElements.17 //@executableElements.18"/>
		//  <executableGroups executableElements="//@executableElements.19 //@executableElements.20 //@executableElements.21 //@executableElements.22 //@executableElements.23"/>
		//  <executableGroups executableElements="//@executableElements.24 //@executableElements.25 //@executableElements.26 //@executableElements.27 //@executableElements.28 //@executableElements.29 //@executableElements.30 //@executableElements.31 //@executableElements.32 //@executableElements.33 //@executableElements.34"/>
		//  <executableGroups executableElements="//@executableElements.35 //@executableElements.36"/>
		//  <executableGroups executableElements="//@executableElements.37 //@executableElements.38 //@executableElements.39 //@executableElements.40 //@executableElements.41"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.42"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:2,6
		//!SMAP!4:8,1
		//!SMAP!5:9,1
		//!SMAP!6:10,1
		//!SMAP!7:11,1
		//!SMAP!8:12,1
		//!SMAP!9:24,1
		//!SMAP!10:25,1
		//!SMAP!11:13,1
		//!SMAP!12:14,1
		//!SMAP!13:15,1
		//!SMAP!14:16,6
		//!SMAP!15:22,1
		//!SMAP!17:23,1
		//!SMAP!18:26,1
		//!SMAP!19:27,1
		//!SMAP!20:28,1
		//!SMAP!21:29,1
		//!SMAP!22:30,1
		//!SMAP!24:31,1
		//!SMAP!25:32,1
		//!SMAP!26:33,1
		//!SMAP!29:34,1
		//!SMAP!30:35,1
		//!SMAP!31:36,1
		//!SMAP!33:39,2
		//!SMAP!35:42,1
		//!SMAP!36:43,1
		//!SMAP!37:44,1
		//!SMAP!38:45,1
		//!SMAP!39:46,4
		//!SMAP!40:50,1
		//!SMAP!41:52,1
		//!SMAP!42:53,1
		//!SMAP!43:54,1
		//!SMAP!44:55,1
		//!SMAP!45:56,1
		//!SMAP!46:57,1
		//!SMAP!48:58,1
		//!SMAP!49:59,1
		//!SMAP!1000000:445,1
	}
}
