package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_LocationExposureNotificationService Interface: LocationExposureNotificationService Operation: receiveLocationUpdates Type: request Custom Mediation: HandleErrorsInAggregrationBlock
 */
public class Custom1418372321280 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		java.lang.String __result__1 = "GES-SYS-GNRCF3010";
		java.lang.String FaultCode = __result__1;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__3 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__4 = getMediationServices();
		java.lang.String __result__5 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE;
		java.lang.String __result__6 = "First Failure Information >>\n";
		java.lang.String __result__7;
		{// append text
			__result__7 = __result__5.concat(__result__6);
		}
		utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
				__result__3, __result__4, __result__7, __smo);
		commonj.sdo.DataObject __result__10;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__10 = factory.create("http://aig.us.com/ges/common/v3",
					"GesFaultObjectType");
		}
		commonj.sdo.DataObject GesFaultObjectType = __result__10;
		boolean __result__12 = null != __smo.getDataObject("context")
				.getDataObject("transient").getString("modErrorCode")
				&& __smo.getDataObject("context").getDataObject("transient")
						.getString("modErrorCode").length() > 0;
		if (__result__12) {
			java.lang.String __result__15 = __smo.getDataObject("context")
					.getDataObject("transient").getString("modErrorCode");
			FaultCode = __result__15;
		} else {
		}
		GesFaultObjectType.setString("faultCode", FaultCode);
		java.lang.String __result__21 = "";
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__22 = getSCAServices();
		java.lang.String __result__23 = __result__22.getModuleName();
		java.lang.String __result__24 = "receiveLocationUpdates";
		java.lang.String __result__25 = com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler
				.formatException(FaultCode, __result__21, __result__23,
						__result__24);
		GesFaultObjectType.setString("faultString", __result__25);
		commonj.sdo.DataObject __result__30;
		{// copy BO
			com.ibm.websphere.bo.BOCopy _copyService = (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOCopy");
			__result__30 = _copyService.copy(GesFaultObjectType);
		}
		commonj.sdo.DataObject FaultObject = __result__30;
		__smo.getDataObject("context").getDataObject("correlation").set(
				"gesFaultObject", GesFaultObjectType);
		commonj.sdo.DataObject __result__27 = __smo.getDataObject("context")
				.getDataObject("shared").getDataObject(
						"LocationUpdateStatusCurrent");
		commonj.sdo.DataObject LocationUpdateStatusCurrent = __result__27;
		commonj.sdo.DataObject __result__35;
		{// create ErrorType
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__35 = factory.create("http://aig.us.com/ges/common/v3",
					"ErrorType");
		}
		commonj.sdo.DataObject ErrorType = __result__35;
		java.lang.String __result__34 = FaultObject.getString("faultCode");
		ErrorType.setString("ErrorCd", __result__34);
		java.lang.String __result__38 = FaultObject.getString("faultString");
		ErrorType.setString("ErrorMsg", __result__38);
		LocationUpdateStatusCurrent.set("Error", ErrorType);
		// Removed Error From Location Current
		__smo.getDataObject("context").getDataObject("shared").set(
				"LocationUpdateStatusCurrent", LocationUpdateStatusCurrent);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__45 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__46 = getMediationServices();
		java.lang.String __result__47 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE;
		java.lang.String __result__48 = "Context set with Failure Information , Error handled , Continue with next iteration >>\n";
		java.lang.String __result__49;
		{// append text
			__result__49 = __result__47.concat(__result__48);
		}
		utility.MediationLogger_LogSevere.mediationLogger_LogSevere(
				__result__45, __result__46, __result__49, __smo);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;GES-SYS-GNRCF3010&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@dataOutputs.0" value="FaultCode" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.8/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.8/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE" field="true">
		//    <parameters name="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;First Failure Information >>\n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.4/@result/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.5/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.8/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.8/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create GesFaultObjectType" description="create a new GesFaultObjectType {http://aig.us.com/ges/common/v3}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/common/v3&quot;,&quot;GesFaultObjectType&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.10"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@result/@dataOutputs.0" value="GesFaultObjectType" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="null!=smo.context.transient.modErrorCode&amp;&amp;smo.context.transient.modErrorCode.length() >0" assignable="false">
		//    <dataOutputs target="//@executableElements.12"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.11/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.transient.modErrorCode" field="true">
		//        <dataOutputs target="//@executableElements.12/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.12/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="FaultCode" localVariable="//@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//      </executableElements>
		//      <executableGroups executableElements="//@executableElements.12/@conditionalActivities.0/@executableElements.0 //@executableElements.12/@conditionalActivities.0/@executableElements.1"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="FaultCode" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.14"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.13/@dataOutputs.0" value="GesFaultObjectType.faultCode" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="FaultCode" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.20/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.20/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.18/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getModuleName" category="com.ibm.wsspi.sibx.mediation.esb.SCAServices" className="com.ibm.wsspi.sibx.mediation.esb.SCAServices" memberName="getModuleName">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.17/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.20/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;receiveLocationUpdates&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.20/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="formatException" category="com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler" className="com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler" static="true" memberName="formatException">
		//    <parameters name="aExcepCode" dataInputs="//@executableElements.15/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aExcepMessage" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aModuleName" dataInputs="//@executableElements.18/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="aOperationName" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.21"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.20/@result/@dataOutputs.0" value="GesFaultObjectType.faultString" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.shared.LocationUpdateStatusCurrent" field="true">
		//    <dataOutputs target="//@executableElements.28"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationUpdateStatus_Type" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GesFaultObjectType" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.27"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GesFaultObjectType" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.25/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="copy BO" description="Copy a Business Object or Business Graph" category="SCA and BO services" template="com.ibm.websphere.bo.BOCopy _copyService = &#xA;   (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOCopy&quot;); &#xA;&lt;%return%> _copyService.copy(&lt;%bo%>);">
		//    <parameters name="bo" dataInputs="//@executableElements.24/@dataOutputs.0" displayName="BO">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <result name="copy" displayName="copy">
		//      <dataOutputs target="//@executableElements.26"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.25/@result/@dataOutputs.0" value="FaultObject" localVariable="//@localVariables.3" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.23/@dataOutputs.0" value="smo.context.correlation.gesFaultObject" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.22/@dataOutputs.0" value="LocationUpdateStatusCurrent" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Acknowledgment_Type" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="FaultObject.faultCode" field="true">
		//    <dataOutputs target="//@executableElements.32"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create ErrorType" description="create a new ErrorType {http://aig.us.com/ges/common/v3}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/common/v3&quot;,&quot;ErrorType&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.31"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ErrorType" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.30/@result/@dataOutputs.0" value="ErrorType" localVariable="//@localVariables.4" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ErrorType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.29/@dataOutputs.0" value="ErrorType.ErrorCd" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="FaultObject.faultString" field="true">
		//    <dataOutputs target="//@executableElements.34"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.33/@dataOutputs.0" value="ErrorType.ErrorMsg" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ErrorType" localVariable="//@localVariables.4" variable="true">
		//    <dataOutputs target="//@executableElements.36"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ErrorType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.35/@dataOutputs.0" value="LocationUpdateStatusCurrent.Error" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ErrorType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;/**/Removed Error From Location Current&quot;" assignable="false">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="LocationUpdateStatusCurrent" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.39"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Acknowledgment_Type" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.38/@dataOutputs.0" value="smo.context.shared.LocationUpdateStatusCurrent" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationUpdateStatus_Type" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.46/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.46/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE" field="true">
		//    <parameters name="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__SEVERE">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.44/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Context set with Failure Information , Error handled , Continue with next iteration >>\n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.44/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.42/@result/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.43/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.46/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.46/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogSevere" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.40/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.41/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.44/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.45/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.49/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.49/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.47/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.48/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="FaultCode">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </localVariables>
		//  <localVariables name="GesFaultObjectType">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </localVariables>
		//  <localVariables name="LocationUpdateStatusCurrent">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="Acknowledgment_Type" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="FaultObject">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GesFaultObjectType" namespace="http://aig.us.com/ges/common/v3" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="ErrorType">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ErrorType" namespace="http://aig.us.com/ges/common/v3"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12"/>
		//  <executableGroups executableElements="//@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.15 //@executableElements.16 //@executableElements.17 //@executableElements.18 //@executableElements.19 //@executableElements.20 //@executableElements.21"/>
		//  <executableGroups executableElements="//@executableElements.24 //@executableElements.25 //@executableElements.26"/>
		//  <executableGroups executableElements="//@executableElements.23 //@executableElements.27"/>
		//  <executableGroups executableElements="//@executableElements.22 //@executableElements.28"/>
		//  <executableGroups executableElements="//@executableElements.30 //@executableElements.31"/>
		//  <executableGroups executableElements="//@executableElements.29 //@executableElements.32"/>
		//  <executableGroups executableElements="//@executableElements.33 //@executableElements.34"/>
		//  <executableGroups executableElements="//@executableElements.35 //@executableElements.36"/>
		//  <executableGroups executableElements="//@executableElements.37"/>
		//  <executableGroups executableElements="//@executableElements.38 //@executableElements.39"/>
		//  <executableGroups executableElements="//@executableElements.40 //@executableElements.41 //@executableElements.42 //@executableElements.43 //@executableElements.44 //@executableElements.45 //@executableElements.46"/>
		//  <executableGroups executableElements="//@executableElements.47 //@executableElements.48 //@executableElements.49"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:2,1
		//!SMAP!2:3,1
		//!SMAP!3:4,1
		//!SMAP!4:5,1
		//!SMAP!5:6,1
		//!SMAP!6:7,1
		//!SMAP!7:8,4
		//!SMAP!9:12,1
		//!SMAP!10:13,6
		//!SMAP!11:19,1
		//!SMAP!12:20,1
		//!SMAP!13:21,1
		//!SMAP!15:22,1
		//!SMAP!16:23,1
		//!SMAP!19:27,1
		//!SMAP!21:28,1
		//!SMAP!22:29,1
		//!SMAP!23:30,1
		//!SMAP!24:31,1
		//!SMAP!25:32,1
		//!SMAP!26:33,1
		//!SMAP!27:42,1
		//!SMAP!30:34,6
		//!SMAP!31:40,1
		//!SMAP!32:41,1
		//!SMAP!33:43,1
		//!SMAP!34:51,1
		//!SMAP!35:44,6
		//!SMAP!36:50,1
		//!SMAP!37:52,1
		//!SMAP!38:53,1
		//!SMAP!39:54,1
		//!SMAP!41:55,2
		//!SMAP!44:57,1
		//!SMAP!45:58,1
		//!SMAP!46:59,1
		//!SMAP!47:60,1
		//!SMAP!48:61,1
		//!SMAP!49:62,4
		//!SMAP!51:66,1
		//!SMAP!54:67,1
		//!SMAP!1000000:455,1
	}
}
