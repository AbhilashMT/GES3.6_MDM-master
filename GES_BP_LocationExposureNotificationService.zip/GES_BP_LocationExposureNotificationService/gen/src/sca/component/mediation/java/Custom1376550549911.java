package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_LocationExposureNotificationService Interface: LocationExposureNotificationService Operation: receiveLocationUpdates Type: request Custom Mediation: LogWSRequest
 */
public class Custom1376550549911 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	private String aGESCommonServiceV2Partner;
	private String dataAccessPartner;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		if (dataAccessPartner == null || "".equals(dataAccessPartner.trim())) {
			throw new MediationConfigurationException(
					"Property 'dataAccessPartner' is not set.");
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/**
	 * @generated
	 * @return Returns the aGESCommonServiceV2Partner
	 */
	public String getAGESCommonServiceV2Partner() {
		return aGESCommonServiceV2Partner;
	}

	/**
	 * @generated
	 * @param aGESCommonServiceV2Partner The aGESCommonServiceV2Partner to set.
	 */
	public void setAGESCommonServiceV2Partner(String aGESCommonServiceV2Partner) {
		this.aGESCommonServiceV2Partner = aGESCommonServiceV2Partner;
	}

	/**
	 * @generated
	 * @return Returns the dataAccessPartner
	 */
	public String getDataAccessPartner() {
		return dataAccessPartner;
	}

	/**
	 * @generated
	 * @param dataAccessPartner The dataAccessPartner to set.
	 */
	public void setDataAccessPartner(String dataAccessPartner)
			throws IllegalArgumentException {
		if (dataAccessPartner == null || "".equals(dataAccessPartner.trim())) {
			throw new IllegalArgumentException(dataAccessPartner
					+ " is not a valid value for property 'dataAccessPartner'");
		}

		this.dataAccessPartner = dataAccessPartner;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__9 = getSCAServices();
		java.lang.String __result__10 = com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints
				.getEndPoint(dataAccessPartner, __result__9);
		utility.SCA_and_BO_services.SetTargetAddress.setTargetAddress(
				(com.ibm.websphere.sibx.smobo.ServiceMessageObject) __smo,
				__result__10);
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__3 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__4 = getMediationServices();
		java.lang.String __result__5 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSREQ;
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__3,
				__result__4, __result__5, __smo);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.12/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.11/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.11/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSREQ" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSREQ" field="true">
		//    <parameters name="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSREQ">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.11/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.11/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.10/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="dataAccessPartner" variable="true">
		//    <dataOutputs target="//@executableElements.9/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.9/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getEndPoint" category="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" className="com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints" static="true" memberName="getEndPoint">
		//    <parameters name="key" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="scaService" dataInputs="//@executableElements.8/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.10/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="SetTargetAddress" category="SCA and BO services" targetNamespace="http://GES_Lib_Common/utility/SCA%20and%20BO%20services/">
		//    <parameters name="smo" dataInputs="//@executableElements.6/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sibx.smobo.ServiceMessageObject"/>
		//    </parameters>
		//    <parameters name="targetURI" dataInputs="//@executableElements.9/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.4/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.5/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <executableGroups executableElements="//@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9 //@executableElements.10"/>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.11"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.12"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:5,1
		//!SMAP!4:6,1
		//!SMAP!5:7,1
		//!SMAP!9:2,1
		//!SMAP!10:3,1
		//!SMAP!11:4,1
		//!SMAP!12:8,1
		//!SMAP!13:9,1
		//!SMAP!1000000:134,1
	}
}
