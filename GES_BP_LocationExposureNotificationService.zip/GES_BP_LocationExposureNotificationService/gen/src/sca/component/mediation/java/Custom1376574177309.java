package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: GES_MF_LocationExposureNotificationService Interface: LocationExposureNotificationService Operation: receiveLocationUpdates Type: request Custom Mediation: LogWSResponse
 */
public class Custom1376574177309 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__3 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__4 = getMediationServices();
		java.lang.String __result__5 = com.us.chartisinsurance.ges.logger.constants.MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSRES;
		java.lang.String __result__6 = "Location Details from GES based on Physical Object Id \n";
		java.lang.String __result__7;
		{// append text
			__result__7 = __result__5.concat(__result__6);
		}
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__3,
				__result__4, __result__7, __smo);
		commonj.sdo.DataObject __result__10 = __smo.getDataObject("body")
				.getDataObject("getData").getDataObject("Payload");
		commonj.sdo.DataObject LocationsArray = __result__10;
		commonj.sdo.DataObject __result__12;
		{// create SMO body with getLocationsFromGESResponseMsg
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory
					.createServiceMessageObject(new javax.xml.namespace.QName(
							"http://aig.us.com/ges/services/GESCommonServiceV2",
							"getLocationsFromGESResponseMsg"));
			__result__12 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject GetLocationsFromGEsResponseMsg = __result__12;
		commonj.sdo.DataObject __result__14;
		{// create getLocationsFromGESResponseType
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__14 = factory.create("http://aig.us.com/ges/schema",
					"getLocationsFromGESResponseType");
		}
		commonj.sdo.DataObject GesLocationResponseParamaeter = __result__14;
		commonj.sdo.DataObject __result__16;
		{// create GESLocations
			com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
					.locateService("com/ibm/websphere/bo/BOFactory");
			__result__16 = factory.create("http://aig.us.com/ges/schema",
					"GESLocations");
		}
		commonj.sdo.DataObject GESLocations = __result__16;
		java.lang.String __result__18 = "arrayOfLocations";
		GESLocations.setDataObject(__result__18, LocationsArray);
		byte __result__22 = 0;
		GesLocationResponseParamaeter.setDataObject(__result__22, GESLocations);
		byte __result__26 = 0;
		GetLocationsFromGEsResponseMsg.setDataObject(__result__26,
				GesLocationResponseParamaeter);
		__smo.set("body", GetLocationsFromGEsResponseMsg);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.30/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.30/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.8/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.8/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="MessageBundle.COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSRES" category="com.us.chartisinsurance.ges.logger.constants.MessageBundle" className="com.us.chartisinsurance.ges.logger.constants.MessageBundle" static="true" memberName="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSRES" field="true">
		//    <parameters name="COM_GES_MF_LocationExposureNotificationService_receiveLocationUpdates__WSRES">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Location Details from GES based on Physical Object Id \n&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.6/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="append text" description="Combine the text of two words into one word" category="text" template="&lt;%return%> &lt;%input1%>.concat(&lt;%input2%>);">
		//    <parameters name="input1" dataInputs="//@executableElements.4/@result/@dataOutputs.0" displayName="input 1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="input2" dataInputs="//@executableElements.5/@dataOutputs.0" displayName="input 2">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result name="combined text" displayName="combined text">
		//      <dataOutputs target="//@executableElements.8/@parameters.2"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.8/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.2/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.3/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.7/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.getData.Payload" field="true">
		//    <dataOutputs target="//@executableElements.10"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.9/@dataOutputs.0" value="LocationsArray" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create SMO body with getLocationsFromGESResponseMsg" description="Create SMO body with message {http://aig.us.com/ges/services/GESCommonServiceV2}getLocationsFromGESResponseMsg" category="SMO services" template="com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = &#xA;   com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;&#xA;com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = &#xA;   _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(&quot;http://aig.us.com/ges/services/GESCommonServiceV2&quot;, &quot;getLocationsFromGESResponseMsg&quot;));&#xA;&lt;%return%> (commonj.sdo.DataObject) _new_smo.getBody();">
		//    <result name="message body" displayName="service message object body">
		//      <dataOutputs target="//@executableElements.12"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@result/@dataOutputs.0" value="GetLocationsFromGEsResponseMsg" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create getLocationsFromGESResponseType" description="create a new getLocationsFromGESResponseType {http://aig.us.com/ges/schema}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/schema&quot;,&quot;getLocationsFromGESResponseType&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.14"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESResponseType" namespace="http://aig.us.com/ges/schema" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.13/@result/@dataOutputs.0" value="GesLocationResponseParamaeter" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="create GESLocations" description="create a new GESLocations {http://aig.us.com/ges/schema}" category="SCA and BO services" template="com.ibm.websphere.bo.BOFactory factory = &#xA;   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOFactory&quot;);&#xA; &lt;%return%> factory.create(&quot;http://aig.us.com/ges/schema&quot;,&quot;GESLocations&quot;);">
		//    <result>
		//      <dataOutputs target="//@executableElements.16"/>
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GESLocations" namespace="http://aig.us.com/ges/schema" nillable="false"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@result/@dataOutputs.0" value="GESLocations" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.19/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GESLocations" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;arrayOfLocations&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.19/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="LocationsArray" localVariable="//@localVariables.0" variable="true">
		//    <dataOutputs target="//@executableElements.19/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.16/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.17/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.18/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GesLocationResponseParamaeter" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.23/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.23/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GESLocations" localVariable="//@localVariables.3" variable="true">
		//    <dataOutputs target="//@executableElements.23/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GESLocations" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.20/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.21/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.22/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GetLocationsFromGEsResponseMsg" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="0" assignable="false">
		//    <dataOutputs target="//@executableElements.27/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GesLocationResponseParamaeter" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.27/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="setDataObject" category="commonj.sdo.DataObject" className="commonj.sdo.DataObject" memberName="setDataObject">
		//    <parameters name="DataObject" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <parameters name="arg0" dataInputs="//@executableElements.25/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </parameters>
		//    <parameters name="arg1" dataInputs="//@executableElements.26/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="GetLocationsFromGEsResponseMsg" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.29"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.28/@dataOutputs.0" value="smo.body" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getDataResponseMsg" namespace="wsdl.http://GES_Lib_DataAccess/it/DataAccess"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.1/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="LocationsArray">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationsArray" namespace="http://aig.us.com/ges/schema" nillable="false"/>
		//  </localVariables>
		//  <localVariables name="GetLocationsFromGEsResponseMsg">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//  </localVariables>
		//  <localVariables name="GesLocationResponseParamaeter">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="getLocationsFromGESResponseType" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <localVariables name="GESLocations">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="GESLocations" namespace="http://aig.us.com/ges/schema"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.2 //@executableElements.3 //@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7 //@executableElements.8"/>
		//  <executableGroups executableElements="//@executableElements.9 //@executableElements.10"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12"/>
		//  <executableGroups executableElements="//@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.15 //@executableElements.16 //@executableElements.17 //@executableElements.18 //@executableElements.19"/>
		//  <executableGroups executableElements="//@executableElements.20 //@executableElements.21 //@executableElements.22 //@executableElements.23"/>
		//  <executableGroups executableElements="//@executableElements.24 //@executableElements.25 //@executableElements.26 //@executableElements.27"/>
		//  <executableGroups executableElements="//@executableElements.28 //@executableElements.29"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.1 //@executableElements.30"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!3:2,1
		//!SMAP!4:3,1
		//!SMAP!5:4,1
		//!SMAP!6:5,1
		//!SMAP!7:6,4
		//!SMAP!9:10,1
		//!SMAP!10:11,1
		//!SMAP!11:12,1
		//!SMAP!12:13,8
		//!SMAP!13:21,1
		//!SMAP!14:22,6
		//!SMAP!15:28,1
		//!SMAP!16:29,6
		//!SMAP!17:35,1
		//!SMAP!18:36,1
		//!SMAP!20:37,1
		//!SMAP!22:38,1
		//!SMAP!24:39,1
		//!SMAP!26:40,1
		//!SMAP!28:41,1
		//!SMAP!30:42,1
		//!SMAP!31:43,1
		//!SMAP!1000000:289,1
	}
}
