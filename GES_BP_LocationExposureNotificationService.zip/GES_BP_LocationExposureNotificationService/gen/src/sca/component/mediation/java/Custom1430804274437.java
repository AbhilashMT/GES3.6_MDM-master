package sca.component.mediation.java;

import com.ibm.websphere.sibx.smobo.ServiceMessageObject;
import com.ibm.wsspi.sibx.mediation.InputTerminal;
import com.ibm.wsspi.sibx.mediation.MediationBusinessException;
import com.ibm.wsspi.sibx.mediation.MediationConfigurationException;
import com.ibm.wsspi.sibx.mediation.OutputTerminal;
import com.ibm.wsspi.sibx.mediation.esb.ESBMediationPrimitive;
import commonj.sdo.DataObject;
import com.ibm.wsspi.sibx.mediation.MediationServices;

/**
 * @generated
 *  Flow: BatchProcessing Interface: LocationExposureNotificationService Operation: receiveLocationUpdates Type: request Custom Mediation: SettingAggregationReferences
 */
public class Custom1430804274437 extends ESBMediationPrimitive {

	private InputTerminal in;
	private OutputTerminal out;

	/* state of primitive initialization */
	private boolean __initPassed = false;

	/* primitive display name */
	private String __primitiveDisplayName = null;

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#init()
	 */
	public void init() throws MediationConfigurationException {
		/* Get the mediation service */
		MediationServices mediationServices = this.getMediationServices();
		if (mediationServices == null)
			throw new MediationConfigurationException(
					"MediationServices object not set.");

		/* Get the primitive display name for use in exception messages */
		__primitiveDisplayName = mediationServices.getMediationDisplayName();

		in = mediationServices.getInputTerminal("in");
		if (in == null) {
			throw new MediationConfigurationException(
					"No terminal named in defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		out = mediationServices.getOutputTerminal("out");
		if (out == null) {
			throw new MediationConfigurationException(
					"No terminal named out defined for mediation primitive "
							+ __primitiveDisplayName);
		}

		/* Initialization completed */
		__initPassed = true;
	}

	/* 
	 * @generated
	 * (non-Javadoc)
	 * @see com.ibm.wsspi.sibx.mediation.Mediation#mediate(com.ibm.wsspi.sibx.mediation.InputTerminal, commonj.sdo.DataObject)
	 */
	public void mediate(InputTerminal inputTerminal, DataObject message)
			throws MediationConfigurationException, MediationBusinessException {
		/* If initialization didn't complete, try again */
		if (!__initPassed) {
			init();
		}

		try {
			doMediate(inputTerminal, (ServiceMessageObject) message);
		} catch (Exception e) {
			if (e instanceof MediationBusinessException) {
				throw (MediationBusinessException) e;
			} else if (e instanceof MediationConfigurationException) {
				throw (MediationConfigurationException) e;
			} else {
				throw new MediationBusinessException(e);
			}
		}
	}

	/**
	 * @generated
	 */
	public void doMediate(InputTerminal inputTerminal, ServiceMessageObject smo)
			throws MediationConfigurationException, MediationBusinessException {
		commonj.sdo.DataObject __smo = (commonj.sdo.DataObject) smo;
		java.lang.String __result__2 = com.us.aig.ges.constants.GESConstantBundle.GRASP_BATCHSIZE;
		java.lang.Object __result__3 = com.aig.us.ges.cache.utils.GESCacheLoader
				.getValueFromCache(__result__2);
		java.lang.Object BatchValue = __result__3;
		java.lang.String __result__6 = java.lang.String.valueOf(BatchValue);
		java.lang.Integer __result__7 = null;
		try {
			__result__7 = java.lang.Integer.valueOf(__result__6);
		} catch (java.lang.NumberFormatException ex) {
		}
		int __result__10 = __result__7.intValue();
		int BatchSize = __result__10;
		byte __result__1 = 1;
		__smo.getDataObject("context").getDataObject("correlation").setInt(
				"MinField", __result__1);
		__smo.getDataObject("context").getDataObject("correlation").setInt(
				"MaxField", BatchSize);
		__smo.getDataObject("context").getDataObject("correlation").setInt(
				"CountDummy", BatchSize);
		commonj.sdo.DataObject __result__17 = __smo.getDataObject("body")
				.getDataObject("ReceiveLocationUpdatesRequest").getDataObject(
						"receiveLocationUpdatesRequest");
		commonj.sdo.DataObject ReceiveLocationUpdateReq = __result__17;
		boolean __result__19 = ReceiveLocationUpdateReq != null;
		if (__result__19) {
			int __result__22 = ReceiveLocationUpdateReq.getList(
					"LocationDetails").size();
			__smo.getDataObject("context").getDataObject("correlation").setInt(
					"TotalNoLocs", __result__22);
			commonj.sdo.DataObject __result__24 = ReceiveLocationUpdateReq
					.getDataObject("RequestHeader");
			__smo.getDataObject("context").getDataObject("correlation").set(
					"RequestHeader", __result__24);
			int __result__26 = ReceiveLocationUpdateReq.getList(
					"LocationDetails").size()
					/ __smo.getDataObject("context").getDataObject(
							"correlation").getInt("MaxField");
			int TotalNumberOfBatches = __result__26;
			boolean __result__28 = ReceiveLocationUpdateReq.getList(
					"LocationDetails").size()
					% __smo.getDataObject("context").getDataObject(
							"correlation").getInt("MaxField") > 0;
			if (__result__28) {
				int __result__31 = TotalNumberOfBatches + 1;
				TotalNumberOfBatches = __result__31;
			} else {
			}
			java.util.ArrayList __result__35 = new java.util.ArrayList(
					TotalNumberOfBatches);
			java.util.ArrayList BatchProArray = __result__35;
			while (true) {
				boolean __result__39 = TotalNumberOfBatches > 0;
				if (!__result__39)
					break;
				boolean __result__41 = BatchProArray.add("GRASP");
				int __result__42 = TotalNumberOfBatches - 1;
				TotalNumberOfBatches = __result__42;
			}
			__smo.getDataObject("context").getDataObject("correlation").set(
					"BatchArray", BatchProArray);
			commonj.sdo.DataObject __result__46 = __smo
					.getDataObject("context").getDataObject("correlation");
			commonj.sdo.DataObject __result__47;
			{// copy BO
				com.ibm.websphere.bo.BOCopy _copyService = (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager()
						.locateService("com/ibm/websphere/bo/BOCopy");
				__result__47 = _copyService.copy(__result__46);
			}
			__smo.getDataObject("context").set("shared", __result__47);
		} else {
		}
		com.ibm.wsspi.sibx.mediation.esb.SCAServices __result__52 = getSCAServices();
		com.ibm.wsspi.sibx.mediation.MediationServices __result__53 = getMediationServices();
		java.lang.String __result__54 = "Aggregation initialisation completed";
		utility.MediationLogger_LogInfo.mediationLogger_LogInfo(__result__52,
				__result__53, __result__54, __smo);
		out.fire(__smo);

		//@generated:com.ibm.wbit.activity.ui
		//<?xml version="1.0" encoding="UTF-8"?>
		//<com.ibm.wbit.activity:CompositeActivity xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:com.ibm.wbit.activity="http:///com/ibm/wbit/activity.ecore" name="ActivityMethod">
		//  <parameters name="inputTerminal">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.InputTerminal"/>
		//  </parameters>
		//  <parameters name="smo" objectType="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </parameters>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationBusinessException"/>
		//  </exceptions>
		//  <exceptions>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationConfigurationException"/>
		//  </exceptions>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="1" assignable="false">
		//    <dataOutputs target="//@executableElements.10"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="byte"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="GESConstantBundle.GRASP_BATCHSIZE" category="com.us.aig.ges.constants.GESConstantBundle" className="com.us.aig.ges.constants.GESConstantBundle" static="true" memberName="GRASP_BATCHSIZE" field="true">
		//    <parameters name="GRASP_BATCHSIZE">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.2/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getValueFromCache" category="com.aig.us.ges.cache.utils.GESCacheLoader" className="com.aig.us.ges.cache.utils.GESCacheLoader" static="true" memberName="getValueFromCache">
		//    <parameters name="aKey" dataInputs="//@executableElements.1/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.3"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.2/@result/@dataOutputs.0" value="BatchValue" localVariable="//@localVariables.1" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="BatchValue" localVariable="//@localVariables.1" variable="true">
		//    <dataOutputs target="//@executableElements.5/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="valueOf" category="java.lang.String" className="java.lang.String" static="true" memberName="valueOf">
		//    <parameters name="obj" dataInputs="//@executableElements.4/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.6/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="valueOf" category="java.lang.Integer" className="java.lang.Integer" static="true" memberName="valueOf">
		//    <parameters name="arg0" dataInputs="//@executableElements.5/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.8/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Integer"/>
		//    </result>
		//    <exceptions>
		//      <dataOutputs target="//@executableElements.7/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.NumberFormatException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:ExceptionHandler" name="Exception Handler">
		//    <parameters name="ex" dataInputs="//@executableElements.6/@exceptions.0/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.NumberFormatException"/>
		//    </parameters>
		//    <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ex" variable="true">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.NumberFormatException"/>
		//    </executableElements>
		//    <executableGroups executableElements="//@executableElements.7/@executableElements.0"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="intValue" category="java.lang.Integer" className="java.lang.Integer" memberName="intValue">
		//    <parameters name="Integer" dataInputs="//@executableElements.6/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Integer"/>
		//    </parameters>
		//    <result>
		//      <dataOutputs target="//@executableElements.9"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.8/@result/@dataOutputs.0" value="BatchSize" localVariable="//@localVariables.2" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.0/@dataOutputs.0" value="smo.context.correlation.MinField" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="BatchSize" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.12"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.11/@dataOutputs.0" value="smo.context.correlation.MaxField" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="BatchSize" localVariable="//@localVariables.2" variable="true">
		//    <dataOutputs target="//@executableElements.14"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.13/@dataOutputs.0" value="smo.context.correlation.CountDummy" field="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.body.ReceiveLocationUpdatesRequest.receiveLocationUpdatesRequest" field="true">
		//    <dataOutputs target="//@executableElements.16"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationEngineeringUpdatesRequest" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.15/@dataOutputs.0" value="ReceiveLocationUpdateReq" localVariable="//@localVariables.0" variable="true">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationEngineeringUpdatesRequest" namespace="http://aig.us.com/ges/common/v3"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ReceiveLocationUpdateReq!=null" assignable="false">
		//    <dataOutputs target="//@executableElements.18"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.17/@dataOutputs.0">
		//    <conditionalActivities>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ReceiveLocationUpdateReq.LocationDetails.size()" assignable="false">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.1"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="smo.context.correlation.TotalNoLocs" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="int" namespace="http://www.w3.org/2001/XMLSchema" nillable="false"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ReceiveLocationUpdateReq.RequestHeader" field="true">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.3"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.2/@dataOutputs.0" value="smo.context.correlation.RequestHeader" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="RequestHeader" namespace="http://aig.com/CommonHeaderV12"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ReceiveLocationUpdateReq.LocationDetails.size()/ smo.context.correlation.MaxField" assignable="false">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.5"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.4/@dataOutputs.0" value="TotalNumberOfBatches" localVariable="//@executableElements.18/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="ReceiveLocationUpdateReq.LocationDetails.size()% smo.context.correlation.MaxField >0" assignable="false">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.7"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:BranchElement" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.6/@dataOutputs.0">
		//        <conditionalActivities>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TotalNumberOfBatches +1" assignable="false">
		//            <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.7/@conditionalActivities.0/@executableElements.1"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.7/@conditionalActivities.0/@executableElements.0/@dataOutputs.0" value="TotalNumberOfBatches" localVariable="//@executableElements.18/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.7/@conditionalActivities.0/@executableElements.0 //@executableElements.18/@conditionalActivities.0/@executableElements.7/@conditionalActivities.0/@executableElements.1"/>
		//          <condition value="true"/>
		//        </conditionalActivities>
		//        <conditionalActivities>
		//          <condition value=""/>
		//        </conditionalActivities>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TotalNumberOfBatches" localVariable="//@executableElements.18/@conditionalActivities.0/@localVariables.0" variable="true">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.9/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="new ArrayList" category="java.util.ArrayList" className="java.util.ArrayList" constructor="true" memberName="ArrayList">
		//        <parameters name="capacity" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.8/@dataOutputs.0">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//        </parameters>
		//        <result>
		//          <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.10"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.9/@result/@dataOutputs.0" value="BatchProArray" localVariable="//@executableElements.18/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:WhileActivity">
		//        <condition>
		//          <result dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@condition/@executableElements.0/@dataOutputs.0">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </result>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TotalNumberOfBatches >0" assignable="false">
		//            <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@condition/@result"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@condition/@executableElements.0"/>
		//        </condition>
		//        <body>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="BatchProArray.add(&quot;GRASP&quot;)" assignable="false">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="boolean"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="TotalNumberOfBatches -1" assignable="false">
		//            <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@body/@executableElements.2"/>
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//          </executableElements>
		//          <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@body/@executableElements.1/@dataOutputs.0" value="TotalNumberOfBatches" localVariable="//@executableElements.18/@conditionalActivities.0/@localVariables.0" variable="true">
		//            <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//          </executableElements>
		//          <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@body/@executableElements.0"/>
		//          <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.11/@body/@executableElements.1 //@executableElements.18/@conditionalActivities.0/@executableElements.11/@body/@executableElements.2"/>
		//        </body>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="BatchProArray" localVariable="//@executableElements.18/@conditionalActivities.0/@localVariables.1" variable="true">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.13"/>
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.12/@dataOutputs.0" value="smo.context.correlation.BatchArray" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.List"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo.context.correlation" field="true">
		//        <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.15/@parameters.0"/>
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="BatchMode" namespace="http://COM_GES_MF_LocationExposureNotificationService/bo"/>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:LibraryActivity" name="copy BO" description="Copy a Business Object or Business Graph" category="SCA and BO services" template="com.ibm.websphere.bo.BOCopy _copyService = &#xA;   (com.ibm.websphere.bo.BOCopy) new com.ibm.websphere.sca.ServiceManager().locateService(&quot;com/ibm/websphere/bo/BOCopy&quot;); &#xA;&lt;%return%> _copyService.copy(&lt;%bo%>);">
		//        <parameters name="bo" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.14/@dataOutputs.0" displayName="BO">
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </parameters>
		//        <result name="copy" displayName="copy">
		//          <dataOutputs target="//@executableElements.18/@conditionalActivities.0/@executableElements.16"/>
		//          <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//        </result>
		//      </executableElements>
		//      <executableElements xsi:type="com.ibm.wbit.activity:Expression" dataInputs="//@executableElements.18/@conditionalActivities.0/@executableElements.15/@result/@dataOutputs.0" value="smo.context.shared" field="true">
		//        <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="BatchMode" namespace="http://COM_GES_MF_LocationExposureNotificationService/bo"/>
		//      </executableElements>
		//      <localVariables name="TotalNumberOfBatches">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//      </localVariables>
		//      <localVariables name="BatchProArray">
		//        <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.util.ArrayList"/>
		//      </localVariables>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.0 //@executableElements.18/@conditionalActivities.0/@executableElements.1"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.2 //@executableElements.18/@conditionalActivities.0/@executableElements.3"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.4 //@executableElements.18/@conditionalActivities.0/@executableElements.5"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.6 //@executableElements.18/@conditionalActivities.0/@executableElements.7"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.8 //@executableElements.18/@conditionalActivities.0/@executableElements.9 //@executableElements.18/@conditionalActivities.0/@executableElements.10"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.11"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.12 //@executableElements.18/@conditionalActivities.0/@executableElements.13"/>
		//      <executableGroups executableElements="//@executableElements.18/@conditionalActivities.0/@executableElements.14 //@executableElements.18/@conditionalActivities.0/@executableElements.15 //@executableElements.18/@conditionalActivities.0/@executableElements.16"/>
		//      <condition value="true"/>
		//    </conditionalActivities>
		//    <conditionalActivities>
		//      <condition value=""/>
		//    </conditionalActivities>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="out" variable="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.0"/>
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.26/@parameters.1"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getSCAServices" category="local" className="local" memberName="getSCAServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.25/@parameters.0"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="getMediationServices" category="local" className="local" memberName="getMediationServices">
		//    <result>
		//      <dataOutputs target="//@executableElements.25/@parameters.1"/>
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </result>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="&quot;Aggregation initialisation completed&quot;" assignable="false">
		//    <dataOutputs target="//@executableElements.25/@parameters.2"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="string" namespace="http://www.w3.org/2001/XMLSchema"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:Expression" value="smo" variable="true" assignable="false" input="true">
		//    <dataOutputs target="//@executableElements.25/@parameters.3"/>
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1"/>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:CustomActivityReference" name="MediationLogger_LogInfo" category="utility" targetNamespace="http://GES_Lib_Common/utility">
		//    <parameters name="SCAServices" dataInputs="//@executableElements.21/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.esb.SCAServices"/>
		//    </parameters>
		//    <parameters name="MediationServices" dataInputs="//@executableElements.22/@result/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.MediationServices"/>
		//    </parameters>
		//    <parameters name="inputMessage" dataInputs="//@executableElements.23/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.String"/>
		//    </parameters>
		//    <parameters name="dataObject" dataInputs="//@executableElements.24/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="commonj.sdo.DataObject"/>
		//    </parameters>
		//    <exceptions name="Exception1">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.websphere.sca.ServiceRuntimeException"/>
		//    </exceptions>
		//  </executableElements>
		//  <executableElements xsi:type="com.ibm.wbit.activity:JavaActivity" name="fire" category="com.ibm.wsspi.sibx.mediation.OutputTerminal" className="com.ibm.wsspi.sibx.mediation.OutputTerminal" memberName="fire">
		//    <parameters name="OutputTerminal" dataInputs="//@executableElements.19/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="com.ibm.wsspi.sibx.mediation.OutputTerminal"/>
		//    </parameters>
		//    <parameters name="smo" dataInputs="//@executableElements.20/@dataOutputs.0">
		//      <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="ServiceMessageObject" namespace="http://www.ibm.com/websphere/sibx/smo/v6.0.1" nillable="false"/>
		//    </parameters>
		//  </executableElements>
		//  <localVariables name="ReceiveLocationUpdateReq">
		//    <type xsi:type="com.ibm.wbit.activity:XSDElementType" name="LocationEngineeringUpdatesRequest" namespace="http://aig.us.com/ges/common/v3"/>
		//  </localVariables>
		//  <localVariables name="BatchValue">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="java.lang.Object"/>
		//  </localVariables>
		//  <localVariables name="BatchSize">
		//    <type xsi:type="com.ibm.wbit.activity:JavaElementType" name="int"/>
		//  </localVariables>
		//  <executableGroups executableElements="//@executableElements.1 //@executableElements.2 //@executableElements.3"/>
		//  <executableGroups executableElements="//@executableElements.4 //@executableElements.5 //@executableElements.6 //@executableElements.7 //@executableElements.8 //@executableElements.9"/>
		//  <executableGroups executableElements="//@executableElements.0 //@executableElements.10"/>
		//  <executableGroups executableElements="//@executableElements.11 //@executableElements.12"/>
		//  <executableGroups executableElements="//@executableElements.13 //@executableElements.14"/>
		//  <executableGroups executableElements="//@executableElements.15 //@executableElements.16"/>
		//  <executableGroups executableElements="//@executableElements.17 //@executableElements.18"/>
		//  <executableGroups executableElements="//@executableElements.21 //@executableElements.22 //@executableElements.23 //@executableElements.24 //@executableElements.25"/>
		//  <executableGroups executableElements="//@executableElements.19 //@executableElements.20 //@executableElements.26"/>
		//</com.ibm.wbit.activity:CompositeActivity>
		//@generated:end
		//!SMAP!*S WBIACTDBG
		//!SMAP!*L
		//!SMAP!1:14,1
		//!SMAP!2:2,1
		//!SMAP!3:3,1
		//!SMAP!4:4,1
		//!SMAP!6:5,1
		//!SMAP!7:8,2
		//!SMAP!10:12,1
		//!SMAP!11:13,1
		//!SMAP!12:15,1
		//!SMAP!14:16,1
		//!SMAP!16:17,1
		//!SMAP!17:18,1
		//!SMAP!18:19,1
		//!SMAP!19:20,1
		//!SMAP!20:21,1
		//!SMAP!22:22,1
		//!SMAP!23:23,1
		//!SMAP!24:24,1
		//!SMAP!25:25,1
		//!SMAP!26:26,1
		//!SMAP!27:27,1
		//!SMAP!28:28,1
		//!SMAP!29:29,1
		//!SMAP!31:30,1
		//!SMAP!32:31,1
		//!SMAP!35:35,1
		//!SMAP!36:36,1
		//!SMAP!37:37,1
		//!SMAP!39:38,2
		//!SMAP!41:40,1
		//!SMAP!42:41,1
		//!SMAP!43:42,2
		//!SMAP!45:44,1
		//!SMAP!46:45,1
		//!SMAP!47:46,6
		//!SMAP!48:52,1
		//!SMAP!52:56,1
		//!SMAP!53:57,1
		//!SMAP!54:58,1
		//!SMAP!56:59,1
		//!SMAP!57:60,1
		//!SMAP!1000000:422,1
	}
}
