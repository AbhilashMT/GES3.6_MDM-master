package com_ges_mf_dataservice.bo;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class GraspUpdateLocationDataBinding extends com.ibm.j2ca.jdbc.emd.databinding.JDBCDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://COM_GES_MF_DataService/bo";
	private String businessObjectName = "GraspUpdateLocation";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}