package gesdbupdateutils.gexpdbatesb_audit;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class GexpdbaTesb_AuditDataBinding extends com.ibm.j2ca.jdbc.emd.databinding.JDBCDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://GESDBUpdateUtils/gexpdbatesb_audit";
	private String businessObjectName = "GexpdbaTesb_Audit";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}