package gesdbupdateutils.gexpdbatesb_auditcontainer;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class GexpdbaTesb_AuditContainerDataBinding extends com.ibm.j2ca.jdbc.emd.databinding.JDBCDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://GESDBUpdateUtils/gexpdbatesb_auditcontainer";
	private String businessObjectName = "GexpdbaTesb_AuditContainer";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}