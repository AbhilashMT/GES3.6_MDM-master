package com.us.chartisinsurance.ges.logger;

import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

public class GESServicesFormatter extends Formatter {
	private final static int MAX_THREAD_NAME_LENGTH = 40;

	private static com.us.chartisinsurance.ges.logger.GESServicesFormatter formatter;

	public static Formatter getGESServicesFormatter() {

		if (null == formatter) {
			formatter = new com.us.chartisinsurance.ges.logger.GESServicesFormatter();
		}
		return formatter;
	}

	@Override
	public String format(LogRecord record) {
		// Create a StringBuffer to contain the formatted record
		// start with the date.
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"MM/dd/yyyy HH:mm:ss:SSS zzz");

		StringBuffer sb = new StringBuffer();
		String threadName = Thread.currentThread().getName();

		// Get the date from the LogRecord and add it to the buffer
		String date = dateFormat.format(new Date(record.getMillis()));
		sb.append("[" + date + "]");
		sb.append(" ");

		if (threadName != null && threadName.length() > MAX_THREAD_NAME_LENGTH) {
			threadName = threadName.substring(threadName.length()
					- MAX_THREAD_NAME_LENGTH);
		}

		sb.append("<" + String.format("%08d", record.getThreadID()) + ">");
		// Get the level name and add it to the buffer
		sb.append(" ");
		sb.append(record.getLevel().getName());
		sb.append(" ");

		if (null != record.getSourceClassName()) {
			sb.append(record.getSourceClassName());
			sb.append(" ");

		} else {
			sb.append(" ");
		}

		if (null != record.getSourceMethodName()) {
			sb.append(record.getSourceMethodName());
			sb.append(" ");
		} else {
			sb.append(" ");
		}

		// Get the formatted message (includes localization
		// and substitution of paramters) and add it to the buffer
		sb.append(formatMessage(record));
		sb.append("\n");

		return sb.toString();
	}
}
