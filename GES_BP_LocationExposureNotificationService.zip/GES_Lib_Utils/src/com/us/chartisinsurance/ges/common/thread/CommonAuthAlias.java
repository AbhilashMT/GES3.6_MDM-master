/**
 * 
 */
package com.us.chartisinsurance.ges.common.thread;

/**
 * @author Asurendr
 * 
 */
public interface CommonAuthAlias {

	public String SCA_AUTH_ALIAS = "SCA_Auth_Alias";

	public String BPC_AUTH_ALIAS = "BPC_Auth_Alias";

}
