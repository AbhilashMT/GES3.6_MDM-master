/**
 * 
 */
package com.us.chartisinsurance.ges.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.logging.Level;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.resource.spi.security.PasswordCredential;

import org.apache.commons.lang.StringUtils;

import com.ibm.websphere.sib.api.jms.JmsConnectionFactory;
import com.ibm.websphere.sib.api.jms.JmsFactoryFactory;
import com.us.chartisinsurance.ges.common.thread.AuthAliasExtractor;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;
import commonj.sdo.helper.SDO;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.helper.XMLHelper;

/**
 * @author Asurendr
 * 
 */
public class VerifySIBus {

	/**
	 * @param args
	 */

	public static final String ENV = System.getProperty("env");

	private static DataObject BUSConfigDO;
	private static final String BUSCONFIGREPO = "GESMessagingEngineConfig.xml";
	public static final String APP_BUSNAME = "SCA.APPLICATION.wps70_" + ENV
			+ "_ges_cell.Bus";
	public static final String SYS_BUSNAME = "SCA.SYSTEM.wps70_" + ENV
			+ "ges_cell.Bus";
	public static final String CEI_BUSNAME = "CEI.wps70_" + ENV
			+ "_ges_cell.BUS";
	public static final String BPC_BUSNAME = "BPC.wps70_" + ENV
			+ "_ges_cell.Bus";

	public static final GESLoggerV4 verifySIBLoggerV4 = GESLoggerFactory
			.getLogger();
	private static XMLHelper xmlHelper = SDO.getDefaultHelperContext()
			.getXMLHelper();
	private static String[] toAddress;
	private static String[] ccAddress;

	public String aBusName;

	public String getABusName() {
		return aBusName;
	}

	public void setABusName(String busName) {
		aBusName = busName;
	}

	public String getAProviderEndpoint() {
		return aProviderEndpoint;
	}

	public void setAProviderEndpoint(String providerEndpoint) {
		aProviderEndpoint = providerEndpoint;
	}

	public String aProviderEndpoint;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// checkMEBus(APP_BUSNAME_L,
		// "10.32.11.98:7291:BootstrapSecureMessaging");
	}

	public VerifySIBus() {

	}

	public static void checkMEBus() {
		verifySIBLoggerV4.logCategory(LogCategory.MONITOR, VerifySIBus.class
				.getName(), "checkMEBus", VerifySIBus.class.getSimpleName(),
				"Entering", java.util.logging.Level.INFO);
		List<String> BusNamesList = BUSConfigDO.getList("BusName");

		String providerEndpoint = BUSConfigDO.getString("ProviderEndpoint")
				.trim();
		String[] BusNames = BusNamesList.toArray(new String[4]);

		String targetTransportInboundChain = "InboundSecureMessaging";

		String derivedBusNames = org.apache.commons.lang3.StringUtils.join(
				BusNamesList, ",");

		verifySIBLoggerV4.logCategory(LogCategory.MONITOR, VerifySIBus.class
				.getName(), "checkMEBus", VerifySIBus.class.getSimpleName(),
				" Bus Names to Verify : " + derivedBusNames, Level.INFO);
		JmsFactoryFactory siBusJMSFactory;
		try {
			siBusJMSFactory = JmsFactoryFactory.getInstance();

			for (int i = 0; i < BusNames.length; ++i) {

				JmsConnectionFactory siBusJmsConnFactory;
				try {
					verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
							VerifySIBus.class.getName(), "checkMEBus",
							VerifySIBus.class.getSimpleName(),
							" Verifying Bus : " + BusNames[i], Level.INFO);
					siBusJmsConnFactory = siBusJMSFactory
							.createConnectionFactory();
					siBusJmsConnFactory.setBusName(BusNames[i].trim());
					siBusJmsConnFactory.setProviderEndpoints(providerEndpoint);
					PasswordCredential credential = AuthAliasExtractor
							.getCredentials("");
					siBusJmsConnFactory.setUserName(credential.getUserName());
					siBusJmsConnFactory.setPassword(new String(credential
							.getPassword()));

					siBusJmsConnFactory
							.setTargetTransportChain(targetTransportInboundChain);
					Connection conn = siBusJmsConnFactory.createConnection();
					if (null != conn) {
						conn.close();
						verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
								VerifySIBus.class.getName(), "checkMEBus",
								VerifySIBus.class.getSimpleName(),
								" Connecttion to  Bus : " + BusNames[i]
										+ " Closed ", Level.INFO);
					}
				} catch (JMSException e) {

					verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
							VerifySIBus.class.getName(), "checkMEBus",
							VerifySIBus.class.getSimpleName(),
							" Error Reported from ME ", Level.SEVERE);

					String errorCode = e.getErrorCode();
					String customMessString = e.getMessage();
					String category = "Unable to connect to Messaging Engine  on Bus : "
							+ BusNames[i];
					verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
							VerifySIBus.class.getName(), "checkMEBus",
							VerifySIBus.class.getSimpleName(),
							" Error Code :  " + errorCode
									+ " Custom Message : " + customMessString,
							Level.SEVERE);
					if ("CWSIA0241".equalsIgnoreCase(errorCode)) {
						String initToAddress = BUSConfigDO.getString("ToAddr");
						String ccToAddress = BUSConfigDO.getString("CCAddr");

						toAddress = StringUtils.split(initToAddress, ",");
						ccAddress = StringUtils.split(ccToAddress, ",");

						verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
								VerifySIBus.class.getName(), "checkMEBus",
								VerifySIBus.class.getSimpleName(),
								" Email to be delivered to To Address {"
										+ toAddress + "}, CC Address {"
										+ ccAddress + "}", Level.SEVERE);

						new EMAILTaskExecutor().send(errorCode,
								customMessString, category, toAddress,
								ccAddress);
						break;
					}

				} catch (Exception e) {
					verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
							VerifySIBus.class.getName(), "checkMEBus",
							VerifySIBus.class.getSimpleName(),
							" An Unexpected Error Occurred : "+e.getMessage(), Level.SEVERE);
					e.printStackTrace();

				}

			}
		} catch (JMSException e1) {
			e1.printStackTrace();
		}

	}

	static {

		String ENV = System.getProperty("env");
		InputStream is = null;

		is = (InputStream) VerifySIBus.class
				.getResourceAsStream("/com/us/chartisinsurance/ges/common/utils/"
						+ BUSCONFIGREPO);

		verifySIBLoggerV4.logCategory(LogCategory.MONITOR, VerifySIBus.class
				.getName(), "checkMEBus", VerifySIBus.class.getSimpleName(),
				" BUSCONFIG REPO Obtained : " + is, Level.INFO);

		if (null != is) {

			try {

				verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
						VerifySIBus.class.getName(), "checkMEBus",
						VerifySIBus.class.getSimpleName(),
						" XML Helper Obtained ", Level.INFO);
				XMLDocument GESMEConfigXML = xmlHelper.load(is);
				verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
						VerifySIBus.class.getName(), "checkMEBus",
						VerifySIBus.class.getSimpleName(),
						" XML Document Obtained from XML Helper ", Level.INFO);

				DataObject GESMEConfig = GESMEConfigXML.getRootObject();

				if (null == ENV) {
					ENV = "local";
				}
				verifySIBLoggerV4.logCategory(LogCategory.MONITOR,
						VerifySIBus.class.getName(), "checkMEBus",
						VerifySIBus.class.getSimpleName(), " GESMEConfig { "
								+ GESMEConfig + " }", Level.INFO);
				java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();

				xmlHelper.save(GESMEConfig, GESMEConfigXML.getRootElementURI(),
						GESMEConfigXML.getRootElementName(), baos);

				BUSConfigDO = getBusConfig(GESMEConfig);
				java.io.ByteArrayOutputStream baos1 = new java.io.ByteArrayOutputStream();
				xmlHelper.save(GESMEConfig, GESMEConfigXML.getRootElementURI(),
						GESMEConfigXML.getRootElementName(), baos1);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private static DataObject getBusConfig(DataObject aGESMEConfig) {

		List<DataObject> BUSConfigDOList = aGESMEConfig.getList("BUSConfig");

		for (DataObject busConfigDo : BUSConfigDOList) {
			if (ENV.equalsIgnoreCase(busConfigDo.getString("env"))) {
				java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();

				return busConfigDo;
			}

		}

		return null;
	}
}
