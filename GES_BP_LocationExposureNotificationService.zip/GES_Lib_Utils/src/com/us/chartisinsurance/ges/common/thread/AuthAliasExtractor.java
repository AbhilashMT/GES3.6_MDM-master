/**
 * 
 */
package com.us.chartisinsurance.ges.common.thread;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;

/**
 * @author M1019070
 * 
 */
public class AuthAliasExtractor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static PasswordCredential getCredentials(String aAliasName) {

		Map propMap = new HashMap();
	
		if ("".equalsIgnoreCase(aAliasName)) {

			propMap
					.put(
							com.ibm.wsspi.security.auth.callback.Constants.MAPPING_ALIAS,
							"SCA_Auth_Alias");
		} else {

			propMap
					.put(
							com.ibm.wsspi.security.auth.callback.Constants.MAPPING_ALIAS,
							aAliasName);
		}
		PasswordCredential credential = null;
		try {
			CallbackHandler callBackHandler = WSMappingCallbackHandlerFactory
					.getInstance().getCallbackHandler(propMap, null);
			LoginContext loginCtxt = new LoginContext(
					"DefaultPrincipalMapping", callBackHandler);

			loginCtxt.login();

			Subject subject = loginCtxt.getSubject();

			Set credentials = subject.getPrivateCredentials();

			credential = (PasswordCredential) credentials.iterator().next();

		} catch (NotImplementedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (LoginException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return credential;
	}
}
