package com.us.chartisinsurance.ges.common.utils;

import javax.jms.JMSException;
import javax.resource.spi.security.PasswordCredential;

import com.ibm.websphere.sib.api.jms.JmsConnectionFactory;
import com.ibm.websphere.sib.api.jms.JmsFactoryFactory;
import com.us.chartisinsurance.ges.common.thread.AuthAliasExtractor;

public class TestBus {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String providerEndpoint = "10.32.11.98:7291:BootstrapSecureMessaging";
		String[] BusNames = {"BPC.A4AIGMD16884Cell01.Bus","CEI.A4AIGMD16884Cell01.BUS"};

		String targetTransportInboundChain = "InboundSecureMessaging";
		StringBuffer BusNameBuffer = new StringBuffer();
		JmsFactoryFactory siBusJMSFactory;
		try {
			siBusJMSFactory = JmsFactoryFactory.getInstance();

			for (int i = 0; i < BusNames.length; ++i) {

				JmsConnectionFactory siBusJmsConnFactory;
				try {

					siBusJmsConnFactory = siBusJMSFactory
							.createConnectionFactory();
					siBusJmsConnFactory.setBusName(BusNames[i]);
					siBusJmsConnFactory.setProviderEndpoints(providerEndpoint);
					PasswordCredential credential = AuthAliasExtractor
							.getCredentials("");
					siBusJmsConnFactory.setUserName(credential.getUserName());
				
					siBusJmsConnFactory.setPassword(new String(credential
							.getPassword()));

					siBusJmsConnFactory
							.setTargetTransportChain(targetTransportInboundChain);
					siBusJmsConnFactory.createConnection();
				} catch (JMSException e) {

					String errorCode = e.getErrorCode();
					String customMessString = e.getMessage();
					String category = "Unable to connect to Messaging Engine  on Bus : "
							+ BusNames[i];

				}

			}
		} catch (JMSException e1) {
			e1.printStackTrace();
		}

		if (BusNameBuffer.length() > 0) {

		}

	}

}
