/**
 * 
 */
package com.us.chartisinsurance.ges.dynamicendpoints;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;
import org.apache.commons.lang3.StringUtils;

import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.ibm.websphere.cache.DistributedMap;
import com.ibm.websphere.sca.ServiceRuntimeException;
import com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;

/**
 * @author Asurendr
 * 
 */
public class XMLConfig {

	/**
	 * @param args
	 */

	private static boolean _localPropertiesRead = false;
	private static boolean isPropertiesDisplayed = false;
	private static final String CONFIGURATION_FILE = "Chartis_EPR.xml";
	private static final String VERSIONSEP = "_v";

	private static XMLConfiguration xmlConfigSlave = null;
	private static final String runtimeEnv = System.getProperty("env");
	private static GESLoggerV4 XMLConfigLogger = GESLoggerFactory.getLogger();

	private static DistributedMap gesDBCache = GESCacheLoader.getDbCache();

	static {

		InputStream is = null;
		if (null != runtimeEnv) {

			is = (InputStream) XMLConfig.class
					.getResourceAsStream("/com/us/chartisinsurance/ges/dynamicendpoints/"
							+ CONFIGURATION_FILE);

		}
		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfigSlave = new XMLConfiguration();
			try {
				xmlConfigSlave.load(reader);
				xmlConfigSlave.setExpressionEngine(new XPathExpressionEngine());

				_localPropertiesRead = true;


			} catch (ConfigurationException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}

	}

	public static XMLConfiguration getDynamicEndpointConfig() {
		if (null == xmlConfigSlave) {
			try {
				readProperties();
			} catch (ConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return xmlConfigSlave;
	}

	/**
	 * @param aPartnerName
	 * @param aModuleName
	 * @return
	 */
	public static String getURI(String aPartnerName, String aModuleName,
			String version) throws ServiceRuntimeException {

		String resp = "";
		String endpointURI = "";
		if (null == runtimeEnv) {
			XMLConfigLogger
					.logSevere(
							XMLConfig.class.getName(),
							"getURI",
							"",
							"Error occured in obtaining Dynamic Endpoint configuration ,Environment Varibale ${env} not set\n");

			throw new ServiceRuntimeException(GESExceptionHandler
					.formatException("GES-SYS-U1O12010E1",
							"Environment Varibale ${env} not set",
							XMLConfig.class.getSimpleName(), "getURIE1"));
		} else {

			if (!_localPropertiesRead) {
				XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getURI",
						"",
						"Looking up Endpoint configuration info for Environment : "
								+ "" + runtimeEnv);
				try {
					readProperties();

				} catch (ConfigurationException e) {

					XMLConfigLogger
							.logSevere(XMLConfig.class.getName(), "getURI", "",
									"Error occured in obtaining Dynamic Endpoint configuration  \n");
					throw new ServiceRuntimeException(GESExceptionHandler
							.formatException("GES-SYS-U1O12010E2",
									e.toString(), XMLConfig.class
											.getSimpleName(), "getURIE1"));

				} catch (IOException e) {

					XMLConfigLogger
							.logSevere(XMLConfig.class.getName(), "getURI", "",
									"Error occured in obtaining Dynamic Endpoint configuration  \n");
					throw new ServiceRuntimeException(GESExceptionHandler
							.formatException("GES-SYS-U1O12010E3",
									e.toString(), XMLConfig.class
											.getSimpleName(), "getURIE1"));

				}
			}

		}
		if (null != xmlConfigSlave)

		{

			String refPartEndpoint = "";// ReferenceEndPoints.getEndPoint(
			// aPartnerName, version);

			if (null == refPartEndpoint) {
				String moduleBaseName = getModuleBaseName(aModuleName);
				xmlConfigSlave.setExpressionEngine(new XPathExpressionEngine());
				String moduleNameXpath = "moduleNames/moduleName" + "["
						+ "name=\"" + moduleBaseName + "\"" + "]";
				String partnerXpath = "/wsImport" + "[" + "partnerName=\""
						+ aPartnerName + "\"" + "]";
				String endpointXpath = "/endpointRef" + "[" + "@env=\""
						+ runtimeEnv + "\"" + "]";
				String versionXpath = "/version" + "[" + "@value=\"" + version
						+ "\"" + "]";
				String finalXpath = moduleNameXpath + partnerXpath
						+ endpointXpath + versionXpath;
				String importTypeXpath = moduleNameXpath + partnerXpath
						+ endpointXpath + "/@type";
				XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getURI",
						XMLConfig.class.getName(), "Final Derived XPATH  : "
								+ " Value : " + finalXpath);
				String finalXpathValue = xmlConfigSlave.getString(finalXpath);

				XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getURI",
						XMLConfig.class.getName(), "Import Type  XPATH  : "
								+ " Value : " + importTypeXpath);
				String importTypeXPathValue = xmlConfigSlave
						.getString(importTypeXpath);
				XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getURI",
						XMLConfig.class.getName(), "Type of Partner : "
								+ " Value : " + importTypeXPathValue);

				if ("ws".equalsIgnoreCase(importTypeXPathValue)) {
					XMLConfigLogger.logInfo(XMLConfig.class.getName(),
							"getURI", XMLConfig.class.getName(),
							"XPATH to Evaluvate : " + finalXpath + " Value : "
									+ finalXpathValue);

					XMLConfigLogger.logInfo(XMLConfig.class.getName(),
							"getURI", XMLConfig.class.getName(),
							"Partner Type XPATH to Evaluvate : "
									+ importTypeXpath + " Value : "
									+ importTypeXPathValue);

					XMLConfigLogger.logInfo(GESLoggerV4.class.getName(),
							"getURI()", GESLoggerV4.class.getName(),
							"Import type evaluvated for partner : "
									+ aPartnerName + " is "
									+ importTypeXPathValue);

					XMLConfigLogger.logInfo(GESLoggerV4.class.getName(),
							"getURI()", GESLoggerV4.class.getName(),
							"Endpoint evaluvated for partner : " + aPartnerName
									+ " is " + finalXpathValue);
					resp = finalXpathValue;

					if (null != resp && resp.length() > 0) {
						XMLConfigLogger.logInfo(XMLConfig.class.getName(),
								"getURI", "", " Endpoint URL for  "
										+ aPartnerName + "  Is  " + resp);

					} else {

						XMLConfigLogger
								.logSevere(
										XMLConfig.class.getName(),
										"getURI",
										"",
										" Endpoint URL for  "
												+ aPartnerName
												+ " Could not be obtained from Master Config , PartnerName may be incorrect or Partner may be of SCA type"
												+ endpointURI);
						resp = "EndPoint URI could not be obtained";
						throw new ServiceRuntimeException(
								GESExceptionHandler
										.formatException(
												"GES-SYS-U1O12010E4",
												" Endpoint URL for  "
														+ aPartnerName
														+ " Could not be obtained from Master Config , PartnerName may be incorrect or Partner may be of SCA type",
												XMLConfig.class.getSimpleName(),
												"getURIE1"));

					}
					endpointURI = resp;
				} else {
					if (!"self".equalsIgnoreCase(aPartnerName)) {
						XMLConfigLogger.logInfo(XMLConfig.class.getName(),
								"getURI", "", " Partner is of SCA Type :  "
										+ aPartnerName);
					}

				}

			} else {

				endpointURI = refPartEndpoint;
			}

		}
		XMLConfigLogger.logInfo(XMLConfig.class.getName(), "getURI", "",
				" Endpoint URL for  " + aPartnerName + "  Is  " + endpointURI);
		return endpointURI;
	}

	/**
	 * @throws IOException
	 * @throws ConfigurationException
	 */
	static void readProperties() throws IOException, ConfigurationException {

		readLocalProperties();

	}

	static synchronized void readLocalProperties()
			throws ConfigurationException {
		InputStream is = null;
		if (null != System.getProperty("ges.runtime")) {

			is = (InputStream) XMLConfig.class
					.getResourceAsStream("/com/us/chartisinsurance/ges/dynamicendpoints/"
							+ CONFIGURATION_FILE);

		}
		if (null != is) {
			InputStreamReader reader = new InputStreamReader(is);
			xmlConfigSlave = new XMLConfiguration();
			xmlConfigSlave.load(reader);
			xmlConfigSlave.setExpressionEngine(new XPathExpressionEngine());

			_localPropertiesRead = true;

			if (!isPropertiesDisplayed) {
				displayConfig(xmlConfigSlave);
			}
			if (null != reader || null != is) {
				try {
					reader.close();
					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}

	}

	static synchronized void readPropertiesAndDisplay() throws IOException,
			ConfigurationException {

		readProperties();

	}

	private static boolean displayConfig(XMLConfiguration xmlConfig) {

		try {
			if (null != xmlConfig) {
				Object prop = xmlConfig
						.getProperty("moduleNames.moduleName.name");
				if (prop instanceof Collection) {
					XMLConfigLogger.logInfo(XMLConfig.class.getName(),
							"displayCOnfig()", XMLConfig.class.getName(),
							"Modules listed in Chartis config file : "
									+ ((Collection) prop).size() + "\n");
					int moduleListSize = ((Collection) prop).size();
					xmlConfig.setExpressionEngine(new XPathExpressionEngine());
					for (int i = 1; i <= moduleListSize; i++) {

						String moduleName = (String) xmlConfig
								.getProperty("moduleNames/moduleName[" + i
										+ "]/name");
						XMLConfigLogger.logInfo(XMLConfig.class.getName(),
								"displayCOnfig()", XMLConfig.class.getName(),
								"ModuleName :  " + moduleName + "\n");

						List partnerNameList = (ArrayList) xmlConfig
								.getList("moduleNames/moduleName[" + i
										+ "]/wsImport/partnerName");
						for (Object obj : partnerNameList) {
							String partnerName = (String) obj;
							XMLConfigLogger.logInfo(XMLConfig.class.getName(),
									"displayCOnfig()", XMLConfig.class
											.getName(), "\t" + "<"
											+ partnerName + ">");

							String endpointURI = (String) xmlConfig
									.getProperty("moduleNames/moduleName[" + i
											+ "]/wsImport" + "["
											+ "partnerName='" + partnerName
											+ "']" + "/endpointRef[@env='"
											+ runtimeEnv + "']");
							XMLConfigLogger.logInfo(XMLConfig.class.getName(),
									"displayCOnfig()", XMLConfig.class
											.getName(), "\t\t"
											+ "Endpoint URI's :<" + endpointURI
											+ ">" + "\n");

						}

					}

				}

				isPropertiesDisplayed = true;

			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return isPropertiesDisplayed;
	}



	public static String getModuleBaseName(String aVersionedModuleName) {

		String moduleBaseName = aVersionedModuleName;

		if (null != aVersionedModuleName && aVersionedModuleName.length() != 0) {
			if (aVersionedModuleName.contains(VERSIONSEP)) {

				moduleBaseName = StringUtils.substringBeforeLast(
						aVersionedModuleName, VERSIONSEP);

				XMLConfigLogger.logCategory(LogCategory.EPR, XMLConfig.class
						.getName(), "getModuleBaseName", XMLConfig.class
						.getName(), "Module name under consideration : "
						+ moduleBaseName, Level.INFO);
			}

		}

		
		return moduleBaseName;

	}

	public static void main(String[] args) {
		getModuleBaseName(null);
	}

	public static void loadAllPartners() {
		XMLConfiguration xmlConfig = getDynamicEndpointConfig();
		StringWriter stringWriter = new StringWriter();
		Properties cacheProperties = new Properties();
		try {
			xmlConfig.save(stringWriter);

			XMLConfigLogger.logCategory(LogCategory.EPR, XMLConfig.class
					.getName(), "loadAllPartners", XMLConfig.class
					.getSimpleName(), "CHARTIS EPR . XML "
					+ stringWriter.toString()
					+ "\n\n==========================================\n",
					Level.INFO);

			String moduleNameXpath = "moduleNames/moduleName" + "[" + "name=\""
					+ "{MODULE_NAME}" + "\"" + "]";
			String partnerXpath = "/wsImport" + "[" + "partnerName=\""
					+ "{PARTNER_NAME}" + "\"" + "]";
			String endpointXpath = "/endpointRef" + "[" + "@env=\""
					+ runtimeEnv + "\"" + "]";
			String versionXpath = "/version" + "[" + "@value=\"" + "{VERSION}"
					+ "\"" + "]";

			List<Object> modules = xmlConfig
					.getList("moduleNames/moduleName/name");

			for (Object moduleName : modules) {

				String MODULENAME = moduleName.toString();
				String derivedModuleXPath = StringUtils.replace(
						moduleNameXpath, "{MODULE_NAME}", MODULENAME);

				String partnersXpath = derivedModuleXPath
						+ "/wsImport/partnerName";
				List<Object> partners = xmlConfig.getList(partnersXpath);

				for (Object partnerName : partners) {

					String PARTNER = partnerName.toString();
					String derivedPartnerXPath = derivedModuleXPath
							+ StringUtils.replace(partnerXpath,
									"{PARTNER_NAME}", PARTNER);

					String derivedEndpointXpath = derivedPartnerXPath
							+ endpointXpath;

					String versionsXpath = derivedEndpointXpath
							+ "/version/@value";

					List<Object> versions = xmlConfig.getList(versionsXpath);

					for (Object version : versions) {
						String VERSION = version.toString();
						String derivedVersionXpath = derivedEndpointXpath
								+ StringUtils.replace(versionXpath,
										"{VERSION}", version.toString());

						String ENDPOINTURI = xmlConfig
								.getString(derivedVersionXpath);

						XMLConfigLogger.logCategory(LogCategory.EPR,
								XMLConfig.class.getName(), "loadAllPartners",
								XMLConfig.class.getSimpleName(),
								"EPR Values /n /t" + "Environment : "
										+ runtimeEnv + "\n\t" + "Version : "
										+ VERSION + "\n\t"
										+ "Module Property \n\t\t "
										+ MODULENAME + "\n\t\t"
										+ "Module XPATH : "
										+ derivedModuleXPath + "\n\t"
										+ "Partner Property \n\t\t " + PARTNER
										+ "\n\t\t" + " Partner Xpath : "
										+ derivedPartnerXPath + "\n\t"
										+ "Endpoint Property : \n\t\t"
										+ "Endpoint Xpath : "
										+ derivedVersionXpath + "\n\t\t"
										+ "Endpoint URL : " + ENDPOINTURI,
								Level.INFO);

						String finalKey = MODULENAME + "_" + PARTNER + "_"
								+ VERSION;

						if (null == gesDBCache) {
							System.setProperty(finalKey, ENDPOINTURI);
						}
						gesDBCache.put(finalKey, ENDPOINTURI);
						cacheProperties.setProperty(finalKey, ENDPOINTURI);
					}

				}

			}

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				cacheProperties.storeToXML(baos, "SYSTEM CACHE FOR EPR",
						"UTF-8");
				XMLConfigLogger.logCategory(LogCategory.EPR, XMLConfig.class
						.getName(), "loadAllPartners", XMLConfig.class
						.getSimpleName(), "SYSTEM CACHE \n" + baos.toString(),
						Level.INFO);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
