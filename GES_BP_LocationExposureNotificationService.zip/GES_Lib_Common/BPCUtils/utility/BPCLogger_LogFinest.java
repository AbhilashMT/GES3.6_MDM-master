package BPCUtils.utility;
public class BPCLogger_LogFinest {
	public static void bPCLogger_LogFinest(com.ibm.bpe.api.ActivityInstanceData ActivityInstanceData, com.ibm.bpe.api.ProcessInstanceData ProcessInstance, java.lang.String inputMessage, commonj.sdo.DataObject dataObject)throws com.ibm.websphere.sca.ServiceRuntimeException  {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__1 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__3 = ActivityInstanceData.getApplicationName();
		java.lang.String __result__5 = ProcessInstance.getProcessTemplateName();
		java.lang.String __result__7 = ProcessInstance.getParentProcessInstanceName();
		try {
			__result__1.logFinest(__result__3, __result__5, __result__7, inputMessage, dataObject);
		}
		catch(com.ibm.websphere.sca.ServiceRuntimeException ex){
			throw ex;
		}
	}
}