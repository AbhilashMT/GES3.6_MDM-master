package BPCUtils.utility.utility;
public class SendToMDM {
	public static java.lang.Boolean sendToMDM(commonj.sdo.DataObject sovLocation) {
		java.lang.String __result__1 = "";
		java.lang.String locationName = __result__1;
		java.lang.String siteName = __result__1;
		java.lang.String longtitude = __result__1;
		java.lang.String latitude = __result__1;
		java.lang.String addressLine = __result__1;
		java.lang.String city = __result__1;
		java.lang.String country = __result__1;
		boolean __result__9 = null != sovLocation;
		if (__result__9){
			java.lang.String __result__13 = "geographicArea";
			boolean __result__14 = sovLocation.isSet(__result__13);
			if (__result__14){
				commonj.sdo.DataObject __result__17 = sovLocation.getDataObject("geographicArea");
				commonj.sdo.DataObject geographicArea = __result__17;
				boolean __result__19 = null != geographicArea;
				if (__result__19){
					java.lang.String __result__23 = "ctyNm";
					boolean __result__24 = geographicArea.isSet(__result__23);
					if (__result__24){
						java.lang.String __result__27 = geographicArea.getString("ctyNm");
						city = __result__27;
					}
					else{
					}
					java.lang.String __result__31 = "cntryNm";
					boolean __result__32 = geographicArea.isSet(__result__31);
					if (__result__32){
						java.lang.String __result__35 = geographicArea.getString("cntryNm");
						country = __result__35;
					}
					else{
					}
					java.lang.String __result__39 = "addr";
					boolean __result__40 = geographicArea.isSet(__result__39);
					if (__result__40){
						java.lang.String __result__43 = geographicArea.getString("addr");
						addressLine = __result__43;
					}
					else{
					}
					java.lang.String __result__47 = "lattdInDegrs";
					boolean __result__48 = geographicArea.isSet(__result__47);
					if (__result__48){
						boolean __result__51 = geographicArea.getDataObject("lattdInDegrs").getString("Value") != null;
						if (__result__51){
							java.lang.String __result__54 = geographicArea.getDataObject("lattdInDegrs").getString("Value");
							latitude = __result__54;
						}
						else{
						}
					}
					else{
					}
					java.lang.String __result__59 = "lngtdInDegrs";
					boolean __result__60 = geographicArea.isSet(__result__59);
					if (__result__60){
						boolean __result__63 = geographicArea.getDataObject("lngtdInDegrs").getString("Value") != null;
						if (__result__63){
							java.lang.String __result__66 = geographicArea.getDataObject("lngtdInDegrs").getString("Value");
							longtitude = __result__66;
						}
						else{
						}
					}
					else{
					}
				}
				else{
				}
			}
			else{
			}
		}
		else{
		}
		java.lang.Boolean __result__78 = BPCUtils.utility.utility.utility.MDMDecision.mDMDecision(latitude, longtitude, country, addressLine, city);
		return __result__78;
	}
}