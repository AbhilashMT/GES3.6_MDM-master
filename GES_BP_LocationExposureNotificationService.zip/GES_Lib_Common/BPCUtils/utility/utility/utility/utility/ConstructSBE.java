package BPCUtils.utility.utility.utility.utility;
public class ConstructSBE {
	public static commonj.sdo.DataObject constructSBE(java.lang.String Message, java.lang.String moduleName, java.lang.String operationName, commonj.sdo.DataObject inputFault) {
		commonj.sdo.DataObject __result__1;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__1 = factory.create("http://aig.us.com/ges/common/v3","ArrayOfGESFault");
		}
		commonj.sdo.DataObject arrayOfGesFault = __result__1;
		commonj.sdo.DataObject __result__3;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__3 = factory.create("http://aig.us.com/ges/common/v3","GesFaultObjectType");
		}
		commonj.sdo.DataObject gesFaultObjectType = __result__3;
		commonj.sdo.DataObject __result__6;
		{// create StandardFaultType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__6 = factory.create("http://www.ibm.com/xmlns/prod/websphere/business-process/6.0.0/","StandardFaultType");
		}
		commonj.sdo.DataObject StandardFaultType = __result__6;
		gesFaultObjectType.setString("faultCode", Message);
		java.lang.String __result__10 = "";
		java.lang.String __result__14 = com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler.formatException(Message, __result__10, moduleName, operationName);
		gesFaultObjectType.setString("faultString", __result__14);
		commonj.sdo.Type __result__16 = inputFault.getType();
		java.lang.String __result__17 = __result__16.getName();
		java.lang.String BOTypeName = __result__17;
		java.lang.String __result__20 = "StandardFaultType";
		boolean __result__22 = __result__20.equalsIgnoreCase(BOTypeName);
		boolean isStandardFaultType = __result__22;
		if (isStandardFaultType){
			StandardFaultType = inputFault;
			java.lang.String __result__28 = StandardFaultType.getString("faultName") + " | " + StandardFaultType.getString("faultNameUri") + " | " + StandardFaultType.getString("messageText") + " | " + StandardFaultType.getString("rootException");
			gesFaultObjectType.setString("faultDetail", __result__28);
		}
		else{
			java.lang.String __result__31 = "An uexpected unmodelled fault was caught ,Please check the logs for exception trace ";
			gesFaultObjectType.setString("faultDetail", __result__31);
		}
		java.util.ArrayList __result__19 = new java.util.ArrayList();
		java.util.ArrayList faultList = __result__19;
		boolean __result__39 = faultList.add(gesFaultObjectType);
		byte __result__35 = 0;
		arrayOfGesFault.setList(__result__35, faultList);
		return arrayOfGesFault;
	}
}