package BPCUtils.utility.utility.utility;
public class MDMDecision {
	public static java.lang.Boolean mDMDecision(java.lang.String latitude, java.lang.String longitude, java.lang.String country, java.lang.String address, java.lang.String city) {
		com.us.chartisinsurance.ges.logger.GESLoggerV4 __result__3 = com.us.chartisinsurance.ges.logger.GESLoggerFactory.getLogger();
		java.lang.String __result__4 = "MDMDecision";
		java.lang.String __result__5 = "Does Location have all mandatory required Parameters ? \n";
		java.lang.String __result__6 = "COUNTRY : {";
		java.lang.String __result__16;
		{// append text
			__result__16 = __result__6.concat(country);
		}
		java.lang.String __result__11 = "},LATITUDE : {";
		java.lang.String __result__13;
		{// append text
			__result__13 = __result__11.concat(latitude);
		}
		java.lang.String __result__14;
		{// append text
			__result__14 = __result__16.concat(__result__13);
		}
		java.lang.String __result__15 = "}, LOGITUDE : {";
		java.lang.String __result__18;
		{// append text
			__result__18 = __result__15.concat(longitude);
		}
		java.lang.String __result__20 = "}, ADDRESS LINE ONE : {";
		java.lang.String __result__21;
		{// append text
			__result__21 = __result__20.concat(address);
		}
		java.lang.String __result__22;
		{// append text
			__result__22 = __result__18.concat(__result__21);
		}
		java.lang.String __result__23;
		{// append text
			__result__23 = __result__14.concat(__result__22);
		}
		java.lang.String __result__24 = "}, CITY : {";
		java.lang.String __result__8;
		{// append text
			__result__8 = __result__24.concat(city);
		}
		java.lang.String __result__9 = "}";
		java.lang.String __result__10;
		{// append text
			__result__10 = __result__8.concat(__result__9);
		}
		java.lang.String __result__26;
		{// append text
			__result__26 = __result__23.concat(__result__10);
		}
		java.lang.String __result__27;
		{// append text
			__result__27 = __result__5.concat(__result__26);
		}
		__result__3.logInfo(__result__4, __result__4, __result__4, __result__27);
		java.lang.String __result__29 = "";
		java.lang.Object __result__30 = null;
		BPCUtils.utility.utility.BPCCleansingLogger.bPCCleansingLogger(__result__29, __result__29, __result__29, __result__27, (commonj.sdo.DataObject)__result__30);
		boolean __result__1 = country.length() > 0;
		boolean __result__2 = latitude.length() > 0;
		boolean __result__32;
		{// and
			__result__32 = __result__1 && __result__2;
		}
		boolean __result__33 = longitude.length() > 0;
		boolean __result__34 = address.length() > 0;
		boolean __result__35;
		{// and
			__result__35 = __result__33 && __result__34;
		}
		boolean __result__36;
		{// and
			__result__36 = __result__32 && __result__35;
		}
		boolean __result__37 = city.length() > 0;
		boolean __result__38;
		{// and
			__result__38 = __result__36 && __result__37;
		}
		return new java.lang.Boolean(__result__38);
	}
}