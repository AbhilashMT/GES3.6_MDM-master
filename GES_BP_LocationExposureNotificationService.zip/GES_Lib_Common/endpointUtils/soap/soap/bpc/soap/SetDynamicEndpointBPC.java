package endpointUtils.soap.soap.bpc.soap;
public class SetDynamicEndpointBPC {
	public static void setDynamicEndpointBPC(commonj.sdo.DataObject servicePartners, com.ibm.bpe.api.ActivityInstanceData activityInstanceData, com.ibm.bpe.api.ProcessInstanceData processInstanceData) {
		java.lang.String __result__2 = "";
		java.lang.String moduleName = __result__2;
		boolean __result__1 = null != servicePartners.getList("partners");
		if (__result__1){
			java.lang.String __result__7 = activityInstanceData.getApplicationName();
			java.lang.String AppName = __result__7;
			java.lang.String __result__9 = com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo.getBPCModuleVersion(AppName);
			java.lang.String moduleVersion = __result__9;
			java.util.List __result__6 = servicePartners.getList("partners");
			java.util.Iterator iter6 = __result__6.iterator();
			while(iter6.hasNext()){
				java.lang.String servicePartner = (java.lang.String)iter6.next();
				java.lang.String __result__14 = com.us.chartisinsurance.ges.mediation.module.utils.MediationModuleMetaInfo.getBPCModuleName(AppName);
				java.lang.String __result__16 = com.us.chartisinsurance.ges.dynamicendpoints.XMLConfig.getURI(servicePartner, __result__14, moduleVersion);
				com.us.chartisinsurance.ges.dynamicendpoints.ReferenceEndPoints.setEndPoint(servicePartner, moduleVersion, __result__16);
			}
		}
		else{
		}
	}
}