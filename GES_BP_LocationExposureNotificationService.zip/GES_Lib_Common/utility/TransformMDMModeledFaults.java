package utility;
public class TransformMDMModeledFaults {
	public static com.ibm.websphere.sibx.smobo.ServiceMessageObject transformMDMModeledFaults(commonj.sdo.DataObject smoBody, java.lang.String qName, java.lang.String messageName, java.lang.String gesExcepCode, java.lang.String moduleName, java.lang.String opName) {
		byte __result__2 = 0;
		commonj.sdo.DataObject __result__3 = smoBody.getDataObject(__result__2);
		commonj.sdo.DataObject ModelledFault = __result__3;
		commonj.sdo.DataObject __result__5;
		{// create GesFaultObjectType
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__5 = factory.create("http://aig.us.com/ges/common/v3","GesFaultObjectType");
		}
		commonj.sdo.DataObject GESFaultObjectType = __result__5;
		java.lang.String __result__9 = "";
		java.lang.String __result__12 = com.us.chartisinsurance.ges.exceptionutils.GESExceptionHandler.formatException(gesExcepCode, __result__9, moduleName, opName);
		java.lang.String FormattedMsg = __result__12;
		commonj.sdo.DataObject __result__7 = ((commonj.sdo.DataObject)ModelledFault.getList("applicationMessage").get(0));
		commonj.sdo.DataObject applicationMessage = __result__7;
		java.lang.String __result__15 = gesExcepCode + " , MDM Code : ";
		java.lang.String __result__16 = applicationMessage.getDataObject("reason").getString("@code");
		java.lang.String __result__17;
		{// append text
			__result__17 = __result__15.concat(__result__16);
		}
		GESFaultObjectType.setString("faultCode", __result__17);
		java.lang.String __result__20 = "0";
		boolean __result__21 = __result__20.equalsIgnoreCase(__result__16);
		if (__result__21){
			java.lang.String __result__25 = "  < MDM RC  :  ";
			java.lang.String __result__26 = applicationMessage.getDataObject("reason").getString("@code");
			java.lang.String __result__27;
			{// append text
				__result__27 = __result__25.concat(__result__26);
			}
			java.lang.String __result__28 = " >";
			java.lang.String __result__29;
			{// append text
				__result__29 = __result__27.concat(__result__28);
			}
			java.lang.String __result__30 = "MDM Internal Error , Request resulted in Business Exception ";
			java.lang.String __result__31;
			{// append text
				__result__31 = __result__29.concat(__result__30);
			}
			java.lang.String __result__32;
			{// append text
				__result__32 = FormattedMsg.concat(__result__31);
			}
			GESFaultObjectType.setString("faultString", __result__32);
		}
		else{
			java.lang.String __result__36 = "  < MDM RC  :  ";
			java.lang.String __result__37 = applicationMessage.getDataObject("reason").getString("@code");
			java.lang.String __result__38;
			{// append text
				__result__38 = __result__36.concat(__result__37);
			}
			java.lang.String __result__39 = " > < Cause :  ";
			java.lang.String __result__40;
			{// append text
				__result__40 = __result__38.concat(__result__39);
			}
			java.lang.String __result__41 = applicationMessage.getDataObject("reason").getString("value");
			java.lang.String __result__42;
			{// append text
				__result__42 = __result__40.concat(__result__41);
			}
			java.lang.String __result__43;
			{// append text
				__result__43 = FormattedMsg.concat(__result__42);
			}
			GESFaultObjectType.setString("faultString", __result__43);
		}
		java.lang.String __result__19 = "MDM";
		GESFaultObjectType.setString("faultOrigin", __result__19);
		java.lang.String __result__47 = applicationMessage.getDataObject("reason").getString("value");
		GESFaultObjectType.setString("faultDetail", __result__47);
		java.util.ArrayList __result__46 = new java.util.ArrayList();
		java.util.ArrayList faultList = __result__46;
		boolean __result__52;
		{// add item to list
			__result__52 = faultList.add(GESFaultObjectType);
		}
		commonj.sdo.DataObject __result__53;
		{// create ArrayOfGESFault
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__53 = factory.create("http://aig.us.com/ges/common/v3","ArrayOfGESFault");
		}
		commonj.sdo.DataObject ArrayOfGESFault = __result__53;
		ArrayOfGESFault.set("gesFaults", faultList);
		commonj.sdo.DataObject __result__59;
		{// create SMO body
			com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory _smo_factory = 
				com.ibm.websphere.sibx.smobo.ServiceMessageObjectFactory.eINSTANCE;
			com.ibm.websphere.sibx.smobo.ServiceMessageObject _new_smo = _smo_factory.createServiceMessageObject(new javax.xml.namespace.QName(qName, messageName));
			__result__59 = (commonj.sdo.DataObject) _new_smo.getBody();
		}
		commonj.sdo.DataObject outputSMOBody = __result__59;
		byte __result__61 = 0;
		commonj.sdo.DataObject __result__62 = outputSMOBody.createDataObject(__result__61);
		commonj.sdo.DataObject outputSMOBody_firstChild = __result__62;
		outputSMOBody_firstChild = ArrayOfGESFault;
		byte __result__67 = 0;
		outputSMOBody.setDataObject(__result__67, outputSMOBody_firstChild);
		java.lang.String __result__71 = "..";
		commonj.sdo.DataObject __result__72 = outputSMOBody.getDataObject(__result__71);
		return (com.ibm.websphere.sibx.smobo.ServiceMessageObject)__result__72;
	}
}