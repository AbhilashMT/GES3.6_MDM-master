package utility.MDMUtils.utility;
public class PopulateMDMLocationHazardValueTxt {
	public static commonj.sdo.DataObject populateMDMLocationHazardValueTxt(java.lang.String locationHazardName, java.lang.String locationHazardValueTxt) {
		commonj.sdo.DataObject __result__1;
		{// create LocationHazard
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__1 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","LocationHazard");
		}
		commonj.sdo.DataObject LocationHazardTxt_1 = __result__1;
		commonj.sdo.DataObject __result__3;
		{// create XCdHazardCategoryTP
			com.ibm.websphere.bo.BOFactory factory = 
			   (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager().locateService("com/ibm/websphere/bo/BOFactory");
			 __result__3 = factory.create("http://additions.mdm.aig.com/aigmdmadditions/schema","XCdHazardCategoryTP");
		}
		commonj.sdo.DataObject LocHazardNameBO1 = __result__3;
		LocHazardNameBO1.setString("value", locationHazardName);
		LocationHazardTxt_1.setString("LocationHazardValueTxt", locationHazardValueTxt);
		LocationHazardTxt_1.set("LocationHazardName", LocHazardNameBO1);
		return LocationHazardTxt_1;
	}
}