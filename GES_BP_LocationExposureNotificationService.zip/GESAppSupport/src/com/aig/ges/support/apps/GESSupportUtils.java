package com.aig.ges.support.apps;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.ws.websvcs.transport.http.WASAxis2Servlet;
import com.us.aig.ges.dataobject.utils.DataObjectUtils;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;

import commonj.sdo.DataObject;
import commonj.sdo.helper.SDO;
import commonj.sdo.helper.XMLDocument;
import commonj.sdo.helper.XMLHelper;

/**
 * Servlet implementation class GESSupportUtils
 */
public class GESSupportUtils extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String METHODACTIONCONFIGURATIONFILE = "GESRESTServiceActions.xml";
	private static final GESLoggerV4 gESSupportUtilsLogger = GESLoggerFactory
			.getLogger();

	private static DataObject ActionDobj = null;

	/**
	 * @see WASAxis2Servlet#WASAxis2Servlet()
	 */
	public GESSupportUtils() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(), "doGet",
				GESSupportUtils.class.getSimpleName(), " Request URI : "
						+ request.getRequestURI());
		String resourcePath = StringUtils.substringAfterLast(request
				.getRequestURI(), "/");

		String remote = request.getRemoteAddr();
		String remoteHost = request.getRemoteHost();

		gESSupportUtilsLogger.logSevere(GESSupportUtils.class.getName(),
				"doGet", GESSupportUtils.class.getSimpleName(),
				" Resource Lookup Initiated By : Address  " + remote
						+ "  Host : " + remoteHost);

		gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(), "doGet",
				GESSupportUtils.class.getSimpleName(), " Look for Resource : "
						+ resourcePath);

		DataObject MethodActionDO = getActionDobj().getDataObject(
				"MethodAction[Method='" + resourcePath + "'" + "]");
		OutputStream outputStream = response.getOutputStream();

		if (null != MethodActionDO) {

			String derivedClassString = MethodActionDO.getString("ActionClass");

			String normalizedClassString = StringUtils
					.normalizeSpace(derivedClassString);

			gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(),
					"doGet", GESSupportUtils.class.getSimpleName(),
					" Derived Action Class : " + "<" + normalizedClassString
							+ ">");

			;

			try {
				Class derivedClass = Class.forName(normalizedClassString);

				Method methodToInvoke = derivedClass
						.getDeclaredMethod(resourcePath);
				Object returnObj = methodToInvoke.invoke(derivedClass
						.newInstance());

				response.setContentType("text/plain");

				if (returnObj instanceof DataObject) {
					DataObject outBO = (DataObject) returnObj;
					String XMLResponse = DataObjectUtils.dataObjectToString(
							outBO, outBO.getType().getName());
					outputStream.write(XMLResponse.getBytes());
				} else {
					outputStream.write(((String) returnObj).getBytes());
				}
			} catch (ServiceBusinessException e) {

				DataObject exceptionObj = (DataObject) e.getData();

				String exceptionString = DataObjectUtils.dataObjectToString(
						exceptionObj, "EXCEPTION");
				outputStream.write(exceptionString.getBytes());

			} catch (Exception e) {
				// TODO Auto-generated catch block

				outputStream.write((e.getMessage() != null ? e.getMessage()
						.getBytes() : "OTHER EXCEPTION".getBytes()));
			}
		} else {

			gESSupportUtilsLogger.logSevere(GESSupportUtils.class.getName(),
					"doGet", GESSupportUtils.class.getSimpleName(),
					" Please check the resource configuration ");

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(),
				"doPost", GESSupportUtils.class.getSimpleName(),
				" Request URI : " + request.getRequestURI());

		byte[] byteData = new byte[request.getContentLength()];
		BufferedInputStream bufferIS = new BufferedInputStream(request
				.getInputStream());

		if (null == bufferIS) {
			doGet(request, response);
		} else {
			bufferIS.read(byteData, 0, byteData.length);

			String aDataObjectString = new String(byteData);

			gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(),
					"doPost", GESSupportUtils.class.getSimpleName(),
					" POST DATA : " + aDataObjectString);

			gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(),
					"doPost", GESSupportUtils.class.getSimpleName(),
					" POST DATA : " + aDataObjectString);

			Class derivedClass = GESPOSTHandler.class;
			OutputStream outputStream = response.getOutputStream();
			try {
				DataObject args = DataObjectUtils
						.stringToDataObject(aDataObjectString);

				String resourcePath = StringUtils.substringAfterLast(request
						.getRequestURI(), "/");

				gESSupportUtilsLogger.logInfo(GESSupportUtils.class.getName(),
						"doPost", GESSupportUtils.class.getSimpleName(),
						" Look for Resource : " + resourcePath);
				DataObject MethodActionDO = getActionDobj().getDataObject(
						"MethodAction[Method='" + resourcePath + "'" + "]");

				if (null != MethodActionDO) {

					try {
						Method methodToInvoke = derivedClass.getMethod(
								resourcePath, new Class[] { DataObject.class });
						Object returnObj = methodToInvoke.invoke(derivedClass
								.newInstance(), args);

						response.setContentType("text/xml");

						if (returnObj instanceof DataObject) {
							DataObject outBO = (DataObject) returnObj;
							String XMLResponse = DataObjectUtils
									.dataObjectToString(outBO, outBO.getType()
											.getName());
							outputStream.write(XMLResponse.getBytes());
						} else {
							outputStream.write(((String) returnObj).getBytes());
						}
					} catch (ServiceBusinessException e) {

						DataObject exceptionObj = (DataObject) e.getData();

						String exceptionString = DataObjectUtils
								.dataObjectToString(exceptionObj, "EXCEPTION");
						outputStream.write(exceptionString.getBytes());

					}
				} else {

					gESSupportUtilsLogger.logSevere(GESSupportUtils.class
							.getName(), "doPost", GESSupportUtils.class
							.getSimpleName(),
							" Please check the resource configuration ");

				}
			} catch (InvocationTargetException e) {

				e.printStackTrace();
				outputStream.write("Unable to invoke the associated method"
						.getBytes());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				outputStream.write("Other Exception".getBytes());
			}

			finally {

				if (null != outputStream) {
					outputStream.close();
				}
			}
		}

	}

	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}

	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return super.getServletConfig();
	}

	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	@Override
	public void init(ServletConfig config) throws ServletException {

		InputStream is = null;

		is = (InputStream) GESPOSTHandler.class
				.getResourceAsStream("/com/aig/ges/support/apps/"
						+ METHODACTIONCONFIGURATIONFILE);

		if (null != is) {
			XMLHelper xmlHelper = SDO.getDefaultHelperContext().getXMLHelper();

			try {
				XMLDocument xmlDoc = xmlHelper.load(is);

				setActionDobj(xmlDoc.getRootObject());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			if (null != is) {
				try {

					is.close();
				} catch (IOException e) {

					e.printStackTrace();
				}

			}
		}

		super.init(config);
	}

	/**
	 * @param actionDobj
	 *            the actionDobj to set
	 */
	public static void setActionDobj(DataObject actionDobj) {
		ActionDobj = actionDobj;
	}

	/**
	 * @return the actionDobj
	 */
	public static DataObject getActionDobj() {
		return ActionDobj;
	}

}
