/**
 * 
 */
package com.aig.ges.support.apps;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.lang3.StringUtils;

import com.aig.us.ges.cache.utils.AuthCredentials;
import com.aig.us.ges.cache.utils.GESCacheLoader;
import com.aig.us.ges.cache.utils.LookUpKeysI;
import com.aig.us.ges.workmanager.utils.GESLookupThread;
import com.aig.us.ges.workmanager.utils.GESWorkManagerService;
import com.ibm.websphere.asynchbeans.WorkException;
import com.ibm.websphere.asynchbeans.WorkManager;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.Service;
import com.ibm.websphere.sca.ServiceBusinessException;
import com.ibm.websphere.sca.ServiceManager;
import com.us.aig.ges.constants.GESConstantBundle;
import com.us.chartisinsurance.ges.common.thread.MatchLogMonitor;
import com.us.chartisinsurance.ges.common.utils.AsyncTaskExecutorImpl;
import com.us.chartisinsurance.ges.common.utils.DynamicEndpointUtils;
import com.us.chartisinsurance.ges.common.utils.JMSUtils;
import com.us.chartisinsurance.ges.common.utils.LogUtils;
import com.us.chartisinsurance.ges.common.utils.MetaInfo;
import com.us.chartisinsurance.ges.db.utils.QueryAccess;
import com.us.chartisinsurance.ges.db.utils.QueryAccessBundle;
import com.us.chartisinsurance.ges.gateway.utils.InspectMessageType;
import com.us.chartisinsurance.ges.logger.GESLoggerFactory;
import com.us.chartisinsurance.ges.logger.GESLoggerV4;
import com.us.chartisinsurance.ges.logger.LogCategory;
import commonj.sdo.DataObject;

/**
 * @author M1019070
 * 
 */
public class GESPOSTHandler {

	/**
	 * @param args
	 */

	private static final String CLASSNAME = GESPOSTHandler.class.getName();
	private static final String CLASSNAMESHORT = GESPOSTHandler.class
			.getSimpleName();
	private static final GESLoggerV4 GESPOSTHANDLERLOGGER = GESLoggerFactory
			.getLogger();
	private static final BOFactory bof = (BOFactory) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOFactory");
	private static final BOXMLSerializer BOXML = (BOXMLSerializer) ServiceManager.INSTANCE
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");

	private static final ServiceManager SM = ServiceManager.INSTANCE;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public DataObject setLogLevel(DataObject logLevelBO)
			throws com.ibm.websphere.sca.ServiceBusinessException, Exception {

		GESPOSTHANDLERLOGGER.entering(CLASSNAME, "setLogLevel", CLASSNAMESHORT,
				"ENTRY setLogLevel");

		DataObject logLevelBOOUT = bof.create("http://GES_Lib_Common/bo",
				"LogLevel");
		DataObject logLevelBOResp = bof.create("http://GES_Lib_Common/bo",
				"UpdateLogLevels");
		String setLogLevel = logLevelBO.getString("UpdatedLevel");
		LogManager logManager = LogManager.getLogManager();

		if (setLogLevel != null) {
			if (logManager != null) {
				Logger rootLogger = logManager
						.getLogger(GESLoggerV4.subSystemName);
				Handler handlers[] = rootLogger.getHandlers();
				for (Handler handler : handlers) {

					if ("FileHandler".equalsIgnoreCase(handler.getClass()
							.getSimpleName())) {
						logLevelBOOUT.setString("CurrentLevel", handler
								.getLevel().toString());
						Level derivedLevel = Level.SEVERE;
						if (null != setLogLevel && setLogLevel.length() != 0) {
							if ("ERROR".equalsIgnoreCase(setLogLevel)) {
								derivedLevel = Level.SEVERE;
							}
							if ("INFO".equalsIgnoreCase(setLogLevel)) {
								derivedLevel = Level.INFO;
							}
							if ("WARN".equalsIgnoreCase(setLogLevel)) {
								derivedLevel = Level.WARNING;
							}
							if ("FINEST".equalsIgnoreCase(setLogLevel)) {
								derivedLevel = Level.FINEST;
							}
						}

						handler.setLevel(derivedLevel);
						rootLogger.setLevel(derivedLevel);
						logLevelBOOUT.setString("UpdatedLevel", handler
								.getLevel().toString());

					}

				}

			}
		}

		if (logLevelBO.isSet("Categories")) {

			GESPOSTHANDLERLOGGER.logInfo(CLASSNAME, "setLogLevel",
					CLASSNAMESHORT, "Categories Set in Request", logLevelBO);

			DataObject Categories = logLevelBO.getDataObject("Categories");

			List<DataObject> categoryList = Categories.getList("Category");

			if (!categoryList.isEmpty()) {

				DataObject ArrayOfCategory = bof.create(
						"http://GES_Lib_Common/bo", "ArrayOfCategory");
				List<DataObject> categoryOutList = new ArrayList<DataObject>();

				for (DataObject categoryBO : categoryList) {
					String category = categoryBO.getString("Category");
					String updatedLogLevelCategory = categoryBO
							.getString("UpdatedLevel");

					categoryBO.setString("CurrentLevel", LogUtils
							.getLogLevel(category));

					if (!LogCategory.MATCH.equalsIgnoreCase(category)) {
						categoryBO.setString("UpdatedLevel", LogUtils
								.setLogLevel(updatedLogLevelCategory, category,
										logManager));
					}
					categoryOutList.add(categoryBO);

				}

				ArrayOfCategory.setList("Category", categoryOutList);
				logLevelBOOUT.setDataObject("Categories", ArrayOfCategory);

			}
		}
		logLevelBOOUT.setString("HostName", MetaInfo.getHostName());
		logLevelBOOUT.setString("runtime", System.getProperty("ges.runtime"));
		try {
			List<DataObject> logLevelsList = new ArrayList<DataObject>();
			logLevelsList.add(logLevelBOOUT);
			GESPOSTHANDLERLOGGER.logCategory(LogCategory.EPR, CLASSNAME,
					"setLogLevel", CLASSNAMESHORT, "Set Log Level Complete",
					logLevelBOOUT, Level.INFO);
			logLevelBOResp.setList("logLevels", logLevelsList);
		} catch (Exception e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", CLASSNAMESHORT);
			gesFaultObject.setString("faultString", e.getMessage());
			throw new ServiceBusinessException(gesFaultObject);
		}

		GESLoggerFactory.getLogger().exiting(CLASSNAME, CLASSNAMESHORT,
				"setLogLevel, Inside DataService Java Class of Set Log Level",
				"Exit", logLevelBOResp);
		return logLevelBOResp;
	}

	public static DataObject browseMessage(DataObject browseMessageRequest)
			throws ServiceBusinessException {
		GESPOSTHANDLERLOGGER.entering(JMSUtils.class.getName(),
				"browseMessage", JMSUtils.class.getName(),
				"About to Browse Message  -----------> : ",
				browseMessageRequest);
		String qcfJndi = "";
		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue sourceQueue = null;
		DataObject response = null;

		List<DataObject> responseBOList = new ArrayList();
		Connection con = null;
		Session session = null;
		QueueBrowser queueBrowser = null;

		try {

			if (null != browseMessageRequest) {

				if (browseMessageRequest.isSet("qcfJndi")
						&& (browseMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = browseMessageRequest.getString("qcfJndi");

				if (browseMessageRequest.isSet("queueJndi")
						&& (browseMessageRequest.getString("queueJndi")
								.length() != 0))
					queueJndi = browseMessageRequest.getString("queueJndi");

				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"browseMessage", JMSUtils.class.getName(), " QCF : "
								+ qcfJndi + "  Queue : " + queueJndi);

				Context initCtxt = null;

				initCtxt = new InitialContext();

				qcf = (ConnectionFactory) initCtxt.lookup(qcfJndi);
				con = qcf.createConnection();
				sourceQueue = (Queue) initCtxt.lookup(queueJndi);
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				queueBrowser = session.createBrowser(sourceQueue);

				GESPOSTHANDLERLOGGER
						.logSevere(
								JMSUtils.class.getName(),
								"browseMessage",
								JMSUtils.class.getName(),
								" MQ JMS Objects Created are : Conn Factory , Connection , Queue , Session & Queue Browser");

				Enumeration messageEnum = queueBrowser.getEnumeration();

				int numMsgs = 1;
				if (!messageEnum.hasMoreElements()) {
					GESPOSTHANDLERLOGGER.logSevere(JMSUtils.class.getName(),
							"browseMessage", JMSUtils.class.getName(),
							" NO Messages Exist in Queue");

				} else {
					while (messageEnum.hasMoreElements()) {

						Message textMessage = (Message) messageEnum
								.nextElement();
						if (textMessage instanceof TextMessage) {

							String jmsMsg = ((TextMessage) textMessage)
									.getText();

							DataObject boFromQueue = InspectMessageType
									.getBOFromXML(jmsMsg);// getBO

							if (null != boFromQueue) {
								GESPOSTHANDLERLOGGER.logSevere(JMSUtils.class
										.getName(), "browseMessage",
										JMSUtils.class.getName(),
										" Message No : {" + numMsgs + "}"
												+ "  \n ", boFromQueue);

								numMsgs++;
								responseBOList.add(boFromQueue);
							}
						}

					}

				}

				session.close();
				queueBrowser.close();
				con.close();
			}
		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);

		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		}

		response = bof.create("http://aig.us.com/jms/common/bo",
				"BrowseMessageResponse");
		GESPOSTHANDLERLOGGER.logSevere(JMSUtils.class.getName(),
				"browseMessage", JMSUtils.class.getName(),
				" Queue Contents List  : "
						+ Arrays.toString(responseBOList.toArray()));
		response.setList(0, responseBOList);
		GESPOSTHANDLERLOGGER.logSevere(JMSUtils.class.getName(),
				"browseMessage", JMSUtils.class.getName(),
				" All Messages Browsed from Queue : ", response);

		return response;
	}

	public String putMessage(DataObject aPutMessageRequest)
			throws ServiceBusinessException {

		String response = "Message Posted to Queue : ";

		GESPOSTHANDLERLOGGER.logSevere(JMSUtils.class.getName(), "putMessage",
				JMSUtils.class.getName(), " About to Put Message to MQ");

		String qcfJndi = "";
		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue queue = null;

		Context ctxt = getInitialContext();

		try {
			if (null != aPutMessageRequest) {

				if (aPutMessageRequest.isSet("qcfJndi")
						&& (aPutMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = aPutMessageRequest.getString("qcfJndi");

				if (aPutMessageRequest.isSet("queueJndi")
						&& (aPutMessageRequest.getString("queueJndi").length() != 0))
					queueJndi = aPutMessageRequest.getString("queueJndi");

				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(), " QCF : "
								+ qcfJndi + " Queue : " + queueJndi);
				String message = getStringFromBO(aPutMessageRequest
						.getDataObject("message"));

				qcf = (ConnectionFactory) ctxt.lookup(qcfJndi);
				queue = (Queue) ctxt.lookup(queueJndi);
				Connection con = qcf.createConnection();

				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(),
						" MQ JMS Object QCF , Queue & Connection Obtained");
				Session session = con.createSession(false,
						Session.AUTO_ACKNOWLEDGE);
				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(),
						" MQ JMS Object Session Obtained");
				MessageProducer producer = session.createProducer(queue);
				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(),
						" MQ JMS Object MessageProducer Created  ");
				TextMessage producerMessage = session
						.createTextMessage(message);
				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(),
						" MQ JMS Text Message About to be Sent : {" + message
								+ "}");
				producer.send(producerMessage);
				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(),
						" MQ JMS Text Message Sent ");
				producer.close();
				session.close();
				con.close();
				GESPOSTHANDLERLOGGER.exiting(JMSUtils.class.getName(),
						"putMessage", JMSUtils.class.getName(),
						" Message Sent and All handles Closed");
				response = response + queueJndi;
				session.close();
				con.close();
			}
		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);
		}
		return response;
	}

	private String getStringFromBO(DataObject aObject) {

		String xmlStringBO = "";
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try {
			BOXML.writeDataObject(aObject, aObject.getType().getURI(), aObject
					.getType().getName(), outputStream);
			xmlStringBO = outputStream.toString("UTF-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return xmlStringBO;

	}

	private Context getInitialContext() {

		Context initCtxt = null;
		try {
			initCtxt = new InitialContext();

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return initCtxt;

	}

	public static DataObject readMessage(DataObject browseMessageRequest)
			throws ServiceBusinessException {
		boolean messageExists = true;
		GESPOSTHANDLERLOGGER.entering(JMSUtils.class.getName(), "readMessage",
				JMSUtils.class.getName(),
				"About to Read Message  -----------> : ", browseMessageRequest);
		String qcfJndi = "";

		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue sourceQueue = null;
		DataObject response = null;

		List<DataObject> responseBOList = new ArrayList();
		Connection con = null;
		Session session = null;
		MessageConsumer queueConsumer = null;

		try {

			if (null != browseMessageRequest) {

				if (browseMessageRequest.isSet("qcfJndi")
						&& (browseMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = browseMessageRequest.getString("qcfJndi");

				if (browseMessageRequest.isSet("queueJndi")
						&& (browseMessageRequest.getString("queueJndi")
								.length() != 0))
					queueJndi = browseMessageRequest.getString("queueJndi");

				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"readMessage", JMSUtils.class.getName(), " QCF : "
								+ qcfJndi + "  Queue : " + queueJndi);

				Context initCtxt = null;

				initCtxt = new InitialContext();

				qcf = (ConnectionFactory) initCtxt.lookup(qcfJndi);
				con = qcf.createConnection();
				sourceQueue = (Queue) initCtxt.lookup(queueJndi);
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				queueConsumer = session.createConsumer(sourceQueue);

				GESPOSTHANDLERLOGGER
						.logInfo(
								JMSUtils.class.getName(),
								"readMessage",
								JMSUtils.class.getName(),
								" MQ JMS Objects Created are : Conn Factory , Connection , Queue , Session & Queue Consumer");
				int numMsgs = 0;

				while (messageExists) {
					con.start();
					Message m = queueConsumer.receive(10L);
					if (m != null) {
						GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
								"readMessage", JMSUtils.class.getName(),
								" Message Exists ");
						if (m instanceof TextMessage) {

							try {
								TextMessage jmsTextMsg = (TextMessage) m;

								String jmsMsg = jmsTextMsg.getText();

								DataObject boFromQueue = InspectMessageType
										.getBOFromXML(jmsMsg);// getBO
								GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class
										.getName(), "readMessage",
										JMSUtils.class.getName(),
										" Message No : {" + numMsgs + 1 + "}"
												+ "  \n ", boFromQueue);

								numMsgs++;
								responseBOList.add(boFromQueue);
							} catch (Exception e) {
								// e.printStackTrace(); just break the loop,
								// once array index out of bounds
								break;
							}
						} else {
							break;
						}
					} else {
						break;
					}
				}// while end
			}
			session.close();
			con.close();

		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);
		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		}

		response = bof.create("http://aig.us.com/jms/common/bo",
				"BrowseMessageResponse");
		response.setList(0, responseBOList);
		GESPOSTHANDLERLOGGER.exiting(JMSUtils.class.getName(), "browseMessage",
				JMSUtils.class.getName(), " All Messages read from Queue : ",
				response);

		return response;
	}

	public static String deleteMessage(DataObject browseMessageRequest)
			throws ServiceBusinessException {

		GESPOSTHANDLERLOGGER.entering(JMSUtils.class.getName(),
				"deleteMessage", JMSUtils.class.getName(),
				"About to Read Message  -----------> : ", browseMessageRequest);
		String qcfJndi = "";

		String queueJndi = "";

		ConnectionFactory qcf = null;
		Queue sourceQueue = null;
		String response = null;

		Connection con = null;
		Session session = null;
		MessageConsumer queueConsumer = null;

		try {

			if (null != browseMessageRequest) {

				if (browseMessageRequest.isSet("qcfJndi")
						&& (browseMessageRequest.getString("qcfJndi").length() != 0))
					qcfJndi = browseMessageRequest.getString("qcfJndi");

				if (browseMessageRequest.isSet("queueJndi")
						&& (browseMessageRequest.getString("queueJndi")
								.length() != 0))
					queueJndi = browseMessageRequest.getString("queueJndi");

				GESPOSTHANDLERLOGGER.logInfo(JMSUtils.class.getName(),
						"readMessage", JMSUtils.class.getName(), " QCF : "
								+ qcfJndi + "  Queue : " + queueJndi);

				Context initCtxt = null;

				initCtxt = new InitialContext();

				qcf = (ConnectionFactory) initCtxt.lookup(qcfJndi);
				con = qcf.createConnection();
				sourceQueue = (Queue) initCtxt.lookup(queueJndi);
				session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);

				queueConsumer = session.createConsumer(sourceQueue);

				GESPOSTHANDLERLOGGER
						.logInfo(
								JMSUtils.class.getName(),
								"readMessage",
								JMSUtils.class.getName(),
								" MQ JMS Objects Created are : Conn Factory , Connection , Queue , Session & Queue Consumer");

				Message jmsMessage = null;
				do {
					jmsMessage = queueConsumer.receiveNoWait();

					while (null != jmsMessage) {
						jmsMessage.acknowledge();
					}
				} while (null != jmsMessage);

				queueConsumer.close();
				con.close();
				response = "All Messages deleted from requested Queue";
			}
		} catch (JMSException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", e.getErrorCode());
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getLinkedException()
					.getLocalizedMessage());
			throw new ServiceBusinessException(gesFaultObject);
		} catch (NamingException e) {
			e.printStackTrace();
			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", "NAMING EXCEP");
			gesFaultObject.setString("faultString", e.getMessage());
			gesFaultObject.setString("faultDetail", e.getExplanation());
			throw new ServiceBusinessException(gesFaultObject);
		}

		GESPOSTHANDLERLOGGER.exiting(JMSUtils.class.getName(), "browseMessage",
				JMSUtils.class.getName(), " All Messages read from Queue : "
						+ response);

		return response;
	}

	public DataObject updateEndpoint(DataObject updateEndpointRequest)
			throws com.ibm.websphere.sca.ServiceBusinessException, Exception {

		GESPOSTHANDLERLOGGER.logCategory(LogCategory.EPR, CLASSNAME,
				"updateEndpoint", CLASSNAMESHORT, "Update Endpoint Request",
				updateEndpointRequest, Level.INFO);
		BOFactory bof = (BOFactory) ServiceManager.INSTANCE
				.locateService("com/ibm/websphere/bo/BOFactory");

		DataObject GESEndpointResponseBO = bof.create(
				"http://GES_Lib_Common/bo", "GESEndpointRequest");
		DataObject GESEndpointResponses = bof.create(
				"http://GES_Lib_Common/bo", "GESEndpointResponse");
		if (null == updateEndpointRequest.getString("moduleName")
				&& (updateEndpointRequest.getString("moduleName").isEmpty())) {

			DataObject gesFaultObject = bof.create(
					"http://aig.us.com/ges/common/v3", "GesFaultObjectType");
			gesFaultObject.setString("faultCode", CLASSNAMESHORT);
			gesFaultObject
					.setString(
							"faultString",
							"Modeule name is Mandatory, please provide valid Modeule Name. World has changed post GES2.1");
			throw new ServiceBusinessException(gesFaultObject);

		}
		GESEndpointResponseBO.setString("moduleName", updateEndpointRequest
				.getString("moduleName"));
		GESEndpointResponseBO.setString("partnerName", updateEndpointRequest
				.getString("partnerName"));
		GESEndpointResponseBO.setString("env", updateEndpointRequest
				.getString("env"));
		GESEndpointResponseBO.setString("version", updateEndpointRequest
				.getString("version"));
		GESEndpointResponseBO.setString("updatedEndpoint",
				updateEndpointRequest.getString("updatedEndpoint"));

		GESEndpointResponseBO.setString("hostName", MetaInfo.getHostName());
		GESLoggerFactory.getLogger().logInfo("COM_GES_MF_ServiceUtils",
				"COM_GES_MF_ServiceUtils", "COM_GES_MF_ServiceUtils",
				"Log Input Message", updateEndpointRequest);

		DataObject response = DynamicEndpointUtils
				.updateXMLConfig(updateEndpointRequest);

		try {
			List<DataObject> updateEndpointList = new ArrayList<DataObject>();
			updateEndpointList.add(response);
			GESPOSTHANDLERLOGGER.logCategory(LogCategory.EPR, CLASSNAME,
					"updateEndpoint", CLASSNAMESHORT,
					"Update Endpoint Complete", GESEndpointResponseBO,
					Level.INFO);
			GESEndpointResponses.setList("gesEndpointResponse",
					updateEndpointList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		GESPOSTHANDLERLOGGER.logCategory(LogCategory.EPR, CLASSNAME,
				"updateEndpoint", CLASSNAMESHORT, "Update Endpoint Complete",
				GESEndpointResponses, Level.INFO);

		return GESEndpointResponses;
	}

	@SuppressWarnings("deprecation")
	public DataObject updateCacheValues(DataObject UpdateCacheValues) {

		GESPOSTHANDLERLOGGER.entering(JMSUtils.class.getName(),
				"updateCacheValues", JMSUtils.class.getName(),
				"Update Cache request  : ", UpdateCacheValues);

		DataObject UpdateCacheResponse = null;

		String key = UpdateCacheValues.getString("Key");// $http://GES_Lib_Common/bo$UpdateCacheValues

		String updatedValue = UpdateCacheValues.getString("Value");

		if (StringUtils.isNotBlank(key) && StringUtils.isNotEmpty(key)) {

			UpdateCacheResponse = bof.create("http://GES_Lib_Common/bo",
					"UpdateCacheResponse");
			if ("Properties".equalsIgnoreCase(key)) {

				AuthCredentials auth = new AuthCredentials();
				auth.writeFile(updatedValue);
				auth.setUpAuthCache();

				UpdateCacheResponse.setBoolean("ProcessingStatus", true);

				return UpdateCacheResponse;

			} else {

				Object cacheValue = GESCacheLoader.getValueFromCache(key);

				UpdateCacheResponse.set("ExistingValue", String
						.valueOf(cacheValue));

				if (null != updatedValue) {
					GESCacheLoader.setValueToCache(key, updatedValue);
					UpdateCacheResponse.setString("NewValue",
							(String) GESCacheLoader.getValueFromCache(key));
					UpdateCacheResponse.setBoolean("ProcessingStatus", true);
				} else {
					UpdateCacheResponse.setString("NewValue",
							"DID NOT UPDATE AS NO VALUE WAS PROVIDED");
					UpdateCacheResponse.setBoolean("ProcessingStatus", false);
				}

			}
		}

		return UpdateCacheResponse;

	}

	public DataObject RetrieveCacheValues(DataObject dummyDO) {

		DataObject reteieveCacheValueBO = bof.create(
				"http://GES_Lib_Common/bo", "RetrieveCacheValueResponse");
		reteieveCacheValueBO.setList("WPSCacheValues", GESCacheLoader
				.retrieveCacheValues());

		return reteieveCacheValueBO;

	}

	public DataObject UpdateConfigValues(DataObject UpdateConfigValuesRequest) {

		String typeName = UpdateConfigValuesRequest.getString("TypeName");// $http://GES_Lib_Common/bo$UpdateConfigRequest
		String qName = UpdateConfigValuesRequest.getString("QName");// $http://GES_Lib_Common/bo$UpdateConfigRequest

		DataObject CurrentValues = bof.create("http://GES_Lib_Common/bo",
				"UpdateConfigRequest");
		DataObject UpdatedValues = bof.create("http://GES_Lib_Common/bo",
				"UpdateConfigRequest");
		DataObject UpdateConfigResponseDO = bof.create(
				"http://GES_Lib_Common/bo", "UpdateConfigResponse");

		HashMap ResultProperties = (HashMap) GESCacheLoader
				.getValueFromCache(GESConstantBundle.GES_GATEWAY_CONFIG);
		if (null != ResultProperties && !ResultProperties.isEmpty()) {

			String key = typeName + "_" + qName;

			DataObject RoutingConfigDO = (DataObject) ResultProperties.get(key);// $http://GES_Lib_Common/bo$RoutingConfig

			if (null != RoutingConfigDO) {
				CurrentValues.setString("PartnerName", RoutingConfigDO
						.getString("PartnerName"));
				CurrentValues.setString("MethodName", RoutingConfigDO
						.getString("MethodName"));
				CurrentValues.setString("MessageName", RoutingConfigDO
						.getString("MessageName"));
				CurrentValues.setString("WSDLURI", RoutingConfigDO
						.getString("WSDLUri"));
				UpdateConfigResponseDO.setDataObject("CurrentValues",
						CurrentValues);

				DataObject NewRoutingConfigDO = bof.create(
						"http://GES_Lib_Common/bo", "RoutingConfig");

				NewRoutingConfigDO.setString("MessageName",
						UpdateConfigValuesRequest.getString("MessageName"));
				NewRoutingConfigDO.setString("MethodName",
						UpdateConfigValuesRequest.getString("MethodName"));
				NewRoutingConfigDO.setString("PartnerName",
						UpdateConfigValuesRequest.getString("PartnerName"));
				NewRoutingConfigDO.setString("WSDLUri",
						UpdateConfigValuesRequest.getString("WSDLURI"));
				UpdatedValues.setString("PartnerName",
						UpdateConfigValuesRequest.getString("PartnerName"));

				UpdatedValues.setString("MethodName", UpdateConfigValuesRequest
						.getString("MethodName"));
				UpdatedValues.setString("WSDLURI", UpdateConfigValuesRequest
						.getString("WSDLURI"));
				UpdatedValues.setString("MessageName",
						UpdateConfigValuesRequest.getString("MessageName"));

				UpdatedValues.setString("QName", UpdateConfigValuesRequest
						.getString("QName"));
				ResultProperties.put(key, NewRoutingConfigDO);

				UpdatedValues.setString("TypeName", UpdateConfigValuesRequest
						.getString("TypeName"));

				UpdateConfigResponseDO.setDataObject("UpdatedValues",
						UpdatedValues);
			} else {
				DataObject NewRoutingConfigDO = bof.create(
						"http://GES_Lib_Common/bo", "RoutingConfig");
				NewRoutingConfigDO.setString("MessageName",
						UpdateConfigValuesRequest.getString("MessageName"));
				NewRoutingConfigDO.setString("MethodName",
						UpdateConfigValuesRequest.getString("MethodName"));
				NewRoutingConfigDO.setString("PartnerName",
						UpdateConfigValuesRequest.getString("PartnerName"));
				NewRoutingConfigDO.setString("WSDLUri",
						UpdateConfigValuesRequest.getString("WSDLURI"));
				ResultProperties.put(key, NewRoutingConfigDO);
				UpdatedValues.setString("PartnerName",
						UpdateConfigValuesRequest.getString("PartnerName"));

				UpdatedValues.setString("MethodName", UpdateConfigValuesRequest
						.getString("MethodName"));
				UpdatedValues.setString("WSDLURI", UpdateConfigValuesRequest
						.getString("WSDLURI"));
				UpdatedValues.setString("MessageName",
						UpdateConfigValuesRequest.getString("MessageName"));

				UpdatedValues.setString("QName", UpdateConfigValuesRequest
						.getString("QName"));
				UpdatedValues.setString("TypeName", UpdateConfigValuesRequest
						.getString("TypeName"));
				UpdateConfigResponseDO.setDataObject("UpdatedValues",
						UpdatedValues);

			}

		}
		return UpdateConfigResponseDO;
	}

	public DataObject CleanLogs(DataObject dataObjectIn) {

		DataObject cleanLogsResponse = bof.create("http://GES_Lib_Common/bo",
				"CleanLogsResponse");
		boolean Status = com.us.chartisinsurance.ges.common.utils.CleanLogs
				.cleanLogs(dataObjectIn);
		cleanLogsResponse.setString("ProcessingStatus", String.valueOf(Status));

		return cleanLogsResponse;
	}

	public DataObject updateQueryAccess(DataObject UpdateQueryAccessRequest) {

		DataObject UpdateQueryAccessResponse = bof.create(
				"http://GES_Lib_SchemaV3/schemas/bo",
				"UpdateQueryAccessResponse");

		String Queryname = UpdateQueryAccessRequest.getString("QueryName");// $http://GES_Lib_SchemaV3/schemas/bo$UpdateQueryAccessRequest
		String QueryValue = UpdateQueryAccessRequest.getString("QueryValue");
		DataObject QueryParams = UpdateQueryAccessRequest
				.getDataObject("QueryParams");

		List<String> paramList = QueryParams.getList("QueryParam");
		UpdateQueryAccessResponse.setString("InitialQuery", QueryAccess
				.getQueryValue(Queryname));

		List<String> initialQueryParams = QueryAccess
				.getQueryParamList(Queryname);
		DataObject InitialQueryParam = bof.create(
				"http://GES_Lib_SchemaV3/schemas/bo", "QueryParamType");
		InitialQueryParam.setList("QueryParam", initialQueryParams);
		UpdateQueryAccessResponse.setDataObject("InitialQueryParams",
				InitialQueryParam);

		if (!paramList.isEmpty() && null != QueryValue) {
			QueryAccess.updateQuerybyName(Queryname, QueryValue, paramList);
		}

		List<String> UpdatedQueryParams = QueryAccess
				.getQueryParamList(Queryname);
		UpdateQueryAccessResponse.setString("UpdatedlQuery", QueryAccess
				.getQueryValue(Queryname));

		DataObject UpdatedQueryParam = bof.create(
				"http://GES_Lib_SchemaV3/schemas/bo", "QueryParamType");
		UpdatedQueryParam.setList("QueryParam", UpdatedQueryParams);
		UpdateQueryAccessResponse.setDataObject("UpdatedQueryParams",
				UpdatedQueryParam);
		return UpdateQueryAccessResponse;

	}

	public DataObject runQuery(DataObject runQueryRequest) {

		DataObject RunQueryResponseDO = bof.create(
				"http://GES_Lib_SchemaV3/schemas/bo", "RunQueryResponse");

		String customParam = "N";
		String CustomQuery = "";
		if (null != runQueryRequest && runQueryRequest.isSet("SelectClause"))// $http://GES_Lib_SchemaV3/schemas/bo$RunQueryRequest
		{
			String SelectClause = runQueryRequest.getString("SelectClause");

			if (StringUtils.isNotBlank(SelectClause)
					&& StringUtils.isNotEmpty(SelectClause)) {
				customParam = "Y";
				CustomQuery = SelectClause;

			} else {

				RunQueryResponseDO
						.setString("ErrorMessage",
								"Select Query has not been provided , Please check the input");

			}
		} else if (null != runQueryRequest
				&& runQueryRequest.isSet("UpdateClause")) {

			String UpdateClause = runQueryRequest.getString("UpdateClause");

			if (StringUtils.isNotBlank(UpdateClause)
					&& StringUtils.isNotEmpty(UpdateClause)) {
				CustomQuery = UpdateClause;
			} else {

				RunQueryResponseDO
						.setString("ErrorMessage",
								"Update Query has not been provided , Please check the input");

			}

		} else {

			RunQueryResponseDO
					.setString("ErrorMessage",
							"None of Select or Update Query has been provided , Please check the input");

		}

		if (!RunQueryResponseDO.isSet("ErrorMessage")) {

			DataObject GetDataType = bof.create(
					"http://GES_Lib_DataAccess/it/DataAccess", "GetDataType");

			DataObject GetCustomDataType = bof.create(
					"http://aig.us.com/ges/schema/da/DataAccessV1_0",
					"GetCustomDataType");

			DataObject CustomQueryParamType = bof.create(
					"http://aig.us.com/ges/schema/da/DataAccessV1_0",
					"CustomQueryParamType");

			DataObject CustomParamType = bof.create(
					"http://aig.us.com/ges/schema/da/DataAccessV1_0",
					"CustomParamType");

			List<DataObject> CustomParamsList = new ArrayList<DataObject>();
			CustomParamType.setString("CustomParam", customParam);
			CustomParamsList.add(CustomParamType);
			CustomQueryParamType.setList("CustomParams", CustomParamsList);
			CustomQueryParamType.setString("CustomQuery", CustomQuery);

			GetCustomDataType.setDataObject("QueryParam", CustomQueryParamType);
			GetDataType.set("Payload", GetCustomDataType);

			Service scaService = (Service) SM
					.locateService("DataAccessPartner");

			DataObject responseDO = (DataObject) scaService.invoke("getData",
					GetDataType);

			RunQueryResponseDO.set("runQueryResponse", responseDO);
		}
		return RunQueryResponseDO;

	}

	public Object deleteLogs() {

		boolean filesDeleted = false;
		filesDeleted = com.us.chartisinsurance.ges.common.utils.CleanLogs
				.deleteFiles("");
		return String.valueOf(filesDeleted);

	}

	public Object deleteAllLogs() {

		boolean filesDeleted = false;
		filesDeleted = com.us.chartisinsurance.ges.common.utils.CleanLogs
				.deleteFiles("All");
		return String.valueOf(filesDeleted);

	}

	public Object archiveLogs() {

		String zipFileName = MatchLogMonitor.archiveLogs();

		return zipFileName;

	}

	public Object loadCache() {

		String response = " Cache Loading Initiated , Please verify Server logs to check for Job completion";
		WorkManager gesWM = GESWorkManagerService.locateWMService();
		try {
			gesWM.startWork(new GESLookupThread(
					QueryAccessBundle.GetSetUpCacheConfig,
					LookUpKeysI.LOOKUPCONFIG, true));
		} catch (WorkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response = "CacheLoading Failed : " + e.getMessage();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response = "CacheLoading Failed : " + e.getMessage();
		}
		return response;

	}

	public Object runTasks() {

		AsyncTaskExecutorImpl.AsyncTaskExecutor.runTask("generic");

		return "Tasks Executed . Check Log For Details ";

	}
}
